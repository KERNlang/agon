# Activation artifact retention

Status: building. Standing remediation goal authorizes implementation and tests.
Date: 2026-10-11. Base ddf4b761978a56f4a8f7ad8b3959e2759b88495c.
No push, install, dependency or personal/global state changes.

## Verified gap and required behavior

The runtime contract requires complete immutable generations with migration
outputs and retained rollback state. DurableModHost.commitGeneration accepts
and hashes arbitrary contained extra files. First-party enablement copies only
installation.json, so its next generation loses other committed artifacts.
Source: first-party-activation.ts artifact builder; durable-host.ts generation
file writer/validator. This blocks durable config migration integration.

Preserve verified non-reserved generation files byte-for-byte when only
selection changes. Regenerate lock, desired state, installed index and generation
manifest through their existing owners. Read only declared, verified files;
never copy arbitrary siblings or execute retained assets. Preserve installation
lineage, disabled-owner data and current selected-lock validation.

## Scope

Two authored files: first-party-activation.ts and the existing activation matrix
test. Three build-generated release files. Moderate state-retention risk. No new
public API or dependency. Existing green base: full repository gate with 8,559
tests, six skipped and live configuration probes.

Acceptance: failing test before fix; exact JSON and non-UTF8 binary retention
through disable/re-enable; distinct desired/lock regeneration; original source
bytes remain unchanged; rollback then re-entry retains artifacts; corrupt or
missing declared artifact refuses activation without changing selected pointer.
One isolated default Agon review, full gates and built-host filesystem probe.

This does not claim config readers, ordinary writes or migration execution are
integrated. Those remain original unfinished requirements.

## Re-entry defect found by the required test

The original test failed for missing settings/snapshot.json before the fix
(`activation-artifacts-red`, log SHA-256
`b09ad279f79def2bea10807c7655101b566eff261133b5309b57d14e3f4efb45`).
After artifact retention, rollback followed by apply failed because host chose
selected generation + 1, colliding with retained generation 2. This is an actual
original rollback/re-entry requirement, not a speculative case. Red receipt:
`activation-reentry-red`, SHA-256
`a2845b40e6aa8049c0deecc722876feaec94d7449ad3cc856c17f84cb6706af2`.

Expanded footprint to four authored files: durable-host.ts generation allocation
and existing modular-rollback.test.ts join the original two. Under the existing
writer fence, allocate above every retained canonical generation number, including
incomplete entries. Keep expected-base conflict checks bound to selected generation.
Do not delete old generations to make re-entry succeed. Public contracts unchanged.

Focused host/failure/receipt/rollback/matrix suites and types passed:
`activation-artifacts-focused`, SHA-256
`0fa6bfd26cce1307e41e1b52ccec76057141cb1b82fb4e82afa47ee88aad754a`.
Additional tests preserve the old missing-installation-descriptor refusal and
prove missing/corrupt retained artifacts refuse apply without changing selection.

## Independent review and corrections

Frozen tree e80f959ed31b1ace88791fff9d7a34142f1156d8. Default Agon packet
SHA-256 5393d37eeb80435c11eeacd6b88dc49ac7aedc9ab6ea75671acf5e4219e28841.
Codex returned findings (log 7d09ee55e14e8311902dc4f9574e74dcf8f80c4d718c4c88ddbc0e0a63a69abc).
Kimi exit 1/no review, not counted as a pass. No login repair.

Verified both the copy-read mutation finding and the existing A-to-B-to-A plan
race with failing tests: activation-review-red log
09cf4459bd52823e80405fc8619be8a4a4ebe5483d4502ea6680e207ae286875.
Read each artifact into one buffer, verify its manifest hash, pass that exact
buffer onward. This also covers lock/index parsing, not just extra files.
Host commit now optionally compares the full expected pointer hash under its
writer fence. Both activation and managed lifecycle forward their existing
preview hash; expected generation and all legacy callers remain compatible.
This prevents a rollback returning to the same numeric generation from making
an obsolete approval current again.

Scope now seven authored files (adds activation-service.ts, managed-lifecycle.ts
and its existing concurrency test), plus three build-generated metadata files.
No parallel store, service, dependency, install or new production file.
Expanded controls cover integer exhaustion, copy-read changes for state/lock,
and managed update refusing the same A-to-B-to-A race with prefix cleanup.

Built-host negative control: first attempt failed in the external fixture's
CommonJS resolver against import-only exports, not product evidence. Fixed the
fixture to import the actual built workspace entry. activation-artifacts-old-
binary-v2 then failed for missing generation-2 migration/source.bin, log hash
0f522e1b8caab261cf094b5dcd53519664dfe9d3034078c25c1b810de669b10a.
The same probe must pass against the rebuilt code before commit.

## Cleanup integration correction

Expanded controls first failed (608f3edbbf9b777b49d4852b8265898c98381ecb8ff2cb52c2e3464e520662e7).
The integer assertion expected the raw TypeError text rather than the existing
host error envelope; corrected to exact typed errors plus unchanged pointer/data.
The managed race exposed an actual remaining base+1 assumption in failed-prefix
cleanup. Reused lifecycle-recovery's retained-installation scanner across cleanup,
recovery and purge. Do not guess one candidate path after generation allocation
changes. Unknown ownership remains fail-closed. This adds an internal export,
not a new package-level public API or parallel scanner.

activation-review-controls-v2 passed all 82 selected tests plus types and API
compatibility, log 0f3d17d3d580dcc7c64208b219b89e6b9a04649180a0591c4ef2dde5be9b9189.
Extended the existing committed-update/recovery test to retain generation 2,
roll back to 1, commit generation 3 with a post-pointer failure, and prove its
installation remains usable after recovery and rollback. Source footprint now
nine existing authored files, three generated release files; no new production
file. Scope growth is due to reproduced transition defects, not new features.

Higher-generation post-commit retention/recovery test passed with the complete
lifecycle fault suite and types: activation-retained-prefix-controls, log
c5863f099f960ac2246de1d47486a0731fb3d5c8889c6a960f309cbec0418f97.
Full activation-artifacts-qualified is now running. It includes performance and
sustained-load gates because generation allocation and commit concurrency changed,
plus the built-host four-generation probe and alias CLI smoke at the end.
Do not edit shipping source while that run is active. No commit yet.

## Qualified and committed

Commit c2b4c115e47277b448705c74409061abff3f62ea; tree
ddfba9292c1609cc075db8989bb3a970644c4655. Twelve explicit paths committed locally.
Qualification worktree clean. Candidate branch/index advanced by compare-and-swap
and read-tree without -u. Candidate working bytes were not rewritten. Before and
after preservation checks passed for the 281 baseline paths, both log hashes
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.

activation-artifacts-qualified passed in 594.339 seconds with zero provider
launches. Log SHA-256:
e8f3cbbdabccc9e65beb4cf1c1f2491f48f65444b274bd1248bd0970c5adf839.
Build, types, lint, reexports, API compatibility, generator drift, release-set,
SBOM and their self-tests passed. Repository: 8,572 passed, six skipped.
All eight release-performance slice budgets passed.

Native darwin-arm64 / Node v26.3.0 sustained-load evidence:

| Phase | Duration ms | Completed fixture jobs | Request p95 ms | Peak daemon RSS bytes | Peak process-tree RSS bytes | Settled RSS growth bytes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Transport | 120038.77 | 30400 | 1.8123 | 175996928 | 175996928 | -442368 |
| Workflow | 120178.38 | 752 | 8.3420 | 176209920 | 926154752 | 3178496 |

These are isolated local fixtures, not paid/live model jobs. Both load phases
passed existing budgets. The built-host filesystem probe preserved non-UTF8
artifacts across four generations, rolled back to generation 1, created a new
generation 4, retained all three prior generations and booted generation 4 after
restart. Five built CLI/Node config checks also passed after the full gate.

Independent review findings were reproduced and corrected locally; failed
receipts remain retained. Kimi unavailable is not a second review pass. This
qualifies the retention/re-entry correction only, not the full release.
Durable config migration/readers, remaining owner retirement and exact clean-
checkout release qualification remain unfinished. No push, install, promotion,
global Agon change or personal-state mutation.

## Exact-commit release diagnostic

Read-only qualification on c2b4c115 remains red, as expected for the unfinished
release. Index and commit source hashes match at
sha256:536e72bfec3774de7a0fd003a9470cb54b73e7f2d5a0bef5841e2f0bb7f60a7b;
no ignored/untracked/unstaged source contamination; 49 packages and 151 unique
edges, zero duplicates. Stored Slice 1B review evidence has a subject mismatch,
and clean-checkout steps were not run. No install was authorized or attempted.
Diagnostic log: 17efd695b4eef08c775a64bd830dd59e65fadd4c323b01645211def951e03de4.
Per-slice readiness also remains red, log
59e159c5e02c685a88da59c5a0fa451721f5ff9c9f31855768584ea45509a548.
These failed acceptance diagnostics are retained, not relabeled as passing
because the component's tests and performance gates passed.
