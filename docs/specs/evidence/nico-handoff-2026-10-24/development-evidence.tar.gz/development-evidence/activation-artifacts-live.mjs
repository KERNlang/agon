import assert from 'node:assert/strict';
import { mkdtemp, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { DurableModHost, createFirstPartyActivationService, createFirstPartyModCatalog,
  createFullCompatDesiredState, resolveDesiredState, sha256Canonical,
} from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const repo = '/Users/ra/dev/agon-audit-qualification';
const catalog = createFirstPartyModCatalog();
const desired = createFullCompatDesiredState(catalog, '2026-10-11T00:00:00.000Z');
const packages = await Promise.all([...resolveDesiredState(catalog, desired).effectivePackages].sort().map(async (id, resolutionOrder) => {
  const definition = catalog.packagesById.get(id);
  const manifest = definition.class === 'user-toggleable-mod-package'
    ? (await import(pathToFileURL(join(repo, 'node_modules', id, 'dist/index.js')).href)).MANIFEST
    : { id, version: '0.0.0-slice.6', dependencies: { required: definition.dependencies.map(id => ({ id })) } };
  const manifestHash = sha256Canonical(manifest);
  return { id: manifest.id, version: manifest.version, source: 'bundled', sourceLocator: id,
    contentHash: manifestHash, manifestHash, platform: `${process.platform}-${process.arch}`,
    enabled: true, resolutionOrder, dependencies: manifest.dependencies.required.map(({ id }) => id).sort(),
    trustRecordId: `bundled:${id}`, grantRecordIds: [] };
}));
const lockFields = { kernelVersion: '1.0.0', apiVersion: '1.0.0', desiredStateHash: sha256Canonical(desired), packages };
const lock = { schemaVersion: 1, ...lockFields, graphHash: sha256Canonical(lockFields) };
const root = await mkdtemp(join(tmpdir(), 'activation-artifacts-live-'));
const host = new DurableModHost(root, { kernelVersion: '1.0.0' });
const bytes = Buffer.from([0, 255, 128, 13, 10]);
await host.commitGeneration({ operation: 'install', lock, desiredState: desired, installedIndex: {}, files: { 'migration/source.bin': bytes } });
const service = createFirstPartyActivationService(host);
const disabled = await service.apply(await service.preview({ kind: 'disable', id: 'agon.forge' }));
assert.deepEqual(await readFile(join(host.generationPath(disabled.pointer.generation), 'migration/source.bin')), bytes);
await service.apply(await service.preview({ kind: 'enable', id: 'agon.forge' }));
await service.rollback(1);
assert.equal((await host.boot()).pointer.generation, 1);
const reentered = await service.apply(await service.preview({ kind: 'disable', id: 'agon.forge' }));
assert.equal(reentered.pointer.generation, 4);
for (const generation of [1, 2, 3, 4]) {
  await host.validateGeneration(generation);
  assert.deepEqual(await readFile(join(host.generationPath(generation), 'migration/source.bin')), bytes);
}
const restarted = new DurableModHost(root, { kernelVersion: '1.0.0' });
assert.equal((await restarted.boot()).pointer.generation, 4);
console.log(JSON.stringify({ passed: true, root, builtHost: true, artifactsByteExact: true,
  rollbackThenNewActivation: true, oldGenerationsRetained: 3, restartSelected: 4, providerWorkflowsExercised: false }));
