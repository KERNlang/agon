# Agent session authority integration

Base commit: `69f3836b16858bc7e4a5924c92e4dd92d707b8d1`.
Worktree: `/Users/ra/dev/agon-audit-qualification`.
Status: partial implementation, unstaged; not independently reviewed or committed.

## Verified changes

The existing candidate session draft adds an optional `executionRefusal` to
AgentSessionConfig and forwards it to the API loop. Adopted those two lines.
The solo CLI handler now forwards its optional callback to AgentSession. Plan's
solo Agent executor supplies a live callback using the existing selected-host,
generation, Plan, Agent and cancellation checks. No new authority owner.

New `agent-session-authority.test.ts` mocks only provider dispatch and runs the
real Core facade, support AgentSession, support API loop and real file-writing
tool. Five cases: healthy, entry refusal, provider-return refusal, approval-time
refusal, and refusal between session turns. Before forwarding: four failed and
healthy passed. After forwarding: all five pass with expected file effects,
provider-call counts, error state and no engine quarantine.

- `agent-session-authority-red`, SHA-256
  `cd7ed6c53716f4a7984cace85ede334612328d72eef258638964a140fec56093`.
- `agent-session-authority-forwarded`, types/support build and four test files,
  SHA-256 `f76dfa557d050b87f70b253c970c417485a5ec3c319f92dbf52fd6621e6d124d`.

Composition checks add live callback identity to existing agent-handler tests
and three real modular-host Plan cases: disable Agent, disable Plan, healthy.
The latter invokes the actual callback from inside the stubbed handler before
and after the host generation changes. Assertions live outside callbacks so
production error handling cannot swallow a failing oracle. Caller step.type is
deliberately `self`, proving authority is attached to the executor, not input.

- `agent-solo-composition-red`: four failed, 132 passed. SHA-256
  `f02cf09051b0072bfe79d66d7d29f3b3633db9f1d37533323202bb8772f57168`.
- `agent-solo-composition-fixed`: types and 155 tests passed in 30.072 seconds.
  SHA-256 `c8b5df440dbf0f213f62229585c671b0a5aaa86a17c67813bda83779dc09c4b1`.
All runs recorded zero provider launches. All handles are terminal.

## Continue this integration, not a release claim

Six local changed paths: support agent-session, CLI agent handler, CLI plan-mode,
existing agent-handler test, existing Plan admission test, new real-session test.
Candidate WIP is untouched. No full review/qualification for this increment yet.

Next: wire team configuration, member sessions, solo fallbacks, synthesis and
fitness effects using the existing candidate draft, with negative controls.
Refactor the Plan callback into one local helper only when the team executor
also consumes it; do not introduce a second policy implementation.
Review and full qualification follow the coherent integration boundary.

Confirmed existing outcome gap, still to repair: Plan solo/team Agent awaits the
handler but ignores its `AgentContinuationResult | null`, then unconditionally
returns step success unless authority throws. Handlers legitimately return null
for missing engines and explicit `failed`, `cancelled`, or `no-winner` outcomes.
Reproduce these through the Plan executor before fixing; update healthy mock
results to the real contract, preserve usage and captured diagnostics. Do not
treat missing/failed work as a completed Plan step.

The shared API/tool foundation has its own committed evidence in
`api-tool-authority-progress.md`. Full modular ownership, remaining adapters,
team/Cesar enforcement, and release qualification remain open under the
unchanged goal. No installation, push, promotion or personal-state changes.

## Plan outcomes and team integration progressed

Plan outcome defect now reproduced and fixed in the same existing executor:
solo/team results must explicitly say `completed`. Missing, failed, cancelled,
budget-exceeded and no-winner results enter the existing failure branch, retain
usage/diagnostics, and export no successful context. Both healthy controls pass.
`plan-agent-outcome-red` has ten failures, SHA-256
`73b8664845164e5b17e25e39f500e51017801e38420ec00e670abd4c1794218d`.
Initial fixed run exposed two incomplete old healthy mocks (no status field).
Corrected those mock contracts, not the expected success or production guard.
`plan-agent-outcome-contract` passes, SHA-256
`425fc48fb157c281a7831ea96afd80a9523c5644a37c723a3564dd04685485b1`.

Team owner now checks authority at initialization, before worktree cleanup/create,
session construction and member execution; each member receives the same live
callback. Failed initialization cancels constructed sessions before cleanup.
Thrown authority checks refuse with a generic diagnostic. The existing candidate
semaphore-validation change was NOT copied; it is a separate unverified change.

New real AgentTeam tests use an isolated local Git repository, real sessions and
real tool registry, with only provider dispatch stubbed. Entry, step, provider,
approval and healthy cases fail four/pass one before forwarding and pass after.
Approval target was changed to an explicit workspace escape inside the disposable
fixture so approval is definitely required; the corrected pre-fix red run is
`agent-team-authority-approval-red`, SHA-256
`fd5205e0661a687c223fc2924f3192dfd2d9e0971aa30e7ee5af798b9fccb033`.
`agent-team-authority-fixed` passes 20 tests, SHA-256
`7c544e25f65b90694e4ef9a8c5dc43b05b7124738927a933645014030c0483e4`.
An existing count defect was corrected: failed AgentStepResults counted as team
successes merely because they were present. Only `stopReason: completed` counts
as success now; an additional 401-provider-error case pins this independently.

Plan team callback, CLI team config and both team-to-solo fallbacks are now wired.
Plan uses one local callback builder over its existing owner assertion. Negative
controls reproduced the missing callbacks; `agent-team-composition-red`, SHA-256
`a4673d17511d4cfd291c881e800cf45dd32d91dcc4ebcaf26c518f56943d089b`.
`agent-team-composition-fixed` passed types and five test files (32.164 seconds),
SHA-256 `38e9fee29fb9b85b86d71fbb3f28541a10b255cd64d67f3781487602f05d0ccd`.
Zero provider launches on all runs. All handles are terminal.

Still not ready to commit this integration: team handler post-return effects,
synthesis calls and fitness commands need the same authority. Existing candidate
`agent-synthesis.ts` and `agent-synthesis.test.ts` contain a small forwarding and
fitness guard draft to verify/reuse. CLI draft has post-initialize/post-team,
fitness, synthesis-log and patch-publication checks. Do not copy its unrelated
fitness timeout change without proving units and a regression control.
Strengthen real team tests to assert the refusal reason and approval invocation,
then add handler-composition evidence for real two-member team config, not just
fallbacks. Independent review and full/native qualification still required.

## Synthesis, fitness and handler effects implemented

The existing synthesis draft forwards the same hook to edit/investigate loops.
Fitness checks now refuse before spawning and after settlement, with cancellation
and sanitized thrown-hook failure. `agent-synthesis-authority-red` reproduced
missing guards/forwarding, SHA-256
`d537999e98604bc8532f41ea6cac2fac40b51d7b1b24651842aca9d5bea70ed9`.
`agent-synthesis-authority-fixed` passed, SHA-256
`e43cfba4f30b323325b1176dda86aad5de48b0de644e45f2218fe0496491dc21`.

New team-handler tests isolate backend calls but use real log/patch writes under
a unique disposable directory. They cover entry, initialize return, team return,
first fitness, edit/investigate synthesis return, post-synthesis fitness return,
and healthy controls. Assertions include exact later-effect traces, cleanup,
absent unauthorized files/publication, and callback identity. All 12 initially
failed (ten incorrect completions and two missing callback identities), then
passed after existing-handler guards and forwarding. Red SHA-256
`0cf3ab575ccd5b48aa77fd9d7225286f6121c5e4cf74c1bc1778ce134c90e33d`;
fixed SHA-256 `bd098fdb198ea90c2be9c72a35ae8f4e76f11cfb82f696001a184ea9e067041a`.

Fitness timeout verified independently: process owner passes timeout straight
to setTimeout in milliseconds. Team passed 60. Two real local Node commands
which write a marker after 150ms both exited 124 before the fix. With 60,000ms,
both exit zero and marker exists. This justifies the candidate timeout correction,
not a speculative units change. `agent-team-fitness-timeout-red` SHA-256
`001be83aef1be5f4a297c0d462bd42b9bb131b375b00f6895e21c36474705beb`;
fixed SHA-256 `50c9645b6f6b0ba097268619bbabcd1a0208c878cef4c3d3ebbf69123fadb90c`.
Real team tests now assert authority reasons and actual approval invocation.

The first combined gate stopped correctly on a stale source-hash ledger.
Ran the existing generator, then verified drift. Ledger diff changes hashes,
not assignments or owner counts. `agent-session-integration-focused-ledger`
passes types, drift and 240 tests; SHA-256
`bc45d774773d05ec3952732fcc5d23143402615405bda73ed3bc67f47921f150`.
All verification runs recorded zero provider launches.

## Frozen review/qualification now running

Staged tree `165fe4da8adca1d68dec2da4194f23ac0b851796`, 12 explicit paths,
base `69f3836b16858bc7e4a5924c92e4dd92d707b8d1`. No unstaged source diff.

- Codex review `agent-session-integration`: terminal handle **58171**.
- Kimi same source packet: terminal handle **51601**.
- Full gate `agent-session-integration-qualified`: terminal handle **80022**.

These are running handles, not terminal outcomes. Poll them; never restart just
because an observation times out. Leave the frozen subject unchanged until gate
completion. Reviews use the existing isolated Agon wrapper and default roster.
Verify each claim against source before changing code. No new panel after local
review corrections; rerun the relevant verification instead.
Full gate includes build/types/lint/re-export/drift/roadmap/full repository tests,
21 compiled CLI checks and final real session/team/handler tests. Do not commit
until green and locally actionable review findings are resolved. The whole
modular release still lacks remaining ownership, Cesar and final qualification.

## Codex review returned; corrections pending

Handle 58171 is terminal exit zero. Packet SHA-256
`c780d13b8e14c903daf46be8062f8378273aa39c495591e885ac3d0ac42ff844`, review log
SHA-256 `93246fb1684790ce7d56dd21340f6682c92ae0f4c030004368bb6c2e83a2502f`.
Kimi 51601 and full gate 80022 still live at last poll. Do not edit the frozen
subject while qualification runs. A green gate cannot resolve these findings.

Source-confirmed gaps, require reproductions and fixes before acceptance:

1. Team continuity loading precedes the entry assertion, and the outer failure
   catch appends/saves a summary even after refusal. Current tests disable
   continuity. Move admission before continuity effects; distinguish permitted
   cleanup/diagnostics from starting normal conversation persistence after denial.
2. AgentSession forwards the hook but does not check it after awaiting its API
   loop or shared-thread save. The final save is followed by state=idle/completed
   unless cancelled. Add deferred-save and noncooperative-return tests, preserve
   incurred usage, refuse success and subsequent persistence when stale.
3. Team guards after started work throw into a generic failure catch without
   closing started member streams/team lifecycle. Late abort in fitness/synthesis
   becomes failed, not cancelled. Correct tests: forbid winner/patch/success, not
   all team-complete events; a failure/cancel completion with null winner is
   necessary. Preserve usage and cleanup, balance all started streams exactly
   once, and test real process cancellation plus synthesis/refit cancellation.

Other essential controls requested: isolated real Git worktree cleanup after
initialization-time revocation, empty/throwing hooks at new guards, mixed member
outcome counts. Verify reviewer claims locally. Inherited prompt-only failure
accounting, approximate synthesis cost and standalone result.cancelled semantics
were explicitly distinguished from this diff; do not silently claim them fixed.
The review accepted the direction of explicit Plan outcomes, completed-only team
counts, fallback forwarding and timeout correction, but is not a release verdict.

## Review corrections: session and team continuity

The frozen integration qualification finished successfully (292.015 seconds,
zero provider launches), log SHA-256
`f7fcae4e71a4635f388f19bae7e169689828a9c8354cd1cb6673a34e0d582660`.
This qualifies the previous staged tree only, not the review fixes below.
Both reviewers finished. Kimi review log SHA-256:
`12c62424109e82878802d268d9e31e85ba6cd667db024a85aed49e7352f53425`.

Four session defects reproduced before correction: entry refusal still loaded
history, authority loss on loop return still saved history, loss during a save
still returned completed, and cancellation after refusal still saved history.
Red receipt: `agent-session-persistence-review-red.receipt.json` (4 failed,
6 passed), log SHA-256
`604e839d931848c1fe00e43dbf616f1408be1ed904fe3610c8dc657bd37e6bd8`.

The existing session owner now checks entry, post-loop and post-save authority.
It retains incurred usage while refusing new persistence and success. Cancellation
still aborts after refusal but does not start a thread flush. History callbacks
also refuse new entries after revocation. Empty-string refusal remains a refusal;
thrown checks produce a generic error without leaking exception details.
The save-return control uses an explicitly suspended save, revokes authority,
then releases the save. It proves no false success after an admitted save; it
does not claim that an already-started save can be undone.
Receipt `agent-session-persistence-controls.receipt.json`: 32 tests and typecheck
pass; log SHA-256
`5ea19ce7d97698138fff4439ec82359a1da4b2bbfd8c19a9309396f03a0ab540`.

Three team continuity defects reproduced: entry refusal still loaded and wrote
continuity, initialization refusal wrote a failure summary, and step refusal
wrote a failure summary. Healthy continuity passed. Red receipt
`agent-team-continuity-review-red.receipt.json`: 3 failed, 14 passed; log SHA-256
`0b6281b1c41ebef73f9b1dccd167143d32537e1bf7b1f4044609773ff4c859a8`.
Continuity loading now follows admission inside the existing team try/finally;
the failure-summary write also requires admission. Cleanup remains unchanged.
Receipt `agent-team-continuity-review-fixed.receipt.json`: 50 tests plus typecheck
pass, zero provider launches; log SHA-256
`24e3c3894ffc27807a8c23fa2cddaeda5ea05152ae5fb25de59e546cd5300e51`.

These corrections are unstaged over the reviewed staged integration. No commit
or candidate-branch advance yet. Regenerate the existing source-hash ledger only
after the remaining handler changes; rerun full qualification before committing.

Still open in this batch: solo-handler continuity/admission, team final-save
publication ordering, balanced terminal events and cancellation classification,
incurred synthesis usage on refusal, real isolated-worktree cleanup, and mixed
member outcomes. Do not count a failure completion with null winner as forbidden
success. The old handler test still needs that assertion corrected alongside the
terminal-event implementation and negative controls. No second review panel is
needed for these reviewer-requested fixes; verify each finding locally.

Kimi's claimed caller-controlled step type is rejected by source: the Plan
executor invokes its helper with literal `agent`/`team-agent`, not caller input.
The entry guard is reachable even without an await when a supplied hook already
refuses. Do not remove it. Hook refusal is a boundary check, not process isolation
or an interrupt; abort owns interruption. Localized private-hook duplication is
not grounds for a new public API.

## Review corrections: terminal lifecycle and publication

Seven terminal failures reproduced across refusal/abort during step, fitness,
synthesis and refit. The existing post-step abort control passed. Red receipt
`agent-team-terminal-review-red.receipt.json` (7 failed, 18 passed), log SHA-256
`2706a257c81a25a98ba8668bed8a3e5efee56a435c76ceda3f6f777181cf9dbf`.
The handler now tracks started member steps and uses the common catch to close
remaining steps and streams exactly once. It preserves cancellation, emits a
terminal team event with null winner/patch/analysis, and retains available usage.
The separate post-step cancellation implementation was removed. No new public
API or parallel implementation was added. Corrected tests prohibit success and
winner publication, not legitimate failure/cancel terminal events.

Two publication-order defects reproduced: the first and second continuity save
could revoke authority after the winner had already been published. Red receipt
`agent-team-publication-review-red.receipt.json`, log SHA-256
`558a9118b7e2a803fe20947c80386cc5b56b55e7651a07202abc68b1be2eeba5`.
Winner publication now follows all asynchronous continuity writes and the final
authority check. Patch preparation still precedes summary persistence so the
summary records the actual patch path. A later refusal does not retroactively
erase a patch written while admitted; it prevents winner publication and returns
no available patch. The approved durable archive is unrelated and untouched.
The two save-revocation controls pass, with exactly one null-winner terminal.

Usage regression receipt `agent-team-incurred-usage-red.receipt.json`, log SHA
`3734918d80411e28b574e08cebc547925ad265e70319c492a82b8d47315d94d2`.
Synthesis return facts and the existing response-based cost estimate are now
captured before checking authority. The failure/cancel event retains both member
usage and available synthesis usage. This is not exact billing: failed synthesis
results do not supply the successful response estimate. No invented usage was
added. Removed unreachable synthesis abort-fallback branches after the explicit
abort check; aborted work must not publish a fallback winner.

Latest receipt `agent-team-terminal-live-controls.receipt.json`: 93 focused
tests, typecheck, targeted lint pass; zero provider launches, 4.341 seconds.
Log SHA-256 `3752be39129d2352215c3671902495dc69c5fffb5089b2b2424ff8a2f3df33c4`.
This includes one real fitness-cancellation run with two local subprocesses.
Cancellation is triggered after spawn without sleeps; both return exit 130 and
both PIDs are absent before the handler returns cancelled. Healthy fitness still
runs both real 150ms commands to completion. No provider or active Agon is used.

Remaining in this batch: solo-handler admission/continuity guards; actual
isolated-worktree initialization rollback; mixed member result classification;
final regenerated ledger, full qualification and preservation checks. No commit
yet. All modifications remain in the qualification worktree, with the previous
staged subject unchanged and these review corrections unstaged. The original
full modular roadmap remains active, not replaced by this integration batch.

## Solo admission and real rollback checks

Three solo-handler failures reproduced (entry, step return, continuity save).
Red receipt `agent-solo-continuity-review-red.receipt.json`, log SHA-256
`d9d00f7dada37d99c4171f9941676617b103674b7f6fd8d62f8870e37ff54e98`.
Solo admission now precedes continuity loading and session construction. The
handler rechecks noncooperative step results before closing the step, gates
summary writes, and checks again before publication. Cancellation remains
cancelled in the catch. The fallback callback-identity test now uses an admitted
hook; refusal correctly prevents constructing a session at all. New refusal
tests independently prove the early boundary and unchanged healthy continuity.
Green receipt `agent-solo-continuity-review-fixed.receipt.json`, log SHA-256
`1c708ca31cd3bf95c9dd8a1473b5911de961f8f5253cb272abe2527680bf02ee`.

Two real Git rollback runs use isolate=true. Authority is revoked by observing
actual worktree paths after one or two creations, not by counting hook calls.
Both initialization attempts reject, both restore the exact prior Git worktree
registration output, and all observed created directories are absent afterward.
No provider call runs. A mixed-result control gives one completed, one error,
one cancelled, one budget-exceeded and one thrown member: succeeded=1, failed=4.
Receipt `agent-team-real-rollback-controls.receipt.json`: 62 tests and typecheck
pass; log SHA-256
`fc67163eaaa31afb38261955217d310f8a866a9985c113e10a69b2ad93ff0a3c`.
Additional core-team entry controls cover empty and throwing hooks without any
worktree creation. Full integration-focused checks are running under receipt ID
`agent-integration-review-corrections-focused`; poll before freezing the subject.

Focused checks finished green in 29.01 seconds, zero provider launches, log SHA
`7ca10c5951d629f6c32ad4d85832f8104b04a3665ff9c111f90ca71940879cf1`.
The 12-path integration is now staged as tree
`9f00bb26b977db2c9561e470f6aeb4dd5cf5f3fb` over HEAD `69f3836b`.
No unstaged source changes. Full gate `agent-integration-reviewed-full` is live
under terminal handle 58069. Do not edit this subject while it runs. It includes
the complete build/types/lint/re-export/first-party/roadmap/tests chain followed
by both compiled Plan native harnesses and the session/team authority controls.
Commit only after it passes and preservation is verified; candidate WIP must
remain byte-for-byte preserved when its branch/index advances.

## Committed qualified integration

Commit `d3bc97278beee5a6ecfdbd078af99a8374b5e7b1`
(`fix(modular): enforce agent workflow authority`) has exact qualified tree
`9f00bb26b977db2c9561e470f6aeb4dd5cf5f3fb`. Qualification checkout is clean.
The full gate finished in 291.75 seconds: 7,718 repository tests passed,
6 skipped, then both compiled CLI/native host harnesses and the focused
session/team authority tests passed. Zero live provider launches.
Receipt: `agent-integration-reviewed-full.receipt.json`; log SHA-256
`49b0b2f0642a24f45405ccf75dba2c7b60a238e78c6269e2e2de9d81a210f32b`.
The command also passed build, typecheck, lint, re-export guard, generated
first-party drift and roadmap checks.

The candidate branch advanced with expected-old update-ref and read-tree without
worktree checkout. Its WIP bytes were not replaced by the qualified source.
Preservation receipt `agent-integration-committed-preserved.receipt.json` repeats
the original 281-path check and unchanged allowlist. The qualification checkout,
not the candidate's ambient WIP, is the accepted source for this increment.
No push, installation, global Agon mutation or personal-state change occurred.

Next batch is traced in `cesar-self-integration-scope.md`. The original full
modular goal is not complete: this commit integrates Agent authority, not the
remaining physical self/Forge/Pipeline/review ownership or final release gates.
