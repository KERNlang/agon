// Adapt the existing candidate mutation check to the qualified checkout.
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { cpSync, mkdirSync, mkdtempSync, readFileSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';

const repo = '/Users/ra/dev/agon-audit-qualification';
const root = mkdtempSync(join(tmpdir(), 'agon-api-authority-mutations-'));
const source = 'packages/support-agent-runtime/src/agent-loop.ts';
const test = 'tests/unit/api-agent-authority.test.ts';
cpSync(join(repo, 'packages/core/src'), join(root, 'packages/core/src'), { recursive: true });
for (const path of [source, test]) {
  mkdirSync(dirname(join(root, path)), { recursive: true });
  cpSync(join(repo, path), join(root, path));
}
const bridge = join(root, 'packages/core/src/api/agent-loop.ts');
writeFileSync(bridge, readFileSync(bridge, 'utf8').replaceAll(
  '@kernlang/agon-support-agent-runtime', '../../../support-agent-runtime/src/agent-loop.js'));
symlinkSync(join(repo, 'node_modules'), join(root, 'node_modules'), 'dir');
writeFileSync(join(root, 'package.json'), '{"type":"module"}\n');
writeFileSync(join(root, 'vitest.config.ts'), 'export default { test: { include: ["tests/unit/*.test.ts"] } };\n');
const original = readFileSync(join(root, source), 'utf8');
const cases = [
  { id: 'baseline' },
  { id: 'tool-authority-dropped', from: '    executionRefusal,', to: '',
    test: 'honors execution authority: during approval' },
  { id: 'provider-authority-dropped', from: '      const refusal = refusedResult();\n      if (refusal) return refusal;', to: '',
    test: 'honors execution authority: before dispatch' },
  { id: 'terminal-authority-dropped', from: '  const finalRefusal = refusedResult();\n  if (finalRefusal) return finalRefusal;', to: '',
    test: 'honors execution authority: last-step approval' },
];
const evidence = [];
let baselineNames;
for (const candidate of cases) {
  if (candidate.from && original.split(candidate.from).length !== 2) throw new Error(`Ambiguous mutation: ${candidate.id}`);
  writeFileSync(join(root, source), candidate.from ? original.replace(candidate.from, candidate.to) : original);
  const report = join(root, `${candidate.id}.json`);
  const result = spawnSync(process.execPath, [join(repo, 'node_modules/vitest/vitest.mjs'), 'run', test,
    '--reporter=json', `--outputFile=${report}`], { cwd: root, env: process.env, encoding: 'utf8', timeout: 60_000 });
  writeFileSync(join(root, `${candidate.id}.log`), `${result.stdout ?? ''}\n${result.stderr ?? ''}`);
  const parsed = JSON.parse(readFileSync(report, 'utf8'));
  const assertions = parsed.testResults.flatMap(file => file.assertionResults);
  const names = assertions.map(item => item.fullName).sort();
  if (candidate.id === 'baseline') baselineNames = names;
  const valid = !result.error && !result.signal && assertions.length === 18
    && JSON.stringify(names) === JSON.stringify(baselineNames)
    && (candidate.id === 'baseline'
      ? result.status === 0 && assertions.every(item => item.status === 'passed')
      : result.status === 1 && assertions.some(item => item.fullName === candidate.test
        && item.status === 'failed' && item.failureMessages.some(message => message.includes('AssertionError'))));
  evidence.push({ id: candidate.id, valid, exitCode: result.status, report,
    reportSha256: createHash('sha256').update(readFileSync(report)).digest('hex') });
  if (!valid) throw new Error(`Mutation qualification failed: ${candidate.id}; ${report}`);
}
const receipt = join(root, 'receipt.json');
writeFileSync(receipt, JSON.stringify({ schemaVersion: 1,
  sourceSha256: createHash('sha256').update(original).digest('hex'), evidence }, null, 2));
console.log(JSON.stringify({ passed: true, killed: cases.length - 1, receipt, evidence }));
