# API/tool execution authority

Base: `8a4f5c544ed9de4baf0387b403a9a2d21ca2e5be`.
Initial review tree: `21706d896f87660ab7a85f35dbd81e1d4913092e`.
Scope: shared API loop and tool registry foundation, not session wiring or release acceptance.

## Review adjudication

Default Agon reviewers Codex and Kimi completed against packet SHA-256
`75787991e7da060c29c02b1dc2393dda4585af1628bdeaeb3453c261e8379bc3`.
Raw results: `api-tool-authority-codex-review.log` and
`api-tool-authority-kimi-review.log`, with adjacent immutable receipts.

Confirmed in source; fix before accepting this increment:

- Registry awaits handler execution, then unconditionally runs post-tool hooks.
  Revocation or cancellation during the tool therefore permits a new hook effect.
  Suppress that effect but preserve the completed tool's actual result.
- API loop checks authority after empty-output handling, too late for permanent
  errors, thrown streams, exhausted retries and history continuation writes.
  Check settled dispatch and exception boundaries before those branches.
- API refusal result omits cancellation. Pin cancellation precedence when both
  happen, and reject a successful provider return after caller cancellation.

Kimi F2 rejected: core API loop is an explicit runtime-injection facade calling
the support package, not another implementation. Tests import that facade;
rebuild the support package before testing changes.
Kimi F3 partly rejected: tool count and toolOutcomes are retained on refusal.
Do not claim it discards the execution ledger. Partial response preservation
is a separate policy concern; refusal must never become a successful result.
Kimi F4 rejected as stated: the reviewer itself confirms the next entry check
prevents another provider call. There is no demonstrated N-round refusal spin.
Kimi F5 rejected as stated: registry initial refusal precedes validation and
authorization, so later serial calls do not run those paths after refusal.
Kimi F6 retained limitation: checks guard boundaries, not interruption of a
noncooperative in-flight operation or an atomic cross-process transaction.

Tests must first reproduce the three confirmed defects. Existing full gate
`api-tool-authority-qualified` is running on the frozen initial subject;
leave it unchanged until terminal. Its pass cannot settle the review defects.
No dependencies, personal state, active installation or candidate WIP changed.

## Review fixes and discriminating evidence

Initial full qualification finished successfully (298.331 seconds), zero provider
launches; log SHA-256 `f793e4847b3676fda64260b50dedb22a0be371d39c453f0ccbfa742e755c9f35`.
It does not settle the review findings.

`api-tool-authority-review-red`: 13 failed, 24 passed. The failing tests exercise
post-tool revocation/cancellation, permanent/thrown/synchronous factory failure,
exhausted transient failure, empty/reasoning-only history writes, and cancellation
before dispatch, at provider return, and during approval. SHA-256
`2849614d8989c8739ee1b910a68e4e62ff01ca467d258eacbbeded3e72686996`.

Fixes remain in existing owners. Registry gates post-hooks without changing the
completed result. API loop checks dispatch completion and thrown dispatch before
classification, including synchronous factory failure. Cancellation wins the
terminal classification while retaining the authority reason when present.
No failed engine/quarantine classification is added for a revoked session.

`api-tool-authority-review-fixed`: types, rebuilt support package, all 37 tests
pass. SHA-256 `8d5a68028d8161ed9bcc7b7687a8a0299bc5642ffc407d9401a4d3406cc95d28`.
Two additional controls pin serial batch result completeness and simultaneous
abort/refusal semantics in the registry. `api-tool-authority-final-focused`:
39 tests plus first-party drift check pass. SHA-256
`40050348e96a619bcd0919a3cc5913c78aab09a76c4fbb296715f5df19519354`.
All these runs recorded zero provider launches.

Final staged tree `7cabca6b9cdeb13218f4bc973c58791d7e70467d`, five explicit paths.
`api-tool-authority-final-qualified` now runs the complete build/types/lint,
re-export, first-party and roadmap gates, full suite, compiled CLI admission
and provider guard checks, then focused authority tests. Do not edit its subject
until it finishes. Session/team/Cesar wiring remains unfinished; this is not a
complete modular release. No second review panel after local corrections.

## Next integration trace (read-only during final qualification)

Qualified source, not candidate intent:

- `packages/cli/src/handlers/plan-mode.ts:680,726` invokes solo/team handlers
  with parentSignal only. It checks owner availability after return but cannot
  currently gate nested API calls and tools while the handler is running.
- `packages/support-agent-runtime/src/agent-session.ts:229` builds inner options
  without executionRefusal. Existing candidate has the needed config member and
  forwarding at this exact owner. Core agent-session remains a runtime facade.
- Candidate `packages/cli/src/handlers/agent.ts` threads solo, team and both solo
  fallbacks; candidate core `cesar/agent-team.ts` threads member sessions and checks
  team lifecycle. These drafts must be verified before transfer, not overwritten.
- Candidate team-handler diff also changes fitness timeout 60 to 60,000 and adds
  signals/fitness authority. Verify the timeout units separately; do not treat
  the whole diff as already qualified authority work.
- Existing agent-session tests mock the whole API loop, and handler tests mock
  AgentSession. Those prove composition only. Add a provider-stubbed real session
  test with actual temporary file effects and initialized-host Plan evidence to
  prove authority survives the entire path.
- The Plan Agent handler ignores its nullable continuation result and then marks
  success. Inspect/reproduce failure/no-engine cases before claiming or fixing a
  defect. Preserve captured usage and output; do not infer completion from return.

Next acceptance should prove pre-call, mid-provider, mid-approval, retry, next
turn and terminal semantics with healthy controls. Disabled Agent, disabled Plan,
generation replacement and cancellation need concrete effects-based checks.

## Mutation evidence

Reused the existing candidate `verify-api-agent-authority-mutations.mjs` approach
in external `api-authority-mutation.mjs`, with the qualified source root and
18-test baseline. It requires identical test names in every mutated run, not
just a nonzero exit. All three targeted mutations were killed: missing tool
context authority, missing pre-provider check, and missing final-step check.
Each must fail its named behavioral assertion. Baseline passes all 18 tests.
`api-tool-authority-mutation` passed in 4.614 seconds with zero provider launches;
SHA-256 `b900a6992d3e025b5b8db507236eaef8c806618719d5d696add3eb1fdcb38e3e`.
Raw JSON reports, stdout/stderr logs and receipt were copied byte-for-byte from
the disposable source tree into `api-authority-mutation-evidence/` beside this
file; all nine copies passed `cmp`. No mutation touched a Git worktree.
The original receipt paths identify the run location; the durable copies use
the same basenames. This evidence supports these three guards only, not all
architecture invariants or all session/team callers.

## Qualified and committed

`api-tool-authority-final-qualified` passed in 290.128 seconds: full build,
types, lint, re-export and drift checks, roadmap, 7,635 repository tests passed
(six skipped), seven compiled CLI/provider checks, 14 compiled admission checks,
and 39 focused authority tests. Zero provider launches. Receipt log SHA-256
`e86c7faac4eb8bc4ba907c5059c3986a88c1119b70f173d37f2e34b9bd3e0fae`.

Local commit `69f3836b16858bc7e4a5924c92e4dd92d707b8d1`, exact qualified tree
`7cabca6b9cdeb13218f4bc973c58791d7e70467d`. Qualification checkout clean.
Candidate branch advanced using expected-old update-ref and index-only
read-tree, never checkout/reset of its future WIP. Candidate files remain
unqualified draft bytes where they differ; the committed subject is authoritative.
Preservation run `api-tool-authority-preserved` verifies the 281-path baseline,
SHA-256 `bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
No push, installation, personal-state change or promotion.

All review and qualification handles for this increment are terminal. Continue
session/team/Plan authority wiring; overall architecture goal remains active.
