# Apply authority test isolation

Subject before repair: `611a6b5927922048b62abacfb3f12aaf27d2d9ce`.
Worktree: `/Users/ra/dev/agon-audit-qualification`.

The clean pressure run with shuffle seed 2719 failed after nine passing gates.
Archive: `pressure-611a6b592-seed2719/`. This is a failed receipt, not release evidence.
The standalone authority test file reproduces the failure with seed 2719:
`modular-apply-shuffle-red.receipt.json`.
The affirmative-prompt test passes when selected alone:
`modular-apply-prompt-isolated.receipt.json`.

Cause: the disable-during-approval test commits a new canonical generation.
The shared beforeAll fixture leaves subsequent tests with a stale process authority.
Production correctly refuses that authority before opening the next interaction.
Fix: each test creates and disposes its own host and Git workspace through
beforeEach/afterEach. No assertions or production guards change.

Seed 2719 now passes both authority and workflow suites (33 tests):
`modular-apply-shuffle-fixed.receipt.json`.
Additional orders 1, 42 and 2026 and type/lint results:
`modular-apply-order-matrix.receipt.json` (inspect terminal receipt before claiming success).

Isolated Codex review: no blocking findings. Source confirms disposal clears
the selected boot/client state before the next test initializes its authority.
Review packet SHA-256: `04ca3815ed84216c9602adff729bef6cc62b0a18dc463e014f163d6bdb2ac40d`.
Review log SHA-256: `13f92ae2b614fa762037b1d4f89562dcc27a26eaa9bd8e1c6a90eae76483cdc6`.
The temporary review authentication copy was absent after completion.

Full development gate passed in 829.139 seconds with zero provider launches:
`modular-apply-isolation-full.receipt.json`. Build, typecheck, full test suite,
lint, re-export guard and diff checks passed. Log SHA-256:
`f9b3b87797ed12868fc87c9ac7468c5d1ba6e9a27552e72318f2c436e281c5d4`.
A clean committed pressure rerun remains required. This is not complete release
acceptance.

Latest operator approval repeats Goal -> mod-forge@1.0.0. That dependency is
already present in packages/mod-goal/package.json. No dependency edit or install
was needed. This is not approval for the separate proposed config-owner edges.
