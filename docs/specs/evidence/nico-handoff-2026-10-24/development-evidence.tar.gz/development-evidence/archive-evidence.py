"""Preserve evidence without changing the repository or its index."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

repo = Path('/Users/ra/dev/agon-audit-remediation')
archive = Path('/Users/ra/dev/modular-agon-evidence-archive/2026-10-10-2b59937b')

def git(*args):
    return subprocess.run(['git', *args], cwd=repo, capture_output=True, check=True).stdout

def sha(data):
    return hashlib.sha256(data).hexdigest()

worktrees = [Path(line[9:]).resolve() for line in git('worktree', 'list', '--porcelain').decode().splitlines() if line.startswith('worktree ')]
if any(archive.resolve().is_relative_to(path) for path in worktrees):
    raise RuntimeError('Archive must be outside every worktree')
if archive.exists():
    raise RuntimeError('Refusing to overwrite an archive')
archive.mkdir(parents=True, mode=0o700)
subject = git('rev-parse', 'HEAD').decode().strip()
records = []
sources = [(path, Path('repository') / path.relative_to(repo))
           for path in sorted((repo / 'docs/specs/evidence').rglob('*')) if path.is_file()]
sources += [(Path('/Users/ra/dev/modular-agon-architecture-audit.md'), Path('audit/modular-agon-architecture-audit.md'))]
audit_logs = Path('/tmp/agon-plan-check-ShdTwz')
if audit_logs.is_dir():
    sources += [(path, Path('audit/raw-logs') / path.name)
                for path in sorted(audit_logs.glob('architecture-audit-*')) if path.is_file()]
for source, relative in sources:
    if source.is_symlink():
        raise RuntimeError(f'Refusing symlink: {source}')
    original = source.read_bytes()
    destination = archive / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    copied = destination.read_bytes()
    if original != copied or source.read_bytes() != original:
        raise RuntimeError(f'Copy verification failed: {source}')
    record = {'source': str(source), 'archivePath': relative.as_posix(),
              'bytes': len(original), 'sha256': sha(original), 'subjectCommit': subject}
    if source.is_relative_to(repo):
        path = source.relative_to(repo).as_posix()
        record['repositoryPath'] = path
        record['lastPathCommit'] = git('log', '-1', '--format=%H', '--', path).decode().strip() or None
        committed = subprocess.run(['git', 'show', f'{subject}:{path}'], cwd=repo, capture_output=True)
        if committed.returncode == 0:
            record['committedSha256'] = sha(committed.stdout)
            record['matchesCommit'] = committed.stdout == original
            if not record['matchesCommit']:
                committed_path = archive / 'committed' / path
                committed_path.parent.mkdir(parents=True, exist_ok=True)
                committed_path.write_bytes(committed.stdout)
                record['committedArchivePath'] = committed_path.relative_to(archive).as_posix()
    records.append(record)

# Retrieve every file into a disposable directory and verify the restored bytes.
with tempfile.TemporaryDirectory(prefix='agon-archive-retrieval-') as temporary:
    for record in records:
        restored = Path(temporary) / record['archivePath']
        restored.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(archive / record['archivePath'], restored)
        if sha(restored.read_bytes()) != record['sha256']:
            raise RuntimeError(f'Retrieval verification failed: {restored}')

manifest = {'schemaVersion': 1, 'subjectCommit': subject, 'archive': str(archive),
            'retention': 'Never delete without Raphael explicit approval.',
            'byteComparison': True, 'retrievalVerified': True, 'files': records}
data = (json.dumps(manifest, indent=2) + '\n').encode()
(archive / 'manifest.json').write_bytes(data)
(archive / 'manifest.sha256').write_text(sha(data) + '  manifest.json\n')
print(json.dumps({'archive': str(archive), 'files': len(records), 'bytes': sum(x['bytes'] for x in records),
                  'manifestSha256': sha(data), 'byteComparison': True, 'retrievalVerified': True,
                  'repositoryFilesRemoved': 0}))
