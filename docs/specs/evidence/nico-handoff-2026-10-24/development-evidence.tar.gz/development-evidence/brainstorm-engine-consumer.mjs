import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';

const root = '/Users/ra/dev/agon-audit-qualification';
const require = createRequire(resolve(root, 'package.json'));
const ts = require('typescript');
const consumer = resolve(root, 'brainstorm-engine-consumer.virtual.mts');
const source = `import { runBrainstorm, runScout } from '@kernlang/agon-forge';
import type { EngineRegistry, EngineAdapter } from '@kernlang/agon-core';
import { createBrainstormEngineServices, createBrainstormRuntime } from '@kernlang/agon-mod-brainstorm';
import type { BrainstormEngineEffects, BrainstormEngineOptions } from '@kernlang/agon-mod-brainstorm';
declare const registry: EngineRegistry;
declare const adapter: EngineAdapter;
declare const effects: BrainstormEngineEffects<EngineRegistry>;
const options = { question: 'question', engines: ['fixture'], registry, adapter, timeout: 80, outputDir: '/fixture' };
const typed: BrainstormEngineOptions<EngineRegistry> = options;
void runBrainstorm(options);
void runScout({ ...options, scoutCount: 1 });
void createBrainstormRuntime(createBrainstormEngineServices(effects)).collectRankedDrafts(typed);
`;
const options = { strict: true, noEmit: true, skipLibCheck: false,
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.NodeNext,
  moduleResolution: ts.ModuleResolutionKind.NodeNext, esModuleInterop: true,
  resolveJsonModule: true, types: ['node'], typeRoots: [resolve(root, 'node_modules/@types')] };
function diagnostics(text) {
  const host = ts.createCompilerHost(options);
  const read = host.readFile.bind(host);
  const exists = host.fileExists.bind(host);
  host.readFile = file => resolve(file) === consumer ? text : read(file);
  host.fileExists = file => resolve(file) === consumer || exists(file);
  return ts.getPreEmitDiagnostics(ts.createProgram([consumer], options, host));
}
const errors = diagnostics(source);
assert.equal(errors.length, 0, ts.formatDiagnosticsWithColorAndContext(errors, {
  getCanonicalFileName: file => file, getCurrentDirectory: () => root, getNewLine: () => '\n',
}));
assert(diagnostics(source.replace('registry, adapter, timeout', 'registry, timeout')).length > 0,
  'Missing required adapter must fail the public consumer');

const { createBrainstormEngineServices } = await import(root + '/packages/mod-brainstorm/dist/index.js');
const engine = { schemaVersion: 3, id: 'fixture', displayName: 'fixture', tier: 'user', isLocal: true, timeout: 1 };
let lookups = 0;
const registry = { get: () => { lookups++; return engine; }, findBinary: () => null };
const oldAdapter = { dispatch: () => { throw new Error('Captured obsolete adapter'); } };
const calls = [];
const adapter = { dispatch: async value => {
  calls.push(value);
  return { stdout: 'fixture answer', stderr: '', exitCode: 0, durationMs: 0, timedOut: false };
} };
const services = createBrainstormEngineServices({
  readRatings: () => ({ global: {}, byMode: {} }), buildPrompt: () => '', parseDraft: () => null,
  seedRegistry() {}, loadConfig: () => ({}), classifyTask: () => 'other', updateRanked() {},
});
const beforeSignal = new AbortController().signal;
const afterSignal = new AbortController().signal;
const request = { question: 'fixture', engines: ['fixture'], registry, adapter: oldAdapter,
  signal: beforeSignal, timeout: 80, outputDir: '/old-output' };
const seat = services.selectSeat(request, 'fixture');
const winner = services.selectWinner(request, 'fixture');
request.registry = { get: () => { throw new Error('Repeated engine lookup'); } };
Object.assign(request, { adapter, signal: afterSignal, timeout: 17, outputDir: '/new-output' });
assert.equal((await seat('seat', 'system')).ok, true);
await winner('winner');
assert.equal(lookups, 2);
assert.equal(calls.length, 2);
for (const call of calls) {
  assert.equal(call.engine, engine);
  assert.equal(call.signal, afterSignal);
  assert.equal(call.timeout, 17);
  assert.equal(call.outputDir, '/new-output');
  assert.equal(call.cwd, process.cwd());
}
console.log(JSON.stringify({ publicDeclarationConsumer: true, missingAdapterRejected: true,
  lateOptionDispatches: calls.length, selectionTimeLookups: lookups,
  note: 'Built workspace packages; not an isolated npm installation' }));
