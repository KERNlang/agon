# Brainstorm engine-bound host ownership

Status: committed and qualified locally under the existing remediation goal. Base 754170e91ecabe68c3bc157b467e4aa4a697593c.
Baseline: metadata-readiness-qualified, full suite/types/lint/build and live probes pass.
Backup: backup/brainstorm-engine-host-754170e9. No installation or push allowed.

## Purpose and scope

Move the remaining seat/winner/preflight/rating binding policy from Forge's
Brainstorm facade into the physical Brainstorm mod. Retain the public Forge
functions and their option types. This is A06 host ownership, not release closure.

Initially six paths: mod host.ts and generated index.ts, first-party generator, Forge
brainstorm.ts, existing host-owner and runtime-owner tests. No package, dependency,
schema, lockfile, copied evidence or native asset change. host.d.ts is already packed.
Use the existing runtime factory and service contract; do not introduce another
workflow engine or route. Core still supplies config/registry/protocol/rating effects.

## Contracts that must remain

The engine-bound API gets registry/adapter from options, captures engine lookup
when selecting a seat/winner, and reads cwd at dispatch time. Preflight retains
the support panel's process-cwd config semantics and the option's signal.
Classification precedes score mapping. The invocation-bound API retains its
different existing cwd/signal and score-map order. Do not unify these differences
by changing behavior or hiding them in parity normalization.

Consumers traced in post-metadata-ownership-check.md: Plan's two callbacks,
legacy CLI command/handler, Conquer, team Brainstorm and Forge public exports.
Risk: changed dispatch args, error/order semantics, scout behavior or declaration
inference. Tests must cover live option identity, delayed cwd, lookup capture,
retry/cancellation, preflight config, rating failures and built package exports.
Existing sixteen raw workflow/scout parity scenarios must remain unchanged.

## Acceptance

Ownership regression red before move; focused behavior/parity tests green after.
Independent mod build and exported consumer types compile. Generator/pack checks,
full repository gates, default isolated Agon review and live final probes pass.
No private Core/Forge import inside the mod. Commit only verified named paths.
Do not mark A06/KL-011 complete while other host/installed parity work remains.

## Implementation and verification in progress

Six paths changed as scoped. host.ts gains createBrainstormEngineServices and
its two public types. Forge now injects the existing effects, without seat,
winner, preflight or rating policy. The same runtime factory remains authoritative.
No additional packed file is needed: host.d.ts was already declared.

Ownership regression failed before the move (`brainstorm-engine-owner-red`),
log SHA-256 c916e036fdd0f768522352d4b425524ee6b73809f86ee2a5ff7db9f4e5420899.
Focused build/types/generator and 29 tests passed in 8.068s, log SHA-256
d2bde55e09f6059b1636f7d1ff21b449439b2c5f348666dfdc9d968ec7956226.
An actual source mutant replacing the engine seat cwd with /wrong-cwd failed
the late-binding test, log SHA-256
23a131695dc0ca112959e348af622cdf0616bca2bfa88e8920149e60a012aa08.
The mutant was restored before staging and the full gate.

Frozen tree: b0f9e65c326282c3364bdbf5eef03e1ff35eb7a3.
Default isolated Agon review packet SHA-256:
70f05032487cea95f5b464ab0b728c0c5e5874115dbe40168e3fe059f8124a33.
Codex found no blocking defect; log SHA-256
02b87f79f9c068608b7d25f0bd1bf1d24d237576de13b48f042903983ca9ccc4.
Kimi returned no answer, exit 1; no authentication repair attempted.

Source-verified review assumptions: Core's EngineAdapter re-exports the exact
support-runtime type; the old health facade only injected loadConfig, and the
support preflight requests process cwd when options.cwd is absent. New binding
preserves both. Old frozen runtime-object identity had no exposed consumer.

Reviewer suggested late option reads and declaration consumers. External probe
brainstorm-engine-consumer.mjs checks both against built packages without editing
the frozen tree or installing anything. A missing required adapter is a negative
compiler control. Results pending; do not count helper existence as evidence.

Existing packed CLI/TUI probes can also run against a temporary launcher symlink
to the built workspace. brainstorm-workspace-surfaces.mjs labels this explicitly
as workspace, not installed-package qualification. It uses existing provider
effect guards and fixture engines. Results pending. No production linkage occurs.

## Review-driven declaration repair

The external consumer found a real built declaration leak:
Forge brainstorm.d.ts referenced `packages/support-panel/src`. Its inferred
rankDrafts signature exposed a private source locator. The repository's path
aliases and skipLibCheck did not detect this. Whether the leak predates this
extraction is not yet proven; it is not waived as inherited.

The first probe also omitted the already-required outputDir field. Corrected the
probe, retained its failed receipt, and reproduced the two TS2307 errors alone.
A tracked compile-only consumer and a test now compile through package roots
without path aliases or skipLibCheck. The first CLI test attempt hit TS5112;
the installed TypeScript requires --ignoreConfig for explicit files. After that
test-setup correction, the tracked test failed specifically on both private imports.
Red test receipt: brainstorm-engine-declaration-test-red-verified,
log SHA-256 5e27ff76c243a7eb36e4cccee5278ddafeb96a5a56c7deb4b70e434f86ba7461.

Forge now gives each retained function an indexed type from the public mod
runtime factory. This removes the private-path inference and preserves function
identity and behavior. No duplicate signature or new public runtime API was added.
The seventh scoped file is tests/fixtures/modular-brainstorm-engine-consumer.mts.

brainstorm-engine-declaration-fixed passed build, 30 tests, the public consumer,
missing-adapter negative control and two late-bound built dispatches in 8.839s.
Log SHA-256 aae05f138cd13f327f57ea9938855db89d99a2dbf35615f49f120b94e6cf693d.
The earlier full gate passed 8416 tests, six skips and performance budgets, but
predates the declaration correction. A final gate on the corrected subject is
still required. No extra review panel after this source-verified correction.

## Final qualified commit

Commit e15c05728b5645849ccdffca4423ada86218efd4.
Tree 98d5d921e64c5399b72e3f152e08d383de9a4629 exactly matches the final staged subject.
`brainstorm-engine-host-final` passed in 346.36s, zero provider launches.
Log SHA-256 fa7cac97f20399a83a3b27b5cee05c555e6da93996a489aa315371982f806352.
Full rebuild, types, lint, re-export/generator checks, 8417 tests (six skips),
performance budgets, strict public declaration consumer and its missing-adapter
control all passed. The built service retained late adapter/timeout/output/signal
reads while capturing the selected engine.

Real CLI and 120x40 PTY checks passed twice (standalone and final full command):
invalid style before dispatch, human/quiet/env-quiet output, retry/failure, early
stdout negative control, persisted status, failed command followed by Escape
cancellation and two successful commands, then exit during active work. Engine
exit and unforced terminal exit were checked. Standalone receipt
brainstorm-workspace-surfaces passed in 28.783s, log SHA-256
f83096cee0f86967b9e346c1fa70b92f9c49ebe4fe1dac775dbd93fcedf13a5c.
These run against built workspace packages through a disposable launcher path,
NOT a fresh installed npm package. Four final session-lifecycle invocations also
passed with completed/aborted/crashed/completed receipts and stopped timers.

Candidate advanced by compare-and-swap and index-only read-tree. Both preservation
checks retained all 281 tracked operator snapshot paths; identical log hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification worktree clean. Seven explicit paths committed, no trailers.
No push, install, active/global Agon or personal-state changes.

## Remaining work, unchanged goal

Core config/effect composition remains injected; public Forge entrypoints remain
compatibility facades. This move removes dispatch policy from Forge, not every
compatibility export. Reconcile ownership ledger claims (file presence is not
runtime ownership), then complete remaining Plan/Brainstorm retirement and final
clean installed-subject qualification. Kimi review, native platform and publishing
cells are not counted as passed. The whole goal remains active.
