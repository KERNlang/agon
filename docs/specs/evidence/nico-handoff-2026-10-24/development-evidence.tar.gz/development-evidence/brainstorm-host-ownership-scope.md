# Brainstorm host binding ownership

Status: preparation under the existing modular goal. No implementation yet.
Verified against 45749f24 plus the staged classifier extraction.

## Source-grounded boundary

Core blocks/brainstorm-host.ts still creates the runtime capability object used
by both CLI and MCP decorators. It owns seat/winner dispatch option assembly,
ranked-rating input mapping and mode selection, plus preflight composition.
The workflow algorithm itself is already owned by mod-brainstorm/runtime.ts.
Forge src/brainstorm.ts has a separate legacy-options binding; do not count it
as retired by repairing the Core binding alone.

Physical effect owners now exist:
- engine registry: support-engine-catalog, through Core's current public facade;
- dispatch types/processes: support-engine-runtime and adapter-cli;
- retry/preflight: support-panel;
- classifier/dedup: support-dedup (classifier extraction gate pending);
- ratings algorithms/storage: mod-ratings;
- logger: kernel;
- prompt builder/parser: existing @kernlang/protocol library;
- loadConfig: still Core-owned host configuration, not claimed extracted.

CLI and MCP do not currently declare direct dependencies on mod-brainstorm or
mod-ratings. Core already declares them. Do not introduce new graph edges merely
to change import spelling. Do not duplicate the existing 50-line composition in
both decorators, or pass a legacy whole-workflow callback into the mod.

## Next implementation candidate

Move Brainstorm-specific binding assembly into mod-brainstorm's existing host
module, using its already-declared support-panel/support-dedup/kernel interfaces.
Inject the host's protocol, ratings, classification and config functions through
a small typed input contract. Reuse existing BrainstormRuntimeServices types and
PanelEngineRegistry; do not invent a manager, global configurator or service locator.

Core's current public two-argument factory can remain a compatibility facade that
supplies effects to this physical owner. Both existing decorators must still reach
the same mod-owned factory. This can retire Core's assembly implementation but
does NOT automatically satisfy a requirement to remove the public facade itself.
Document that distinction and verify it against the original removal condition.
No new dependency or lockfile change is planned.

Before implementation, trace the exact config fields and registry methods needed.
Preserve lazy opening, invocation cwd/signal, no provider work during construction,
prompt text, textOnly flags, timeout/outputDir, preflight behavior, logging,
deduplication and rating-write order. The raw legacy workflow parity tests and
CLI/MCP route tests remain the oracle. Add a meaningful ownership/dispatch-options
control, not only a marker search. Default isolated Agon review must challenge
whether this actually transfers responsibility or only adds forwarding layers.

Expected touched paths: mod-brainstorm/src/host.ts, Core blocks/brainstorm-host.ts,
mod-brainstorm index/manifest generator as required, and existing/new focused
host-boundary tests. Freeze the exact list before editing. Reject the approach if
it makes the public contract larger without retiring actual Core responsibility.

## Still open after this candidate

## Frozen implementation slice

Base f9f59422; prior full gate classifier-owner-final is green (8,404 tests,
build/types/lint/performance). Six paths: Core blocks/brainstorm-host.ts,
mod-brainstorm/src/host.ts and index.ts, first-party package generator, and
tests/unit/modular-brainstorm-host-owner.test.ts plus this external scope note
(five repository paths). New focused tests are authorized by the active goal.
No dependency, lockfile, config, or Forge behavior change. Existing raw parity
tests stay unchanged. The mod owns dispatch assembly and ratings mapping;
Core supplies typed effects through its existing public two-argument facade.
This does not retire the facade or the separate Forge binding. Backup ref:
backup/brainstorm-host-f9f59422. No new generic framework or manager.

Forge's legacy host binding, final config ownership, installed CLI/MCP/TUI parity,
disabled-owner checks, unresolved daemon flake and complete release qualification.
This is not authority to mark A06/A11 complete or to relax acceptance conditions.

## Implementation and checks

Mod host owns assembly. Core retains only effect injection and its public signature.
Five repository paths changed; no dependency/lockfile change. Initial standalone
typecheck saw stale declaration exports. Building the mod exposed generic inference
choosing PanelEngineRegistry for Core's richer registry; explicit EngineRegistry
type parameter fixes that without casts or a weakened boundary. Both failed receipts
are retained (`brainstorm-host-types`, `brainstorm-host-built-types`).

`brainstorm-host-focused` passed in 58.290s: types, 21 focused tests, lint.
Log hash a34348ad6eb63f0034e41cd3ec271d72006058a10c85eb831fea29c8529e28e2.
`brainstorm-host-controls` passed in 5.063s: owner build, types, 22 focused tests,
and generated first-party check (36 packages, 290 files).
Log hash f63bc96bd9438a43a42134230e45d3b8953d3f8afc7b7311548377e32dde73d8.
`brainstorm-host-cwd-negative` deliberately failed the context-isolation assertion
after mutating the actual seat dispatch cwd to process.cwd(); four other tests passed.
Mutation restored before staging. Log hash
92ebccc51f8096478ff7a5e74f7282649eeafeb0fa43564727b567f3406ae1b2.
All local checks above had zero provider launches.

Reviewed/frozen tree f4320b0ce339f6556d08ab621bf3646ca83decae.
Default Agon review packet hash
0e40c925a16d06b7dcc6141b891bb35854f7273d413c7c93f1c0ee8aef096054.
First attempts could not start sandbox-exec (exit 71); receipts retained. Approved
escalated retry kept the review's own sandbox, isolation, and cleanup unchanged.
Codex returned no concrete runtime regression and confirmed actual responsibility
transfer. Log hash 16ea4283a5fccc7ae3fcf2e0ae0696ad57a5008fa82320c2abf80db6bf8d94fe.
Kimi returned no answer (exit 1), unavailable auth hash
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No personal auth repair or extra panel.

Review coverage clarification accepted: ten parity cases exercise generated Core
host bindings; six scout cases only compare Forge and legacy. Do not call all
sixteen generated-host coverage. Confirmed missing controls to add: distinct
per-invocation registry/adapter identity; successful lookup capture through retry;
rating evaluation order and sentinel exceptions; open failures; built-package
export/typing evidence. No production defect established by these gaps.

Full gate `brainstorm-host-final` is running on the frozen tree; current exec
session 12695. Do not edit frozen source until it ends. Read its terminal receipt,
then add the reviewed controls, rerun affected/full gates, and commit only after
green. No release acceptance claim or commit yet.

## Post-review qualification

The first full gate was mistakenly launched without the local-socket escalation.
Build/types/lint/re-export/generator checks passed, but socket tests hit EPERM.
Stopped only its verified process group 96340; the wrapper recorded terminal
exit -15 after 254.066s, zero providers, log hash
e9861fbb6a18d11d9235358beb1fb0a4961f3734786e23c854d18e55173ecdfd.
This run is not passing evidence and does not establish a source regression.
Process correction: full process/socket gates require the approved escalation,
while keeping isolated state and provider blockers. No test oracle was weakened.

Added reviewed controls: separate registry/adapter/engine identities for interleaved
opens; each preflight's registry/adapter/signal/config cwd; lookup capture through
retry; registry/adapter-open failure; mapping-before-classification and propagation
of classification/write errors; runtime use of the independently built package
factory. Existing Core compilation also consumes its exported declarations.
`brainstorm-host-review-controls` passed before the final three test refinements:
23 tests plus types, 1.518s, zero providers, log hash
b3ed367b6a01500f070eeb963ec08b5181e2b58e039abfca1a330bdef66c7b64.

New frozen tree 252b9d07ddc929e0df8c4ab5fed72b9b27328abf. Production unchanged
from the reviewed tree; only tests extended. Full gate `brainstorm-host-qualified`
now runs with approved socket permissions (exec 81931): focused built-package
checks, build/types/lint/guards/generator/full tests/performance, final host and
raw parity checks, then existing live persisted-session harness. That final
harness exercises session persistence/recovery, not live model quality or complete
installed-surface qualification. Do not commit until its terminal receipt is green.

## Verified checkpoint

`brainstorm-host-qualified` passed in 317.476s, exit 0, zero provider launches.
Log hash acc2dbdce10b879190ac17d3401940cdc0a2d2d100a89ad0133c5b56b87f3aee.
Full suite: 8,412 passed, 6 skipped; 636 files passed, one skipped. Build, types,
lint, re-export guard, first-party generated check and release performance passed.
Final 24 host/parity tests passed. Native session harness completed four invocations:
completed, aborted, crashed, completed; six checkpoints, original session retained,
replacement session untouched, receipt before presentation and stopped timers.

Local commit 253a53af0ddd2e9bd75b9793a06592f426a28ba6 has the exact tested tree
252b9d07ddc929e0df8c4ab5fed72b9b27328abf. Five explicit paths, 247 added/45 removed
lines (173 new test lines; no new runtime dependency). Candidate ref advanced by
compare-and-swap and index-only read-tree. Before/after preservation checks passed,
log hash bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification worktree clean. Nothing pushed or installed. This closes Core's
Brainstorm assembly ownership, not the public effect facade, Forge compatibility
binding, config ownership, old daemon flake or final release acceptance.
