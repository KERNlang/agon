import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { setTimeout as delay } from 'node:timers/promises';
import { createBrainstormPresentation } from '/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/blocks/brainstorm-presentation.js';
import { renderBlockOwnRows } from '/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/surfaces/app-rendering.js';
import { TranscriptRowView } from '/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/surfaces/app-views.js';
import { captureSurfaceFrame } from '/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/blocks/frame-capture.js';

const require = createRequire('/Users/ra/dev/agon-audit-qualification/package.json');
const React = require('react');
const { Box } = await import(require.resolve('ink'));
const events = [];
const otherEvents = [];
const view = createBrainstormPresentation(event => events.push(structuredClone(event)));
const other = createBrainstormPresentation(event => otherEvents.push(structuredClone(event)));
try {
  view.setEngines(['fixture-alpha', 'fixture-missing']);
  view.onEvent({ type: 'brainstorm:seat-started', data: { engineId: 'fixture-alpha' } });
  other.setEngines(['fixture-other']);
  await delay(1300);
  assert(events.some(event => event.type === 'progress-update' && event.engines.some(engine => engine.elapsed >= 1)));
  assert(otherEvents.filter(event => event.type === 'progress-update').every(event => event.engines.every(engine => engine.id === 'fixture-other')));
  view.complete({ question: 'Fixture', winner: 'fixture-alpha', response: 'usable answer',
    bids: [{ engineId: 'fixture-alpha', reasoning: 'First rationale', approach: 'First approach', score: 71, confidence: 0 }],
    synthesis: { status: 'fallback', detail: 'fixture timeout' } });
  assert(events.some(event => event.type === 'info' && event.message.includes('fixture-missing')));
  assert(events.some(event => event.type === 'warning' && event.message.includes('fixture timeout')));
  for (const width of [40, 100]) {
    const rows = events.filter(event => event.type === 'kern-draft').flatMap((event, id) =>
      renderBlockOwnRows({ id, event }, 'chat', false, true, width - 4, width - 2, width - 8));
    const Surface = () => React.createElement(Box, { flexDirection: 'column' },
      ...rows.map(row => React.createElement(TranscriptRowView, { key: row.key, row })));
    const frame = await captureSurfaceFrame(Surface, {}, width, 30);
    const compact = frame.replace(/\s/g, '');
    assert(compact.includes('score:71,confidence:0%'));
    assert(compact.includes('Firstrationale'));
    assert(!compact.includes('undefined'));
    console.log(`Rendered frame (${width} columns):\n${frame}`);
  }
  view.dispose();
  other.fail();
  other.dispose();
  const count = events.length;
  const otherCount = otherEvents.length;
  view.onEvent({ type: 'brainstorm:seat-started', data: { engineId: 'late' } });
  view.dispose();
  other.dispose();
  await delay(1100);
  assert.equal(events.length, count);
  assert.equal(otherEvents.length, otherCount);
  console.log('Real-clock progress, concurrent invocation isolation, rendered metrics, failure/disposal and late-event suppression passed.');
} finally {
  view.dispose();
  other.dispose();
}
