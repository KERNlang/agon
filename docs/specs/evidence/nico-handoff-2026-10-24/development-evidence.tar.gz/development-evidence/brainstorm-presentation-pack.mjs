import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { posix } from 'node:path';

const root = '/Users/ra/dev/agon-audit-qualification';
const directory = root + '/packages/mod-brainstorm';
const require = createRequire(root + '/package.json');
const ts = require('typescript');
const manifest = JSON.parse(readFileSync(directory + '/agon.mod.json', 'utf8'));
const packed = JSON.parse(execFileSync('npm', ['pack', '--json', '--dry-run', '--ignore-scripts', '--offline'], {
  cwd: directory, encoding: 'utf8', env: { ...process.env, npm_config_ignore_scripts: 'true' },
}))[0];
const files = packed.files.map(file => file.path).sort();
assert.deepEqual(files, ['package.json', ...manifest.pack.include].sort());
function verifyDeclarationClosure(files) {
for (const path of files.filter(path => path.endsWith('.d.ts'))) {
  const source = readFileSync(directory + '/' + path, 'utf8');
  for (const dependency of ts.preProcessFile(source).importedFiles) {
    if (!dependency.fileName.startsWith('.')) continue;
    const target = posix.normalize(posix.join(posix.dirname(path), dependency.fileName)).replace(/\.js$/, '.d.ts');
    assert(files.includes(target), `${path} references unpacked ${target}`);
  }
}
}
verifyDeclarationClosure(files);
assert.throws(() => verifyDeclarationClosure(files.filter(path => path !== 'dist/result.d.ts')), /references unpacked dist\/result\.d\.ts/);
assert(files.includes('dist/presentation.d.ts'));
assert(files.includes('dist/result.d.ts'));
assert(!files.some(path => path.startsWith('src/') || path.endsWith('.map')));
console.log(JSON.stringify({ package: packed.name, files, declarationClosure: 'passed', size: packed.size }));
