import type { BrainstormResult } from '../agon-audit-qualification/packages/mod-brainstorm/dist/index.js';
import type { BrainstormGroup, BrainstormDedupStatus } from '../agon-audit-qualification/packages/support-dedup/dist/index.js';

// Frozen structural contract from 4efb6e05 Core models/types.ts.
interface LegacyBrainstormResult {
  question: string;
  bids: { engineId: string; confidence: number; reasoning: string; approach: string; score?: number }[];
  winner: string;
  response: string;
  groups?: BrainstormGroup[];
  dedup?: BrainstormDedupStatus;
  synthesis?: { status: 'completed' | 'fallback'; detail?: string };
  panelHealth?: { requested: number; responded: number; degraded: boolean; notes: string[]; banner: string | null };
}
declare const previous: LegacyBrainstormResult;
declare const current: BrainstormResult;
export const acceptsPrevious: BrainstormResult = previous;
export const acceptsCurrent: LegacyBrainstormResult = current;
// @ts-expect-error The public contract still rejects invalid confidence types.
export const malformed: BrainstormResult = { question: '', winner: '', response: '', bids: [{ engineId: '', confidence: 'high', reasoning: '', approach: '' }] };
