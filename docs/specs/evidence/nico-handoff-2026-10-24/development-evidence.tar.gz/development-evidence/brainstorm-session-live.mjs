import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const root = mkdtempSync(join(tmpdir(), 'agon-brainstorm-session-live-'));
const previous = process.env.AGON_HOME;
process.env.AGON_HOME = root;
try {
  const { startChatSession, chatsDir } = await import('/Users/ra/dev/agon-audit-qualification/packages/support-persistence/dist/index.js');
  const { runBrainstormSession } = await import('/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/blocks/brainstorm-session.js');
  const { recentRunRecords } = await import('/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/telemetry/index.js');
  const original = startChatSession({ engineIds: ['fixture'] });
  const replacement = { id: 'never-write-replacement', startedAt: new Date().toISOString(), messages: [] };
  const ctx = { chatSession: original, activeEngines: () => ['fixture'] };
  const events = [];
  const cb = { ctx, dispatch(event) {
    if (event.type === 'engine-block') assert(recentRunRecords().some(record => record.success && record.mode === 'brainstorm'));
    events.push(event);
  } };
  const result = { question: 'native fixture', winner: 'fixture', response: 'native persisted answer',
    bids: [{ engineId: 'fixture', reasoning: 'why', approach: 'how', confidence: 80, score: 71 }] };
  let calls = 0;
  assert.equal(await runBrainstormSession({ question: 'native fixture' }, cb, new AbortController().signal,
    async (_input, context) => {
      calls++;
      context.onWorkflowEvent({ type: 'brainstorm:seat-started', data: { engineId: 'fixture' } });
      await delay(20);
      ctx.chatSession = replacement;
      return { exitCode: 0, result };
    }), result);
  assert.equal(calls, 1);
  assert.equal(original.messages.length, 2);
  assert.equal(replacement.messages.length, 0);
  assert(readFileSync(join(chatsDir(), original.id + '.ndjson'), 'utf8').includes('native persisted answer'));
  assert.equal(recentRunRecords().length, 1);
  assert.equal(events.at(-1).type, 'progress-clear');

  ctx.chatSession = original;
  const controller = new AbortController();
  const reason = new Error('operator cancelled native fixture');
  const before = events.length;
  await assert.rejects(runBrainstormSession({ question: 'cancel native fixture' }, cb, controller.signal,
    async () => { controller.abort(reason); return { result }; }), error => error === reason);
  assert(!events.slice(before).some(event => event.type === 'engine-block'));
  assert.equal(recentRunRecords().at(-1).completionState, 'aborted');
  assert.equal(original.messages.length, 2);

  await assert.rejects(runBrainstormSession({ question: 'malformed native fixture' }, cb, new AbortController().signal,
    async () => ({ result: { ...result, bids: [null] } })), /Invalid Brainstorm result/);
  assert.equal(recentRunRecords().at(-1).completionState, 'crashed');
  assert.equal(original.messages.length, 2);
  await runBrainstormSession({ question: 'recovery native fixture' }, cb, new AbortController().signal,
    async () => ({ result: { ...result, question: 'recovery native fixture' } }));
  assert.equal(original.messages.length, 4);
  const records = recentRunRecords();
  assert.deepEqual(records.map(record => record.completionState), ['completed', 'aborted', 'crashed', 'completed']);
  assert.equal(new Set(records.map(record => record.id)).size, 4);
  const checkpoints = readFileSync(join(root, 'runs', 'checkpoints.jsonl'), 'utf8')
    .trim().split('\n').map(line => JSON.parse(line));
  assert.equal(checkpoints.filter(item => item.phase === 'pre-dispatch').length, 4);
  assert.equal(checkpoints.filter(item => item.phase === 'post-dispatch').length, 2);
  for (const record of records) {
    assert(checkpoints.some(item => item.runId === record.id && item.phase === 'pre-dispatch'));
  }
  const count = events.length;
  await delay(1100);
  assert.equal(events.length, count);
  console.log(JSON.stringify({ invocations: 4, receiptStates: records.map(record => record.completionState),
    originalMessages: original.messages.length, replacementMessages: replacement.messages.length,
    checkpoints: checkpoints.length, receiptBeforePresentation: true, timersStopped: true }));
} finally {
  if (previous === undefined) delete process.env.AGON_HOME;
  else process.env.AGON_HOME = previous;
  rmSync(root, { recursive: true, force: true });
}
