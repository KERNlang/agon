import { mkdtempSync, mkdirSync, symlinkSync, rmSync, readdirSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { verifyPackedBrainstorm } from '/Users/ra/dev/agon-audit-qualification/scripts/spec/verify-packed-brainstorm.mjs';
import { verifyPackedBrainstormTui } from '/Users/ra/dev/agon-audit-qualification/scripts/spec/verify-packed-brainstorm-tui.mjs';

// Reuse the behavioral oracle against the built workspace, not an installed package.
const scratch = mkdtempSync(join(tmpdir(), 'agon-brainstorm-surfaces-'));
try {
  const prefix = join(scratch, 'fixture-prefix');
  mkdirSync(join(prefix, 'node_modules/.bin'), { recursive: true });
  symlinkSync('/Users/ra/dev/agon-audit-qualification/packages/cli/dist/index.js',
    join(prefix, 'node_modules/.bin/agon'));
  const cli = await verifyPackedBrainstorm(prefix, scratch, process.env);
  console.log(JSON.stringify({ phase: 'workspace-cli', passed: cli.passed }));
  const tui = await verifyPackedBrainstormTui(prefix, scratch, process.env);
  console.log(JSON.stringify({ phase: 'workspace-tui', passed: tui.passed }));
  const exit = await verifyPackedBrainstormTui(prefix, scratch, process.env, { activeExit: true });
  console.log(JSON.stringify({ phase: 'workspace-active-exit', passed: exit.passed }));
  console.log(JSON.stringify({ installedQualification: false, source: 'built workspace CLI',
    phases: 3, providers: 'local fixture only; existing effect guard active' }));
} finally {
  // Immutable host generations need owner write permission for fixture cleanup.
  function writableDirectories(path) {
    chmodSync(path, 0o700);
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      if (entry.isDirectory() && !entry.isSymbolicLink()) writableDirectories(join(path, entry.name));
    }
  }
  writableDirectories(scratch);
  rmSync(scratch, { recursive: true, force: true });
}
