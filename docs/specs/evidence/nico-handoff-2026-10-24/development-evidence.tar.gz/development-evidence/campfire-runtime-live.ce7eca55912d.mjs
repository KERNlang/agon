import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
if (!process.argv[2]) {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  for (const scenario of ['campfire-live', 'campfire-disabled', 'campfire-cancel']) {
    process.stdout.write(execFileSync(process.execPath, [process.argv[1], scenario], { encoding: 'utf8', timeout: 30000 }));
  }
  console.log(JSON.stringify({ passed: true, nativeProcesses: 3 }));
  process.exit(0);
}
const scenario = process.argv[2];
const root = mkdtempSync(join(tmpdir(), 'agon-step-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const fixture = {};
new Function('exports', 'require', ts.transpileModule(readFileSync(join(repo,
  'tests/helpers/modular-surface-lock.ts'), 'utf8'), { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
async function owner(symbol) {
  const files = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
  assert.equal(files.length, 1, symbol);
  const module = await import(pathToFileURL(join(directory, files[0])).href);
  assert.equal(typeof module[symbol], 'function', symbol);
  return module;
}
const authority = await owner('initializeProcessSurfaceAuthority');
const cli = await owner('buildStepExecutors');
const host = new kernel.DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0', processIdentity: 'native-step' });
async function install(disabledId) {
  const catalog = kernel.createFirstPartyModCatalog();
  const full = kernel.createFullCompatDesiredState(catalog, '2026-10-10T00:00:00.000Z');
  const desired = disabledId ? kernel.planDesiredStateChange(catalog, full,
    { kind: 'disable', id: disabledId }, '2026-10-10T00:00:00.000Z').nextState : full;
  await host.commitGeneration({ operation: disabledId ? 'disable' : 'install',
    lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
}
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isDirectory()) unlock(join(path, entry.name));
  }
}
try {
  await install(scenario === 'campfire-disabled' ? 'agon.campfire' : undefined);
  await authority.initializeProcessSurfaceAuthority(join(root, 'host'));
  process.env.AGON_DISABLE_FORGE_HEALTH_CHECK = '1';
  process.env.AGON_FORCE_HEALTH_PROBE = '';
  const { EngineRegistry } = await import(join(repo, 'packages/support-engine-catalog/dist/index.js'));
  const { CliAdapter } = await import(join(repo, 'packages/adapter-cli/dist/index.js'));
  const registry = new EngineRegistry();
  for (const id of ['fixture-alpha', 'fixture-beta']) {
    registry.register({ schemaVersion: 3, id, displayName: id, binary: process.execPath,
      isLocal: true, tier: 'user', timeout: 5, exec: { args: ['-e',
        `setTimeout(() => console.log(${JSON.stringify(id + ': NATIVE_CAMPFIRE_VIEW')}), ${id === 'fixture-beta' ? 200 : 0})`] } });
  }
  const adapter = new CliAdapter(registry), dispatch = adapter.dispatch;
  const controller = new AbortController();
  const calls = [];
  let active = 0;
  adapter.dispatch = async options => {
    calls.push(options);
    active++;
    try {
      const result = await dispatch(options);
      if (scenario === 'campfire-cancel' && options.engine.id === 'fixture-alpha') controller.abort(new Error('fixture cancellation'));
      return result;
    } finally {
      if (scenario === 'campfire-cancel' && options.engine.id === 'fixture-beta') await new Promise(resolve => setTimeout(resolve, 100));
      active--;
    }
  };
  const executor = cli.buildStepExecutors({ config: {}, registry, adapter,
    activeEngines: () => ['fixture-alpha', 'fixture-beta'] }).campfire;
  const running = executor.execute({ id: 'native-campfire', type: 'campfire',
    description: 'Physical runtime discussion', state: 'pending', estimatedTokens: 0, estimatedCostUsd: 0 }, {}, controller.signal);
  if (scenario === 'campfire-disabled') {
    await assert.rejects(running, /unavailable/);
    assert.equal(calls.length, 0);
  } else {
    const value = await running;
    assert.equal(active, 0, 'Every started seat must settle before workflow return');
    assert.equal(calls.length, 2);
    assert.equal(value.result.status, scenario === 'campfire-cancel' ? 'failure' : 'success');
    if (scenario === 'campfire-live') assert.match(value.result.output, /NATIVE_CAMPFIRE_VIEW/);
    else assert.equal(value.contextExport, undefined);
    for (const call of calls) {
      assert.equal(call.textOnly, true);
      assert.equal(call.mode, 'exec');
      assert.match(call.outputDir, /native-campfire$/);
    }
  }
  console.log(JSON.stringify({ passed: true, scenario, compiledCli: true, realDurableHost: true }));
} finally {
  process.chdir(repo);
  unlock(root);
  rmSync(root, { recursive: true, force: true });
}
