# Next integration: Cesar authority and physical Plan self ownership

Read-only trace while agent-session tree 9f00bb26 qualified. Candidate WIP is
not an accepted implementation. Do not copy its full plan-mode.ts over the
qualified handler; that would also introduce Forge, Pipeline and Agent/Review
extractions without their own validation.

## Current source facts

- Qualification plan-mode.ts calls handleCesarBrain twice from the inline self
  executor, without forwarding the step AbortSignal or owning-mod admission.
  Calls are near lines 280 and 295 on the current staged subject.
- Candidate brain.ts adds optional parentSignal and assertOwnerAvailable,
  preserves parent ownership of the active abort handle, guards session/fallback
  dispatch, propagates authority to eager/native tools, and denies stale MCP
  permission replies. Candidate session.ts adds captureToolRefusal and per-call
  tool contexts; turn-runtime.ts carries a run-local owner assertion.
- Candidate tools.ts accepts an optional ToolContext executionRefusal hook.
- Candidate plan-mode.ts also imports multiple extraction factories. Only the
  self factory and its composition belong to the immediate self slice.

## Draft defects to verify before adopting

Candidate mod-plan/src/self-step-execution.ts currently accepts brain outcomes
with only awaitingUserInput and decisionReason fields. It does not inspect
terminalState=failed/timed_out. A non-aborted failed brain turn can therefore
reach the verification gate and success path. The legacy inline implementation
has the same weakness. Reproduce against the actual executor before correction.

Candidate self factory checks delegate ownership before dispatch, but after
dispatch its runVerifyGate checks only self ownership. Current qualified inline
delegate path checks delegate ownership both after dispatch and verification.
Do not regress that stronger boundary during extraction.

Captured streamed output lives inside the self branch, while its outer catch
returns output=''. Authority loss after partial work could erase receipts from
the step result. Preserve observed output and tracker deltas in failure cases.

Candidate brain wrapper checks parent abort before installing the listener.
Check whether synchronous callbacks between those operations can abort without
propagating the signal. Also check provider iterator boundaries: validating only
before entering an async iterator does not prove each subsequent send/tool/result
is current. These are hypotheses, not accepted findings.

## Verification scope

Use existing cesar-brain-cleanup-boundary, cesar-session-acquisition-cleanup,
cesar-recovery-cleanup, turn-runtime and Plan admission tests. Add targeted
negative controls for admission, suspended acquisition, fallback, streamed tool
approval, delayed MCP replies, parent cancellation, replacement turns and
noncooperative completion. Validate physical self ownership with the candidate
self-step parity/owner tests only after reading their oracles. Keep healthy
legacy behavior, bounded retry/pause semantics, verify-command results, output
receipts, metered tracker deltas and parent abort ownership.

No live provider or personal session is needed for these local proofs. Independent
default Agon review remains required for the completed next integration batch.

## Admission reproduction started after d3bc9727

The qualification checkout now has only the next batch's two unstaged paths:
brain.ts and cesar-brain-cleanup-boundary.test.ts. Two added tests prove that
the old four-argument brain ignores a supplied cancelled parent or disabled
owner and starts anyway. Red receipt `cesar-parent-admission-red.receipt.json`:
2 failed, 102 passed; log SHA-256
`d21b94aa89d485af6e8fedff14542af8f825f7e075d35dcf31e0ba86c820b52b`.

Initial correction adds the optional parent/owner arguments and a wrapper around
the existing brain body. It checks entry, bridges parent abort, closes the
listener race by checking parent state after registration, removes the listener
in finally, and does not overwrite the parent's active-abort handle. The inner
brain is otherwise unchanged. This is not full owner enforcement: later awaits,
native/eager/MCP tools, session creation and Plan composition remain to integrate.

Focused run `cesar-parent-admission-initial-fixed` is live on handle 89090;
poll before editing. No commit until the full next integration is reviewed and
qualified. In particular, do not infer that the optional owner assertion is
enforced throughout the turn merely because its entry check passes.

The initial focused run finished green: 104 tests plus typecheck, 15.725 seconds,
zero providers. Log SHA-256
`10897a807e2e3ed4b7e49977505b28648e05a8a61ce8b41ac6dd3e1624b1b649`.
Handle 89090 is terminal. Continue suspended-boundary and live-owner tests next.

## Suspended budget and acquisition boundaries

Eight red controls cover budget/acquisition × resolved/rejected × parent
cancellation/owner disable. The old entry-only wrapper allowed work afterward.
Red receipt `cesar-owner-boundaries-red.receipt.json`: 8 failed, 104 passed;
log SHA-256 `b661199726a783ec9689a32fee0f321253b3018b27caba2421ad024b1ca21f4a`.
The inner brain now has a live assertion that checks abort and the supplied
owner callback. Rechecks follow the pre-brain event hook, budget gate, and both
session-acquisition outcomes. Authority failure aborts child work and propagates
through existing finally cleanup without clearing the parent's abort handle.
Green receipt `cesar-owner-boundaries-fixed.receipt.json`: 112 tests, typecheck
and targeted lint passed, zero providers; log SHA-256
`5add41fa6b006f890d78a9ccef0b4deb7657fc79b2c7a8efce336fe49573e55e`.

Fallback-return controls are next: no late answer publication or normal assistant
history after owner loss, but incurred provider usage must remain recorded. This
must also propagate through the fallback's existing broad catch rather than
silently converting refusal into a recoverable ordinary dispatch failure.

## Fallback and stream return boundaries

Fallback red receipt `cesar-fallback-owner-red.receipt.json`, log SHA-256
`e393755677f7d2db6251ba83b7cbee7df01ed7432e9eb14a8541680f993872cd`.
Two controls prove late fallback answers were published after parent abort or
owner disable. The fallback now checks before dispatch and after return, records
incurred usage before refusing publication, and rethrows authority loss outside
its generic catch. The already-admitted user message remains; no late engine
message or engine-block is emitted. Both controls verify usage is recorded once.
Green receipt `cesar-fallback-owner-fixed.receipt.json`: 114 tests, typecheck and
targeted lint passed; zero providers; log SHA-256
`c13ac69b9ba06062f1af929fcc9c9e33e39dcb9fb5f01dff830b474f924c6338`.

Stream red receipt `cesar-stream-owner-red.receipt.json`: 2 failed, 116 passed;
log SHA-256 `b09843caddf026709d9367f8f4d08842729d43a4db379454ba6cc2984f255245`.
The failures are owner disable while awaiting a text chunk or iterator end.
Existing parent cancellation controls already pass. Added live checks before
session.send, before iterator consumption, after each next result, after each
yield resumes, and at normal iterator completion. Thus a disabled owner cannot
publish the next chunk or trigger a later send. Existing abort classification
handles the stop as cancelled, with busy/parent-handle cleanup preserved.
Run `cesar-stream-owner-fixed` is active under handle 98094; poll before editing.

Remaining dimensions are unchanged: per-call native/eager/MCP tool authority,
session creation internals, runtime owner lifetime, Plan caller composition and
physical self extraction, independent review and complete qualification. These
boundary tests use controlled providers, not live-provider evidence.

Stream gate completed: 118 tests, typecheck and targeted lint passed in
17.664 seconds; zero providers. Log SHA-256
`8393dd2ae9b5814c6cc21a4475b905b87b00929fa4d709b20ec144fc7d66fb84`.
Handle 98094 is terminal. The two-file Cesar batch remains unstaged and uncommitted
over d3bc9727. Continue native/eager/MCP callback lifetime before review/commit.

## Companion and native callback lifetime

Four delayed companion approval bugs reproduced across owner disable, turn
replacement, terminal completion and cancellation. Red receipt
`cesar-companion-owner-red.receipt.json`, log SHA-256
`8a3399a4fbb3a2f7cad80e9be782dae94dcacfde09759f8aa36541c3a51b748c`.
CesarTurnRuntime now holds an optional run-local owner assertion; begin checks it
before replacing a turn, and brain binds its live authority check into the
runtime. The assertion is not placed in persisted envelopes or copied to a new
turn. Session callbacks capture runtime identity and abort signal per invocation,
not per long-lived session. They recheck before approval grants and after awaits.
Green receipt `cesar-companion-owner-fixed.receipt.json`, log SHA-256
`0c81c701bb9b61e4f8390db46253ec65554867db637417c2f126f5521818d69f`.

Four analogous native execution bugs reproduced with the real ToolRegistry and
a non-executing fixture Bash tool. The destructive-looking command is only input
to the approval policy; no shell executes it. After delayed approval the old
callback executed the fixture despite loss of authority. Red receipt
`cesar-native-owner-red.receipt.json`, log SHA-256
`cc4141961bab0a590e278feabf149489526659e707d4b011861a6ac300fc56ce`.
Native execution now receives a per-invocation ToolContext with the captured
abort signal and refusal hook. Preflight and permission callbacks deny stale
approval before it can create a grant; the existing core registry enforces the
remaining execution boundary. Completed tool receipts are preserved.

First fixed run correctly stopped execution but exposed misleading denial text
(`User denied permission`). Kept the strict denial test and fixed reporting:
failed tool results caused by owner loss return owner denial, not a user choice.
Receipt `cesar-native-owner-reason-fixed.receipt.json`: 99 tests, typecheck and
lint passed; log SHA-256
`7f1c31a34c2ad4835dcb5868bc02e496034e17f7d7dfbc92f30429cb3f25b375`.

Two additional new-callback controls proved that clearing host.active on terminal
completion allowed later companion/native reads to bypass the captured-runtime
check. Red receipt `cesar-terminal-callback-red.receipt.json`, log SHA-256
`ec7b9af3999e1ba250c42c149f608f9352ca0e5120fc3067578af63b28c6dc15`.
When a runtime host exists but has no active turn, new callbacks now deny. Legacy
contexts without any runtime host retain their existing path. Read-only calls
with stale response metadata can still execute against a valid active turn;
this does not restore an ended turn.

Combined callback/brain/runtime/recovery/acquisition controls are running under
`cesar-callback-authority-controls`, handle 88879. Poll before source edits.
The five-file next batch remains uncommitted. Remaining dimensions: eager and
MCP approvals, session creation internals, special native delegation paths,
Plan wiring/physical extraction, full qualification and independent review.

Combined control run completed in 17.321 seconds: all selected tests, typecheck
and lint passed; zero provider launches. Log SHA-256
`0fe5dc53edaaeb59870ee16de584ab9c17374c90c98b26aae4c4b76547f8916e`.
Handle 88879 is terminal. Continue the remaining tool routes; no review/commit yet.

## Eager, XML and MCP approval boundaries

Two actual brain controls proved eager/XML fixture tools executed after their
owner was disabled during approval. Red receipt `cesar-eager-xml-owner-red`:
2 failed; log SHA-256
`a83133da2a130c072563547b723799bddfc6430aead45e3d0afb23e88615d702`.
Exported the existing captureToolRefusal from session.ts rather than creating
a second authority implementation. The brain captures one turn-bound hook;
eager and XML ToolContexts pass it into the existing core execution guard.
Approval callbacks also recheck before creating task grants. Healthy and
cancelled controls remain; added replacement/terminal controls.

MCP file-response controls reproduced four false approvals after disable,
cancel, replacement and terminal completion. Red receipt `cesar-mcp-owner-red`,
log SHA-256 `e66479acad1a7d7e00efac5f14c3dc05c1297fa65fcf7939510a401dfa899a31`.
MCP checks the same captured hook before automatic resolution and before a
delayed human reply. Refusal writes a typed denial reason, not approval, and
does not grant the task action. Tests use an isolated temporary signal directory;
no live MCP/provider runs.

A stronger oracle found four stale-turn continuations after eager/XML denial:
the tool did not run, but the old turn still sent two follow-up prompts.
Red receipt `cesar-tool-stale-continuation-red`, log SHA-256
`dbc136e61b90cf28868e8e9b4dd3a3a03f18ccc78dfa19944a1d32d06243f304`.
The shared send wrapper now checks captured runtime identity at entry, each
stream boundary and iterator completion. This initially duplicated a cleanup
warning in two existing tests; retained those strict tests and consolidated the
warning latch with the existing acquisition/cleanup refusal function.

Green receipt `cesar-tool-stale-continuation-clean-fixed`: 234 tests, typecheck
and targeted lint passed in 18.743 seconds; zero provider launches. Log SHA-256
`4a139c7e51591eb7399d7bfb8163936c7dcd3148dbb61357d46568d80395a018`.
All run handles in this section are terminal. Current uncommitted scope is six
paths: brain.ts, session.ts, tools.ts, turn-runtime.ts and the two existing tests.
Still required: acquisition-internal authority, special native async seams,
Plan composition/physical extraction, independent review and full qualification.

## Acquisition and physical Self integration

Four more negative controls proved that prompt preparation and dead-session
restart could proceed to replacement creation after owner disable or turn
replacement. Receipt `cesar-acquisition-owner-red`, log SHA-256
`20c0ff64cec170368db54bc6cddc7a58f32d1b6545a8aae42ee165b08dab9d0c`.
ensureCesarSession now captures an active turn's refusal hook and rechecks it at
its existing cleanup boundaries. Callers without an active runtime retain the
legacy session-acquisition path. Green receipt `cesar-acquisition-owner-fixed`:
tests, typecheck and lint passed; SHA-256
`50baebc91636158556395a254fc7da773a13f475b2fbead9ac29bc9f40f764f0`.

Six native Plan controls proved that dynamic import of ProposePlan/ExitPlanMode
could resume into state mutation after disable, cancellation or replacement.
Red receipt `cesar-native-plan-import-red`, SHA-256
`13ce3b5ce4057678205613fcff4a02cf139a425d0a82c954a8f043f969560f0e`.
Both branches recheck the captured hook after the import. Green receipt
`cesar-native-plan-import-fixed`: 82 tests, types and lint passed; SHA-256
`022e3f41b62d64fd14f048cab8fdb81700f6bc924b49917c4e14214d2d1665d5`.

The physical Self factory and its existing owner tests were imported selectively
from candidate WIP. No other Plan factories or candidate handler replacement
were copied. Six new controls failed against that draft: failed/timed-out/
cancelled brain outcomes reported success; thrown brain work lost observed
output; the separate Delegate owner was not checked after delegation/verification.
Draft red receipt `plan-self-owner-draft-red`, SHA-256
`f88dda1cac7c734ecd40da60896ce216a83c93127bdfead6da669598e65d75fb`.
The original qualified inline Self executor also failed the three false-success
controls before extraction: `plan-self-legacy-false-success-red`, SHA-256
`d396f47bafd59b8c4bcf71ddc4a1f30383790b97b519482334c2383fc6e67d81`.

Corrections retain captured output and incurred usage on failure, reject all
non-completed terminal states including superseded, and keep the stronger
qualified Delegate checks. The CLI now composes createSelfStepExecutor and
forwards the step signal plus live Self assertion to both brain attempts. The
existing withProcessSurfaceAuthority wrapper remains authoritative; it was not
removed as in the older candidate draft. Other factories remain untouched.

First integrated tests caught loss of detailed generation/cancellation reasons.
Kept those tests unchanged; only the default AbortError maps to `cancelled`.
The public brain outcome type now includes the real `superseded` alternative.
Green `plan-self-owner-integrated-types-fixed`: 188 focused tests, package build,
typecheck and lint; SHA-256
`b50e68d01f23c4f8c9977deafcfcbe78adedf555192c7ad447ca63f32b7710c0`.

Added physical-owner regression and real durable-generation host-composition
checks, then regenerated the existing migration ledger's source hashes without
changing its assignments or claiming full runtime retirement. Combined run
`cesar-self-combined-focused` is active on handle 66010. No commit or review yet.
Remaining checks include raw Self compatibility, full repository qualification,
independent review, and final source/receipt preservation checks. Do not infer
full release acceptance from this batch.

## Frozen integration and independent review

Combined focused run passed 449 tests, types and workspace lint, then correctly
failed generated export drift. Updated the existing generator (not the oracle)
for the additive Self exports. `cesar-self-generated-drift-fixed` passes; log
SHA-256 `8d17d993096d08b39c412a7de8d5c55eae129a67e0bd9f057d46d2b3c9808bde`.
All 14 batch paths are staged at tree
`2bd23ae001ad2245dbb9d2e171e1e49264b856d2`; no unstaged source changes.
Full gate `cesar-self-integration-full` runs on handle 4481. Do not edit the
qualification checkout until it ends. Candidate WIP and refs remain untouched.

Default independent review packet SHA-256
`426fb6869c35d7d093f5f3e9c1f6207b6dc32f5be15669e2726609a458f0c6dd`.
Codex review completed, log SHA-256
`1ac41f0755f38d9499d2b338fa63d9586de56b84a0375ae9193018cfcb33df6a`.
Four hypotheses require controls and source adjudication before acceptance:

1. Fresh session.start completion publishes a revoked candidate and may replace
   a successor. Recheck before attachment; dispose the rejected candidate only.
   Cover cleanup failure without losing the host's fail-closed barrier.
2. Acquisition's supersession refusal can enter brain fallback because the
   catch checks parent/owner but not the captured runtime identity. Bind that
   authority before acquisition, not only after it.
3. Native ProposePlan checks after import but not after awaiting the handler.
   Its handler is synchronous internally today, but the async wrapper yields
   before setActivePlan/proposedPlan. Preserve completed receipts; stop later
   publication into successor state.
4. The new Self dispatch assertion can discard a completed tool receipt after
   cancellation. Capture observed terminal evidence before refusing new UI
   publication; no success/context export after revocation.

Kimi returned no answer, exit 1 at Agon / exit 2 at wrapper. Its isolated log
shows invalid authorization grant, refresh failure and HTTP 401. This is an
authentication blocker, not an architectural verdict. Receipt
`cesar-self-integration-kimi-review.receipt.json`, log SHA-256
`a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff`.
No login or credential modification attempted. Both review handles are terminal;
the wrapper removed its temporary credential copies in finally. Do not rerun
a paid panel after fixes; validate findings locally as instructed. Retain the
missing second-engine evidence as external unless authentication is restored.

## Review corrections and raw compatibility (2026-10-11)

All four Codex findings were reproduced and corrected. Fresh session startup
now checks captured authority before publication and closes only the rejected
candidate. Failed cleanup keeps the host fail-closed without replacing a
successor. Brain acquisition checks runtime identity before fallback. Native
ProposePlan checks authority after its handler resolves and before publishing
state. Self retains completed tool-call and tool-stream-end receipts before
refusing later UI publication on cancellation or revocation.

The first startup/receipt red run had five valid failures and one bad fixture:
the supersession fixture had no active engine, so acquisition never started.
After repairing that precondition, the focused fallback negative control
proved one unwanted dispatch without the runtime guard and zero with it.
Receipts: `cesar-acquisition-fallback-review-red` (log SHA-256
`b62e17133212ffdfbe39bda648ae4897019b6ee041ec49d3f5c0f5e30a25141c`),
`cesar-proposal-publication-review-red` (SHA-256
`7a34a664fe3d5ce5090fbd273b486b37233737c6d98531d627891f46052cc24e`).
`cesar-self-review-corrections-focused` passed 460 tests, build, types and lint;
log SHA-256 `e9089b4ed36be3e2dbdd0755de6f6ff673841adc177dab9d6422dddd22855984`.

The frozen Self fixture contains the exact inline executor body from commit
`d3bc97278beee5a6ecfdbd078af99a8374b5e7b1`. Provenance receipt
`plan-self-oracle-provenance` verifies the byte match and source SHA-256;
log SHA-256 `18a107a355c252318397bcc80be22a47ffb0ffa078f6ded4b3e5131b39effb48`.
Raw parity covers 56 scenarios across four dispatch modes. Ten cases now
retain output that legacy exceptions discarded; each difference is asserted
explicitly, with all other raw fields and events compared unchanged.
`plan-self-raw-parity-verified` passed 83 tests, types and lint; log SHA-256
`45e0bfa1ab931288cef7692d238fd612ff0931151e25d536283bb446da93b0e8`.
Four further negative controls proved streaming terminal receipts were lost.
`plan-self-stream-receipts-fixed` passed 89 tests, build, types and lint;
log SHA-256 `7dc56b5e4faa5ac96ff9dc885bbbe2e6bbec10eebbfca83db0de9112214cb45e`.

The final 16-path staged subject is tree
`bdfc9095e47595cadeff2fa097fd9461b75f7659`. Qualification run
`cesar-self-integration-reviewed-full` is in progress. The earlier full run
passed 7,804 tests plus six skips and compiled checks, but predates review
corrections and is not the final acceptance receipt. No commit yet.

## Accepted local increment

Final qualification passed in 304.469 seconds: 7,878 tests passed, six skipped;
build, typecheck, all lint partitions, re-export guard, first-party generator
check and roadmap verification passed. The final live checks ran 21 compiled
CLI subprocess scenarios against real isolated durable hosts. Provider shims
recorded zero launches. Receipt `cesar-self-integration-reviewed-full`, log
SHA-256 `fc05d914cfe56a3b5c7f81b35fb997599f22f53c52b6725eee31b6e9096d41cf`.

Local commit `f91bd221ece55b6ae3b47de0c59ccb0123b8977c` contains exactly the
qualified tree `bdfc9095e47595cadeff2fa097fd9461b75f7659`. Qualification worktree
was clean afterward. Candidate ref and index advanced with expected-old checks
and no working-file writes. Before/after preservation receipts verify the 281
baseline paths against the unchanged allowlist; log SHA-256 in both cases
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
The frozen legacy fixture deliberately retains its source whitespace for the
byte-exact oracle check. Nothing pushed or installed. Kimi authentication and
the remaining modular ownership/release work are not declared complete.
