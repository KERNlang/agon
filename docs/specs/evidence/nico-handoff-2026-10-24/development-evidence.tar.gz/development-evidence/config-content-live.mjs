import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, utimesSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { performance } from 'node:perf_hooks';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const { loadConfig, invalidateConfigCache } = await import('/Users/ra/dev/agon-audit-qualification/packages/core/dist/signals/config.js');
const root = mkdtempSync(join(tmpdir(), 'config-content-live-'));
const timestamp = new Date(1700000000000);
const results = [];
for (const name of ['config.json', '.agon.json', '.agon.local.json']) {
  const home = join(root, name.replaceAll('.', '-'));
  mkdirSync(home);
  process.env.AGON_HOME = home;
  process.env.AGON_MODULAR_HOST_ROOT = join(home, 'modular-host');
  const path = join(home, name);
  writeFileSync(path, '{"commitCoAuthor":"first"}');
  utimesSync(path, timestamp, timestamp);
  assert.equal(loadConfig(home).commitCoAuthor, 'first');
  writeFileSync(path, '{"commitCoAuthor":"other"}');
  utimesSync(path, timestamp, timestamp);
  assert.equal(loadConfig(home).commitCoAuthor, 'other');
  const samples = [];
  for (let index = 0; index < 1000; index++) {
    const start = performance.now();
    assert.equal(loadConfig(home).commitCoAuthor, 'other');
    samples.push(performance.now() - start);
  }
  unlinkSync(path);
  assert.notEqual(loadConfig(home).commitCoAuthor, 'other');
  samples.sort((a, b) => a - b);
  results.push({ name, calls: 1003, p95Milliseconds: samples[950], maxMilliseconds: samples.at(-1) });
  invalidateConfigCache();
}
console.log(JSON.stringify({ passed: true, builtCore: true, sameTimestampAndSize: true, deletionObserved: true, results }));
