import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DurableModHost, sha256Canonical } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { configSet, loadConfig } from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const home = await mkdtemp(join(tmpdir(), 'config-fence-live-'));
process.env.AGON_HOME = home;
process.env.AGON_MODULAR_HOST_ROOT = join(home, 'custom-host');
const config = join(home, 'config.json');
const original = '{"debug":false,"mods":{"absent.mod":"retain"}}\n';
await writeFile(config, original);
let checked = false;
const host = new DurableModHost(process.env.AGON_MODULAR_HOST_ROOT, { kernelVersion: '1.0.0', fault: async point => {
  if (point !== 'after-lock') return;
  assert.throws(() => configSet('debug', true), { code: 'MOD_HOST_BUSY' });
  assert.equal(await readFile(config, 'utf8'), original);
  checked = true;
} });
const desired = { fixture: true };
const fields = { kernelVersion: '1.0.0', apiVersion: '1.0.0', desiredStateHash: sha256Canonical(desired), packages: [] };
await host.commitGeneration({ operation: 'install', lock: { schemaVersion: 1, ...fields, graphHash: sha256Canonical(fields) }, desiredState: desired, installedIndex: {} });
assert.equal(checked, true);
assert.equal(configSet('debug', true), undefined);
assert.equal(loadConfig().debug, true);
assert.equal(JSON.parse(await readFile(config, 'utf8')).mods['absent.mod'], 'retain');
console.log(JSON.stringify({ passed: true, builtCore: true, builtHost: true,
  blockedDuringPublication: true, sourcePreserved: true, synchronousWriteAfterRelease: true,
  customHostRoot: true, providerWorkflowsExercised: false }));
