import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { DurableModHost, sha256Canonical, withSynchronousWriterFence } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const repo = '/Users/ra/dev/agon-audit-qualification';
const home = await mkdtemp(join(tmpdir(), 'config-fence-processes-'));
const root = join(home, 'modular-host');
const config = join(home, 'config.json');
await writeFile(config, '{"debug":false}\n');
const env = { ...process.env, AGON_HOME: home, AGON_MODULAR_HOST_ROOT: root };
const desired = { fixture: true };
const fields = { kernelVersion: '1.0.0', apiVersion: '1.0.0', desiredStateHash: sha256Canonical(desired), packages: [] };
const input = { operation: 'install', lock: { schemaVersion: 1, ...fields, graphHash: sha256Canonical(fields) }, desiredState: desired, installedIndex: {} };
const host = new DurableModHost(root, { kernelVersion: '1.0.0', fault: async phase => {
  if (phase !== 'after-lock') return;
  const result = run(`import {configSet} from '${repo}/packages/core/dist/index.js';
    try { configSet('debug',true); console.log(JSON.stringify({code:'UNEXPECTED_WRITE'})); }
    catch(error) { console.log(JSON.stringify({code:error.code})); }`);
  assert.equal(result.code, 'MOD_HOST_BUSY');
  assert.equal(await readFile(config, 'utf8'), '{"debug":false}\n');
} });
let processes = 0;
function run(code) {
  const result = spawnSync(process.execPath, ['--input-type=module', '-e', code], { env, encoding: 'utf8', timeout: 15000 });
  processes++;
  assert.equal(result.error, undefined); assert.equal(result.status, 0, result.stderr);
  return JSON.parse(result.stdout);
}
withSynchronousWriterFence(host.paths.writerLock, 'fixture.parent-config', () => {
  const result = run(`import {DurableModHost} from '${repo}/packages/mod-kernel/dist/index.js';
    try { await new DurableModHost(process.env.AGON_MODULAR_HOST_ROOT,{kernelVersion:'1.0.0'}).commitGeneration(${JSON.stringify(input)});
      console.log(JSON.stringify({code:'UNEXPECTED_COMMIT'})); }
    catch(error) { console.log(JSON.stringify({code:error.code})); }`);
  assert.equal(result.code, 'MOD_HOST_BUSY');
});
await host.commitGeneration(input);
const holder = spawn(process.execPath, ['--input-type=module', '-e', `
  import {writeSync} from 'node:fs';
  import {join} from 'node:path';
  import {withSynchronousWriterFence} from '${repo}/packages/mod-kernel/dist/index.js';
  withSynchronousWriterFence(join(process.env.AGON_MODULAR_HOST_ROOT,'locks','writer.json'),'fixture.killed-config',()=>{
    writeSync(1,'LOCKED'); Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10000);
  });`], { env, stdio: ['ignore', 'pipe', 'pipe'] });
processes++;
const exited = new Promise((resolve, reject) => { holder.once('error', reject); holder.once('exit', (code, signal) => resolve({code,signal})); });
try {
  await Promise.race([new Promise(resolve => holder.stdout.once('data', bytes => { assert.equal(String(bytes), 'LOCKED'); resolve(); })),
    exited.then(result => { throw new Error('holder exited before lock: ' + JSON.stringify(result)); })]);
  holder.kill('SIGKILL');
  assert.equal((await exited).signal, 'SIGKILL');
} finally { if (holder.exitCode === null && holder.signalCode === null) { holder.kill('SIGKILL'); await exited; } }
await host.recoverStaleWriter(async pid => {
  try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; }
});
withSynchronousWriterFence(host.paths.writerLock, 'fixture.reentered', () => {});
assert.equal((await host.readCurrentPointer()).generation, 1);
console.log(JSON.stringify({passed:true, processes, actualProductionClients:true,
  synchronousBlocksHost:true, hostBlocksCoreConfig:true, killedSyncOwnerRecovered:true,
  priorGenerationRetained:true, providers:false}));
