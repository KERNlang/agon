// Diagnostic prototype only. Do not import this file into shipping packages.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdirSync, writeFileSync, readFileSync, openSync, fsyncSync, closeSync, unlinkSync } from 'node:fs';
import { mkdtemp } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { DurableModHost, sha256Canonical } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

const source = fileURLToPath(import.meta.url);
const desired = { schemaVersion: 1, fixture: true };
const lockFields = { kernelVersion: '1.0.0', apiVersion: '1.0.0', desiredStateHash: sha256Canonical(desired), packages: [] };
const lock = { schemaVersion: 1, ...lockFields, graphHash: sha256Canonical(lockFields) };
function syncPath(path) {
  const fd = openSync(path, 'r');
  try { fsyncSync(fd); } finally { closeSync(fd); }
}
function withSyncFence(path, action) {
  const at = new Date().toISOString();
  const record = { schemaVersion: 1, ownerId: 'fixture.config', pid: process.pid,
    processIdentity: randomUUID(), fenceToken: randomUUID(), createdAt: at, heartbeatAt: at };
  mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  writeFileSync(path, JSON.stringify(record) + '\n', { flag: 'wx', mode: 0o600 });
  syncPath(path); syncPath(dirname(path));
  try { return action(); }
  finally {
    const selected = JSON.parse(readFileSync(path, 'utf8'));
    if (selected.fenceToken !== record.fenceToken || selected.processIdentity !== record.processIdentity) {
      throw new Error('fixture fence lost; foreign lock retained');
    }
    unlinkSync(path); syncPath(dirname(path));
  }
}

if (process.argv[2] === 'child') {
  const root = process.argv[3];
  const hold = process.argv[4] === 'hold';
  const host = new DurableModHost(root, { kernelVersion: '1.0.0', fault: async phase => {
    if (!hold || phase !== 'after-lock') return;
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('fixture release timeout')), 15000);
      process.once('message', () => { clearTimeout(timeout); resolve(); });
      process.send({ state: 'locked' });
    });
  } });
  try {
    await host.commitGeneration({ operation: 'install', lock, desiredState: desired, installedIndex: {} });
    console.log(JSON.stringify({ committed: true }));
  } catch (error) {
    console.log(JSON.stringify({ committed: false, code: error.code, message: error.message }));
  } finally { if (process.connected) process.disconnect(); }
} else {
  assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
  const root = await mkdtemp(join(tmpdir(), 'config-fence-prototype-'));
  const host = new DurableModHost(root, { kernelVersion: '1.0.0' });
  let subprocesses = 0;
  async function heldWriter() {
    const child = spawn(process.execPath, [source, 'child', root, 'hold'], { stdio: ['ignore', 'pipe', 'pipe', 'ipc'], env: process.env });
    subprocesses++;
    let output = ''; let stderr = '';
    child.stdout.on('data', bytes => { output += bytes; });
    child.stderr.on('data', bytes => { stderr += bytes; });
    const exited = new Promise((resolve, reject) => {
      child.once('error', reject);
      child.once('exit', (code, signal) => resolve({ code, signal, output, stderr }));
    });
    try {
      await Promise.race([
        new Promise(resolve => child.once('message', message => { assert.equal(message.state, 'locked'); resolve(); })),
        exited.then(result => { throw new Error('fixture exited before lock: ' + JSON.stringify(result)); }),
      ]);
      return { child, exited };
    } catch (error) { child.kill('SIGKILL'); await exited; throw error; }
  }
  const writer = await heldWriter();
  try {
    assert.throws(() => withSyncFence(host.paths.writerLock, () => assert.fail('must not enter')), { code: 'EEXIST' });
    const old = JSON.parse(readFileSync(host.paths.writerLock, 'utf8'));
    writeFileSync(host.paths.writerLock, JSON.stringify({ ...old, createdAt: '2000-01-01T00:00:00.000Z', heartbeatAt: '2000-01-01T00:00:00.000Z' }));
    assert.throws(() => withSyncFence(host.paths.writerLock, () => assert.fail('old timestamps must not permit reclaim')), { code: 'EEXIST' });
    await assert.rejects(host.recoverStaleWriter(async pid => {
      try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; }
    }), { code: 'MOD_HOST_BUSY' });
    writer.child.send('release');
    const completed = await writer.exited;
    assert.equal(completed.code, 0, completed.stderr);
    assert.equal(JSON.parse(completed.output).committed, true);
  } finally { if (writer.child.exitCode === null && writer.child.signalCode === null) { writer.child.kill('SIGKILL'); await writer.exited; } }
  withSyncFence(host.paths.writerLock, () => {
    const child = spawnSync(process.execPath, [source, 'child', root, 'once'], { env: process.env, encoding: 'utf8', timeout: 15000 });
    subprocesses++;
    assert.equal(child.error, undefined); assert.equal(child.status, 0, child.stderr);
    assert.equal(JSON.parse(child.stdout).code, 'MOD_HOST_BUSY');
  });
  const killed = await heldWriter();
  killed.child.kill('SIGKILL');
  assert.equal((await killed.exited).signal, 'SIGKILL');
  await host.recoverStaleWriter(async pid => {
    try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; }
  });
  withSyncFence(host.paths.writerLock, () => {});
  assert.equal((await host.readCurrentPointer()).generation, 1);
  console.log(JSON.stringify({ passed: true, root, subprocesses, asyncBlocksSync: true,
    syncBlocksAsync: true, oldTimestampNoReclaim: true, liveOwnerNoReclaim: true,
    killedOwnerRecovery: true, priorGenerationRetained: true, productionIntegration: false }));
}
