import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, readFile, writeFile, unlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { performance } from 'node:perf_hooks';
import { DurableModHost, rollbackGeneration } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { loadConfig, configSet } from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/signals/config.js';
import { artifact, request } from '/Users/ra/dev/agon-audit-qualification/tests/helpers/modular-lifecycle.ts';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const home = await mkdtemp(join(tmpdir(), 'config-generation-reader-live-'));
process.env.AGON_HOME = home;
process.env.AGON_MODULAR_HOST_ROOT = join(home, 'host');
delete process.env.AGON_MOD_SAFE_MODE;
const sourcePath = join(home, 'config.json');
const source = '{"retained":true,"permissions":{"allow":["Read(a)"]}}\n';
await writeFile(sourcePath, source);
const host = new DurableModHost(process.env.AGON_MODULAR_HOST_ROOT, { kernelVersion: '1.0.0' });
const input = request([artifact('@kernlang/agon-mod-forge')]);
const hash = bytes => `sha256:${createHash('sha256').update(bytes).digest('hex')}`;
for (const timeout of [91, 137]) {
  const schema = { type: 'object', properties: { forgeFitnessTimeout: { type: 'number', default: timeout } },
    'x-agon-config': { version: 1, legacyAliases: ['forgeFitnessTimeout'] } };
  await host.commitGeneration({ operation: timeout === 91 ? 'install' : 'update', lock: input.lock,
    desiredState: input.desiredState, installedIndex: {}, files: {
      'config/index.json': JSON.stringify({ schemaVersion: 1, source: { path: sourcePath, contentHash: hash(source) }, selectedHash: hash(source), ownerCount: 1 }),
      'config/source-global.json': source, 'config/selected-global.json': source,
      'config/owners.json': JSON.stringify([{ ownerId: 'agon.forge', version: 1, schema, assetHash: hash(JSON.stringify(schema)) }]),
      'config/migration-receipts.json': '[]',
    } });
  assert.equal(loadConfig().forgeFitnessTimeout, timeout);
}
await rollbackGeneration(host, 1);
assert.equal(loadConfig().forgeFitnessTimeout, 91);
assert.throws(() => configSet('forgeFitnessTimeout', 'invalid'));
assert.equal(await readFile(sourcePath, 'utf8'), source);
configSet('forgeFitnessTimeout', 53);
assert.equal(loadConfig().forgeFitnessTimeout, 53);
await writeFile(sourcePath, '{"retained":true,"permissions":{"allow":[]},"mods":{"absent.owner":"keep"}}\n');
assert.equal(loadConfig().forgeFitnessTimeout, 91);
assert.deepEqual(loadConfig().permissions.allow, []);
assert.equal(loadConfig().mods['absent.owner'], 'keep');
const project = join(home, 'project');
await mkdir(project);
await writeFile(join(project, '.agon.json'), '{"forgeFitnessTimeout":39}');
await writeFile(join(project, '.agon.local.json'), '{"forgeFitnessTimeout":52}');
assert.equal(loadConfig(project).forgeFitnessTimeout, 52);
await unlink(join(project, '.agon.local.json'));
assert.equal(loadConfig(project).forgeFitnessTimeout, 39);
await unlink(join(project, '.agon.json'));
assert.equal(loadConfig(project).forgeFitnessTimeout, 91);
const samples = [];
for (let index = 0; index < 1000; index++) {
  const start = performance.now();
  assert.equal(loadConfig(project).forgeFitnessTimeout, 91);
  samples.push(performance.now() - start);
}
samples.sort((a, b) => a - b);
await writeFile(join(host.root, 'current-generation.json'), '{broken');
assert.throws(() => loadConfig());
process.env.AGON_MOD_SAFE_MODE = '1';
assert.equal(loadConfig().forgeFitnessTimeout, 120);
console.log(JSON.stringify({ passed: true, builtCore: true, builtKernel: true, generations: 2, rollback: 1,
  sourcePreserved: true, directEdits: true, permissionRevocationObserved: true, sparseLayers: true,
  safeMode: true, fixtureGenerationOnly: true, installs: 0, providers: 0,
  populatedHostReads: { calls: 1000, p95Ms: samples[950], maxMs: samples.at(-1) } }));
