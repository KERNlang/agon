import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const repo = '/Users/ra/dev/agon-audit-qualification';
const home = mkdtempSync(join(tmpdir(), 'config-invalid-cli-'));
const path = join(home, 'config.json');
let calls = 0;
for (const bytes of ['{"private":"fixture-private",', 'null', '[]']) {
  writeFileSync(path, bytes);
  const result = spawnSync(process.execPath, [join(repo, 'packages/cli/dist/index.js'),
    'config', 'set', '--key', 'debug', '--value', 'true'], {
    cwd: home, env: { ...process.env, AGON_HOME: home, AGON_MODULAR_HOST_ROOT: join(home, 'modular-host') },
    encoding: 'utf8', timeout: 30000,
  });
  assert.equal(result.error, undefined);
  assert.equal(result.status, 1, result.stdout + result.stderr);
  assert.equal(readFileSync(path, 'utf8'), bytes);
  assert.ok(!(result.stdout + result.stderr).includes('fixture-private'), 'CLI diagnostics disclose configuration contents');
  calls++;
}
console.log(JSON.stringify({ passed: true, calls, malformedBytesPreserved: true, valuesNotLogged: true, providers: false }));
