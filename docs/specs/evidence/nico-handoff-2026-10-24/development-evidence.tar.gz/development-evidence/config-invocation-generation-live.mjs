import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DurableModHost, ModRegistry, readSelectedGenerationConfigurationSync } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { loadConfig } from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/signals/config.js';
import { artifact, request } from '/Users/ra/dev/agon-audit-qualification/tests/helpers/modular-lifecycle.ts';
import { manifest } from '/Users/ra/dev/agon-audit-qualification/tests/helpers/modular-agon.ts';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const home = await mkdtemp(join(tmpdir(), 'config-invocation-generation-'));
process.env.AGON_HOME = home;
process.env.AGON_MODULAR_HOST_ROOT = join(home, 'host');
delete process.env.AGON_MOD_SAFE_MODE;
const sourcePath = join(home, 'config.json');
const source = '{"permissions":{"allow":["Read(a)"]}}';
await writeFile(sourcePath, source);
const host = new DurableModHost(process.env.AGON_MODULAR_HOST_ROOT, { kernelVersion: '1.0.0' });
const input = request([artifact('@kernlang/agon-mod-forge')]);
const hash = bytes => `sha256:${createHash('sha256').update(bytes).digest('hex')}`;
const schemaFor = timeout => ({ type: 'object', properties: { forgeFitnessTimeout: { type: 'number', default: timeout } },
  'x-agon-config': { version: 1, legacyAliases: ['forgeFitnessTimeout'] } });
async function select(timeout) {
  const schema = schemaFor(timeout);
  return host.commitGeneration({ operation: timeout === 91 ? 'install' : 'update', lock: input.lock,
    desiredState: input.desiredState, installedIndex: {}, files: {
      'config/index.json': JSON.stringify({ schemaVersion: 1, source: { path: sourcePath, contentHash: hash(source) }, selectedHash: hash(source), ownerCount: 1 }),
      'config/source-global.json': source, 'config/selected-global.json': source,
      'config/owners.json': JSON.stringify([{ ownerId: 'agon.forge', version: 1, schema, assetHash: hash(JSON.stringify(schema)) }]),
      'config/migration-receipts.json': '[]',
    } });
}
await select(91);
const owner = { id: 'agon.forge', version: '1.0.0', contentHash: hash('fixture') };
const registry = new ModRegistry({ generation: `generated:1:${input.lock.graphHash}`, activeOwners: [owner],
  configurationScope: { hostRoot: host.root, configuration: readSelectedGenerationConfigurationSync(host.root) } });
const declaration = manifest(owner.id);
declaration.contributes.cliCommands = [{ id: 'nested-settings', aliases: [] }];
declaration.contributes.configKeys = [{ id: owner.id, aliases: [] }];
const registration = registry.beginRegistration(declaration);
let resume;
const paused = new Promise(resolve => { resume = resolve; });
let entered;
const ready = new Promise(resolve => { entered = resolve; });
registration.registrar.config(owner.id, schemaFor(91));
registration.registrar.command('cli', { id: 'nested-settings', description: 'Fixture nested settings read', inputSchema: { type: 'object' },
  async run(_input, context) {
    const before = loadConfig().forgeFitnessTimeout;
    entered();
    await paused;
    const after = loadConfig();
    return { exitCode: 0, result: { before, contextTimeout: context.config.forgeFitnessTimeout,
      nestedTimeout: after.forgeFitnessTimeout, permissions: after.permissions.allow } };
  },
});
registration.commit();
const command = registry.resolve('cli-command', 'nested-settings').payload;
const pending = command.run({}, { invocationId: 'fixture', cwd: home, platform: 'darwin-arm64',
  signal: new AbortController().signal, config: loadConfig().mods[owner.id] });
await ready;
await select(137);
await writeFile(sourcePath, '{"permissions":{"allow":[]}}');
resume();
const result = await pending;
await registry.disposeOwner(owner.id);
assert.equal(loadConfig().forgeFitnessTimeout, 137);
assert.deepEqual(result.result.permissions, []);
console.log(JSON.stringify({ builtCore: true, builtRegistry: true, fixtureGenerationOnly: true, result: result.result,
  outsideTimeout: loadConfig().forgeFitnessTimeout, providers: 0, installs: 0 }));
assert.equal(result.result.before, 91);
assert.equal(result.result.contextTimeout, 91);
assert.equal(result.result.nestedTimeout, 91, 'an invocation must not mix its old owner schema with the new generation');
