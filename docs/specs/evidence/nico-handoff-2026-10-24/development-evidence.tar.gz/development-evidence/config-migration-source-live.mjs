import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { DurableModHost, ManagedLifecycleService } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const repo = '/Users/ra/dev/agon-audit-qualification';
const home = await mkdtemp(join(tmpdir(), 'config-migration-source-'));
const hostRoot = join(home, 'modular-host');
const configPath = join(home, 'config.json');
const original = '{"forgeFitnessTimeout":91,"unknown":{"retain":"before-preview"}}\n';
const edited = '{"forgeFitnessTimeout":137,"unknown":{"retain":"after-preview"}}\n';
await writeFile(configPath, original);
const result = spawnSync(process.execPath, [join(repo, 'packages/cli/dist/index.js'), 'setup', '--plan'], {
  cwd: home, env: { ...process.env, AGON_HOME: home, AGON_MODULAR_HOST_ROOT: hostRoot },
  encoding: 'utf8', timeout: 30000,
});
assert.equal(result.error, undefined);
assert.equal(result.status, 0, result.stderr + result.stdout);
const preview = JSON.parse(result.stdout);
assert.equal(preview.status, 'planned');
await writeFile(configPath, edited);
const host = new DurableModHost(hostRoot, { kernelVersion: '1.0.0' });
let failure;
try {
  // Metadata-only fixture installer; no package manager or executable mod runs.
  await new ManagedLifecycleService(host).apply(preview.lifecycle, {
    async install(entry, prefix) {
      const path = join(prefix, 'node_modules', entry.id);
      await mkdir(path, { recursive: true });
      await writeFile(join(path, 'package.json'), JSON.stringify({ name: entry.id, version: entry.version }));
    },
  }, { async verify(prefix, plan) {
    const checks = await Promise.all(plan.packages.map(async entry => ({ id: entry.id,
      passed: JSON.parse(await readFile(join(prefix, 'node_modules', entry.id, 'package.json'), 'utf8')).version === entry.version })));
    return { passed: checks.every(check => check.passed), checks };
  } });
} catch (error) { failure = error; }
const pointer = await host.readCurrentPointer();
const manifest = pointer ? await host.validateGeneration(pointer.generation) : null;
const hash = value => createHash('sha256').update(value).digest('hex');
console.log(JSON.stringify({
  previewSourceHash: hash(original), applySourceHash: hash(edited),
  errorCode: failure?.code ?? null, selectedGeneration: pointer?.generation ?? null,
  generationFiles: manifest ? Object.keys(manifest.files) : [],
  sourceBytesPreserved: await readFile(configPath, 'utf8') === edited,
  fixturePackagesOnly: true, providers: false,
}));
assert.ok(failure, 'setup accepted a plan after its config source changed; migration source is not bound');
assert.equal(failure.code, 'MOD_TRANSACTION_CONFLICT');
assert.equal(pointer, null, 'a stale configuration plan must not select a generation');
assert.equal(await readFile(configPath, 'utf8'), edited);
