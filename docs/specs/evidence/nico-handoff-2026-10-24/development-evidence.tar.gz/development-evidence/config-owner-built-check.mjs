import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const repo = '/Users/ra/dev/agon-audit-qualification';
assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const root = mkdtempSync(join(process.env.TMPDIR, 'config-owner-built-'));
process.env.AGON_HOME = join(root, 'first');
process.env.AGON_MOD_SAFE_MODE = '1';
const load = relative => import(pathToFileURL(join(repo, relative)).href);
const core = await load('packages/core/dist/signals/config.js');
const types = await load('packages/core/dist/models/types.js');
const persistence = await load('packages/support-persistence/dist/index.js');
const names = ['loadConfig', 'configSet', 'configGet', 'invalidateConfigCache',
  'ensureAgonHome', 'pruneRuns', '_configMemoCache'];
for (const name of names) assert.strictEqual(core[name], persistence[name], name);
assert.strictEqual(types.DEFAULT_AGON_CONFIG, persistence.DEFAULT_AGON_CONFIG);
assert.strictEqual(types.DEFAULT_CONFIG, persistence.DEFAULT_CONFIG);

core.configSet('debug', true);
assert.equal(persistence.configGet('debug'), true);
assert.equal(JSON.parse(readFileSync(join(root, 'first', 'config.json'))).debug, true);
const first = core.loadConfig();
first.goalReviewEngines.push('fixture-mutation');
assert.ok(!persistence.loadConfig().goalReviewEngines.includes('fixture-mutation'));
process.env.AGON_HOME = join(root, 'second');
assert.equal(core.configGet('debug'), persistence.DEFAULT_AGON_CONFIG.debug);
persistence.configSet('debug', false);
assert.equal(core.configGet('debug'), false);
process.env.AGON_HOME = join(root, 'first');
assert.equal(core.configGet('debug'), true);

// A copied function must fail the same identity oracle.
const duplicate = (...args) => persistence.loadConfig(...args);
assert.throws(() => assert.strictEqual(core.loadConfig, duplicate));
console.log(JSON.stringify({ passed: true, sharedExports: names,
  defaultIdentity: true, crossSurfaceWrite: true, cloneIsolation: true,
  dynamicHomeIsolation: true, duplicateOwnerNegativeControl: true, fixture: root }));
