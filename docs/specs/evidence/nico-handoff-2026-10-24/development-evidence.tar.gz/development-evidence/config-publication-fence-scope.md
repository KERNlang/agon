# Config publication fence

Status: verified increment committed; durable settings migration still incomplete.
Baseline: 6f252733026c3f86431e30b5772069cd24b6b682, clean qualification worktree.
Green baseline: selected-desired-owner-final (8,589 tests, six skipped; types,
lint, affected builds, API/pack/supply-chain and performance gates, real CLI runs).

## Purpose

Preserve synchronous configSet completion while serializing config writes against
the existing host generation writer. Do not add another independent lock protocol.
This does not yet implement versioned settings snapshots or staged migrations.

## Existing machinery and proof

WriterFence owns versioned exclusive-create records and explicit dead-owner
recovery. Host commit, rollback and recovery already use host.paths.writerLock.
The old config TTL lock has a different protocol and must not share that path.

External prototype `config-fence-prototype.mjs` uses the actual built host in
three child processes. It proves async blocks sync, sync blocks async, old
timestamps do not permit reclaim, live-owner recovery refuses, and killed-owner
recovery permits subsequent sync access while retaining generation 1.
Receipt `config-fence-prototype.receipt.json`, log SHA-256
4c510d4d3a1612ccf341670fe13f0a15cdf11383aa1f506fe07046837c033132.
It is not production integration and is not an oracle for all crash windows.

## Production boundary

Add synchronous acquisition/release on the same WriterFence record protocol.
Share ownership record construction and ownership checks with the async client.
Core's existing config-store lock injection composes the existing config lock
outside the host fence. Host paths resolve dynamically from AGON_HOME and the
existing AGON_MODULAR_HOST_ROOT override. All config writes participate, including
before the first installed generation; otherwise first installation has a race.
Consequently a config write can create the host locks directory before setup.
No generation, activation, trust or installation is created by that directory.

Lock order: legacy config lock then host writer fence. Host publication never
acquires the legacy config lock. Busy host state refuses the synchronous write
with MOD_HOST_BUSY and leaves source bytes unchanged. No TTL-based takeover.
No asynchronous callback is permitted in the synchronous wrapper contract.

## Blast radius

Planned production files: writer-lock.ts, kernel index.ts, Core signals/config.ts.
Planned tests: writer-lock safety and config-store tests; external process probe.
Generated release metadata refreshed after verification. Existing WriterFence
consumers are traced in durable-host, host-rollback, lifecycle-recovery,
managed-lifecycle, leases, external activation and transactional authority.
They retain their async API/protocol. Risk: high, cross-process mutation boundary.
No new dependency or installation. No active/global or personal-state mutation.

## Acceptance

- Actual Core configSet fails while a real async host fence is held; original
  bytes remain exact. It succeeds after release and remains synchronous.
- Actual host commit refuses while the synchronous client holds the same path.
- Exception cleanup releases only the caller's own record; ownership loss never
  deletes a foreign record. Unknown liveness and malformed records fail closed.
- Separate processes prove exclusion and killed-owner recovery.
- Dynamic home/host paths do not share state. Existing config scope, alias,
  disabled namespace preservation and clone contracts stay unchanged.
- Full repository gates and relevant live probes pass before local commit.

Do not claim migrations complete. Next: bind source revisions and schema-backed
staged outputs into lifecycle plans, then route reads/writes/rollback through
the selected settings snapshots using this same publication authority.

## Independent review and corrections

Frozen review tree: fa4f53e96fa37aff41ebe40e03352581bd5e288e.
Packet SHA-256: 6421d9ea4d81af3a7700009b0769601afc2b4fdfdbb6155b55a51c64fd55ad97.
Codex review completed; log SHA-256:
ee74fb342089a38bd4f21d409b5f9afd7065715f0f0d84f1f30f1d2f18abc060.
Kimi exited 1 without review. That is missing evidence, not a pass; no auth repair.

P1 confirmed: sync failure after complete exclusive record creation stranded a
live-owner lock. Both async and new sync acquisitions now attempt ownership-
checked cleanup and retain the original error. Partial or malformed writes
remain fail-closed; automatic repair of those existing protocol limitations is
not claimed. Tests inject file and directory sync failure separately.

P2 confirmed: release failure concealed action failure. Both failures now remain
in AggregateError.errors; a replacement owner's record remains untouched.
Successful action followed by release failure instead reports MOD_RESTART_REQUIRED
with outcome action-completed, so callers cannot mistake it for a refused write.

Additional controls cover first-write directory creation, dynamic home/host roots,
and accidental async callbacks. The callback type rejects Promise returns; the
runtime guard rejects AsyncFunction. This is not a sandbox against JavaScript
callbacks that conceal background work.

Red controls: config-fence-review-red (five failures), and
config-fence-release-outcome-red (completed-action classification failure).
Both raw receipts/logs are retained beside this note.

Final focused receipt: config-fence-final-controls.receipt.json, exit 0,
77 tests, types, Kernel build, actual built Core/host probe and three-process
production-client exclusion/dead-owner recovery probe; 14.491 seconds.
Log SHA-256: a4f3a66d55cfb5477d52deff5b8ab8b74fb13b344475e09ceb0377972eddc695.
Provider launches: zero. This does not prove full release acceptance or migration.

## Committed result

Commit: 72f50beeb4388a1c4d61729e261b1a747927e830.
Tree: d1ed447030a34fccfb05222186336dbc1a48e5cb.
Eight explicit paths: five authored files and three generated release metadata
files. Qualification worktree clean; candidate ref/index advanced without
updating its preserved working files. No push, install or personal-state change.

Full gate: config-fence-full-gates, exit 0, 356.189 seconds.
Log SHA-256: d7689a4c9d84924c1ba907dbc43e92a235879aef2dfd7554b87e612e60c267de.
Full workspace build, typecheck, lint, reexports, public API compatibility,
first-party generation drift, release-set and supply-chain validation/self-tests
passed. Repository tests: 8,603 passed, six skipped; 642 files passed, one skipped.
All existing release performance budgets passed on darwin-arm64, Node 26.3.0.
Other native platforms and Node versions were not tested by this run.

End-to-end checks ran last: actual Core/host exclusion; three-process mutual
exclusion and killed-owner recovery; five real config CLI calls; six real setup/
update-preview and mod-list calls with metadata-only fixture installations.
No real npm install and zero provider launches. No live-provider acceptance claim.

Preservation checks config-fence-preserved-before/after passed for the existing
281-path baseline with its previously recorded exceptions. Both log hashes:
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Exact-commit qualification is recorded separately as config-fence-clean-subject;
it must not inherit release approval from the above working-tree gate.

That diagnostic is RED: review subject mismatch and no clean-install steps.
Index and commit subject hashes match:
dc270bd2eb236f3a71d97befa8eca532e175772c7543d4edc09f1c4a0b7d7e70.
No ignored, untracked or unstaged source contamination. Graph: 49 packages,
151 declared/unique edges, no duplicates. Diagnostic log SHA-256:
cedf68f05f06d880d7895cac53725d2976fbea929dbe39e2ac90e538e3803add.
The verifier reads the tracked slice1b review record from the exact Git subject;
bounded external increment reviews do not replace final subject-bound review.
Its --run-clean path runs npm ci. That was not executed under the no-install
constraint. Neither missing requirement has been waived or marked green.
