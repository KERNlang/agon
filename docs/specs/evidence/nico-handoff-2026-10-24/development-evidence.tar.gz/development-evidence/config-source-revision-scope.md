# Config source revision binding

Status: verified increment committed; complete config migration still open.
Baseline: 72f50beeb4388a1c4d61729e261b1a747927e830; qualification checkout clean.
Verified green baseline: config-fence-full-gates, 8,603 tests, six skipped,
full workspace build and release/performance/live checks. Release acceptance is
not green: final subject-bound review and clean-install qualification remain open.

## Defect and contract

The built CLI preview followed by a changed config source was accepted by the
built lifecycle service. Receipt config-migration-source-red preserves the failing
case. No data was lost; required migration source qualification was absent.
Runtime contract phase 2 requires "Run declarative data/config migrations against
staged copies" and atomic selection of the qualified generation. Binding the
source is necessary before those outputs can be safely published.

## Change

Reuse migration-engine.ts for capture/verification of an exact source revision
(absolute path, SHA-256 or explicit missing-file marker). Propagate the optional
revision through the hashed lifecycle plan. Setup always supplies its current
global config revision. No config values appear in plans, logs or receipts.
Refuse changed sources before staging and again under the existing host writer
fence immediately before publication. Capture missing files distinctly from
empty files; permission/read failures are errors, not absence.

No new independent state, lock, package, installer, resolver or migration engine.
The optional field preserves existing lifecycle callers that do not migrate
configuration. It must not be described as completing the versioned migration
contract. A future migration descriptor must carry this revision, not bypass it.

## Blast radius and tests

Five production files: migration-engine, kernel index, durable-host,
managed-lifecycle, CLI setup. Existing tests: setup-selection,
lifecycle-concurrency, host-boundaries and migration-engine. Generated release
metadata follows normal verification. Risk: high, transaction publication.

Test source edits before apply, during staging, and immediately before pointer
selection; creation/deletion; unchanged bytes; missing/unreadable sources; plan
hash binding/tampering; old-generation retention and re-entry. Existing transaction
cleanup must discard only this candidate, never prior selected data.
The original live reproduction must turn green; no provider/install is involved.

## Limits

External editors do not obey the host fence. Revalidation detects observed edits;
it is not an OS-wide compare-and-swap guarantee against arbitrary editors in the
final read/rename window. Versioned source backup and generation-bound readers
remain necessary for the complete migration contract.
No push, install, global Agon mutation or personal-state change.

## Evidence in progress

Three source tests failed before the fix: setup source edit, edit after package
staging, edit after prefix promotion. config-source-revision-red log SHA-256:
5f08047e1f98f73a2a1dc860e66dde4b84aa1c7eb1d874861a8823b0bc545adc.

config-source-revision-controls passed 54 tests, types and Kernel build in
15.382 seconds, zero provider launches. Log SHA-256:
7cfd76e797aabaec34543e59015a2353706fad4d96311cd3c75052ab30d65e42.
Controls now cover exact plan hash/tampering, source creation/deletion, unreadable
sources, missing versus empty, malformed identities, three host publication
boundaries, prior generation byte preservation and fresh-plan re-entry.

Review subject: 9da1556471a0eca9115516281453f7838fa5d787 (frozen staged tree).
Default isolated Codex/Kimi review packet: config-source-revision-review-input.txt.

Codex completed with one P2 finding, reproduced before correction: a mutable
JSON-deserialized plan could lose or replace configSource during verification.
Two negative controls both committed incorrectly before the fix. Receipt
config-source-review-red; log SHA-256:
d400733cc1a4b9352adcb6983a47fa4569befa99857819cd9a6a65e34198a46b.
Apply now clones and deeply freezes the entire input before its first await,
validates that snapshot's hash and retains it through all callbacks/publication.
The review's cleanup evidence gap is also covered: failed candidate prefix and
staging directories are absent, while prior installation entries remain exact.

Review packet SHA-256:
d962945348d9151f0f1513564c78e01732a59be66c4c32702e46ef18ec627195.
Codex log SHA-256:
b57fdabcbef9857b682a30b788c09c3c77eacc7c9be71141c4d590d2a72c6606.
Kimi exited 1 without review, not a pass. No login or personal-state repair.

Built CLI reproduction now rejects with MOD_TRANSACTION_CONFLICT, selects no
generation and preserves the edited bytes. config-source-revision-live log:
12093d5ddf6f2b185fcc3a61d7d169d6ba71d0f84a79f805df173f3d7e3a245e.
The live assertion was subsequently tightened to require that exact error code;
it will run again at the end of the final full gate.

## Committed result

Commit d7562383518cc29e9cefbd5e754b70c470e2b2e8.
Tree bf83dcebdb9ece8ff0c0997f432ba3eda81a461b.
Nine authored paths plus three generated release files. Qualification checkout
clean; candidate branch/index advanced without rewriting its working files.

config-source-full-gates passed in 359.735 seconds, zero provider launches.
Log SHA-256: bab67f123e16f503edb686c60ceb38f995ca788d67056fa8feb2d4a2f95c7ef9.
Full build, typecheck, lint, reexports, API compatibility, generated drift,
release-set, supply-chain and self-tests passed. Full suite: 8,616 tests passed,
six skipped; 642 files passed, one skipped. Existing performance budgets passed
on native darwin-arm64, Node 26.3.0. This is not other-platform evidence.
Last checks: tightened stale-preview CLI reproduction, real Core/host exclusion,
three-process killed-owner recovery, six setup/update/mod-list subprocess calls,
and activation artifact preservation through rollback and re-entry.

281-path preservation baseline passed before and after with its prior exceptions.
Both preservation log hashes:
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.

Exact-commit diagnostic config-source-clean-subject is RED, not waived. It found
no ignored/untracked/unstaged source contamination, 49 packages and 151 unique
edges without duplicates. Index/commit subject hash matches:
b3005d23d5c8832fd1cf08433e2c59b5d652906f6c12ee8e1761d3b4f6a8a35f.
Stored final review remains bound to an older subject; --run-clean was not run
because it installs dependencies. Diagnostic log SHA-256:
2910657e4b49220fc640d9014504ebdf0ccf169c9eb80fdf892f72409f38d8e3.

No push, install, active/global Agon or personal-state change. Existing architecture
still needs durable versioned settings snapshots, staged declarative migrations,
generation-bound readers/writers, rollback and old-generation invocation coverage.
