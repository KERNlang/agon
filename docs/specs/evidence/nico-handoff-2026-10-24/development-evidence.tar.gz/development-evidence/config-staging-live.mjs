import assert from 'node:assert/strict';
import { cp, mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { DurableModHost, ManagedLifecycleService, createManagedLifecyclePlan, readMigrationSourceRevision,
  rollbackGeneration, sha256Canonical } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { artifact, request } from '/Users/ra/dev/agon-audit-qualification/tests/helpers/modular-lifecycle.ts';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const root = await mkdtemp(join(tmpdir(), 'config-staging-live-'));
const packageRoot = '/Users/ra/dev/agon-audit-qualification/packages/mod-forge';
const manifest = JSON.parse(await readFile(join(packageRoot, 'agon.mod.json'), 'utf8'));
const source = join(root, 'config.json');
const host = new DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0' });
const service = new ManagedLifecycleService(host);
const entry = artifact('@kernlang/agon-mod-forge', [], { manifestHash: sha256Canonical(manifest) });
const installer = { async install(entry, prefix) {
  const target = join(prefix, 'node_modules', entry.id);
  for (const path of [...new Set(['package.json', ...manifest.pack.include])]) {
    await mkdir(dirname(join(target, path)), { recursive: true });
    await cp(join(packageRoot, path), join(target, path));
  }
} };
let verifications = 0;
for (const timeout of [91, 137]) {
  const bytes = JSON.stringify({ forgeFitnessTimeout: timeout, autoReviewAfterForge: false, retained: { unknown: true } }, null, 2) + '\n';
  await writeFile(source, bytes);
  const plan = await createManagedLifecyclePlan(host, request([entry], {
    operation: timeout === 91 ? 'install' : 'update', configSource: await readMigrationSourceRevision(source),
  }));
  const result = await service.apply(plan, installer, { async verify(prefix) {
    const selected = JSON.parse(await readFile(join(prefix, '.agon-config/selected-global.json'), 'utf8'));
    assert.deepEqual(selected.mods['agon.forge'], { forgeFitnessTimeout: timeout, autoReviewAfterForge: false });
    assert.deepEqual(selected.retained, { unknown: true });
    assert.equal(await readFile(join(prefix, '.agon-config/source-global.json'), 'utf8'), bytes);
    verifications++;
    return { passed: true, checks: [{ id: 'actual-forge-owner-config', passed: true }] };
  } });
  await host.validateGeneration(result.pointer.generation);
  assert.equal(await readFile(source, 'utf8'), bytes);
  const generation = host.generationPath(result.pointer.generation);
  assert.equal(await readFile(join(generation, 'config/source-global.json'), 'utf8'), bytes);
  const receipts = JSON.parse(await readFile(join(generation, 'config/migration-receipts.json'), 'utf8'));
  assert.equal(receipts.length, 1);
  assert.equal(receipts[0].receipt.ownerId, 'agon.forge');
  assert.equal(await readFile(join(generation, receipts[0].sourceArtifact), 'utf8'), bytes);
}
const edited = '{"forgeFitnessTimeout":250,"operatorEdit":"retain after rollback"}\n';
await writeFile(source, edited);
await rollbackGeneration(host, 1);
assert.equal((await host.readCurrentPointer()).generation, 1);
assert.equal(await readFile(source, 'utf8'), edited);
const oldSelected = JSON.parse(await readFile(join(host.generationPath(1), 'config/selected-global.json'), 'utf8'));
assert.equal(oldSelected.mods['agon.forge'].forgeFitnessTimeout, 91);
console.log(JSON.stringify({ passed: true, verifications, realOwner: 'agon.forge', builtKernel: true,
  generations: 2, rollback: 1, currentEditsPreserved: true, settingsReadersNotYetIntegrated: true,
  fixturePackageCopyOnly: true, installs: 0, providers: 0 }));
