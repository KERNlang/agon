import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const repo = '/Users/ra/dev/agon-audit-qualification';
const root = mkdtempSync(join(tmpdir(), 'config-store-live-'));
const home = join(root, 'agon');
const project = join(root, 'project');
mkdirSync(home);
mkdirSync(project);
const env = { ...process.env, AGON_HOME: home };
const calls = [];
function run(args, expectedStatus = 0) {
  const result = spawnSync(process.execPath, args, { cwd: project, env, encoding: 'utf8', timeout: 30000 });
  assert.equal(result.error, undefined);
  assert.equal(result.status, expectedStatus, result.stderr + result.stdout);
  calls.push({ args, status: result.status });
  return result.stdout.trim();
}
const cli = join(repo, 'packages/cli/dist/index.js');
run([cli, 'config', 'set', '--key', 'debug', '--value', 'true']);
assert.equal(run([cli, 'config', 'get', '--key', 'debug']), 'true');
const configPath = join(home, 'config.json');
const before = readFileSync(configPath, 'utf8');
run([cli, 'config', 'set', '--key', 'unknown-fixture-key', '--value', 'unsafe'], 1);
assert.equal(readFileSync(configPath, 'utf8'), before);
writeFileSync(configPath, JSON.stringify({ debug: true, permissions: { deny: ['Bash(rm:*)'] } }));
writeFileSync(join(project, '.agon.json'), JSON.stringify({ debug: false, permissions: { allow: ['Read(*)'] } }));
writeFileSync(join(project, '.agon.local.json'), JSON.stringify({ debug: true, permissions: { deny: ['Bash(git push:*)'] } }));
const core = pathToFileURL(join(repo, 'packages/core/dist/index.js')).href;
const value = JSON.parse(run(['--input-type=module', '-e',
  `import { loadConfig } from ${JSON.stringify(core)}; const c = loadConfig(process.cwd()); console.log(JSON.stringify({ debug: c.debug, permissions: c.permissions }));`]));
assert.deepEqual(value, { debug: true, permissions: {
  allow: ['Read(*)'], deny: ['Bash(rm:*)', 'Bash(git push:*)'],
} });
console.log(JSON.stringify({ passed: true, root, calls, scopedPermissions: value.permissions }));
