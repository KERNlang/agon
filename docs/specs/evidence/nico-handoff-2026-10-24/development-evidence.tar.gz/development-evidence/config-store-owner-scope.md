# Configuration storage owner

Status: building under the accepted ownership-remediation goal.
Base: 64ecbc42b0c6eb2d96a439c65c34d6efafbdd248.
Baseline: roadmap-status-qualified, full build/types/lint/reexports and 8,458
tests passed with six skips, zero provider launches.

## Scope and contract

Move file read, mtime cache, clone isolation, atomic write and cache invalidation
mechanics from Core config.ts into Kernel. Keep defaults, normalization, key
validation, ConfigError identity, run pruning, and Core public exports unchanged.
Kernel takes the existing path resolver, merge policy and synchronous lock as
injected capabilities: it must not depend on support-persistence or Core.
No new package edge, dependency, installation or configuration option.

The original idea to move all AgonConfig declarations/defaults into Kernel is
rejected: the ledger assigns 121 config keys to nine owners. The store is shared
mechanics, not ownership of those policies. No claim of complete config or
Brainstorm host retirement follows from this increment.

Authored scope: Kernel store and barrel; Core config.ts; focused store tests.
Generated release/SBOM inputs may need refresh after compiled contents change.
Risk: shared configuration I/O, cache identity, permission precedence and writes.
Public callers stay unchanged; no mass import rewrite.

## Evidence required

- Kernel works without importing Core or hidden support packages.
- Dynamic home/project paths, three-scope precedence, and cloned cache hits/misses.
- Writes read under the supplied lock and invalidate only after successful write.
- Missing/malformed files retain existing warning/fallback behavior.
- Existing memoization, permissions and config callers retain behavior.
- Negative control fails when Kernel storage does not exist.
- Actual isolated filesystem exercise after full gates; no personal paths.
- One default Agon review; preserve and resolve findings against source.

Keep original requirements and frozen ownership counts; legacy Core facade and
per-key policy remain visible pending subsequent owner retirement.

## Trace and controls

73 production source files mention loadConfig/configSet/invalidateConfigCache or
the cache; 25 source/test files mention AgonConfig/default declarations. Commands:
`rg -l '\b(loadConfig|configSet|invalidateConfigCache|_configMemoCache)\b' packages --glob '*.ts' --glob '!**/dist/**'`
and the equivalent type/default search across packages/tests. Callers need no
changes; direct authored scope remains four files. Backup ref:
backup/config-store-owner-64ecbc42.

Exact merge/normalization policy remains 2,750 identical bytes, SHA-256
0d7d2ccfbfd0712c2f330039f59056052edafabc45612f3a5949d47bff479df3.
Verified by comparing the original Git blob's merged-object through permission
aggregation block to the extracted callback. Defaults and pruning are unchanged.

New tests failed before implementation: four missing-factory failures.
config-store-owner-red log SHA-256:
d97032a9fc0328a8bcdc924d909fd8f8757a74880e6ff1057fc81644983a3132.
Initial build found a generic empty-object inference error; explicit Partial<T>
annotation repaired it. No runtime cast or relaxed compiler gate was added.
Focused run then passed 97 tests and typecheck; expanded controls passed 100
tests, lint and reexports. Last log SHA-256:
8da03402fa9d47356e7fe43e96bee09bd3d8b7d09e4e45c5f5d648465b525205.

Replacing only Core config.ts with its exact base Git blob makes the shared-cache
ownership test fail: Kernel factory called zero times. The edited source was
restored immediately afterward. config-store-owner-legacy-negative log SHA-256:
d715d8bc78bb6f6b1a197feff495a792271df3359505c29edbf0e5a4ec00f38f.

## Independent review

Agon reviewed tree be592fa3534231569ab1b856fd169fdf74e180c5.
Packet SHA-256: fd89b452c47103cb9d777044e3e266afa8ee8912c7880e54838c7432414901cf.
Codex found no source-level regression. It correctly identified oracle gaps:
write invalidation was not distinguished from mtime changes, and home/scope
cache tests did not force equal/different mtimes. Added direct cache-empty checks,
equal-home mtimes, same-mtime explicit invalidation, and independent project and
private-project mtime controls. No policy behavior changed to satisfy the tests.
Codex log SHA-256: 6c9d97c0a8468881744bf62dc38b2a1c5581536a220fd41f2c547cc4d94b7160.
Kimi produced no answer (exit 1); no authentication repair attempted.

## Next unresolved configuration boundary

Verified, not inferred: Forge and Review schemas/config.schema.json contain only
type object plus additionalProperties true, without their assigned key policies.
First-party manifests list opaque configKeys IDs. Registry.config registers a
schema, but this does not supply the existing Core defaults or merge behavior.
Thus moving storage alone must not mark these per-key owners complete. Follow-up
must migrate concrete key policy/default ownership and bind it into the host;
merely generating more schemas would leave the runtime owner unchanged.

## Completed increment

Commit fb77dc970e720403cb18a27577b5ebf9b2ad1a9b; tree
87c22a712c2d9e71dd6ecd0e30dca2580197b737. Seven files: four authored and
three generated release metadata files. Kernel and launcher tarball hashes
changed; launcher chunk names changed transitively. No package dependency changed.

Full gate passed once (config-store-owner-qualified, 306.740 seconds): build,
typecheck, lint, reexports, release-set and supply-chain generation/check/negative
controls, 8,468 passing tests and six skips. Provider launches zero.
Log SHA-256: 69758a26125e7313b15d7b06fad0ad00313957ba827fd133bbb9051aa7b8eed7.

Live checks ran twice, each in a fresh isolated home: actual built CLI sets and
gets debug, rejects an unknown key without changing bytes; built Core reads all
three scopes and preserves global/project permission rules. Four subprocesses
per run; no provider launch. No real user config is read or changed.

Two targeted negative controls both failed for the intended assertion:
- Removing write invalidation left two entries instead of zero; log hash
  0a3f0fb279f18d508cf98b414d3512507d4cc809c906816ccb16c59e104223a4.
- Removing globalPath from the cache key returned the first home's value in the
  second home with equal mtimes; log hash
  616b5ca19638b1e711076d0d84c2ad2ee1c075b7c8ff2cb89120a61ad337e1ce.
Both source mutations were restored immediately. The final focused run passed
103 tests plus the second live run, hash
7a02ce211b509b7eaf6b5fa9555bc810d19898725269c29a3ec5f1ec4d723a40.

Roadmap and support-boundary structural checks also pass; not full ownership
acceptance. Candidate branch advanced with CAS and index-only read-tree; preserved
working bytes pass the before/after check with identical hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification checkout clean. No installs, push or global/personal-state changes.
Core still owns policy/default composition and pruning; this is not full release
or Brainstorm-host-retirement acceptance.
