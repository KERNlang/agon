import { execFileSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createMod } from '/Users/ra/dev/agon-audit-qualification/packages/mod-conquer/dist/index.js';
import { runDoneOracle } from '/Users/ra/dev/agon-audit-qualification/packages/forge/dist/index.js';

const cwd = mkdtempSync(join(tmpdir(), 'conquer-oracle-parity-'));
const git = (...args) => execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
git('init');
git('config', 'user.name', 'Isolated parity fixture');
git('config', 'user.email', 'fixture@example.invalid');
mkdirSync(join(cwd, 'tests'));
writeFileSync(join(cwd, 'tests/check.sh'), 'exit 1\n');
git('add', 'tests/check.sh');
git('commit', '-m', 'fixture baseline');
let providerCalls = 0;
const services = {
  identity: { id: 'agon.conquer', version: '1.0.0', contentHash: `sha256:${'a'.repeat(64)}` },
  logger: { debug: async () => {}, info: async () => {}, warn: async () => {} },
  receipts: { record: async () => 'isolated-fixture' },
  permissions: { check: () => {} }, state: { read: async () => null, write: async () => {} },
  engines: {
    listActive: async () => ['fixture-builder'],
    rank: async ids => ids.map(engineId => ({ engineId, reason: 'fixture', scope: null })),
    dispatch: async (engineId, _prompt, context, options) => {
      providerCalls++;
      if (options.mode !== 'agent') throw new Error('Unexpected non-builder dispatch');
      writeFileSync(join(context.cwd, 'tests/check.sh'), 'exit 0\n');
      return { engineId, exitCode: 0, stdout: 'CONQUER_DONE: gate passes', stderr: '', timedOut: false };
    },
  },
};
let command;
const registrar = new Proxy({}, { get: (_, name) => (...args) => {
  if (name === 'command' && args[0] === 'cli') command = args[1];
  return () => {};
} });
await (await createMod(services)).activate(registrar);
const context = { invocationId: 'parity', cwd, platform: 'darwin-arm64', signal: new AbortController().signal, config: {} };
const current = await command.run({ task: 'Fix the implementation without weakening tests', gate: 'sh tests/check.sh', builder: 'fixture-builder', maxTurns: '1' }, context);
const diff = current.result?.winningPatch ?? current.result?.lastPatch ?? '';
const legacy = await runDoneOracle({ claim: 'gate passes', diff, gate: 'sh tests/check.sh', gateOk: true,
  oracleTampered: false, engines: [], registry: {}, adapter: {}, timeout: 1, outputDir: cwd, cwd });
console.log(JSON.stringify({ fixture: cwd, simulatedBuilderCalls: providerCalls,
  current: { exitCode: current.exitCode, status: current.result?.status }, legacy, diff }, null, 2));
if (current.exitCode === 0 && legacy.passed === false) process.exitCode = 1;
