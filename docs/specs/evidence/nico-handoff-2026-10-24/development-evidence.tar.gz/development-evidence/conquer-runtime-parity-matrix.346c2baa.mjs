import { execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createMod } from '/Users/ra/dev/agon-audit-qualification/packages/mod-conquer/dist/index.js';
import { runConquer } from '/Users/ra/dev/agon-audit-qualification/packages/forge/dist/index.js';

process.env.AGON_NO_KERN_CONTEXT = '1';
const results = [];
for (const scenario of ['healthy', 'missing-claim', 'builder-failure', 'green-baseline', 'numeric-turn-cap', 'tui-options']) {
  const cwd = mkdtempSync(join(tmpdir(), 'conquer-parity-matrix-'));
  const git = (...args) => execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  git('init'); git('config', 'user.name', 'Parity fixture'); git('config', 'user.email', 'fixture@example.invalid');
  writeFileSync(join(cwd, 'README.md'), 'baseline\n');
  git('add', 'README.md'); git('commit', '-m', 'fixture baseline');
  const gate = scenario === 'green-baseline' ? 'true' : scenario === 'numeric-turn-cap' ? 'false' : 'test -f solved.txt';
  const stdout = scenario === 'missing-claim' || scenario === 'numeric-turn-cap' ? 'still working' : 'CONQUER_DONE: feature works';
  const calls = [];
  const services = {
    identity: { id: 'agon.conquer', version: '1.0.0', contentHash: `sha256:${'a'.repeat(64)}` },
    logger: { debug: async () => {}, info: async () => {}, warn: async () => {} },
    receipts: { record: async () => 'fixture' }, permissions: { check: () => {} },
    state: { read: async () => null, write: async () => {} },
    engines: {
      listActive: async () => scenario === 'tui-options' ? ['builder', 'advisor-a', 'advisor-b'] : ['builder'],
      rank: async ids => ids.map(engineId => ({ engineId, reason: 'fixture', scope: null })),
      dispatch: async (engineId, _prompt, context, options) => {
        if (options.mode !== 'agent') throw new Error('Unexpected consult');
        calls.push({ engineId, timeout: options.timeoutSeconds });
        const failed = scenario === 'builder-failure' && calls.length === 1;
        if (!failed && scenario !== 'numeric-turn-cap') writeFileSync(join(context.cwd, 'solved.txt'), 'yes\n');
        return { engineId, exitCode: failed ? 1 : 0, stdout, stderr: '', timedOut: false };
      },
    },
  };
  let cli, tui;
  const registrar = new Proxy({}, { get: (_, name) => (...args) => {
    if (name === 'command' && args[0] === 'cli') cli = args[1];
    if (name === 'command' && args[0] === 'tui') tui = args[1];
    return () => {};
  } });
  await (await createMod(services)).activate(registrar);
  const context = { invocationId: scenario, cwd, platform: 'darwin-arm64', signal: new AbortController().signal, config: {} };
  const input = scenario === 'tui-options'
    ? tui.parse('/conquer build feature --gate "test -f solved.txt" --builder builder --engines advisor-a --max-turns 1 --timeout 7')
    : { task: 'build feature', gate, builder: 'builder', maxTurns: scenario === 'numeric-turn-cap' ? 1 : scenario === 'builder-failure' ? '2' : '1' };
  const current = await (scenario === 'tui-options' ? tui : cli).run(input, context);
  let legacyCalls = 0;
  const legacy = await runConquer({ task: 'build feature', builderEngine: 'builder', advisorEngines: [],
    registry: { get: id => ({ id }) }, cwd, outputDir: cwd, timeout: 7,
    caps: { maxTurns: scenario === 'builder-failure' ? 2 : 1, maxWallClockMs: 0 },
    adapter: { dispatch: async () => {
      legacyCalls++;
      return { exitCode: scenario === 'builder-failure' && legacyCalls === 1 ? 1 : 0, stdout, stderr: '', timedOut: false };
    } }, evaluateDone: async () => ({ diff: '', gateOk: scenario !== 'numeric-turn-cap', oracleTampered: false }),
  });
  results.push({ scenario, parsedInput: input,
    current: { exitCode: current.exitCode, status: current.result?.status, advisers: current.result?.advisors,
      builderCalls: calls.length, timeouts: [...new Set(calls.map(call => call.timeout))] },
    legacy: { done: legacy.done, stopReason: legacy.stopReason, builderCalls: legacyCalls },
  });
}
console.log(JSON.stringify({ subject: '346c2baa7907aecb36f63a3196f82ff9e836818c', providerMode: 'local simulated adapters only', results }, null, 2));
if (results.some(({ scenario, current, legacy }) => scenario !== 'tui-options' && ((current.exitCode === 0) !== legacy.done || current.builderCalls !== legacy.builderCalls))) process.exitCode = 1;
