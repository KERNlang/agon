import { join } from 'node:path';

import { mkdirSync } from 'node:fs';

import { ensureAgonHome, RUNS_DIR, tracker, appendMessage, resolveWorkingDir } from '@kernlang/agon-core';

import { runCouncil } from '@kernlang/agon-forge';

import { ENGINE_COLORS } from '../blocks/output-format.js';

import { sessionResultStore } from '../models/session-results.js';

import { recordRun, formatRunSummary } from '../telemetry/index.js';

import type { Dispatch, HandlerContext, EngineProgress } from './types.js';

import { filterDefaultOrchestrationEngines } from './engine-filter.js';

export async function handleCouncil(question: string, dispatch: Dispatch, ctx: HandlerContext, opts?: {roles?:string[], chairman?:string}): Promise<void> {
  const coAbort = new AbortController();
  try {
    ensureAgonHome();
    
    if (!question || !question.trim()) {
      dispatch({ type: 'warning', message: 'No decision provided. Usage: /council <decision>' });
      return;
    }
    
    const allEngines = ctx.activeEngines();
    const pool = filterDefaultOrchestrationEngines(allEngines);
    if (pool.length < 2) {
      dispatch({ type: 'error', message: `A council needs at least 2 engines (have ${pool.length}). Add engines with /engines.` });
      return;
    }
    
    let chairman: string | undefined;
    if (opts?.chairman && opts.chairman.trim()) {
      const resolved = ctx.registry.resolveId(opts.chairman.trim());
      if (ctx.registry.activeIds(ctx.config as any).includes(resolved)) {
        chairman = resolved;
      } else {
        dispatch({ type: 'info', message: `Chairman '${opts.chairman.trim()}' is not available — using rating-based selection.` });
      }
    }
    
    dispatch({ type: 'header', title: `Council · ${pool.length} engines` });
    dispatch({ type: 'info', message: question.length > 120 ? question.slice(0, 120) + '…' : question });
    
    const outputDir = join(RUNS_DIR, `council-${Date.now()}`);
    mkdirSync(outputDir, { recursive: true });
    
    ctx.setActiveAbort(coAbort);
    
    const startTime = Date.now();
    const progressInterval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const progress: EngineProgress[] = pool.map((id: string) => ({ id, status: `deliberating… ${elapsed}s`, elapsed, done: false, failed: false }));
      dispatch({ type: 'progress-update', engines: progress });
    }, 250);
    
    let progressCleared = false;
    function clearProgress(): void {
      if (progressCleared) return;
      progressCleared = true;
      clearInterval(progressInterval);
      dispatch({ type: 'progress-clear' });
    }
    
    let result: any;
    try {
      result = await runCouncil({
        question,
        engines: pool,
        roles: opts?.roles,
        chairman,
        registry: ctx.registry,
        adapter: ctx.adapter,
        timeout: 120,
        outputDir,
        cwd: resolveWorkingDir(),
        signal: coAbort.signal,
      });
    } catch (err) {
      clearProgress();
      throw err;
    }
    clearProgress();
    
    if (!result.ok) {
      dispatch({ type: 'error', message: 'Council produced no usable verdict.' });
      return;
    }
    
    const seating = result.seats.map((s: any) => `${s.role}=${s.engineId}`).join(', ');
    dispatch({ type: 'info', message: `Chair: ${result.chairmanId}  ·  ${seating}` });
    
    if (result.brief && result.brief !== question) {
      dispatch({ type: 'text', content: `Decision brief:\n${result.brief}` });
    }
    
    for (const s of result.seats) {
      const content = s.critique
        ? `${s.response || '(no response)'}\n\n↳ ${s.role} critiquing ${s.critiquedRole}:\n${s.critique}`
        : (s.response || '(no response)');
      dispatch({ type: 'engine-block', engineId: s.engineId, color: (ENGINE_COLORS as Record<string, number>)[s.engineId] ?? 124, content: `[${s.role}]\n${content}` });
      appendMessage(ctx.chatSession, { role: 'engine', engineId: s.engineId, content: `[council:${s.role}] ${s.response || ''}`, timestamp: new Date().toISOString() });
      tracker.record(s.engineId, { prompt: question, response: s.response || '' });
    }
    
    dispatch({ type: 'separator' });
    const verdictBy = result.actingChairmanId || result.chairmanId; // the engine that actually synthesized (failover-aware)
    dispatch({ type: 'engine-block', engineId: verdictBy, color: (ENGINE_COLORS as Record<string, number>)[verdictBy] ?? 124, content: `━━━ Chairman verdict ━━━\n${result.verdict}${result.confidence != null ? `\n\nConfidence: ${result.confidence}%` : ''}` });
    appendMessage(ctx.chatSession, { role: 'engine', engineId: verdictBy, content: `[council:verdict] ${result.verdict}`, timestamp: new Date().toISOString() });
    
    if (result.warnings.length > 0) {
      for (const w of result.warnings) dispatch({ type: 'info', message: `⚠ ${w}` });
    }
    
    sessionResultStore.add({
      type: 'council',
      timestamp: new Date().toISOString(),
      question,
      engines: pool,
      winner: verdictBy,
      data: {
        verdict: result.verdict,
        chairmanId: result.chairmanId,
        confidence: result.confidence ?? null,
        seats: result.seats.map((s: any) => ({ role: s.role, engineId: s.engineId })),
      },
    });
    
    const runRecord = recordRun({
      mode: 'council',
      intent: question,
      winner: verdictBy,
      success: true,
      durationMs: Date.now() - startTime,
      engineIds: pool,
      completionState: 'completed',
    });
    if (!process.env.AGON_NO_SUMMARY) dispatch({ type: 'info', message: formatRunSummary(runRecord) });
  } finally {
    ctx.setActiveAbort(null);
  }
}
