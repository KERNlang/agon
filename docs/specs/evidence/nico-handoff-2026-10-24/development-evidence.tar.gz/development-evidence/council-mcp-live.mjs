import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
if (!process.argv[2]) {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  for (const scenario of ['json', 'quiet', 'failover', 'all-failed', 'disabled']) {
    process.stdout.write(execFileSync(process.execPath, [process.argv[1], scenario], { encoding: 'utf8', timeout: 30000 }));
  }
  console.log(JSON.stringify({ passed: true, nativeProcesses: 5 }));
  process.exit(0);
}
const scenario = process.argv[2];
const root = mkdtempSync(join(tmpdir(), 'agon-council-mcp-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const fixture = {};
new Function('exports', 'require', ts.transpileModule(readFileSync(join(repo,
  'tests/helpers/modular-surface-lock.ts'), 'utf8'), { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
async function owner(symbol) {
  const files = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
  assert.equal(files.length, 1, symbol);
  const module = await import(pathToFileURL(join(directory, files[0])).href);
  assert.equal(typeof module[symbol], 'function', symbol);
  return module;
}
const authority = await import(pathToFileURL(join(repo, 'packages/mcp/dist/surface-authority.js')).href);
const host = new kernel.DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0', processIdentity: 'native-council-mcp' });
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) if (entry.isDirectory()) unlock(join(path, entry.name));
}
try {
  const catalog = kernel.createFirstPartyModCatalog();
  const full = kernel.createFullCompatDesiredState(catalog, '2026-10-24T00:00:00.000Z');
  const disabled = scenario === 'disabled';
  const desired = disabled ? kernel.planDesiredStateChange(catalog, full,
    { kind: 'disable', id: 'agon.council' }, '2026-10-24T00:00:00.000Z').nextState : full;
  await host.commitGeneration({ operation: disabled ? 'disable' : 'install',
    lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
  process.env.AGON_MODULAR_HOST_ROOT = join(root, 'host');
  await authority.initializeMcpSurfaceAuthority();
  const definitions = join(process.env.AGON_HOME, 'engines');
  mkdirSync(definitions, { recursive: true });
  const marker = join(root, 'dispatches.txt');
  const ids = ['fixture-alpha', 'fixture-beta', 'fixture-gamma'];
  for (const id of ids) {
    const fail = scenario === 'all-failed' || (scenario === 'failover' && id === 'fixture-gamma');
    const script = 'require("node:fs").appendFileSync(' + JSON.stringify(marker) + ',' + JSON.stringify(id + '\n') + ');' +
      'console.log("NATIVE_COUNCIL_RESULT Confidence: 73%");process.exitCode=' + (fail ? 2 : 0);
    writeFileSync(join(definitions, id + '.json'), JSON.stringify({ schemaVersion: 3, id,
      displayName: id, binary: process.execPath, isLocal: true, tier: 'user', timeout: 5,
      exec: { args: ['-e', script] } }));
  }
  const { decorateMcpFirstPartyServices } = await import(pathToFileURL(join(repo, 'packages/mcp/dist/first-party-services.js')).href);
  const services = decorateMcpFirstPartyServices({ id: 'agon.conquer' }, {
    receipts: { record: async () => 'native-receipt' }, logger: { warn: message => console.error(message) },
  });
  const output = [], errors = [];
  const originalOut = process.stdout.write, originalErr = process.stderr.write;
  let failure;
  try {
    process.stdout.write = chunk => { output.push(String(chunk)); return true; };
    process.stderr.write = chunk => { errors.push(String(chunk)); return true; };
    const result = await modules.get('@kernlang/agon-mod-council').runCouncil({ question: 'Native Council',
      engines: ids.join(','), chairman: 'fixture-gamma', timeout: '5', quiet: scenario === 'quiet' },
      { invocationId: 'native-mcp-nested', cwd: root, platform: process.platform + '-' + process.arch,
        signal: new AbortController().signal, config: {} }, services);
    process.exitCode = result.exitCode;
    output.push(result.stdout ?? '');

  } catch (error) { failure = error; }
  finally { process.stdout.write = originalOut; process.stderr.write = originalErr; }
  const runsRoot = join(process.env.AGON_HOME, 'runs');
  const statuses = existsSync(runsRoot) ? readdirSync(runsRoot, { withFileTypes: true }).filter(entry => entry.isDirectory())
    .map(entry => join(runsRoot, entry.name, 'status.json')).filter(existsSync) : [];
  if (disabled) {
    assert.ok(failure || (process.exitCode ?? 0) !== 0, 'Disabled command must fail');
    assert.equal(statuses.length, 0);
    assert.equal(existsSync(marker), false, 'Disabled Council must not dispatch');
  } else {
    assert.equal(failure, undefined);
    assert.equal(process.exitCode ?? 0, scenario === 'all-failed' ? 1 : 0);
    assert.equal(statuses.length, 1);
    const status = JSON.parse(readFileSync(statuses[0], 'utf8'));
    assert.equal(status.ok, scenario !== 'all-failed');
    assert.deepEqual(status.requested, ids);
    assert.equal(status.timeoutSec, 5);
    const calls = readFileSync(marker, 'utf8').trim().split('\n');
    assert.ok(calls.length >= 6, 'Must execute brief, advisors, critiques and verdict');
    assert.ok(calls.every(id => ids.includes(id)));
    if (!['human', 'quiet'].includes(scenario)) {
      const result = JSON.parse(output.join(''));
      assert.equal(result.ok, scenario !== 'all-failed');
      assert.equal(result.chairmanId, 'fixture-gamma');
      assert.equal(result.seats.length, 2);
      if (result.ok) assert.equal(result.confidence, 73);
      if (scenario === 'failover') {
        assert.notEqual(result.actingChairmanId, result.chairmanId);
        assert.equal(result.degraded, true);
        assert.equal(status.engines[0].status, 'error');
        assert.match(status.summary, /acting; seated fixture-gamma failed/);
      }
    } else {
      assert.match(output.join(''), /NATIVE_COUNCIL_RESULT/);
      if (scenario === 'quiet') assert.equal(output.join('').trim(), 'NATIVE_COUNCIL_RESULT Confidence: 73%');
      else {
        assert.match(output.join(''), /Chairman verdict/);
        assert.match(output.join(''), /AGON_SUMMARY: 3\/3 succeeded/);
        assert.match(output.join(''), /Decision brief/);
      }
    }
  }
  process.exitCode = 0;
  console.log(JSON.stringify({ passed: true, scenario, compiledMcpHost: true, realDurableHost: true, statusFiles: statuses.length }));
} finally {
  await authority.disposeMcpSurfaceAuthority();
  process.chdir(repo);
  unlock(root);
  rmSync(root, { recursive: true, force: true });
}
