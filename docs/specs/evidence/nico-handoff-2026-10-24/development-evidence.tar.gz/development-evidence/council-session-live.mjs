import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
if (!process.argv[2]) {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  for (const scenario of ['success', 'failure', 'fallback-success', 'fallback-failure', 'disabled', 'cancel', 'cesar']) {
    const output=execFileSync(process.execPath, [process.argv[1], scenario], { encoding: 'utf8', timeout: 30000 });
    process.stdout.write(output);
    if(scenario==='cancel') {
      const record=output.trim().split('\n').map(line=>{try{return JSON.parse(line);}catch{return null;}}).find(value=>value?.scenario==='cancel');
      assert.ok(record.root.startsWith(join(tmpdir(),'agon-council-session-live-')));
      const runs=join(record.root,'data','runs');
      const statuses=readdirSync(runs,{withFileTypes:true}).filter(entry=>entry.isDirectory()).map(entry=>JSON.parse(readFileSync(join(runs,entry.name,'status.json'),'utf8')));
      assert.equal(statuses.length,1);
      assert.equal(statuses[0].ok,false);
      assert.equal(statuses[0].summary,'native cancellation');
      console.log(JSON.stringify({passed:true,scenario:'cancel-host-exit',finalizedRuns:statuses.length}));
      unlock(record.root);
      rmSync(record.root,{recursive:true,force:true});
    }
  }
  console.log(JSON.stringify({ passed: true, nativeProcesses: 7 }));
  process.exit(0);
}
const scenario = process.argv[2];
const root = mkdtempSync(join(tmpdir(), 'agon-council-session-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const fixture = {};
new Function('exports', 'require', ts.transpileModule(readFileSync(join(repo,
  'tests/helpers/modular-surface-lock.ts'), 'utf8'), { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const { build } = await import(createRequire(join(repo, 'package.json')).resolve('esbuild'));
const probePath = join(root, 'tui-probe.mjs');
await build({stdin:{contents:[
  "export { initializeProcessSurfaceAuthority, processSurfaceClient } from './packages/cli/src/surface-authority-runtime.ts';",
  "export { dispatchIntent } from './packages/cli/src/signals/dispatch/intent-router.ts';",
  "export { dispatchOrchestrationIntent } from './packages/cli/src/signals/dispatch/intent-orchestration.ts';",
  "export { runPhysicalCesarWorkflow } from './packages/cli/src/signals/dispatch/cesar-router.ts';",
  "export { detectIntent } from './packages/cli/src/signals/intent.ts';",
  "export { JobManager } from './packages/cli/src/signals/job-manager.ts';",
  "export { sessionResultStore } from './packages/cli/src/models/session-results.ts';",
].join('\n'),resolveDir:repo,loader:'ts'},outfile:probePath,bundle:true,platform:'node',format:'esm',
packages:'external',logLevel:'silent',plugins:[{name:'resolve-workspace-packages',setup(builder){
  const require = createRequire(join(repo,'package.json'));
  builder.onResolve({filter:/^[^./]/},args=>{
    if(args.path.startsWith('node:')) return {path:args.path,external:true};
    if(args.path.startsWith('@kernlang/')) {
      const packageRoot=join(repo,'node_modules',args.path);
      const metadata=JSON.parse(readFileSync(join(packageRoot,'package.json'),'utf8'));
      return {path:join(packageRoot,metadata.exports?.['.']?.import ?? metadata.main),external:true};
    }
    try{return {path:require.resolve(args.path),external:true};}catch{return undefined;}
  });
}}]});
const probe = await import(pathToFileURL(probePath).href);
const authority = probe;
const host = new kernel.DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0', processIdentity: 'native-council-session' });
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) if (entry.isDirectory()) unlock(join(path, entry.name));
}
try {
  const catalog = kernel.createFirstPartyModCatalog();
  const full = kernel.createFullCompatDesiredState(catalog, '2026-10-10T00:00:00.000Z');
  const disabled = scenario === 'disabled';
  const desired = disabled ? kernel.planDesiredStateChange(catalog, full,
    { kind: 'disable', id: 'agon.council' }, '2026-10-10T00:00:00.000Z').nextState : full;
  await host.commitGeneration({ operation: disabled ? 'disable' : 'install',
    lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
  await authority.initializeProcessSurfaceAuthority(join(root, 'host'));
  const definitions = join(process.env.AGON_HOME, 'engines');
  mkdirSync(definitions, { recursive: true });
  const answer = 'NATIVE_COUNCIL_RESULT Confidence: 73%';
  const startedPath = join(root, 'engine-started');
  const engineScript = scenario === 'cancel'
    ? `require('node:fs').writeFileSync(${JSON.stringify(startedPath)},String(process.pid));setTimeout(()=>console.log(${JSON.stringify(answer)}),20000)`
    : `console.log(${JSON.stringify(answer)});process.exitCode=${scenario.includes('failure')?2:0}`;
  const ids = ['fixture-alpha', 'fixture-beta', 'fixture-gamma'];
  for (const id of ids) writeFileSync(join(definitions, id + '.json'), JSON.stringify({ schemaVersion: 3, id,
    displayName:id, binary:process.execPath, isLocal:true, tier:'user', timeout:5,
    exec:{args:['-e',engineScript]} }));
  const persistence = await import(join(repo,'packages/support-persistence/dist/index.js'));
  const chat = persistence.startChatSession({cwd:root,engineIds:ids});
  const events=[];
  const manager = new probe.JobManager();
  let jobId;
  const cb = {dispatch:event=>events.push(event),dynamicSkills:[],allSlashCommands:[],ctx:{config:{sessionContinuity:false},chatSession:chat,
    inputEpoch:0,activeEngines:()=>ids},
    runAsJob:(type,label,run)=>{jobId=manager.run(type,label,run).id;}};
  // Native session exercise stops at the result; no live Cesar provider is allowed.
  cb.ctx.inputEpoch=1;
  const raw='/council Native Council';
  const intent=probe.detectIntent(raw);
  assert.ok(disabled || intent._modSurface, 'slash parser selects the physical contribution');
  // A new user turn makes automatic Cesar continuation ineligible.
  const originalRun=cb.runAsJob;
  cb.runAsJob=(type,label,run)=>originalRun(type,label,signal=>{
    cb.ctx.inputEpoch++;
    return run(signal);
  });
  if(disabled){
    assert.equal(intent._modSurface,undefined);
    await assert.rejects(probe.dispatchOrchestrationIntent({type:'council',question:'Native Council'},raw,cb));
  }else if(scenario==='cesar') {
    cb.runAsJob('council','Native Council',signal=>probe.runPhysicalCesarWorkflow('council',{question:'Native Council'},cb,signal,root));
  }else if(scenario.startsWith('fallback-')){
    await probe.dispatchOrchestrationIntent({type:'council',question:'Native Council'},raw,cb);
  }else await probe.dispatchIntent(intent,raw,cb);
  let cancelledPid;
  if(scenario==='cancel') {
    const deadline=Date.now()+5000;
    while(!existsSync(startedPath)&&Date.now()<deadline) await new Promise(resolve=>setTimeout(resolve,20));
    assert.ok(existsSync(startedPath),'local engine started before cancellation');
    cancelledPid=Number(readFileSync(startedPath,'utf8'));
    assert.equal(manager.cancel(jobId,'native cancellation'),true);
  }
  const finished=jobId?await manager.wait(jobId):undefined;
  if(disabled){
    assert.equal(jobId,undefined);
    assert.equal(chat.messages.length,0);
    assert.equal(probe.sessionResultStore.getResults().length,0);
  }else if(scenario==='cancel') {
    assert.equal(finished.state,'cancelled');
    const deadline=Date.now()+5000;
    let alive=true;
    while(alive&&Date.now()<deadline) {
      try { process.kill(cancelledPid,0); } catch(error) { if(error.code!=='ESRCH') throw error; alive=false; }
      if(alive) await new Promise(resolve=>setTimeout(resolve,20));
    }
    assert.equal(alive,false,'cancelled engine process terminated');
    assert.equal(chat.messages.length,0);
    assert.equal(probe.sessionResultStore.getResults().length,0);
    assert.ok(!events.some(event=>event.type==='engine-block'));
  }else if(scenario.includes('failure')){
    assert.equal(finished.state,'failed');
    assert.match(finished.error,/Council produced no usable verdict/);
    assert.equal(chat.messages.length,0);
    assert.equal(probe.sessionResultStore.getResults().length,0);
  }else{
    assert.equal(finished.state,'done',finished?.error);
    assert.equal(chat.messages.length,3);
    assert.equal(chat.messages[2].content,'[council:verdict] NATIVE_COUNCIL_RESULT Confidence: 73%');
    assert.ok(ids.includes(chat.messages[2].engineId));
    assert.match(readFileSync(join(persistence.chatsDir(),chat.id+'.ndjson'),'utf8'),/NATIVE_COUNCIL_RESULT/);
    assert.equal(probe.sessionResultStore.getResults().length,1);
    assert.equal(probe.sessionResultStore.getLatest().type,'council');
    assert.equal(probe.sessionResultStore.getLatest().winner,chat.messages[2].engineId);
    assert.ok(events.some(event=>event.type==='engine-block'&&event.content.includes('NATIVE_COUNCIL_RESULT')));
    assert.ok(events.some(event=>event.type==='progress-clear'));
  }
  console.log(JSON.stringify({passed:true,scenario,compiledSourceHarness:true,realDurableHost:true,realJobManager:true,messages:chat.messages.length,...(scenario==='cancel'?{root}:{})}));
} finally {
  process.chdir(repo);
  if(scenario!=='cancel') {
    unlock(root);
    rmSync(root,{recursive:true,force:true});
  }
}
