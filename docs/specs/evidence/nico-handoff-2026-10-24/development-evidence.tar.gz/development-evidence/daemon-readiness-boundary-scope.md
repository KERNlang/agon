# Daemon test readiness boundary

Status: fix committed and combined tree qualified. Not a release receipt.

Base: 253a53af0ddd2e9bd75b9793a06592f426a28ba6.
Combined staged tree: 1aab0ceffe5667f9379fd89217b854825df0bb77.
Two test files only; the other 40 staged files belong to metadata simplification.

## Evidence and diagnosis

`metadata-full-qualified.receipt.json` records exit 1, 8411 passing tests,
one failing daemon cancel test, six skips and zero provider launches.
The one-shot job-submit received ECONNREFUSED in 1 ms, before connection, with
zero reply bytes. This is a transport refusal, not a response parser failure.
Null child exit/signal fields do not prove subsequent liveness.

The failing test waited for socket existence alone. Production publishes its
PID record atomically only in the listen callback, after socket permissions are
secured. The other survival tests already wait for both files. The corrected
test follows this boundary and checks ready:true and the spawned child's PID.
It retains the same request, timeout, cancellation, shutdown, child termination,
and cleanup assertions. No request retry or production change is added.

The existing controlled readiness test now checks the intermediate state:
socket present, listen callback not called, PID record absent. This proves the
publication ordering contract, not the exact operating-system scheduling that
produced the intermittent refusal. That causal explanation remains an inference.

## Independent review

Default isolated Agon review packet SHA-256:
a598758923ff2912e1ee301e07e205c08d4ac24fc273d9136696add69d2e6182.
Codex found no blocking defect or weakened assertion. It correctly requested
post-change runtime evidence and cautioned against claiming exhaustive flake
resolution. Kimi returned no answer (exit 1); no authentication repair attempted.
Review receipts and logs retain engine attribution and content hashes.

## Acceptance

Run affected unit/integration tests, types and lint, then the full rebuilt gate
with final live probes. Preserve the failed receipt. Keep this test repair and
metadata simplification as distinct commits. Do not claim full release readiness.

## Completed qualification

`daemon-readiness-boundary` passed 22 tests, typecheck and lint in 69.226s.
Log SHA-256: 2d6e732c9bf79e050db861a445ab079c2e36e3db65aa0064518b563ed093b521.
Codex review log SHA-256:
6064c297b43ef24306dadea42f1a3a6eab9023e4b99951a8cbda22cf23360cae.

`metadata-readiness-qualified` passed in 333.07s with zero provider launches:
full rebuild, types, lint, re-export and generator checks, 8412 passing tests
(six skips), performance budgets, immutable-base metadata parity, Plan consumer
compile and four missing-declaration controls, four live Brainstorm session
invocations, then 22 final daemon/readiness tests. Three post-fix suite runs
included the affected daemon cases: focused, full, final focused. No refusal
recurred in these runs. This is bounded evidence, not proof of zero future flakes.
Log SHA-256: bd198f1f726428b488f1f7f7be3041af4f7b87ca501cd5e26dc4e45a357b92d6.

Test-only commit: 072d75536bb1afefc4507cddb1683e01fc4478da.
Following metadata commit: 754170e91ecabe68c3bc157b467e4aa4a697593c.
The latter has exactly the qualified combined tree above. The intermediate
test-only commit was not separately rebuilt as a clean checkout; no standalone
release qualification is claimed for it.

Candidate branch advanced by compare-and-swap and index-only read-tree. Existing
working files were not replaced. Before/after checks preserved the original 281
paths, with identical log hash bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification worktree is clean. No push, install or global-state change.
