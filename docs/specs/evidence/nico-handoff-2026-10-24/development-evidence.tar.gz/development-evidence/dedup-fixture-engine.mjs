#!/usr/bin/env node
import { writeFileSync } from 'node:fs';

const mode = process.env.AGON_DEDUP_FIXTURE_MODE;
if (process.env.AGON_DEDUP_FIXTURE_PID) writeFileSync(process.env.AGON_DEDUP_FIXTURE_PID, String(process.pid));
if (mode === 'hang') {
  process.on('SIGTERM', () => {});
  setInterval(() => {}, 1000);
} else {
  let input = '';
  for await (const chunk of process.stdin) input += chunk;
  const records = input.trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
  if (mode === 'unavailable') {
    console.error('fixture dependency unavailable');
    process.exitCode = 2;
  } else if (mode === 'invalid') {
    console.log('{');
  } else {
    console.log(JSON.stringify({ groups: [{ members: records.map(record => record.id),
      representative: records[0].id, similarity: 0.9 }] }));
  }
}
