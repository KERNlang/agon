import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { setTimeout as delay } from 'node:timers/promises';
import { dedupBrainstormDrafts } from '/Users/ra/dev/agon-audit-qualification/packages/support-dedup/dist/index.js';

const root = mkdtempSync(join(tmpdir(), 'agon-dedup-native-'));
const previous = process.env.AGON_PYTHON;
process.env.AGON_PYTHON = '/Users/ra/dev/modular-agon-remediation/dedup-fixture-engine.mjs';
const drafts = [{ engineId: 'a', text: 'first\nsecond line' }, { engineId: 'b', text: 'other' }];
const alive = pid => {
  try { process.kill(pid, 0); return true; }
  catch (error) { if (error.code === 'ESRCH') return false; throw error; }
};
async function stopped(path) {
  assert(existsSync(path), 'Fixture subprocess must have started');
  const pid = Number(readFileSync(path, 'utf8'));
  assert(Number.isInteger(pid) && pid > 0);
  const end = Date.now() + 3000;
  while (alive(pid) && Date.now() < end) await delay(20);
  assert(!alive(pid), 'The controller must terminate its hung fixture process');
}
try {
  process.env.AGON_DEDUP_FIXTURE_MODE = 'success';
  const success = await dedupBrainstormDrafts(drafts, { timeoutMs: 2000 });
  assert.equal(success.status.status, 'applied');
  assert.deepEqual(success.groups, [{ members: ['a', 'b'], representative: 'a', similarity: 0.9 }]);
  process.env.AGON_DEDUP_FIXTURE_MODE = 'invalid';
  assert.equal((await dedupBrainstormDrafts(drafts, { timeoutMs: 2000 })).status.status, 'failed');
  process.env.AGON_DEDUP_FIXTURE_MODE = 'unavailable';
  assert.equal((await dedupBrainstormDrafts(drafts, { timeoutMs: 2000 })).status.status, 'unavailable');
  process.env.AGON_DEDUP_FIXTURE_MODE = 'hang';
  process.env.AGON_DEDUP_FIXTURE_PID = join(root, 'timeout.pid');
  assert.equal((await dedupBrainstormDrafts(drafts, { timeoutMs: 500 })).status.status, 'timed-out');
  await stopped(process.env.AGON_DEDUP_FIXTURE_PID);
  const controller = new AbortController();
  process.env.AGON_DEDUP_FIXTURE_PID = join(root, 'abort.pid');
  const pending = dedupBrainstormDrafts(drafts, { timeoutMs: 5000, signal: controller.signal });
  const outcome = pending.then(() => null, error => error);
  const startedDeadline = Date.now() + 2000;
  while (!existsSync(process.env.AGON_DEDUP_FIXTURE_PID) && Date.now() < startedDeadline) await delay(10);
  controller.abort();
  assert.match((await outcome).message, /aborted/);
  await stopped(process.env.AGON_DEDUP_FIXTURE_PID);
  console.log('Native public dedup owner: success, malformed JSON, unavailable sidecar, timeout, abort and forced child cleanup passed. No Python model was loaded.');
} finally {
  if (previous === undefined) delete process.env.AGON_PYTHON;
  else process.env.AGON_PYTHON = previous;
  delete process.env.AGON_DEDUP_FIXTURE_MODE;
  delete process.env.AGON_DEDUP_FIXTURE_PID;
  rmSync(root, { recursive: true, force: true });
}
