# Doctor sidecar ownership

Status: locally committed and qualified under the existing remediation goal; not release acceptance.
Base: 7cb51822c2f111932938c8d8499f479033edce1e, clean qualification checkout.
Baseline: model-probe-owner-qualified, 8,448 tests passing, six skipped.

Doctor checks history-search.py through the legacy dedup resolver, while execution
uses support-persistence's resolver. Reproduce both false failure (legacy absent,
physical owner present) and false success (legacy present, physical owner absent).
Then bind Doctor to the execution resolver and identify actual missing asset
owners in repair advice. Preserve the Python dependency subprocess, timeouts,
failure/warning statuses, managed installer command and five sidecar names.

Blast radius: one CLI source file, one new focused test file, one existing subprocess
test file, generated launcher
and release metadata if build hashes change. CLI already depends on persistence;
no dependency change, installation, sidecar deletion, or Python implementation
change. No new production helper or public API. Tests use mocked filesystem
resolver boundaries and Python subprocess results; no real providers or installers.
Use existing isolated test harness, source review, full repository gates and a
final direct diagnostic probe with an isolated Python stub. No global state writes.

The asset copies and their other consumers remain; this removes one incorrect
legacy consumer, not every legacy owner. Review findings require source evidence.

## Verification and review in progress

doctor-sidecar-owner-red initially had five failures: four intended ownership
failures plus an incorrect test expectation that a shell-safe path is quoted.
Corrected only that expectation. The unchanged production source then failed
exactly four ownership assertions and passed both Python-failure controls in
doctor-sidecar-owner-red-verified. Log SHA-256:
5262c2440e86c4cadd8bebdbc63953d79bff58ab45380e024b10154e25142d60.

After the fix, doctor-sidecar-owner-focused passed tests, types, lint and re-export
guard in 59.681 seconds. Log SHA-256:
dc781dc595604316db7d780b3d9d5b277dac2be0a7de0bfe5f81a8133decaccc.
The later real-subprocess assertion awaits the full/final run.

Agon reviewed tree 2c984bc20296c196877c9aadefac29a15c89c950.
Packet SHA-256: c962558f2e08bd497fd6b219d4445dc27442781aa5e5f56c4864170a7db2f8fc.
Codex log SHA-256: 999b4fd32d16094ffd34254de44e4618dae8426100160b365405e2fd35f7d4dd.
Kimi returned no answer (exit 1), log SHA-256:
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.

Codex's POSIX subprocess fixture finding is true for native Windows, which is
outside the agreed v1 scope (acceptance-roadmap.md:133: macOS/Linux). The fixture
must run on both supported platforms; do not add a skip or claim Windows support.
Its suggested assertions for owner names in detail were added, alongside existing
repair-command assertions. No production correction was requested by review.

## Qualified increment

doctor-sidecar-owner-qualified passed in 306.602 seconds: build, typecheck, lint,
re-export guard, release-set and supply-chain generation/checks/self-tests,
8,455 repository tests (six skipped), then fourteen focused checks including
the real subprocess and physical history asset. Zero provider launches in this
verification run. Log SHA-256:
27ff150613bf0ae468c772e6fe8cbc6951ac819898addec23b5eab8d6940f481.

Commit: 9b523a34df930d66a145063a2da4a095468afb7e.
Tree: 8bbea9fe14ac27f73795277d57a41a27c547e31a.
Five paths: three authored, two generated metadata. Launcher channel unchanged.
Qualification worktree clean after commit. Candidate branch/index advanced with
CAS update-ref and read-tree without -u; working files not replaced. Before/after
preservation receipts pass with matching log SHA-256:
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.

Still open: full ownership/adapter retirement and clean release acceptance. The
TUI probe still resolves its CLI py copy instead of the support-verification asset
(tool-tui-probe.ts:16-33; tui-probe-tool.test.ts:41-46 explicitly asserts the old
location). This is a separate consumer migration; check actual terminal behavior
and its optional pyte prerequisite before deleting or relocating any asset.

Prerequisite probe tui-probe-prerequisite completed successfully but reported
pyteAvailable:false for python3 in the existing isolated harness. This is NOT a
passing TUI check. Log SHA-256:
a39384ecfd0f1c1683d00706b994cf47a7420b96322e1d852905f9210ac1f61d.
No dependency was installed. Before treating the TUI lane as blocked, check for
an already available isolated interpreter with pyte; do not use personal state or
silently enable the skipped E2E without its prerequisites. Asset-path and package
checks remain locally actionable without pyte. Other acceptance work continues.
