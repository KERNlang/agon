# Engine configuration policy owner

Status: building under the existing ownership-remediation goal.
Base fb77dc970e720403cb18a27577b5ebf9b2ad1a9b is clean and qualified by
config-store-owner-qualified: 8,468 tests pass, six skipped, full gates and two
isolated CLI runs. No install, dependency, global state, or push is authorized.

## Scope

Move exactly the 13 config keys assigned to support-engine-runtime by the frozen
ownership ledger: types, defaults and existing normalization. Core composes the
owned values into its existing public AgonConfig/default object. Keep every key,
value, optional/required type, runtime normalization rule, and object key order.
Keep the eight other owners' keys untouched. No new package edge is needed.

Authored files: support-engine-runtime engine-settings.ts and public barrel,
Core models/types.ts and signals/config.ts, focused ownership/parity tests.
Generated release/SBOM/channel metadata changes follow compiled contents.
Do not regenerate the frozen 872-assignment baseline or claim all config owners
retired. The baseline inventory generator is explicitly historical.

## Verification

Before implementation, test the absent public physical-owner defaults to get a
negative control. Compare moved declarations/defaults to the base Git blob.
Compare normalized outputs against the exact old normalization across malformed
JSON values. Require Core to use the physical policy, not a second implementation.
Keep configuration-list key order and the public Core defaults unchanged.
Run full gates, API compatibility, pack/supply-chain checks, default Agon review,
and isolated real CLI configuration checks. No external provider launches in tests.

## Remaining product gap

Mod-owned namespaces, schemas/defaults/migrations and other per-key owners are
still required by runtime-contract.md. This increment addresses one concrete
existing hidden support owner; it is not complete configuration cutover.

## Focused and negative evidence

Physical defaults test failed before implementation (undefined export), log
8a2eede84f8077c454c0434da6166203083d3d215751e536bf24ec027ee33cd7.
Initial focused build/types run passed 115 checks, log
9f4c7c9ba950ca3d047b76dc74e1c8225b6d25c7a82969a96485349d5f15fc10.
Expanded controls plus types/lint/reexports passed, log
0edc08d7c70ec078337d6de7a0cd010bf4efc82a80b1e8c90bf28aa70d0a2707.

Exact base Core models/types.ts restored temporarily: owner/Core array identity
fails, so a duplicate legacy default object cannot silently remain authoritative.
Log fa7215eb0dcef0b80d4b8c122b0cdf8d5d4c0144183a5066c1c9e64e462940cb.
Exact base Core config.ts restored temporarily: physical normalizer called zero
times, so old inline policy is rejected. Log
044c096d8f4ed5e0936460577bb6014f24a5ebb76d16ec9d6c857b31c5f10213.
Both restorations were reversed immediately; no test exclusion was added.

## Independent review

Agon packet tree 0f0b677f43dff9f896971689467fc6470b5d2839, packet SHA-256
52ddf0d0cdf2e7ccdb912287c9955f54058ac1110bd75b7c7d6f3991114d8fe4.
Codex found no implementation regression. It correctly notes that composition
type equality is not historical parity and that built-default checks require a
fresh matching build. The external baseline helper compares the exact fb77dc97
Git blob's declarations/default expression with current source and freshly built
Core. Its result is required before acceptance, not inferred from review.
Codex log SHA-256:
19f44474be162c603af23f68a27f6ec754792120fd2149e1be9ce2f7317c48ba.
Kimi returned no answer (exit 1); no login or credential modification attempted.

## Completed increment

Commit: 0f92bff32f8697cfdc9c70f566eb1318f1abd8f9.
Tree: 0e2421eca8c470888b852076825c41326ff65211.
Five authored files, three generated release metadata files. Eight files total;
301 added/181 removed lines includes launcher chunk-name churn. No package edge,
lockfile, frozen ownership assignment, or acceptance requirement changed.

engine-settings-owner-qualified passed once in 306.916 seconds. Full build,
typecheck, lint, reexports, existing N-1/N-2 compatibility gate, release/SBOM
checks and their negative controls, 8,472 passing tests, six skipped, independent
Git-baseline parity, then actual isolated CLI/Core configuration checks.
Log SHA-256: 1fa8627cdbf3e1297bbb0fa58f41044be10fd9764b7f4bf6f09a9109986729dd.
Provider launches: zero. The authored source tree did not change after review.

The independent comparison proves 121 public field names/types/optionalities
unchanged after composing the 13 moved fields. Freshly built Core defaults match
the base object's exact JSON and key order. Defaults SHA-256:
2ce42634048b04c7ed0564438791070ae23f1e41bb9a8e1afa7f3555a0166414.
This resolves the review's historical-parity and fresh-build evidence limits.
One live run, four subprocesses, verified set/get, rejected unknown key without
file mutation, and three-scope permission retention in a fresh isolated home.

Candidate branch advanced with CAS and index-only read-tree. Before/after
preservation checks match bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification worktree clean; no installs, global changes, promotion or push.

Remaining config-key owners: Kernel 92, persistence 6, browser bridge 1,
Forge 2, Review 2, Agent 1, Mutate 1, Synthesis 3. The first three already have
Core dependency edges and can be extracted without new dependencies. User-mod
defaults need final host composition without blindly importing executable mods
from the foundational Core layer. Do not add those edges as an unreviewed shortcut.
