"""Export sanitized development evidence without changing original files."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

source = Path('/Users/ra/dev/modular-agon-remediation')
target = Path('/Users/ra/dev/agon-audit-qualification/docs/specs/evidence/nico-handoff-2026-10-24')
target.mkdir(parents=True, exist_ok=True)
archive = target / 'development-evidence.tar.gz'
index_path = target / 'index.json'
if archive.exists() or index_path.exists():
    raise SystemExit('Refusing to overwrite evidence export')
extensions = {'.log', '.json', '.txt', '.md', '.mjs', '.py', '.mts', '.ts', '.patch', '.ndjson', '.cjs', '.sb', '.html'}
patterns = [
    (re.compile(r'-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?-----END [^-]*PRIVATE KEY-----'), '[REDACTED PRIVATE KEY]'),
    (re.compile(r'\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9_]{16,}|github_pat_[A-Za-z0-9_]{16,}|AKIA[A-Z0-9]{16})\b'), '[REDACTED TOKEN]'),
    (re.compile(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b'), '[REDACTED JWT]'),
    (re.compile(r'(?i)(["\x27]?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|id[_-]?token|client[_-]?secret|password|authorization)["\x27]?\s*[:=]\s*)["\x27][^"\x27\r\n]+["\x27]'), r'\1"[REDACTED VALUE]"'),
    (re.compile(r'(?i)\bBearer\s+[A-Za-z0-9._~+/-]{8,}'), 'Bearer [REDACTED]'),
    (re.compile(r'https?://[^\s/"\x27]+:[^\s/@"\x27]+@[^\s"\x27]+'), '[REDACTED AUTHENTICATED URL]'),
    (re.compile(r'\b(?:10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2}|100\.(?:6[4-9]|[7-9]\d|1[01]\d|12[0-7])(?:\.\d{1,3}){2})(?::\d+)?\b'), '[REDACTED PRIVATE ADDRESS]'),
    (re.compile(r'\b[A-Za-z0-9.-]+\.ts\.net(?::\d+)?\b'), '[REDACTED PRIVATE HOST]'),
]
rows = []
with archive.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w|') as bundle:
    for path in sorted(source.iterdir()):
        if not path.is_file() or path.is_symlink() or path.suffix not in extensions:
            continue
        if any(word in path.name.lower() for word in ('credential', 'auth.json', 'secrets')):
            raise SystemExit('Sensitive filename requires manual review: ' + path.name)
        raw = path.read_bytes()
        text = raw.decode('utf-8')
        count = 0
        for pattern, replacement in patterns:
            text, changes = pattern.subn(replacement, text)
            count += changes
        data = text.encode('utf-8')
        member = tarfile.TarInfo('development-evidence/' + path.name)
        member.size = len(data)
        member.mode = 0o644
        bundle.addfile(member, io.BytesIO(data))
        rows.append({'originalRelativePath': path.name, 'archivePath': member.name,
                     'originalSha256': hashlib.sha256(raw).hexdigest(),
                     'exportSha256': hashlib.sha256(data).hexdigest(),
                     'bytes': len(data), 'redactions': count})
with tarfile.open(archive, 'r:gz') as bundle:
    for row, member in zip(rows, bundle.getmembers(), strict=True):
        data = bundle.extractfile(member).read()
        assert member.name == row['archivePath']
        assert hashlib.sha256(data).hexdigest() == row['exportSha256']
index = {'schemaVersion': 1, 'scope': 'All top-level development logs, receipts, review packets, notes and reproduction helpers; no nested worktrees, caches or installed dependencies.',
         'warning': 'Historical failures and review hypotheses are retained. Exported files may be sanitized; original receipt log hashes refer to original bytes, not sanitized bytes. This is not release acceptance.',
         'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': rows}
index_path.write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'files': len(rows), 'redactedFiles': sum(row['redactions'] > 0 for row in rows), 'archiveBytes': archive.stat().st_size, 'archiveSha256': index['archiveSha256']}))
