import assert from 'node:assert/strict';
import { ModRegistry } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { createMod, MANIFEST } from '/Users/ra/dev/agon-audit-qualification/packages/mod-forge/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const owner = { id: MANIFEST.id, version: MANIFEST.version, contentHash: `sha256:${'a'.repeat(64)}` };
const registry = new ModRegistry({ generation: 'built-forge-settings', activeOwners: [owner] });
const session = registry.beginRegistration(MANIFEST);
const seen = [];
const registrar = { ...session.registrar, command(surface, contribution) {
  return session.registrar.command(surface, { ...contribution, run(input, context) {
    seen.push(context.config);
    return contribution.run(input, context);
  } });
} };
const mod = await createMod(new Proxy({}, { get() { throw new Error('unexpected host effect'); } }));
await mod.activate(registrar);
session.commit();
const command = registry.project('cli').entries.find(entry => entry.payload.description.includes('Forge') || entry.payload.description.includes('forge')) ?? registry.project('cli').entries[0];
const context = { invocationId: 'built-settings', cwd: process.cwd(), platform: 'darwin-arm64', signal: new AbortController().signal, config: {} };
// Missing task reaches the real command but returns before host effects.
await command.payload.run({}, context);
assert.deepEqual(seen[0], { autoReviewAfterForge: true, forgeFitnessTimeout: 120 });
await command.payload.run({}, { ...context, config: { autoReviewAfterForge: false, forgeFitnessTimeout: 0, future: 'keep' } });
assert.deepEqual(seen[1], { autoReviewAfterForge: false, forgeFitnessTimeout: 0, future: 'keep' });
assert.throws(() => command.payload.run({}, { ...context, config: { forgeFitnessTimeout: 'wrong' } }), /mod settings.*forgeFitnessTimeout/);
assert.equal(seen.length, 2);
await registry.disposeOwner(owner.id);
assert.throws(() => command.payload.run({}, context), /unavailable/);
assert.equal(seen.length, 2);
console.log(JSON.stringify({ passed: true, builtOwnerDefaults: true, explicitValuesPreserved: true, invalidRejectedBeforeRun: true, disposedRejected: true, hostEffects: 0 }));
