# Forge settings ownership

Status: building. Implementation authorized by the standing remediation goal.
Date: 2026-10-11. Base: fe6e6c8e55c86bdbbc29a29891f49e741a6cac21.
Local changes and commits allowed; no push, installs or personal-state changes.

## Purpose and source

Move Forge's two configuration definitions from Core to its physical package.
Runtime contract section Configuration requires owner schemas and defaults.
The ownership ledger assigns autoReviewAfterForge and forgeFitnessTimeout to
@kernlang/agon-mod-forge. Both types/defaults still live in Core models/types.ts.
Forge implementation.ts registers two unrestricted object schemas instead.

## Design and boundary

Use existing schemas/config.schema.json as authored input. The existing package
generator reads it, retains asset hashes, and generates Core's compatibility
types/defaults for ledger-assigned legacy properties. No new descriptor format,
package edge, runtime mod import, schema framework or config store.
Forge registers this same schema (without its resource-identity annotation).
Core preserves optional types, default values and key order.

Expected footprint: generator; Forge schema/manifest/implementation; Core types
and one generated compatibility file; focused tests; three release metadata
files. Risk: medium (public config types and actual execution validation).
Existing 8,531-test full gate, types, lint and built-runtime checks are green.

## Acceptance

- Owner schema provides exactly the two ledger-assigned keys and old defaults.
- Active Forge registry enforces these types/defaults before execution.
- Invalid namespaced values fail; explicit false/zero and unknown data survive.
- Core's 121 public fields, optional types, defaults and order remain identical.
- Generator check detects schema/default drift; no disabled mod runtime import.
- Existing package/API/full gates and isolated built-runtime probes pass.
- One Agon review; findings fixed or source-refuted before local commit.

## Not claimed by this increment

Seven remaining mod fields, namespace-to-flat compatibility precedence, versioned
durable migration integration, and whole-release acceptance remain unfinished.
No filesystem config migration or activation occurs from reading settings.

## Review and verification

Initial owner-schema test failed because the package had no assigned properties.
The second initial failure was a test import error (internal resolver imported
from public barrel), not product evidence. Corrected locally; retained logs.
Focused tests, types, lint and generator check passed in
forge-settings-owner-focused-v2 (SHA-256
0000ad22b525b06c3974b4272662febae5b19a95fcb2da80c45a9df125bb04a2).

Agon reviewed tree 2a1f7427797fb6ec90ee7f5c8f3f6ada558340fc.
Packet hash e4c9957edf6d0f1878da4a25e14276cd072cb50554d621c0e69dd9220bb69cc2.
Codex found no confirmed blocker; log
bd085bfae214589dd010ada5db8c5f2cdc2ca0c6adf88c8d8987c382f39f2e1a.
Kimi exit 1 without review, not counted as passing.

Added reviewer-requested controls in a temporary generator fixture: unowned and
foreign-owner properties do not enter Core; unsupported type, missing/wrong
default and duplicate ownership fail; changed defaults make --check fail, then
regeneration passes without rewriting the owner schema. Invalid boolean, null,
nonfinite values and omission of $id checked at the registered boundary. The
generator now refuses malformed falsy definitions instead of treating them as
absent. Repeated emitted ownership is fail-closed; the frozen config ledger has
one occurrence per assigned setting in this extraction.

forge-settings-review-controls passed (SHA-256
91a4671ebe1bb2d05dfacb76bf209c8ba54599c15d8717f2ee7484f935c6e05d).
Full gate is running, including new malformed-definition controls and a built
Forge/Kernel command-boundary probe. No whole-release conclusion is implied.

## Qualified commit

Commit ac4b6dd0e7ce07423ec4e4dcdc13be53ff22d161, tree
a2a4370a86211b5dacbe8c468a0c04b17c23e2db. Ten explicit files committed.
forge-settings-owner-qualified passed in 341.164 seconds; log SHA-256
3a21b9442cc2ece0badcc1992e0d5138395459360211516c5f01a2597afd0810.
One full run: build, types, lint, reexports, API compatibility, generator drift,
release-set/supply-chain and self-tests, 8,534 tests passed and 6 skipped.
Seven isolated CLI processes and one built Forge/Kernel invocation probe passed.
All 121 historical public config fields retain types, defaults and key order;
114 now derive from physical owners (two through generated static compatibility
data). No external provider launches. No pack-install/runtime claim beyond the
checked pack metadata and built artifacts.

Candidate branch/index advanced without modifying its preserved working files.
Before/after preservation checks passed for 281 baseline paths, both log hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification checkout clean. No push, install, global or personal-state change.
