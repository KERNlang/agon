# Forge workflow cutover: review adjudication

Review input SHA-256: `5bb429238155caad27ab6af0c2143c19957f77b0aae85b8e0c7470636616c347`.
Codex review SHA-256: `ac31a69310f9404736648d50acef1e6c91194daf766a8f69c7665a3091b0bffd`.
Source: `agon-audit-qualification`, descendant of `684a548a`; fixes are now
committed as `36d358c12a45b45ae8336957af790334f9d96154`. The review input above
predates the fixes; its hash is unchanged. This adjudication is not release acceptance.

## Findings

1. Failed workflow published as winner: confirmed and fixed. The generated report
   now checks manifest.error/status, preserves provisional evidence and returns
   failure. Correctly injected forge:done failure and a killed negative control
   prove this. See forge-workflow-error-injected, -negative and -restored receipts.
2. Immediate revocation through completion: not the frozen requirement. Runtime
   contract steps7–8 pin existing invocations until completion and forbid stale
   new work. Existing CLI adapter checks were preserved in the shared guard;
   generated Forge adds captured CLI/MCP authority at provider entry. The broad
   recommendation to cancel every old-generation invocation would change that
   contract. No such change made. A failed optional judge remains advisory,
   reported separately, as before. Disabled/new-entry checks still need the full
   original acceptance matrix; these unit tests alone do not prove all surfaces.
3. Numeric JSON options ignored: inherited, but a real direct-export boundary
   weakness. HEAD implementation uses string-only text() for these inputs, and
   current/HEAD surface schemas explicitly declare timeout, healthCheckTimeoutSec,
   earlyFinalizeCount and finalizeOnScore as strings. Team Forge and pipeline
   consumers pass strings. Do not silently widen schemas or change parser policy.
   Non-string supplied values are now rejected before engine listing or host
   opening. forge-input-type-before reproduced all four fields reaching host
   lookup instead of validation. The focused after run covers seven invalid
   values per field and existing valid string workflows. The after receipt passed
   60 tests and type checking, SHA-256
   `0900daa4e5512838d15a12a3411d3208ac7300b88d0425e6997cbd8f2a436f0c`.
4. Source fitness observer overwritten: confirmed and fixed by composition.
   Source observer callback failures remain failures; the effect contract never
   promised best-effort callbacks. Silently swallowing them would mask evidence
   or host failures. The before receipt saw no callbacks; the after test compares
   actual source measurements and publication.
5. Candidate duration replaced by fitness duration: confirmed and fixed. The
   report uses dispatchLog.totalDurationMs; command duration is a separate field.
   Before/after tests compare actual persisted manifest and measurement values.

## Inherited findings verified during the migration

- Synthesis cleanup race: reproduced with a worker outliving timeout and cleanup
  grace. Fixed by awaiting actual settlement after abort; named listener removed.
  forge-synthesis-drain-before failed on premature cleanup; -after passed83 tests.
- Filtered starter resurrection: reproduced beta becoming winner after beta's
  failed probe. Fixed by taking the sole eligible engine. Before/after receipts
  prove no implementation dispatch to the skipped engine.
- Caller cancellation: original reason now forwarded; health probes receive the
  signal; listeners dispose on success and preflight exceptions. The raw-manifest
  test reproduced no-winner after candidate cancellation. Phase checks now record
  failed status with the caller reason. Internal quorum cancellation stays distinct.
- Dirty-source provenance: stashSnapshot includes tracked dirty edits, excludes
  untracked files and can fall back to HEAD. Current report captures the actual
  returned baseSha. It must not claim dirtySourceExcluded=true or universal dirty
  inclusion. No false boolean restored. Snapshot semantics need explicit final
  contract/consumer verification, not an inference from the SHA alone.

## Ownership and evidence limits

Legacy packages/forge/src/forge.ts now binds the mod-owned factory. CLI/MCP hosts
provide effects, not workflow callbacks. Forge, Team Forge and the existing
pipeline fixture use that owner. This retires the parallel generated competition,
not every legacy Forge import or every first-party compatibility adapter.

Full working-tree gate forge-consumer-release-gates passed9,444 tests and84 npx
checks before the later lifecycle fixes. It cannot qualify those later changes.
forge-lifecycle-release-gates passed9,449 tests and84 installed checks for that
later source (522.171s, zero providers, SHA
927127a0f7d946497b3bc29650456d841a4748cc7020031e8c42c0e8ef928211).
The subsequent `forge-workflow-commit-gates` qualified the input-type fix:
9,453 tests and 84 installed checks, with build, types, lint, re-exports,
release-set and supply-chain checks passing. Log SHA-256:
`d566ef4c05f54a15fcc07d19a5633d0649571d482a4e9639dc4255d6aa4e526c`.
After commit, `forge-committed-clean-online` passed all ten execution steps from
an exact clean archive, including frozen install, independent API/kernel builds,
negative controls, oracle, roadmap, runtime build and contract tests. Log SHA-256:
`c19e58d70a81b01135162d83ae9204d1f10c2559b55671e8164805232141d7a8`.
Overall receipt remains FAILED: stored S1B review evidence belongs to an older
subject. This component adjudication does not replace a fresh final subject-bound
independent review. No acceptance gate was bypassed.

No second external panel requested. Claims above were checked against local source,
Git HEAD, contracts and discriminating tests. Preserve raw review and receipts.
