# Goal controller parity: remaining work

## Live status (supersedes historical next-step paragraphs)

CURRENT 996ee253d4b2884d952a117b982065aa1d2f0116: MCP safe startup committed.
7302 TERMINAL PASS861.445s, 10719passed/sixskipped, zero providers. Full log:
d33fe74960e443691e9ffff7789292c3af1662ac5a7f20acffa2ede1ed07e1bb.
Final built MCP probe PASS0.454s, two processes; log
e0a6814966f757f4acef1157c623e41f0f236e27da84d29e9a10041da37381a8.
Tracked evidence in modular-agon-product-audit.md. No push/global change.
Memory contract regression added to existing MCP authority test; production
memory source unchanged. Receipt modular-memory-project-contract-red TERMINAL
FAIL1.835s: exactly the new schema test fails (engineId/observation instead of
memory/section); nine previous tests pass. Log SHA-256
5dfa36dce1ba16a51581fe261acf13dffab111c81cea77d58e4c0cb4df2b079e.
No active process. Worktree dirty only with that red regression; keep it and
repair the contract, never relax it to match the replacement engine-note tool.
Old ACTIVE messages superseded.

CURRENT full gate27697 TERMINAL FAIL775.909s, log
5dc7fec7a5440efe0237cfc242ae71811ee9fc2d0ac805f9d887a1ef7c8d175e.
51failed/10645passed/29skipped/16errors: daemon/serve listen EPERM and watch
failures under default sandbox. MCP-focused controls passed, but this does not
waive full gate. Exact retry with require_escalated approved by auto-review,
run.py still isolates homes and blocks providers/browser: session7302 ACTIVE,
receipt ID modular-mcp-safe-full-gate-local-sockets. Source/tests remain frozen.
No other run.py until terminal. Correct process: full gates need socket/watch
permission; preserve failed receipt and verify the rerun, never assume success.

NEW source-confirmed contract mismatch found during eager-import tracing:
packages/mod-memory/src/implementation.ts registers SaveMemory on both surfaces
with required engineId/observation and writes engine-memory.json. Legacy
packages/core/src/tools/tool-save-memory.ts:136 requires memory/section, explicitly
asks permission per fact, and appends/deduplicates/caps dated facts in the cwd's
.agon/project.md. Generated catalogs still bind that public name to agon.memory.
The current mod test tests only the replacement engine-note behavior, so it
cannot prove legacy parity. MCP routes owner-tagged tools before its old
SaveMemory branch, making the mismatch relevant to real dispatch. Next: add a
fixture invocation through the registry with legacy input and compare actual
file effects against the legacy oracle; then repair at one owner, including
per-memory approval. Do not merely lazy-load the stale kernel SaveMemory branch
and claim compatibility. No source edits while gate27697 runs.
Ownership ledger also needs reconciliation: the tool contribution belongs to
mod-memory while tool-save-memory.ts stateStoreModules is kernel-contract-default.
Resolve from the original user contract; do not silently move unrelated state.

SaveMemory repair preparation (2026-10-19, spec skill, bug/self-written;
authorized by original compatibility goal, no separate product requirement):
The same traced flow loses approval: cesar/tools.ts:54 returns allow for all
bundled tools; MCP executes owner-tagged dynamic tools before kernel write
approval, and base services.permissions.check always allows. Restoring schema
alone would therefore write project memory without the original confirmation.
Acceptance must cover original memory/section input, cwd-scoped project.md,
dated append, dedup, section cap, untouched unrelated content, confirmation,
denial/cancel/generation replacement without writes, and disabled-memory refusal
on both MCP and Cesar. Reuse legacy save-memory-tool tests and existing host
approval plumbing. Do not build a second generic approval system or copy the
markdown algorithm. Shared support-persistence is already a dependency of both
Core and mod-memory, a potential location for common storage primitives; this is
an architectural option, not yet a verified migration choice. Core's read-file
cache update must survive. Existing engine-note helper remains in support-engine-
runtime; avoid deleting genuine engine-rating functionality. Original user need
controls SaveMemory's public contract, not the replacement one-line mod test.
No new dependencies or source edits made during this preparation.

CURRENT MCP safe-startup WIP, e140d078c base. Full gate session27697 ACTIVE;
do not edit source or run a concurrent run.py. Nine review controls/types/full
lint PASS60.716s, log a6ac215f3a443b0fb841c79e38a3be8b03f0a8d6d8f4d8b2b6fc87cfa1dbd7c2.
Initial built MCP probe PASS0.400s, log
e0a6814966f757f4acef1157c623e41f0f236e27da84d29e9a10041da37381a8.
Codex review packet bac41cfbdf36edf2d459fa88834aa82d8960ff92b1908447285fa03f1044204d;
review log cdb20d75ec4e9d84026d1ab7f8ebd22bba2fe2b8cb7536fa27def8f02ae9c385.
No blocking review finding. Additional controls applied for pointer change,
replacement, import rejection and positive continuation. Safe MCP catalog is
empty by design (kernel-management-surfaces has CLI/TUI only); replaced the
vacuous every assertion with exact empty catalog assertions. Initialization
overlap has no current production caller: index.ts awaits initialization once
before startMcpServer; dispose is test-only. Do not inflate this hypothesis into
a demonstrated production defect. Final rebuilt probe and commit remain.

Read-only package-boundary trace while gate runs: first-party-services in both
hosts eagerly imports optional mods, plus Core's barrel. Core's EngineRegistry
injects mod-ratings; its public Forge host factory imports mod-forge. The kernel
decorator is synchronous (first-party-surface-bootstrap.ts loadPackage), although
loadPackage itself is async. Changing that callback alone cannot remove eager
Core reexports or TUI's static Plan imports. MCP transport also imports Core's
memory helpers for executeApprovedKernelWrite SaveMemory. KL-007 checks source
strings, not emitted chunks; verify-modular-npx does exercise a 15-package
minimal+think+review installation, but inlined mods currently mask missing
optional-package imports. Next package slice must preserve those installed
checks and add an output-boundary negative control, not simply externalize
packages and assume directories prove modularity. No package edit made yet.
Older CURRENT/ACTIVE paragraphs below are historical.

CURRENT e140d078c: CLI safe-mode startup committed. Full gate22119 TERMINAL
PASS865.677s (10,712passed/six skipped), log
ce541b3f269389d085210bfac77d4650174f2feff7a60cf19fb1bc50e752be85.
Final rebuilt import-hook probe PASS0.568s, log
1ca196ed16d859ad9ec5b4878162b9745aaf919d8bf340d567d0e4cbcd824d7b.
All zero providers. No active check, no push/global install. Tracked evidence in
modular-agon-product-audit.md. Next: MCP recovery import boundary described below.
Earlier ACTIVE statements are superseded; do not restart completed gates.

ACTIVE session22119: modular-safe-startup-full-gate. Source/test freeze; do not
run another run.py concurrently. HEAD cd60a459e; four source/test files dirty
plus generated metadata expected. 96739 terminal PASS31.586s: 44 focused cases,
types/lint, log ff8ae7ccc820ff45ad5b3751d7339d764e3441e93766665bc482b40e772c76f2.
modular-safe-startup-built-probe PASS0.505s (three CLI invocations with an import
hook refusing first-party-services), log
1ca196ed16d859ad9ec5b4878162b9745aaf919d8bf340d567d0e4cbcd824d7b.
Both zero providers. Repeat that receipt.command via a new ID after final build.
The probe's script is also functions store safeStartupProbe (convenience only).
Need final gate, repeat, tracked evidence and explicit-path commit. Then resume
packaging boundary work. No active reviewer; no second panel needed.

Read-only follow-up during22119: MCP has the same eager feature-host loading
pattern. `packages/mcp/src/surface-authority.ts:15` statically imports
createMcpEngineServices/decorateMcpFirstPartyServices, and initialize constructs
engine services before entering the kernel safe-mode branch. That dependency
imports mod-brainstorm and mod-ratings, plus Core's Forge host. The MCP authority
also statically imports Core loadConfig, used only by async invocation; preserve
the public config owner but defer that lookup until invocation. Next bounded
recovery prerequisite: poison the MCP feature-services import, prove safe mode
boots and ordinary mode still fails, retain tools/authority/config behavior.
The entrypoint also imports agon-orchestration.ts, whose Core memory helpers
must be traced before claiming ALL optional package absence works end to end.
Do not claim the CLI slice fixes MCP or final package isolation.

Source-map census of existing CLI output found embedded ownership from ten
mods: brainstorm, conquer, forge, goal, jobs, nero, plan, rag, ratings, review.
Method: read *.js.map sources and collect /mod-([^/]+) paths, excluding mod-api.
This identifies build inputs, not reachability or a ten-mod bypass claim.
Final packaging gate must inspect emitted dependency provenance; a single Forge
function-name grep remains only the initial red reproduction. Existing CLI
maps omit sourcesContent, so map-based provenance can be checked without
shipping private source. No tests/source changed during22119.

WIP 2026-10-19 after cd60a459e: safe-mode startup prerequisite (four files).
Spec type: bug, source-verified; existing goal authorizes implementation. Scope:
CLI index, surface-authority-runtime, production-surface-bootstrap tests and
first-party-cli-recovery tests. No API, dependency, installation or migration
change. Existing contract: kernel-only recovery must remain available with
unavailable mods; ordinary behavior and state-independent version remain.
Rollback: revert only this increment. Backup modular-cli-boundary-cd60a459e.

Root cause and diagnostic: adding an external mod pattern to CLI tsup removes
embedded Forge successfully, but a resolver-hook probe denying all selectable
mod imports fails `mod list` in safe mode on mod-forge. --help/--version succeed,
but pristine --help advertises feature commands instead of kernel commands.
The tsup diagnostic change was reverted, not committed. Its built artifacts
were replaced by the ordinary CLI build. Packaging remains OPEN, not waived.
Receipts: modular-cli-external-boundary-build PASS0.493s,
95e6e5cb001196b279484c98d8db3295f573e26b8ad6132fe00541d66672e172;
modular-cli-absent-mod-startup-red FAIL0.456s,
d27a7136d998ad98efddf4f9eb972587151bd52f1c664a8ab5dd7afebb9e1bc0.

Implementation: safe mode bypasses the dynamic feature-services import and
engine-services construction before bootstrap; the kernel already ignores
decorators in its safe branch. Normal startup still imports once, constructs
engine dispatch, and honors injected decorator. Pristine safe-mode help cannot
use the all-feature shortcut; version retains the existing independent path.
No broad refactor of the 46 import-bearing files was attempted.

Verification: initial red wrapper could not find vitest outside npm PATH
(modular-safe-host-import-red); next fixture expected an unwrapped Vitest error
(modular-safe-host-import-red-test). Corrected control verifies its cause and
then fails specifically on the safe-mode import: modular-safe-host-import-red-control,
f2f0fb847209d647ec355b61eaa72868fd053cd6ba5a6cdc55c4ffe699a1cea4.
14 source tests/types/lint passed: modular-safe-host-import-focused,
31718d3c9a87dc98062c5d3993ec4afab014cc32d3a31cdb895c74f514fa9b8c.
Both built pristine-help aliases failed before index fix:
modular-safe-pristine-help-red, 8845c62a22934fbfdee780dd79efc08719470ea78e00d8aa7e6c6d9f74a698c9.
First combined run failed 2/42 because Consola defaults to warn under NODE_ENV=test;
fixed subprocess fixtures set CONSOLA_LEVEL=3, not a production logging change.
Native probe shows correct help/mod-list/version:
modular-safe-help-output-probe, 320b364c42c349600e0054f153c46db4bb7526835ca3b9446e931d47259f8362
(diagnostic output only; not an assertive acceptance test).

Codex review modular-safe-startup terminal23273: no blocking finding.
Packet64158eddbe8b6522bdbeff82135a493ef0ff2adfb8bd308af43dc51c7bda5cbf;
log4e47500ca93bd1d3d62f71b787303dccfe6a1c5bbd6a9e670eeba199b897dfeb.
Auth copy absence verified. Added suggested throwing-decorator and version
alias/bad-host tests; ordinary poison control explicitly clears safe mode.
Session63497 terminal FAIL: 43 passed/one failed; new test incorrectly assumed
`-v` is a version alias. Source `node_modules/citty/dist/index.mjs:438` recognizes
only `--version`; no alias added. Test now preserves `-v` exit1/no-command and
`--version` exit0 while checking host bytes unchanged for both. This is correction
of an invented expectation, not a relaxed production acceptance requirement.
Session96739 modular-safe-startup-final-focused ACTIVE; serialize run.py.
Need terminal focused result, assertive rebuilt CLI import probe, full gate,
final repeat, tracked evidence and local commit. No second review required.

CURRENT cd60a459e: strict-reader increment committed. Full gate77946 TERMINAL
PASS934.377s: 10,707passed/six skipped; log
3888176ca35d7d84a0805c6f4a36554efcec47df755122238f0ee19bc3ba765e.
Final built CLI2772 TERMINAL PASS1.338s, five requests, log
4e2183c276d834da78b9bca5cfe25ee72f64e49aabf8b73048e263408db02a82.
All zero providers; no push or global change. No active check. Old ACTIVE
paragraphs below are historical. Next: packaging boundary evidence below,
then continue original acceptance. Migration/Think decisions remain pending.

REFUTED verification concern before final strict-reader CLI repeat: I misread
JSON/tool escaping as two backslashes in the saved script. A character-level
check of receipt.command[3] proved the sequence is 92,117,102,101,102,102
(one backslash followed by ufeff). The prior probe DOES produce a real BOM.
The first final-repeat wrapper asserted two backslashes and failed before it
started run.py or a CLI. No test subject ran in that failed wrapper. The final
repeat replaces the single JS Unicode escape with literal U+FEFF to make this
unambiguous. Process correction: inspect decoded characters before diagnosing
serialized-source escaping. Earlier receipt remains valid BOM evidence.

Read-only packaging follow-up, 2026-10-19, during session 77946:
the rebuilt CLI contains selectable feature implementations, not only host
adapters. `packages/cli/dist/chunk-PQ43A7VE.js` defines
`createForgeWorkflow` (2193) and `runForgeCompetition` (3070), and the latter
is referenced by contribution handlers in that chunk (3490, 3531, 3540, 3550).
`chunk-4GKUJIEO.js:6912` constructs the legacy Forge workflow from that bundled
factory. Source path: `packages/forge/src/forge.ts:3` imports the public mod
factory; CLI tsup still inlines legacy Forge and does not externalize mod
packages. CLI also imports Goal's host factory from its public mod package.
The kernel bootstrap separately uses `await import(packageId)` at
`packages/mod-kernel/src/first-party-surface-bootstrap.ts:147`.

This is a verified final-packaging gap against
`docs/specs/modular-agon-authoring-build-and-packaging.md:266-276`: temporary
registry-first inlining is allowed, but final CLI/MCP must not embed selectable
feature implementations. It is NOT evidence of a disabled-mod bypass by itself.
The existing KL-007 check in `scripts/spec/verify-modular-kill-list.mjs` only
rejects old chunk path strings and engine-copy text in tsup config; it does not
inspect emitted code. Do not cite a green KL-007 as proof of this requirement.

Cause verified in installed build tooling: tsup's `getProductionDeps` in
`node_modules/tsup/dist/chunk-VGC3FXLU.js:76` includes dependencies and
peerDependencies, NOT optionalDependencies. CLI lists all 36 selectable mods
under optionalDependencies. Its explicit external array lists kernel/support
packages but no mod pattern, so public mod imports are bundled. Correcting the
external boundary alone is not sufficient: eager imports could then make an
absent optional mod prevent boot. Trace and exercise minimal/disabled/absent
package startup before accepting any packaging change. KL-007 currently has
no specific entry in the verifier's negative-control array either.

Next: after the current strict-reader increment is verified and committed,
trace all runtime imports and packed loaders; use the existing build/package
gates to discriminate embedded mod code from external package references.
Do not just externalize one symbol, add a parallel catalog, or claim removal
from package-directory counts. Inspect whether previous packaging receipts
already record this limitation. No source or test edits made during the gate.

Executable packaging red control on cd60a459eb0d0fc9c4ad0762181cc1acd8d7ae8d:
`modular-cli-embedded-forge-subject-red`, FAIL0.132s, zero providers, log
09caad5eed8607ef477f8f8862a00d85871badca0521f3f946fad6ea68b42d80.
The existing entire kill-list reports passed=true, including KL-007, while
the rebuilt CLI contains `runForgeCompetition` in chunk-PQ43A7VE.js. Assertion
rejecting embedded Forge fails as intended. This tests one representative
feature, not all 36. No code change yet.
Earlier `modular-cli-embedded-forge-red` used run.py's default cwd (the older
audit-remediation worktree), so it stopped at that tree's KL-013 failure and
is NOT current-subject evidence. Retained log
ddcf27d3160757bac8e1bbf409ef66acb331be3b38955afaa743a8a1f32b5f2d.
Corrected probe explicitly changes cwd and prints the subject hash. All future
relative-path probes through this helper must do the same.
Existing verify-modular-npx.mjs already covers minimal+think+review setup and
offline frozen installation; extend that qualification for absent-mod startup.

ACTIVE 77946: goal-historical-strict-read-full-gate. Freeze source/tests and
serialize run.py until terminal. HEAD f7101c610; new strict-reader increment
uncommitted. Backup backup/goal-strict-journal-f7101c610. No push/global install.

Confirmed inspection defect: historical corrupt JSON reported "No persisted
goal". Strict readJournalSnapshot in existing Goal journal owner now reads one
byte buffer, distinguishes ENOENT from other I/O failures, rejects invalid UTF-8
and JSON with fixed non-content diagnostics, and retains exact bytes/unknown
fields. Existing legacy loadJournal unchanged (including tolerant decoding and
null-on-error behavior). Host consumes strict snapshot; rejects null/scalar/array,
keeps identity/summary validation and authority checks. No adoption/publication,
new dependency, or changed personal state. Exact bytes support later migration;
this does not claim migration completion or old-writer quiescence.

Evidence IDs/log hashes:
- goal-historical-strict-read-red FAIL1.745s, corrupt case produced missing-state
  diagnostic: d6e458b1d4218b6d83f461112e81f2ea22f4aa0b2e83240d30c501f86cd83236.
- goal-historical-strict-read-focused FAIL9.712s, 21passed/four failed because
  tests imported old built Goal API without new snapshot method. Build fixed it;
  no test weakened. e3c65995fb3d04749baef958130ff43ddbeac89a166e39506af023a270c1f29b.
- goal-historical-strict-read-built PASS15.359s, 25tests/types/lint:
  b85ed1878f0181c3ecdac2744dde3c6301969f551a411f1eda2bbb371bd2bee3.
- goal-historical-strict-read-review-controls PASS11.112s, 26tests/types/lint,
  including BOM: ea20bdf6f459406457bc9dd277b2087dfd6619862a9208b2e30ed95e290bf424.
- goal-historical-strict-read-cli FAIL0.57s: stale CLI bundled host still used
  legacy loadJournal despite mod-goal build. CLI rebuild required and performed.
  148808d3686e5c470458cbaf4bef89abf6d155d7f3cc3d1657df22c3fb68aec5.
- goal-historical-strict-read-cli-build PASS0.454s:
  46f640268c7b68eddca99bfd1f5b5e3777c9a07397c9160d0c31cfc033a4f517.
- goal-historical-strict-read-cli-rebuilt PASS1.324s, five actual CLI invocations
  (missing, JSON, UTF-8, null, BOM), source bytes preserved:
  4e2183c276d834da78b9bca5cfe25ee72f64e49aabf8b73048e263408db02a82.
All test receipts zero providers. Probe script saved in receipt.command[3];
functions store goalStrictReadProbe is convenience only. Repeat with new run ID
after final full build, then record tracked evidence and commit explicit paths.

Codex review goal-historical-strict-read completed56483, no concrete defect.
Packet b46ee2b249327ee0b01cf0e41d348af4bfdeda87721480135d83dfe7287bd581;
log d5a4af49b5fef0431f15fdaad764422a08d8cdf6460279531e98007fe92a06d4.
Auth copy absence verified. Optional BOM control added/pass. Directory I/O error
is covered; a separate native EACCES control was suggested but is not claimed.
No second review. Build prerequisites now verified before public-API/runtime
probes: package consumers need Goal build, CLI host is bundled and needs CLI build.

CURRENT f7101c610caa2d5e9f300b6a917a9da98084009a: TUI registry fix committed.
Full gate78033 TERMINAL PASS862.235s, 10,698 passed/six skipped, log hash
321f556e091c94ba7670d4912e0f6e30d5cd400a8889c53ffcffc876799e6801.
Final source-route test with rebuilt dependencies16968 TERMINAL PASS2.872s,
log81f05d9fa6570f606670ede30754a6d584b3a77a3683f76f922bc175e8bd7489.
Both zero providers. Mode docs unchanged. Tracked evidence updated, clean tree,
no push/global install. All earlier ACTIVE handles are superseded.

Read-only committed acceptance diagnostic goal-tui-committed-acceptance-diagnostic
RED0.296s, log79acb5d84d9c6a209fe0e1d6ff0c4f56c924fe6ecf3bac9afe2164185b5b0a4b.
Commit/index review hash both bd9919dfb25aaebb78fb10e519cb78b2a94c9291ea06320a2de9f5c0ef8e4492;
no ignored/untracked/unstaged source contamination; 49packages/156unique edges.
Review error = review input policy mismatch. Source-verified: stored S1B review
manifest has old subject hash b23001a6... and no subject.policy; validation
expects current REVIEW_INPUT_POLICY (slice1b-qualification-gates.mjs:236).
This is stale historical evidence, not permission to rewrite its hash/policy.
Fresh final-subject review required after implementation; no clean steps requested
in this diagnostic. It performs no installation. Full release remains incomplete.

Next safe migration prerequisite to investigate: journal.loadJournal deliberately
collapses missing and corrupt bytes to null; the historical status host currently
uses it. Preserve that legacy public API, but migration will need one strict
snapshot reader distinguishing absence/corruption and retaining exact raw bytes.
Trace status behavior/tests before changing; do not silently convert malformed
state or add an independent parser. Quiescence/product and Think dependency
questions remain pending; this does not authorize adoption or a new dependency.

Read-only follow-up during TUI gate 78033 (2026-10-19): rejected a speculative
new regression claim that resuming without --engines loses the prior roster.
Physical prepareEngines reads this invocation's flags/defaults, but the legacy
CLI goal.ts:245-260 also builds requestedEngines from current args rather than
restoring journal.spec.engines into the implementation closure. Persisted
legacy engines must still be retained as migration provenance, but changing
resume roster policy is not established parity work. Do not add it as a new
requirement without stronger evidence.

Migration seam confirmed: ModServices.state has only read/write, so a mod cannot
directly invoke kernel migration APIs. Existing host injection is the correct
boundary for migrateStagedCopy. That API reserves staging with wx, checks source
bytes after conversion, and returns before/after hashes; it does not itself
publish owner state. ModStateStore.write publishes an owner/key/value record
with temporary rename and does not fsync. Preserve these limits in any adoption
receipt; do not claim power-loss durability from a process-kill test.

ACTIVE 2026-10-19: goal-tui-registry-full-gate session 78033. Freeze source/tests
until terminal; no concurrent run.py. HEAD 9f08f28fb, five source/test files dirty
(three CLI files, existing real-route test, new modular-goal-tui-routing.test.ts).
Backup branch backup/modular-goal-tui-9f08f28fb. No commit/push for this increment.

TUI fix removes /bin/sh + PATH dispatch. parseGeneratedCommandLine in existing
lazy-commands.ts reuses the selected generated command's argument projection,
Citty parser and option normalization, with non-expanding quoted text tokenization.
No new Goal catalog or dependency. Dynamic import avoids eager catalog/cycle work.
TUI captures generation and cwd before enqueue, checks before execution, and
passes the job signal plus captured cwd to runPhysicalCesarWorkflow. Optional cwd
parameter preserves other callers. CLI cwd default is overridden by captured cwd;
explicit relative --cwd stays relative to that captured invocation directory.

Evidence (durable logs and JSON receipts in this directory):
- goal-tui-registry-red: all ten tests failed on prior shell dispatch, zero
  providers, log b806102f70278358c8ed0f13f7db36adfa8ffb0c0082dbd63125b81f0718a34d.
- goal-tui-registry-focused: failed test module setup because static import
  eagerly constructed command catalog before mock contribution initialization.
  Corrected test catalog mock and used dynamic import in queued production path.
- goal-tui-registry-focused-2: 32 tests/types/lint pass, log
  9922dab9fdfed677a0a9d13b32f51ad24abaffa0ad1ef7716941724aff4bfb38.
- goal-tui-registry-contracts: 38 tests/types/lint pass, log
  c702c38eb81b3c3b1e183fdb091ef7d0493eae8bd2a851f1e737a7e02a18276a.
- goal-tui-captured-directory-red: both cwd variants failed, log
  0d7e115c10ff5d53b2196c85e7395d324eb6fd033d4a2fc543bd6e54a2205c57.
- goal-tui-registry-real-route: 46 tests pass, types failed ArgDef union for
  string cwd default; fixed by narrowing type === string, no assertion bypass.
- goal-tui-registry-real-route-final: 46 tests/types/lint pass5.441s, log
  39db81b0d5beb5fda00d0dccc24a9ec22d930879a70909695f9737680dad907b.
All test receipts zero providers. Unit controls cover quote concatenation,
escaped/empty quotes, aliases, --, negated flags, status/resume, unsafe shell
text rejection, stale generation, disabled mod, cancellation, and physical error.
Real-route test uses initializeProcessSurfaceAuthority/default services, real Git,
ModStateStore and TUI callback; verifies dry-run persistence and status/resume.

Isolated Codex review goal-tui-registry complete (35504 terminal), auth copy
absence verified. Packet 7bc88a92c3e56923c59d146a4e68854e491360bb30788134806fbc9bda87623c;
log 6bf0dbb635442f837cb4146c0072c71abe1e0640692e490f8525361ac666e418.
Confirmed cwd finding reproduced/fixed above. Conditional schema finding refuted:
physical Goal plan-step uses schema, not cesarSchema tool schema; actual route
calls the owner handler, which normalizes CLI numbers/arrays. Real-route check
passes string maxHours, status and resume through the actual registry. No claim
of a second peer pass. No other blocking review finding.

After full gate green: repeat real-route live test against rebuilt dependencies,
regenerate docs/modes.md (expected unchanged), record tracked evidence and commit
explicit paths plus generated release metadata. Keep whole release goal active.
Legacy journal adoption and pending Think dependency remain, see lower sections.

CURRENT 2026-10-19: 9f08f28fb, supervisor checkpoint identity repair committed.
78211 TERMINAL PASS, all gates green: 10,679 tests/six skips, 940.522s,
log SHA 2e1b854dd7b6c03787b97911c973d162f3f0f1529e979064a6fe2c92cac5231a.
Final built probe goal-supervisor-checkpoint-final-built PASS2.41s, seven
requests plus one real child, log SHA
a89f93c6ba9936fcddcd0118027fc78850d28bb2a0d0b4171694e49e1b03f7f1.
Both receipts zero providers; no push/global change. Detailed tracked evidence:
docs/specs/evidence/modular-agon-goal-forge-integration.md. All ACTIVE handles
below superseded. Next gap remains TUI Goal routing, described below.

Read-only parser trace: no reusable shell-argument tokenizer found in current
support packages/CLI. lazy-commands.ts owns Citty schema projection and option
spelling normalization; reuse that schema/argument machinery, not a duplicate
Goal option catalog. Cesar execution route already carries a job AbortSignal.
Potential fix must preserve quoting, escaped characters, --/negative flags,
status/resume, and reject shell expansion rather than executing arbitrary text.
Useful existing tests: modular-cli-nested-dispatch.test.ts and
modular-brainstorm-interactive-recovery.test.ts (job/registry boundary pattern).
No production code or tests for this gap have been changed yet.

Next actionable ownership gap (source verified while gate 78211 runs):
packages/cli/src/signals/dispatch/intent-orchestration.ts case 'goal' (around
436–454) runs /bin/sh -c `agon goal ${_gInput}` inside a background job. It
resolves whichever binary is on PATH, not the captured modular registry, and
does not pass the job's AbortSignal to spawnWithTimeout. Do not test it against
the active/global binary. Prove it with a stubbed spawn or isolated fixture.
Cesar's goal path in cesar-router.ts already calls runPhysicalCesarWorkflow and
executeProcessCesarRoute with structured arguments and a signal. Reuse existing
parsing/execution owners; preserve quoted CLI flags, background-job tracking,
status/resume behavior and output. Do not add a parallel Goal parser without
tracing existing schema/argument machinery. The mod's TUI parse hook returns
{input}; this is consumed by dispatchOrchestrationIntent, so it is NOT by itself
proof of a broken missing-intent call. Goal has no direct MCP tool registration
in createMod; do not invent an MCP execution defect from process.argv alone.

This gap is independent of the pending Think dependency and legacy-writer
confirmation. Address after the current startup/recovery increment is verified.

ACTIVE NOW: goal-supervisor-checkpoint-identity-final-gate, session 78211.
All earlier ACTIVE handles below are superseded. Do not restart or run run.py
concurrently. Source/test freeze. HEAD 515e3f6d8; no new commit or push yet.

2026-10-19 latest verification: first identity full gate TERMINAL FAIL, session
3786, 865.321s, zero providers. SHA
410be8364ff2b644ffd24e05f49fd6e76f5837c16ef88f2e8ca075465a82087b.
Three failed tests: (1) multi-error test reused an already-created ID and now hit
the earlier collision check; distinct IDs restore protected-branch/dependency
checks, retaining exact expected errors. (2) CLI parity lacked the new exact
supervisorRunId string/optional/no-default contract; added only that named field,
no broad exclusions. (3) nested generated-dispatch test expected resume=true for
both starts; now asserts false then true and one exact shared UUID. No production
source changed after that failed full run. Do not dismiss the failed gate as green.

goal-supervisor-checkpoint-contracts PASS 58 cases/types/focused lint/diff, 8.73s,
zero providers; SHA 2f715352f85002951594e245c110174c3e4fe2d44bac3d57eeef3dc8df02e1ae.
goal-supervisor-checkpoint-built-cli PASS 2.416s, seven outer CLI invocations plus
one actual supervised child; checks missing-state refusal, fresh startup, collision,
wrong run identity, correct CLI flag forwarding, matched recovery and manual resume.
SHA a89f93c6ba9936fcddcd0118027fc78850d28bb2a0d0b4171694e49e1b03f7f1.
Zero providers. Complete command persisted in receipt. Before running, probe was
corrected from baselineVerified===false to !==true plus attempts===0, matching
the source's unset flag on failed baseline. No failed runtime probe was hidden.
Full rerun goal-supervisor-checkpoint-identity-final-gate now started. Four
source/test files plus generated metadata remain uncommitted. Freeze until terminal.
After full pass, repeat the built probe with a new ID after the final build; then
record evidence/adjudication and commit explicit paths. Legacy adoption remains.

Migration design refinement during verification (not implemented): existing
ModStateStore.write in packages/mod-kernel/src/mod-state-store.ts publishes one
canonical owner/key/value record through temporary-file rename. Therefore an
adoption receipt and exact raw journal bytes can potentially live inside the same
Goal persistence envelope as the execution projection. This would avoid a new
selection pointer or second authoritative store. Verify crash durability and the
receipt contract before adopting that design; atomic rename alone is not an fsync
guarantee. Existing migrateStagedCopy still owns staged conversion/source-byte
preservation. Host injection can use its public kernel API without a mod importing
kernel internals. Preserve unknown legacy fields as raw provenance, not operational
spread fields. This is a source-grounded simplification candidate, not acceptance
evidence or an answer to the pending quiescence/product question.

ACTIVE gate: goal-supervisor-checkpoint-identity-full-gate, session 3786.
Poll the same handle; do not edit source/tests or run another run.py concurrently.
Last committed HEAD remains 515e3f6d8. Current source/test changes uncommitted.

LATEST WIP: startup/recovery distinction implemented, independent review race
reproduced and fixed locally. No new dependency or store. First supervised child
uses fresh mode unless resume was explicitly requested; retries use resume.
Missing state and existing-goal/state-change collisions stop. Fresh supervision
generates one UUID forwarded as supervisorRunId through the declared CLI schema;
the fresh checkpoint stores it and automatic resumes require an exact match.
Manual explicit resume remains allowed without this internal marker. Crash before
any checkpoint now stops on missing state, rather than silently initializing
again. This is a deliberate fail-closed recovery correction, not legacy adoption.

Evidence: goal-supervisor-startup-recovery-red failed four controls, SHA
46a664e20f372263fca842ea46c8a6ef0ef1ddcdfb2403eab14736caf075a270.
First correction passed 21 cases/types/lint (15af2c387ab72f987f65c76589f2fa16f6413634ca6719dd4d5d901bdf5a44a2).
Codex review goal-supervisor-startup-recovery found acquisition collision could
turn into an implicit resume. Packet SHA af888d8ba295ab6a56821b83f53cc113ddd428856769569dffe7ff6b74970896;
log SHA 7ad153410b3b05f4d608a26e58830f425254523075dd99f1a9be739c719f0434.
goal-supervisor-competing-checkpoint-red reproduced both acquisition collision
and replacement checkpoint after an early crash; SHA
a9c0b753ecfc88d1c58bfb1bd7da05d339a11bd931e83e5ff23d81528d981144.
Terminal classification plus stable checkpoint identity fixes both. Final
goal-supervisor-checkpoint-identity-focused PASS: 23 cases, types, focused lint,
diff check, 9.074s, zero providers, SHA
065b8f0fce8797a48ddd2f835a64b14263ba79a3f72f1bfc86030ede5f97cf7e.
Review temporary auth copy absent. No second panel claimed. Full gate just started;
record its returned handle below. Freeze source/tests until terminal. Built CLI
must still prove new internal flag forwarding, unknown-resume refusal, ordinary
fresh supervised startup, explicit resume, and identity mismatch rejection.

Correction to older note: runGoalSupervisor is exported from implementation.ts
for local tests, but NOT from the package index. runGoal is its only production
caller. The next migration work remains blocked on no claim of old-writer death;
the pending product question is not answered by this modern-state fix.

LATEST WIP after 515e3f6d8: one regression test added, no production change yet.
goal-explicit-resume-missing-red TERMINAL FAIL 1.472s, zero providers,
SHA bd27229fc8a905a761ef3435200192a1cd2b340ab628d177296ee9193fb29fe7.
Explicit resume with id+intent+gate but no saved state returns success and creates
a fresh goal; expected refusal fails. Supervisor startup coupling below must be
resolved with this defect, not broken by an isolated guard change. Existing
supervisor tests assert --resume on the first child. Only production caller of
runGoalSupervisor is runGoal; it is also publicly exported/tested. The runtime
interface has no persisted-state probe. No active process; do not reuse red ID.

CURRENT COMMIT: 515e3f6d8f67534c739f7fed91970c5467c363be,
fix(goal): retain retry limits on resume. Full gate session 90458 TERMINAL PASS
929.59s, 10,672 passed/six skipped, zero providers. Log SHA
9412885fe5b55f02434453c44d034364f81bde00fb1a29512d0ae33073a2cc27.
Built CLI session 65638 TERMINAL PASS, five invocations/1.7s, zero providers,
SHA 02eb5b82c06139ac07e89e89a1c9290e87f118b749db62291cec1da3db417585.
Tracked evidence includes review adjudication. Worktree clean after commit.
No push/global changes. All prior ACTIVE statements below are historical.

NEXT INVESTIGATION: explicit resume with no modern state and supplied intent+gate
falls through into fresh initialization (implementation.ts unknown-goal check).
Do not simply make all missing-state resumes fail: supervisorArguments currently
unconditionally appends --resume, including first child startup, and depends on
that same fallback. Need distinguish intentional fresh supervised startup from
explicit recovery, preserving crash/restart behavior without silently resetting
missing state. Source-confirmed coupling; runtime regression still to establish.
This is relevant to lossless legacy adoption, not its replacement.

Latest gate update: goal-resume-attempt-limit-full-gate is ACTIVE, session 90458.
Do not start another run.py process or edit source/tests while it is live. Poll
this handle and inspect its immutable log; quiet output is not a stopped run.
Independent isolated Codex review completed (session 93600 terminal), no blocking
defect. Packet SHA 7e232a724746bbebf99d46b581377c4305651286d401cf792d00a67ff8065daf;
review log SHA 4a4c523d9e15825a75ae4a1a8b325e57dd0c71cf891b6bda14c1371a37f86bc7.
Temporary auth copy absence verified. Suggested controls added and passed:
corrupt state cannot open capabilities or write state, valid explicit override
cannot bypass corruption validation even with supervised=true, lowered limits
do not retry exhausted tasks, and clamped limits survive resume.
goal-resume-attempt-limit-review-controls: twelve tests/types/lint PASS 14.38s,
zero providers, SHA 9145bc398a77cf2be3f6e05620c4a1263eecef8d5b3298a32098c62f6972c083.
After full gate: built CLI fresh/resume/override/status probe in isolated home,
record review adjudication and receipts, commit only verified explicit paths.
Legacy migration and the original full acceptance goal remain incomplete.

2026-10-19 latest WIP (supersedes clean-worktree statements below): Goal to
mod-forge approval reconfirmed; dependency already present at 1.0.0, no new
dependency edit or installation needed. Resume attempt-limit regression reproduced
by goal-resume-attempt-limit-red (expected one dispatch, observed three).
Implementation now persists maxAttempts, restores it only on resume, preserves
explicit overrides and old-record default three, and rejects invalid saved limits.
goal-resume-attempt-limit-focused passes nine checks, typecheck and focused lint,
zero providers; log SHA 2293635050a73a55d2f0f13d262126252328539bcdee619bead2a0762c0e3de8.
Two source/test files remain uncommitted. Independent review, full gate and built
runtime verification remain required before this increment can be committed.

Legacy resume control: goal-historical-resume-legacy-control passes, proving old
controller reads the same completed-task fixture that the modular CLI rejects.
Log SHA 8d030b496a0f009ac1167b342a41d3c03b278b7c56d4248a066cd159cac834b4.
Design review: goal-historical-resume-design-codex-review.log, SHA
c96981550e594e0de35172b8a913b1177b7756be6d2ccfc50906d6ff6083aec3.
Findings are migration hypotheses, not implemented acceptance. Preserve raw bytes,
costs, limits, frozen oracle and accepted commits; do not infer old writer death
from heartbeat. Operator question about explicit old-runner-stop confirmation
remains pending. This does not block the independent saved-limit repair.

CURRENT HEAD: 60c2d718831f2ff28c6ca6defedd9ac815860e60,
fix(goal): read historical journal status. Clean worktree; no push/install.
Session 38253 terminal PASS. Full gate 951.933s, 10,660 tests passed, six skipped,
all build/type/lint/generated/re-export/release/supply-chain checks green, zero
providers. Log SHA ea5769aa06b85c5a3ddc51b0e5b5128e66d39740a0ac1f98642ef97fce4117ff.
Final built probe repeated after the full gate: goal-historical-status-final-built,
0.393s, SHA 36d8a76c91d40eeb1acef4892aff7ad5c0797dba5481973b228311d746d2bf87.
All detailed evidence and review adjudication recorded in the tracked integration
note. No whole-product or clean-checkout acceptance claim.

NEXT LIVE REGRESSION: goal-historical-resume-red, 0.458s, zero providers,
SHA 8491172ad13f96653abea89d622dd4c2b0500fb49aecfb60b448f4d071d4f180.
Built CLI `goal --id legacy-resume --resume --dry-run` returns exit 1:
`Cannot resume unknown goal 'legacy-resume'.` Fixture has an actual Git repo,
goal branch with a completed task commit, valid old journal (spentUsd 0.25,
one attempt, maxAttempts 2/budget 5/maxHours 1), and the existing Goal owner's
frozen oracle. Journal bytes and accepted branch tip remain unchanged. Receipt
contains the complete reproduction; functions store legacyResumeProbeScript is
convenience only, receipt command is durable authority. Resume conversion is not
implemented yet. Use the field/authority/rollback map below before changing it.


Resume contract preparation (2026-10-19; read-only during full gate):
status slice is not resume migration. Original goal authorizes migration work;
the current implementation remains frozen while session 38253 runs.

Additional migration concurrency risk, source-verified: the legacy controller
does not acquire the modular Goal WriterFence. Its journal heartbeat records
time, not a process identity or lease; its Git update-ref is compare-and-swap
per task. Therefore an old process could keep editing its own journal while a
new importer reads a snapshot. A stale heartbeat alone is not proof of death.
Scope of search: `rg -n 'lock|pid|lease|heartbeat|update-ref'
packages/forge/src/goal/controller.ts packages/mod-goal/src/journal.ts`.
Required before acceptance: source-revision recheck at migration publication,
preserve rollback bytes, and explicit prior-host quiescence/restart semantics.
Do not solve this by killing unknown PIDs or changing the operator's active home.

Binding requirement: "Preserve required historical readers and verification
fixtures" and "Finish ... persisted-state migration, rollback and re-entry
requirements" (active six-stage goal). Repo AGENTS: "All handlers support
AbortSignal for cancellation." No dependency, installation or personal-state
change is needed for the status reader. Any resume conversion must be staged,
source-hash-bound, idempotent and rollback-safe, never overwrite the old journal.

Verified field map from mod-goal/journal-types.ts, implementation.ts:38-103,
legacy controller.ts:135-224, and oracle.ts:
- spec.goalId/intent/branch/gate -> id/intent/branch/gate, exact values.
- tasks.status inflight -> running/queued recovery needs proof; do not silently
  drop an in-flight attempt or reset completed/parked history.
- tasks.commitSha -> commit; prove every accepted commit exists in the chosen
  repository and is an ancestor of the retained goal branch before effects.
- tasks.costUsd has no current per-task counterpart; preserve raw provenance,
  not merely aggregate spentUsd. Attempts/attemptLog/lastError/notes also matter.
- spentUsd, parkedStreak, noProgressStreak, recentOutcomes, and configured limits
  must retain their original meaning. Legacy outcomes include parked; modern
  ring is typed done/failed. Mapping requires breaker-equivalence tests.
- startedAt is the legacy elapsed-time anchor; modern loop uses createdAt.
  Preserve elapsed budget without relabeling the original creation timestamp.
- legacy oracleHash refers to the existing goals/<id>/oracle snapshot. Reuse
  its gate.txt/hash.txt/files.json and exact file bytes. Never mint a fresh oracle
  to make an old run pass. Existing snapshotOracle(requireExisting) is reusable.
- legacy JournalState lacks repoRoot and initial baseSha. The controller uses
  the operator's repoRoot and reads goal branch HEAD before each task. Resolve
  current repository/branch and accepted ancestry explicitly; do not fabricate
  a historical base from current HEAD or claim the missing field was persisted.
- legacy events use numeric ts/kind; modern events use ISO at/type. Preserve
  droppedEvents and unknown historical fields in retained source evidence.

Verified control-flow difference: legacy controller reruns preflight on each
resume when nextTask exists. Modern controller skips preflight when prior
baselineVerified or any attempts exist. A migration cannot claim baseline
qualification merely because a legacy attempt count is nonzero.

Blast radius for eventual resume work: Goal journal/types/artifacts and physical
implementation, injected host effects, CLI service composition, legacy controller
compatibility exports, existing real-Git Goal tests and generated package outputs.
Open locally answerable work: historical commit/branch fixture; frozen-oracle
conversion fixture; killed-import/re-entry test; no repeated billing or work;
preserve source bytes on both success and refusal. No migration code written yet.


LATEST WIP after 3002bf0ed: historical Goal status fallback implemented in five
source/test files (CLI first-party-services, Goal host, implementation, artifacts,
implementation.test). Explicit journalEffects inject the existing journal owner;
readHistoricalState checks captured authority before/after read and exact id.
Status uses it only without modern state; returns legacy-journal tagged result
and existing summary. No writes, providers, resume conversion or new dependency.

Red unit goal-historical-status-red reproduced failure for valid old state;
SHA 8fa5ca63b0fc9ea5ecc2db55a22830839e0cf1fa8face86e71613e388c1b474b.
Initial green run failed only fixture equality: undefined optional properties
are absent from JSON. Corrected comparison uses actual persisted JSON, retains
byte equality. Failed receipt retained (8b4640bda9774cc5681c027fae69013707238e0144650bd560b1d78bbb5fd8e0).
Built CLI probe goal-historical-status-built PASS (4.745s), now prints historical
intent and remaining task; bytes unchanged. SHA
ab2ae4aa95b5e5b8a4d552408ffb96a336f458d5b3a87850e903c1f21a4aca7a.

One isolated Codex review (goal-historical-status) found malformed tasks could
misreport complete. Reproduced with tasks:[{}] and unknown status in
goal-historical-status-malformed-red, SHA
de5269a7591b52191f4ecc508b6a695da98bdbda3adea07b80e2a0773faaff11.
Fixed in shared summarizeGoal: validate fields used by status before deriving
completion. No second parser or state store. Existing summaries preserved for
valid input. Review packet SHA abc6aed710d99fbf0c11cdaeabe1114f9569b146264f2c2abdcf4e4192f3c757;
log SHA 0fa3d542b20856b26c11bf09ef229ade7a5819223d795ca9604a69045961ca3f.
Auth copy absent verified. No second review claimed for local finding repair.

Final focused run goal-historical-status-final-focused PASS, 16 tests/types/
focused lint/diff, 4.081s; SHA
58ea7f0364f71ceda1216d84bcce9068ba5979ecd9cf56bcdbc3f659c22e41c4.
Includes authority revocation during path resolution and throwing historical
reader with modern state present. All test receipts have zero providers.
Full goal-historical-status-full-gate launched, session 38253; SOURCE/TEST FREEZE until
terminal. After green, repeat built probe using its receipt command (new run id),
record tracked evidence, commit locally. Legacy resume migration and controller
retirement remain required, not solved by this status-only increment.


CURRENT COMMIT: 3002bf0edf876615a4c0cef303926d7170501ade,
fix(goal): honor supervised invocation cancellation. Full gate terminal PASS
in 945.115s: 10,650 passed, six skipped, all build/type/lint/generated/re-export/
release/supply-chain gates green, zero providers. Log SHA-256
7e65963b268db4e4b45e61a933f59d2c15c2e3b73882a8a66959ca69721e6804.
Tracked integration note records review, red controls and coverage limits.
Worktree clean after commit; no push/global installation. Session 24177 terminal.

NEXT CONFIRMED DEFECT: goal-legacy-journal-status-probe fails on built CLI.
The probe creates a valid JournalState through the built public Goal journal
store in a fresh isolated home. The same store reads its task successfully.
Built CLI `goal --id legacy-status --status` exits 1 with
`No persisted goal 'legacy-status' was found.` Original journal bytes unchanged.
Receipt exit 1, 0.405s, zero providers; log SHA-256
465cef464d62968ca5a745f71af3ca1e010f55555329924b6a6ed8b14a9c85a1.
The receipt contains the complete reproducible Node command. This is now a
runtime-proven compatibility defect, not merely a source observation.

Traced boundaries: first-party-surface-bootstrap.ts:createServices constructs
ModStateStore(hostRoot, manifest.id); mod-state-store.ts hashes keys beneath
`mod-state/agon.goal`. Goal readGoal only reads that store. Goal journal.ts
uses `goals/<id>/journal.json`. CLI first-party-services.ts supplies the only
production createGoalHostServices call, with existing host-owned oracleEffects
path/ensureHome and captured authority. No migration bridge found in that route.
Next implementation must reuse the Goal-owned journal reader through injected
host effects, not read personal/global paths directly or introduce another store.
Preserve modern-state precedence, original bytes and disabled-mod enforcement;
test corrupt/absent journals and historical status. Resume needs a separate
lossless migration of counters, accepted commits and frozen oracle evidence;
do not invent baseSha/repo identity or silently restart historical work.


Read-only follow-up during cancellation full gate (2026-10-19): old Goal
state migration remains a distinct acceptance dimension. Verified source:
`mod-goal/src/journal.ts:createGoalJournalStore` reads host-home
`goals/<id>/journal.json` as JournalState; `implementation.ts:readGoal` reads
`services.state.read(goals/<id>)` and unwraps a GoalState plan envelope.
The generated Goal route does not call the old CLI goalCommand; its only
source occurrence under CLI is the definition in commands/goal.ts.
Legacy Forge still exports controller and supervisor, so deleting their source
would break that library contract without a compatibility decision/adapter.
`tests/unit/modular-release-state-migrations.test.ts` defines its own
`migrateLegacyNdjson`; it proves staged byte-preserving envelope conversion,
not production Goal journal resume. Do not count it as Goal migration proof.
Before retiring the legacy controller: trace actual host state storage,
exercise a historical journal through installed Goal status/resume, preserve
the old bytes, and prove counters/oracles/accepted commits are retained.
No production migration defect is claimed from these source observations alone.


LATEST: cancellation Codex review finished exit 0, no introduced blocker.
Packet SHA 8517ad4d2a79e2d7a72bf0844dc241ccae13a5fedda8817cee7877f229c5daa3;
log SHA cf889c609f6fb3db63c68379bcd198eb0809d56465a6fdc0e4be66d826be732e.
Temporary auth copy confirmed absent. Source-verified coverage suggestions
implemented: abort during state read, exactly one child launch, backoff timer
cleared, accumulated stdout marker. Fifteen focused tests/types/lint pass in
goal-supervisor-invocation-cancel-reviewed (3.099s, zero providers), log SHA
ea63a46d2dbe56ac614481650b700a1418c0b0b16cf6904c0c9ebc46ec8d6c77.
Full goal-supervisor-invocation-cancel-full-gate launched, session 24177. Source/test freeze
until terminal. Not committed. Pre-existing resistant-child/process-descendant
limitations remain unqualified; no blanket prompt-cancellation guarantee.


CURRENT 2026-10-19: missing-queue correction committed as
3b449310cc63df3734c913ba7208b8eb097afc40. Full gate passed: 10,646 tests,
six skipped, zero provider launches, 951.978s. Log SHA-256
132c1378d137321da9f787e6e871e23947a16505fb48b2ca70988c4e5971b182.
Old session 33276 is terminal, not active.

WIP: invocation AbortSignal was ignored by supervised Goal. Real-child red
controls proved unwanted spawn after pre-abort and missing termination after
active abort. Correction wires the existing runtime to the signal, checks
before spawn, propagates the original reason, and removes listeners.
Initial backoff fixture used zero retries and therefore never entered backoff;
that test failure is retained, not counted as production-defect evidence.
Corrected fixture permits one retry. Run
goal-supervisor-invocation-cancel-boundaries-corrected passed 14 focused tests,
types, focused lint and diff check (3.146s, zero providers). Log SHA-256
2cf62fb057faafc096b93407af11626015289d7c38711625131780e771d99fec.
Isolated Codex review goal-supervisor-invocation-cancel active, session 1912.
This correction is not full-gated or committed yet. No push or install.
Goal-to-Forge approval already fulfilled; Think dependency remains unapproved.


CURRENT WIP after 54057119d: missing-queue supervisor correction reviewed.
Codex goal-supervisor-missing-queue finished exit 0 with no blocking finding;
packet SHA b97e5c0c293d16592f0654647a7a57394b5b97d056e7c1c81e85044b087dad02,
log SHA 17cef27197c3c65065af168bae418b5df38187eedb42e6ceda930ed3bab7fcd3.
Reviewer correctly notes substring false positives are an existing heuristic
limitation, not introduced here; clean exits take precedence. The focused run
also covers transient restart and 17 legacy supervisor cases. Review did not
run tests. Auth copy verified absent afterward.
One actual built-CLI run (goal-supervisor-missing-queue-cli) passed: spawned
supervised Goal, real child reports absent queue, exits 1 with restarts=0 and
deterministic reason within a 4s process timeout. Provider launches zero.
Log SHA 60eab7e6e4c0b50a5d66a3ea8ece6e49d6e05ca2abe4acd9f89e98e946b0263f.

Full gate goal-supervisor-missing-queue-full-gate ACTIVE, exec session 33276.
SOURCE/TEST FREEZE until terminal. Poll same handle, no restart for quiet output.
No commit for this change yet; two source/test files dirty plus expected release
metadata regeneration. On green, append evidence to tracked integration note,
commit explicit paths, continue ownership/parity and release requirements.
Think dependency still pending; do not add it. No push/install/global changes.

COMMITTED: 54057119d8221464235cf12dc04d18b5f764426e, preserve Goal review
consensus. Full goal-consensus-final-full-gate passed in 902.794s: 10,645 tests,
six skipped; all build/type/lint/generated/re-export/release/supply-chain gates
passed, zero providers. Log SHA
5562d7d151cd4ad23058d44b12c86fa05833882743cd2c8ceeeb215e94da81f2.
Session 25642 terminal. Tracked evidence note includes failures and adjudication.
Worktree was clean after commit. No push/global installation.

NEXT WIP: supervisor missing-queue regression. Actual runGoal error fed into
runGoalSupervisor reproduced two retries instead of zero (goal-supervisor-missing-
queue-red, SHA 7936e0f2922add1b4c83307b945eaf85c30462e83b45a601bf5f99f31eeec4ef).
Added the missing `queue not found` phrase to the existing classifier, matching
legacy behavior. Green receipt goal-supervisor-missing-queue-green passes 11
modular cases plus 17 legacy cases, types/diff, zero providers; SHA
f1c183e2c5822bad6e7d9c0261be162b9949e237fa24584cb8e1f280cf33b3e2.
Only implementation.ts and implementation.test.ts are dirty. Isolated Codex
review goal-supervisor-missing-queue launched; see process handle in continuation.
No full gate for this new change yet. Keep goal active; Think edge pending.

CURRENT: goal-consensus-unavailable-panel-diagnostic PASS, 76.312s, ten tests,
types/full lint/re-export guard/diff, zero providers. Log SHA
e0f284f93f98a4a9a50761878d600465c11a9d6d8a18b7ae2e8d4b49e7cde24d.
Fresh full gate goal-consensus-final-full-gate ACTIVE, exec session 25642.
Same complete command as prior run; isolated state/provider blockers plus local
socket/watch permissions. Source/test freeze until terminal. No commit/push.
Poll 25642 on continuation; do not restart on quiet output. Previous failed
full receipt is retained and does not qualify acceptance. Next action on green:
record review/adjudication and full receipt in existing Goal/Forge evidence note,
commit explicit paths, then continue Goal supervisor/controller retirement.

LATEST: full gate goal-consensus-reviewed-full-gate TERMINAL exit 1 after
822.147s: 10,644 passed, one failed, six skipped, zero provider launches.
Log SHA 25a4864610c1c709ef06c86c868933d8b74a3c14b4807c241939c4cf71de6d99.
Only failure: unavailable-panel test expected task.error `review=1`; the reviewed
diagnostic repair now preserves `Unknown or inactive review engines: builder,
reviewer\n`. Existing attemptLog assertion already expects this reason. The
failure is an obsolete diagnostic assertion, not lost blocking: exit 1, no
extra dispatch and zero commits remain asserted. Updated exact task error and
added exact review-block event detail; no production change or weaker guard.
Focused goal-consensus-unavailable-panel-diagnostic ACTIVE, session 54185,
covering ten cases plus types/full lint/re-export guard/diff. No commit yet.
Session 88563 is terminal; do not poll/restart it. Full gate must be green before
committing. Later stages were not reached after npm test failed.

### Retirement trace during full-gate wait

Source checked on 58d4ba5f3 plus the consensus WIP, 2026-10-19:
- Next supervisor safety check, source observation on 54057119d plus queue fix:
  `runGoal`'s supervised branch calls `runGoalSupervisor(raw)` without passing
  context.signal. `processSupervisorRuntime` subscribes only to OS signals;
  its child termination and backoff wake-up are otherwise private. The loop
  checks interrupted only after starting a child. Reproduce invocation abort
  before spawn, during child execution and during backoff, plus listener cleanup,
  before changing it. Existing supervisor tests mostly inject a runtime, so they
  do not prove this actual process boundary. This is a potential cancellation
  contract gap, not yet executable evidence or a claim about live providers.
- Built-artifact check during the next gate: CLI source maps mention legacy
  controller/supervisor files, and its JS contains their bare imports. However,
  `rg -n 'runGoalController|persistGateLog|runSupervisor|writeGoalArtifacts|goalCommand'
  packages/cli/dist --glob '*.js'` returns no matches. These functions are
  tree-shaken from this launcher build, not demonstrated duplicate executable
  Goal loops in the launcher. `packages/forge/dist/index.js:46-47` still exports
  them as a library. Release-set packages contain no `@kernlang/agon-forge`;
  its compatibilityArtifacts contain only the dedup sidecar. This narrows the
  retirement issue to remaining source/public-library ownership unless another
  runtime consumer is found. It does not establish complete installed parity.
  Do not cite source-map presence as proof of live execution.
- Pending Think integration needs two distinct decisions in implementation:
  package import availability and optional activation. Current generator line
  188 turns every package-map edge into a required activation dependency, and
  Goal's manifest has no optional edges. Blindly adding Think there would
  disable ordinary Goal when Think is disabled, contrary to the pending
  approval request. ModServices has no generic workflow invocation service to
  reuse instead. Preserve the agreed optional `--think` behavior; do not add a
  generic dispatcher merely to avoid a package edge. No dependency was added.
- `cli/src/lazy-commands.ts` routes Goal through the generated registry, and
  `lazy-commands.test.ts:181` forbids importing the old Goal command. The old
  `cli/src/commands/goal.ts` still calls the legacy controller and supervisor.
- `forge/src/index.ts:92-94` still publicly exports controller, artifacts and
  supervisor functions. `goal-oracle-jit.test.ts` and `goal-journal.test.ts`
  exercise controller/artifact imports; `goal-supervisor.test.ts` exercises
  supervisor exports, including real child processes. Preserve these contracts
  or explicitly migrate their callers before deleting their owners.
- The modular supervisor and legacy supervisor are separate implementations.
  Legacy checks journal completion after a crashed child; modular supervisor
  currently decides from exit code and output alone. Legacy exposes backoff
  configuration and emits supervisor events. Modular runtime has injectable
  child/wait effects and disposes signal handlers. These differences require
  parity checks before consolidation; no fix selected from resemblance alone.
- `mod-goal/ownership.json` lists 14 inventory occurrences but does not list
  controller/supervisor function definitions. The 15-row kill-list verifier
  checks selected dispatch/catalog patterns, not every legacy implementation.
  Neither ledger count nor a passing kill-list proves controller retirement.
- Concrete next supervisor regression candidate: physical `loadTasks` throws
  `Queue not found: ...` (implementation.ts:383), but
  `isDeterministicGoalExit` omits `queue not found`. Legacy
  `isDeterministicExit` includes it and its test proves no retry. The modular
  supervisor therefore classifies this permanent input failure as transient.
  Reproduce through `runGoalSupervisor` using the actual `runGoal` diagnostic
  before editing. This needs no new dependency or live provider.

Next retirement boundary: reconcile public controller/supervisor contracts with
the physical Goal runtime, then reuse the existing owner through narrow public
compatibility calls. Do not move a second executable controller into mod-goal
and call that consolidation. Think parity remains a separate pending dependency
decision. This trace changed no source, tests, package graph or acceptance bar.

2026-10-19 CURRENT WIP: Goal consensus repair implemented, not committed.
Backup branch backup/goal-consensus-58d4ba5f3. No dependency change.
Moved CLI consensus.ts unchanged into mod-review/src/consensus.ts; old path is
an explicit compatibility re-export. Moved extractReviewFindings unchanged from
CLI handler into mod-review/src/findings.ts (local sentinel constant); old
handler imports/re-exports it. Generator owns new public exports and .d.ts pack
entries. Surface catalog regenerated after manifest change. Existing consensus
and parser policies were not edited during the moves.

Goal uses raw seat output through the shared legacy parser before consensus,
preserving inferred confidence and sparse verified findings. Failed transports
have empty output and fail closed. Non-object finding rows fail closed. Verified
solo/pair findings and no-verdict panels never reach adjudication. Medium findings
begin blocked; only valid successful judge answers can clear them. Judge input
now contains needsCheck, mutation evidence and taskDiff (separate bounded fields),
not the whole panel output. Retry diagnostics use consensus.summary, not review=0.
Public Review command parsing/verdict output is intentionally unchanged in this
bounded Goal repair. Existing accounting tests now use 0.8 for legitimate
adjudication; separate 0.9 no-override regression remains.

Evidence (all logs in this directory):
- review-consensus-owner-parity PASS: byte-identical consensus move, package
  build/types, legacy consensus/summary tests, guard; SHA
  68db9160fd9ab97607cc62611a09c393572aa66f1aaa4bbe6e949d2c6f14e722.
- goal-verified-blocker-green PASS, regression + types; SHA
  5e273b31f72f872da001ee1a7903117d00645e8cff9133ab78cf27253d9130f2.
- goal-consensus-parity-controls PASS 20 focused cases/types/lint; SHA
  1279929cecb5b4c69d7e070b9c45816595e2f3ab11983b7ae3850dc4ee674636.
- Isolated Codex review goal-consensus-policy finished, exit 0. Packet SHA
  942d4b07c6f68111e144c1865febd2d2b472f19d4a10c09ff3ad7b651d5504ff;
  review log SHA 0d538350058fff7d9d3b7df1ed88ffffc7ebc4e72efb2634cc10dfdc79d30e83.
  Auth copy verified absent. Findings: missing diff/whole-panel judge input,
  lost raw confidence/sparse findings, misleading retry diagnostics. Source
  confirmed; corrected locally, no second panel under one-review rule.
- goal-consensus-review-findings-red selected zero tests (Vitest quotes table
  names), so INVALID evidence despite exit 0. Keep receipt, do not count it.
- Correct goal-consensus-review-findings-red-selected ran eight cases: four
  failed as intended, four passed. SHA
  fc5c27814a2e86144359c26d02b56b12f0c91383c0987e0fd6833bfc45e808e2.
- goal-consensus-generated-boundaries failed stale surface catalog; regenerated
  with existing generator, no exclusion or oracle weakening.
- goal-consensus-reviewed-controls PASS: 22 Goal cases +112 legacy/parser/Review
  cases, package build/types/generated checks/guard/focused lint/diff; 52.635s,
  zero providers. SHA ebab514aa773c71dd3b0b99fafa10ddd835d5daddd3869ce19a0bb3689b13137.
- goal-consensus-retry-diagnostics PASS: ten cases incl. actual retained retry
  and resume, block->repair->success attempt records and no judge override,
  consensus diagnostic text, types/diff; 24.516s, zero providers. SHA
  689f44292a2462213bbe5354f2fdd4efb446ae02d5b516619e51e686a3049d24.

Full gate goal-consensus-reviewed-full-gate is ACTIVE, exec session 88563. SOURCE/TEST FREEZE
until terminal. Poll the same handle on continuation; do not restart. No
commit/push/install. Goal -> mod-think approval remains unanswered, separate from
this fix. Last clean committed base remains 58d4ba5f3; goal remains active.

CURRENT WIP after 58d4ba5f3: one Goal regression test only, no production edits.
Confirmed review-policy regression, not a new requirement:
- Legacy cli/commands/goal.ts:595-608 uses buildConsensus, refuses autoBlock
  immediately and judges only needsCheck. One blocking finding at confidence
  0.85 or higher, or a qualifying pair, cannot be cleared by another judge.
- Physical Goal implementation.ts:1497-1524 judges any failed Review result.
  A 0.9 blocker can therefore be cleared and committed. Existing accounting
  tests at the end of implementation.test.ts accidentally encode that drift.
- New test "does not let adjudication clear a verified review blocker" uses
  real temporary Git worktrees and the existing Goal harness. Correct red run
  goal-verified-blocker-red-valid-roster failed expected true to be false at
  the assertion forbidding an Adjudicate call; log SHA
  da2225b11e2848f2331e385a40474a94f2b7b37ee97aa7595d58525db4c96a73.
- Initial goal-verified-blocker-red is INVALID negative evidence: fixture judge
  ID was unavailable, so admission rejected before review. Preserved; do not
  count it as reproduction. Corrected test uses existing reviewer engine.
- All runs terminal, zero providers. Only dirty path is
  packages/mod-goal/src/implementation.test.ts. Last full green base is 58d4ba5f3.

Repair direction: reuse the existing consensus algorithm, not another threshold
implementation. Current owner cli/src/blocks/consensus.ts has six source/test
consumers (rg -l 'blocks/consensus|buildConsensus|formatConsensusRow' packages tests
--glob '*.ts' --glob '*.tsx'). It is pure TypeScript, no imports. Move unchanged
policy to mod-review, export through its existing public index/generator, retain
CLI import compatibility during migration. CLI and Goal already depend on
mod-review; no new package edge is needed. Update physical Review/Goal to expose
and use autoBlock/needsJudge while preserving existing consumer output fields.
Verify paired findings, lone-medium findings, failed panel, speculative/nit,
duplicate-engine votes and malformed answers. Existing Goal judge-cost tests
must use medium-confidence findings to exercise legitimate adjudication;
retain the separate high-confidence no-override regression. Do not silently
change the old consensus implementation while moving ownership.
Refactor skill read; green baseline, source history and consumers inspected.
Before moving, finish impact list (index/manifest/generator/pack declarations,
consensus tests, Goal tests) and announce scope. No code move performed yet.

Cost scope correction: legacy Goal also uses absent Review usage -> zero and
does not account pre-run Think. Do not treat every unknown-cost edge as a new
migration regression or expand billing requirements without evidence. The
verified blocker-policy and Think-parsing differences take priority over that
speculative expansion. The accepted original ownership/behavior requirements
remain unchanged.

COMMITTED: 58d4ba5f3904629278874cd02a7afff32b007ab8 (shared engine usage
estimates and tracker validation). Clean worktree; no active test process.
Assessor acceptance-58d4ba5f3 exited 1 as expected: clean=true, roadmapValid=true,
all commands available, readySlices=[], all nine aggregate receipts missing and
all nine reviews report input policy mismatch. Log SHA
6e1be93a41ad455e0bba178b107732fc3c9ef624a9a258e64f302668059b9f1a.
Do not relabel the full working-tree gate as committed release qualification.
Next read-only trace: legacy Review's usage estimator versus physical Review's
absent-cost -> zero fallback. No new production repair selected yet.

TERMINAL: modular-dispatch-reviewed-full-gate PASS, 832.038s, 10,636 passed,
six skipped; build/types/lint/re-export/generated/release-set/supply-chain green.
Zero provider launches. Log SHA
789504c382a55b299db7fa35bdc18696f991acc7d013af4d64b6971ad09e3ae1.
Session 75489 exited 0. No test process remains active. Evidence appended to
the tracked Goal/Forge integration note. Local commit pending. The new optional
Goal -> mod-think dependency was requested asynchronously, not approved or added.

Next ownership/parity slice, source verified during the running gate:
- Legacy packages/cli/src/commands/goal.ts:271-310 runs Think when no journal
  exists (including the first supervised --resume invocation), persists the
  structured result and adopts refinedSpec only when protocolValid is true.
- Modular packages/mod-goal/src/implementation.ts:718-744 skips on any resume
  flag and appends any successful nonempty raw answer. Its current frozen-evidence
  test explicitly expects that raw behavior; it does not prove legacy parity.
- packages/mod-think/src/implementation.ts already owns parsing, grounding,
  protocol validation and branch selection, but runThink is private. Its dispatch
  currently omits textOnly, unlike legacy runThinkChain. Verify adapter behavior
  with a regression before selecting a correction; do not claim live tool use.
- Goal currently has no mod-think package edge. Reuse the existing owner rather
  than copying parser/grounding or adding another Think implementation. Any new
  internal dependency still needs explicit authority; current approval is Forge
  only. Goal without --think must remain usable when Think is disabled.
- Legacy runGoalController remains exported from forge/index.ts and consumed by
  cli/commands/goal.ts. Do not delete it merely because the generated Goal route
  exists. Retire after full semantic parity and historical-reader proof.
These observations are not remediation or new acceptance criteria. They restore
the original behavior-preservation and physical-ownership requirements.

Latest: modular-dispatch-reviewed-host-controls PASS, 130 tests plus typecheck,
full lint, re-export guard and diff check; 60.906s, zero provider launches.
Log SHA 5d9f1b05b8af714b70ecdd46cb104e8bd0ba0530ef60a3e8bf7db6af4611ff4b.
Full gate modular-dispatch-reviewed-full-gate is ACTIVE, exec session 75489,
with isolated state/provider blockers and permission-correct local socket tests.
Source/test freeze until terminal. No commit/push/global changes.

2026-10-19 continuation: Goal -> mod-forge approval reconfirmed; dependency is
already committed in aa3c551a5. No new dependency change or installation needed.
The modular-dispatch-cost Codex review finished (exit 0), not active. Packet SHA
0c6f478dadbe8e229898b8a5c36d72f6dd3e38eba2eaf7955b1146bd6154b6e3;
review log SHA 5a515ee467eebfd21dcfbb9eb6c41184d7a2fb941ff3b786fce96de80e6a81f3.
Confirmed accounting boundary defect: malformed counts entered TokenTracker and
could poison aggregates. Validation now rejects non-safe-integer/negative
counts, invalid source and invalid cached counts before mutation. Existing pure
pricing clamp remains unchanged. Review-selection tests reset their tracker.
The first token-tracker-invalid-usage-red run was INVALID evidence (missing
TokenTracker import, ReferenceError). Preserved, not counted as a negative
control. Corrected run reproduced seven missing-rejection assertion failures:
token-tracker-invalid-usage-red-corrected, log SHA
708198edcda28820f8f7f519fe175da90d8db40d80f7929ee54f03b4c0d8dcde.
After correction modular-dispatch-reviewed-usage-validation passed 128 tests,
typecheck/focused lint/diff; zero provider launches, 4.783s. Log SHA
f27388944f3ef0c058dd8077e84a1afc59c17174d1e2393b9af546b49150316a.
Added host-level malformed-usage rejection and exact fallback cache-price
assertions afterward; modular-dispatch-reviewed-host-controls is running.
No adapter-side tracker.record/trackUsage calls found in adapter-cli source.
No demonstrated duplicate recording; this is not proof of all session lifetimes.
Pricing provenance, absent-usage Review zero, Goal auxiliary costs and full
installed qualification remain open as described below. No claim of billing
accuracy or release acceptance. Current changes remain uncommitted.

CURRENT WIP: shared CLI/MCP dispatch cost for returned usage. Both engine service
implementations reuse tracker.record and return costUsd plus costSource (usage
provenance), preserving raw usage. Missing usage remains absent, not measured
zero; Review's treatment of missing usage remains an open consumer gap.
No dependency or price table added. Before: six red CLI/MCP cases, SHA below.
After: modular-dispatch-cost-green passed 58 tests/types/lint/diff, SHA
8de88b9c6d62dcdac6f4e424d552bd52bc1545fffcc3da44372e195e949823b6.
modular-dispatch-cost-consumers passed 108 tests/types/lint/diff in 4.084s,
SHA 621f4ed452a467ca0a755fba81569120db71b79670118d676d7a87a1d0380c55.
Controls use actual tracker and actual CLI/MCP host plus Review consumer, with
only adapter/provider dispatch mocked. Cover cache discount, flat-rate zero,
success/failure Review costs and absence of fabricated missing usage.
ACTIVE isolated Codex review modular-dispatch-cost, exec session 24042. Verify
receipt/auth-copy cleanup after terminal. No test process active. Four dirty
files: CLI/MCP first-party-services.ts, modular-engine-dispatch-contract.test.ts,
modular-review-engine-selection.test.ts. No full gate/commit for this WIP.

CURRENT COMMITTED POINTER: 3ede3cd77, fix(adapter): retain usage when API output
persistence fails. Full api-artifact-reviewed-full-gate passed in 831.591s:
10,619 tests, six skipped; build/types/lint/generated/re-export/release-set/
supply-chain checks passed. Zero provider launches. Log SHA
7363cc7a26a7d4b36c22e5c88bc6ae09882832283759699592a3091f10e8b1e5.
No full-gate process is active. The worktree was clean after commit; only the
new shared-dispatch contract regression test is WIP now. Focused red run
modular-dispatch-cost-red reproduced six failures across actual CLI/MCP engine
service implementations: reported usage has no costUsd for Review/Goal to use.
Log SHA 027c678c1399589461a25c3bdde0beed1431e4f14f62e175d50ac593eaa0d714.
No subprocess remains active. No production repair chosen yet. Keep original
accounting and unknown-usage semantics explicit, not silently measured zero.

CURRENT WIP after aa3c551a5: API agent output-artifact usage preservation.
Read-only next-slice tracing while the full gate runs:
- CLI first-party-services.ts:216-225 and MCP first-party-services.ts:93-111
  return raw usage but no costUsd. Review implementation.ts:240 reads only
  costUsd and substitutes zero. Goal adjudication reads the same absent field;
  Think and PR drafting do not account returned usage at all. These are source
  observations; next slice must reproduce through actual host services, not
  mocks inventing costUsd (current Goal judge tests do so).
- Prefer repairing the shared dispatch/accounting boundary using existing
  pricing/usage owners over more Goal-only calculators. Verify package ownership
  and subscription/estimated-cost semantics before selecting the repair. Do not
  add a parallel billing subsystem or silently equate missing usage with zero.
- Goal's pre-run Think also differs from legacy structured chain parsing and
  grounding. Legacy runThinkChain is one dispatch plus parsing/grounding (not an
  unbounded loop). The physical Think mod already has those operations. Do not
  invent a multi-call requirement; compare actual legacy outputs and consumers.
- captureNewAgentDiff uses readOnlyDiff, which catches normal Git read failures
  and returns an empty string. A thrown Git diff dropping usage is not currently
  demonstrated. Do not implement speculative exception machinery for it.

- Two real EISDIR cases reproduced discarded billed usage in dispatchAgent and
  dispatchAgentStream. api-artifact-usage-red failed both, SHA
  4f7da1bf7483a9d0d0343749598686ab74c8b8d6458ac8d0b5fbfe6f97e5db6b.
- CliAdapter now shares a private persistApiAgentOutcome method: normalize the
  result first, then write. Write failure returns a failed result retaining
  usage, stdout and prior timeout/cancel code/reason. No new provider fault flag.
- api-artifact-usage-green passed 26 tests/types/focused lint/diff, SHA
  2788b1d1bc41b40e96ad288d9bd9c37778839df2cb994ee89d560038ba20fc65.
- Expanded eight artifact-failure controls plus existing regressions: 32 tests,
  types/lint/diff passed in api-artifact-terminal-controls (3.683s), SHA
  0b96d22e0c2d03e7cc0ea7f36d844fb96b9a391cc62a35f4757980fda3f72cf7.
- Isolated Codex review api-artifact-usage completed. Packet SHA
  42b16ed0937bf9debbfdac55f1eb5f63e75270073cb960c60b2123bf699a256f,
  log f46b6e20168796ff4973ef20eebf35fbd02956ad21e99b32cb7ce2e55c99f738.
  Temporary auth copy verified absent. Usage/status fix had no confirmed defect;
  health contamination hypothesis verified locally: output path containing
  unauthorized quarantined a healthy engine. api-artifact-health-red failed six
  cases (timeout controls passed), SHA
  29d89d5f16cd71f88374399f2a52b5f8fe6d2b3906206ec44c7f27d5addbcf09.
  Fix classifies provider health before appending local write errors; shared
  classifier itself is unchanged. api-artifact-health-green passed 32 tests,
  types/lint/diff, SHA
  54b7f5ad3f21cc6bb104ed58be25ad0edca4ca53a8c50233bc7ca0d9c38a7b33.
  Tests now assert actual engine health, timedOut and retained EISDIR text.
  Two additional engineFault preservation cases passed: 34 tests/types/lint/diff
  in api-artifact-reviewed-controls (3.756s), SHA
  764023a51d8f574f126cc7ca56c13a0ed0607f8019f752f8025d7ca3ca63b5b7.
  No repeat review panel is needed.
- COMPLETED api-artifact-reviewed-full-gate, exec session 14378: full build, release-set/SBOM refresh,
  full tests/types/lint/generated/re-export/release checks. Provider-blocked,
  isolated state, local socket/watch permissions. Freeze source/tests until
  terminal and do not start a second run.py. Source edits: adapter.ts and adapter-api-fallback.test.ts.
  No full gate/commit for this new fix. Other dispatch artifact paths and thrown
  diff capture remain unqualified; do not claim all usage loss solved.

COMMITTED: aa3c551a5, fix(modular): restore Goal Forge execution and accounting.
Worktree clean immediately after commit. No push or global installation.
Full gate goal-forge-routing-full-qualified-environment PASSED (815.633s):
10,609 tests passed, six skipped; build/types/lint/generated drift/re-export/
release-set/supply-chain self-tests/diff checks passed. Zero provider launches.
Log SHA b95243603d1291eae937e4f97778c6f030e3b24bcab99f09b8155ba44e6cc472.
The later test-only reviewer fixes passed 56 tests/types/focused lint/diff in
goal-supervisor-reviewed-contract (3.073s), SHA
752b8d466452a9eef2b864031efffc57c7dc5333d12cb34985394c2aee15591e.
Roadmap check passed after prose edge count was updated from stale 153 to 156.
All three receipts are indexed in the committed integration evidence note.
No verification process remains running. This is development evidence, not a
fresh clean-checkout release qualification. Next: reproduce artifact-write usage
loss, then remaining auxiliary accounting and legacy Goal controller retirement.

SBOM refreshed using the existing generator; release-set and supply-chain checks
including self-tests passed in goal-forge-sbom-refresh (18.915s), zero providers.
Log SHA 8a3586f8ec5c55fe3bf0aa52406b3502d22283735f8fbd7b0d113ec2eaa6f0b0.

Independent Codex review of the contract delta completed through isolated Agon:
packet fb984a6b43176752931ec31a78ba972c7c87aa122acd08171c6d00dbf5b83b02,
log fd96570c67dc2c6e7ada5bb5a24aae62df008b368b33ea0220c911db6b3d17d9.
Temporary auth copy verified absent. Reviewer confirms the exact extension does
not permit unrelated extra fields or changed legacy arguments. Follow-ups after
the active source freeze:
1. FIXED: assert legacy tasks/commit keys are absent before extension; currently true,
   but without that guard a future legacy declaration could be overwritten by
   the extension. Rename test to acknowledge exact additive Goal repair.
2. FIXED: wire actual supervisor-produced argv into the generated Goal route in the
   existing parser test, rather than manually supplied argv under ratings. This
   is a coverage gap, not a demonstrated dispatch defect.
3. Reviewer lacked full tests: commit=false execution is already covered by
   implementation.test.ts "keeps accepted uncommitted tests on the next task
   baseline", asserting two done tasks and zero branch commits. Do not duplicate
   it. The default-commit counterpart is "runs dependency-ordered work,
   gates/mutates/reviews it, commits on goal branch, and leaves source untouched"
   at implementation.test.ts:1451: no commit option, two done tasks, exactly two
   branch commits. Finding 3 is a packet-coverage limitation, not a missing
   execution test. These tests must pass in the active full gate.
Do not run a second review panel after these local follow-ups; verify locally.

2026-10-19 full-suite failure triage:
- Launcher inventory contained 90 missing paths after rebuilding. Existing
  verify-modular-release-set.mjs regenerated it with no production workaround.
  goal-forge-release-refresh passed (17.221s), log SHA
  1e352979258f707de63a9308af642dd18e85ffd0eb4f8c3aae0f05aba088daa7.
- goal-forge-environment-retry passed 144 tests in 6 files (23.076s), including
  all 80 setup-selection tests, rooms watch tests and unit serve tests. Zero
  providers. SHA 340e22db186f56d7ecb60f9e80734b71df61ff9676ace51351c846e22de2e574.
  Four requested test paths did not exist under unit/; these were not run and
  are explicitly retried under integration/ in the next receipt.
- Goal CLI parity failed on two intentional extensions from the previously
  reproduced supervisor input-loss repair (see item 8 below): tasks:string and
  commit:boolean default true. The comparison now requires those exact fields
  plus the entire unchanged legacy contract. No blanket extra-key allowance or
  skipped Goal comparison. Real parser/restart regression tests remain required.
- goal-forge-daemon-contract-retry passed 101 tests across four integration
  suites plus CLI parity/nested dispatch, types, focused lint and diff checks
  (17.042s). Zero providers. SHA
  7cef70cbdee5635970721b4886543ce06369d02f18ff0cdfaf3698e9db652c8d.
  All previously failing test files now pass in targeted reruns. This is not
  proof of a green full suite. The retry did not change daemon or watch code.

TERMINAL FAILURE: goal-forge-routing-repository-gate-current, exec session
23459, exit 1 after 785.557 seconds. Generated checks, full build and typecheck
passed. Tests: 10,496 passed, 90 failed, 29 skipped, 16 unhandled errors.
Lint/re-export/diff gates were not reached. Log SHA-256:
82cae93c67409f27b017b41ae9f5550a5f8e2dc49499bcb8376765e9432652d7.
Separate failures: setup selection reads stale launcher inventory (90 of 113
recorded files no longer exist after build); Goal CLI parity reports additional
tasks and commit arguments. Investigate both without weakening their oracles.
The current sandbox denies Unix socket listen (EPERM), causing daemon fixture
failures. A minimal Node net.createServer probe in a fresh temporary directory
reproduced EPERM inside the sandbox (exit 1) and UNIX_SOCKET_BOUND outside it
(exit 0), same code. Both probe directories were removed after server close/error.
This establishes an environment limitation, not a daemon fix. Let this run reach
terminal and retain its failed receipt; rerun the same isolated provider-blocked
gate with require_escalated for local test sockets. Do not weaken tests or run a
second run.py concurrently: they share the isolated fixture home.
The rooms-work event test also failed via its one-second degraded watchdog.
A separate fresh-process fs.watch probe returned EMFILE inside the sandbox and
FS_WATCH_EVENT outside it, same fixture code, both directories removed afterward.
This supports an environment cause for the watch failure; the real test still
must pass on the retry. Do not increase its deadline or weaken its event assertion.
No active process remains; source/test freeze lifted. Command runs first-party/generated drift,
full build, types, full npm test, full lint, re-export guard and diff hygiene.
Receipts/logs remain in this directory. Earlier goal-forge-routing-repository-gate
failed immediately because the two newly exported symbols lacked matching
generator templates; both template inputs are now corrected, checker unchanged.
Failed log SHA f6fb687019920fb81fe235cd91904ced09f2ed3751e52db506a88f7543c15b0e.

2026-10-19 default routing continuation (uncommitted):
- Confirmed missing default narrowing with goal-default-roster-red: two failures,
  explicit-roster control passed. SHA
  a8f2529d4d313f1aea09d694543fcecfc560bc38711606a48792973355d78cb0.
- Goal now receives existing CLI routing hints through its authority-bound host,
  uses its existing chooseImplementRoster policy, and preserves explicit rosters
  and full repair rosters. CLI hints accept the invocation directory instead of
  relying on unrelated global working-directory state. No new dependency.
- goal-default-roster-green passed 3 controls + 53 policy/routing regressions,
  build/types/focused lint/diff, 17.402 seconds, zero providers. Log SHA
  b26db667ddd07f43b818863b82d871dcbdc7a9f2c43ffc226d5fd91531ba1b14.
- goal-routing-escalation-controls passed 11 cases/types/lint/diff (21.716s), SHA
  d94771d10b4ad7a078ebe9fba558e145345b18eca5d50e4c83b3f50d15c7f795.
- Independent isolated Codex review: packet
  c4d1571ec28b288b0d66efb7f4ac4dcbd1fc3b4957b073e87aa65c06bc416825,
  log 783ebef2274b08a3887a26e8fc9d2bb439cd1d98fa060169174b6d7406b77e49.
  Temporary auth copy absent after completion. Three findings: normal usage
  bypassed budget, aliases no longer resolved, routing run association lost.
  The dispatch adapter already writes raw output in its own run directory, so
  literal absence of all raw output is refuted; missing Goal-associated routing
  artifact/lifecycle is confirmed. Cancellation also lost returned cost.
- goal-routing-review-red reproduced all four cases (budget, alias, run artifact,
  cancellation accounting), log SHA
  e64b6b1f00863147173148a802cbb6c487cf2ac23382b6a05e0491f227f3f650.
- Fixes reuse existing run/artifact services and engine alias resolution; selection
  is intersected with the original allowed roster. Forge's existing usage
  calculator is now exported for Goal's routing call, not copied. Account and
  persist returned usage before testing cancellation; revoked authority still
  prevents writes. goal-routing-review-green passed 13 controls, both builds,
  types/lint/diff (31.746s), SHA
  758da4ff3907e0225cf5b7c73cae8b6099b8e047fbaf7c01864a76b8603f7541.
- Follow-up hardening uses the canonical usage calculator only, not an arbitrary
  costUsd field outside the dispatch contract. Reported/cache-aware and estimated
  budget controls PASS: goal-routing-usage-controls, 11 cases/types/lint/diff,
  17.359 seconds, SHA a2c204e3465aee461ea3597cb4512b58c078bdd9b23f92d0908d3d8ff41e137c.
  goal-routing-boundary-controls PASS: 7 cases including singular explicit engine,
  narrowed first attempt then full repair roster, and authority revocation during
  hints/judge with no stale writes or competitor dispatch. Types/lint/diff, 13.233s,
  SHA 8113219cc040b4d04a9e6711f6980016aae64d1dea298ce7e35a9860284d6744.
  Unknown provider cost on thrown dispatch and
  mid-provider crash recovery remain open across Goal. No release claim.

2026-10-19 real process death and synthesis accounting:
- Combined PASS goal-forge-reviewed-synthesis-integration: all 583 tests in
  eight Goal/Forge/adapter files, repository typecheck, full repository lint,
  re-export guard and diff hygiene; 504.495 seconds, zero provider launches.
  Log SHA fb7c3e6b49b5b328d78e13d4d7873d6e9bcce29e87fe686c53d0a640db8d91d4.
  Includes actual completed-run SIGKILL recovery and the review fix. No test or
  reviewer process remains active. This is scoped integration evidence, not the
  full repository suite or clean-checkout release acceptance. Source freeze lifted.
- Independent Codex review completed through isolated Agon; temporary auth copy
  absent after completion. Packet SHA
  45ecc327567368a98b73c6f8094110bca2f2d62106dbc2d76282d6a15f8331ac;
  review log SHA 36f4a10f0db1de9ee8cdc3c3e4e11d58aa9972ebe617a07453a2e40325510d82.
  One new finding reproduced: tracker exceptions replaced successful critique
  results and skipped refinement. Red goal-synthesis-tracker-red, log SHA
  178a9fb1d22fc77488fc2461e89e95c690227e935c7d9646cb0d1ec43cbc5fad.
  Fix: checkpoint before optional telemetry; isolate tracker/log failures;
  preserve provider results/errors if the observer throws. No repeat panel.
- PASS goal-synthesis-accounting-review-green: 4 Goal outcome cases and 12 real
  worktree refinement cases (agent/exec, fitness pass/fail, provider throw,
  accounting throw), build/types/focused lint/diff. 17.77 seconds, no providers.
  Log SHA 1883deb9864f9e171595e0cfdd97a9c75b71b28bbf5456235bd31e22c15a4a47.
- PASS goal-synthesis-outcome-accounting before the review fix: 3 Goal cases,
  48 Forge finalize/timeout regressions, types/lint/diff; 44.439 seconds.
  Log SHA 308aefab36c435dec9a5e677e34a8717e548c366fa2ced45bbd28d91e17f9e31.
- Actual nested-process SIGKILL now covers completed implementation and oracle
  Forge runs before Goal persists accounting. Resume recovers the stale writer,
  accounts cost once, retains implementation repair input, and never adopts the
  oracle patch. PASS goal-real-process-forge-boundaries: 2 cases, types, focused
  lint, diff; 13.559 seconds, no providers. Log SHA
  19487f3e65dc9031b5949cf10dcfd498209ac593841f96190944e015631b1e1a.
  The first nested test selector failed to execute its child case; the explicit
  SIGKILL assertion caught that harness error. Its failed receipt is retained.
- Real Goal→Forge synthesis adopted an improved patch but recorded only competitor
  costs. Red goal-real-synthesis-accounting-red expected 1.00, got 0.50; log SHA
  9959291c3abc55cd73e65145fe6c6c57e6d2b2fb5cdcfe4da98aeb2744fdac82.
  Synthesis now reports each critique/refinement dispatch through the existing
  Forge metric ledger and shared usage calculation. No new package or service.
- PASS goal-real-synthesis-accounting-green: 1 discriminating case plus Forge
  build, repository types, focused lint and diff; 11.741 seconds, no providers.
  Log SHA f05006db192716c73a208d778471ff2d545b3e120b79ffa1e7137e8a26561691.
  More outcome controls and independent review remain pending.
- The real-kill cases cover a COMPLETED Forge manifest, not mid-provider death.
  Running ledgers, detached worker ownership, unknown costs and default routing
  remain open. These results do not qualify the complete release.

2026-10-19 discriminator/storage continuation:
- Review F3 reproduced using a retained probe worktree and equal task/global
  verify commands: remove purpose but retain verify, then resume. The old branch
  accepts the checkpoint as an implementation competition. Reject that inconsistent
  field combination before recovery effects. Legacy implementation checkpoints
  without either field remain accepted and covered by existing recovery tests.
- goal-oracle-discriminator-red: 1 failed (purpose), 5 corruption controls passed;
  SHA 5a200ecfee9a04b3690835331273827fecf13592be4a853e65e39b3ca30e1e17.
- goal-oracle-discriminator-green: 20 cases, types/focused lint/diff, 48.627 seconds,
  zero provider launches; SHA
  2767f8e889b5f8bece5568a85115ff7dfa142e70ce7634a52f7cfb50d43048f9.
  Controls cover missing purpose, wrong verify/manifest command, missing/running
  manifest, changed candidate, legacy cancellation, ordinary competition recovery.
- goal-oracle-storage-retry-controls PASS: one and two failed accounting writes
  (the latter includes interruption persistence), repeated warn receipt failures,
  and two-probe-per-launch retry cap. Resume counts probe cost once, no cheating
  edits reach the candidate, and unprobed continuation is recorded. Types/focused
  lint/diff pass; 18.901 seconds, zero provider launches; SHA
  eb508176588113f6b3a69353be301672e5ab0b817cf154bf7fdfdfaa92c62225.
- PASS goal-oracle-cancellation-boundaries: 3 cases, initial verify, probe receipt
  and recovery receipt cancellation followed by resume. Types/focused lint/diff,
  11.244 seconds, zero provider launches; SHA
  f728be3dddb20ccdb3969b9d2389feb56526bfd79337fedb44c4bbb43dd860fc.
- PASS goal-oracle-reviewed-integration: all 351 Goal cases, repository typecheck,
  full lint and diff hygiene, 485.39 seconds, zero provider launches. Log SHA
  6d3adff91fa65f110a59a8f173926266777f01738f52d63468b1d2e53163750e.
  No process remains active. Source freeze lifted. This is the first full Goal
  receipt containing all four review fixes and storage/cancellation/cap controls.
  All four independent-review findings now reproduced and fixed locally.
  Actual SIGKILL/incomplete-ledger recovery remains separate, unresolved work;
  controlled AbortSignal tests are not process-death evidence. The existing
  pressure-process-death.mjs covers DurableModHost, not Goal dispatch recovery.
  Original full-suite/release acceptance still pending.

Actual process-death trace: CLI first-party-services.ts:142-148 already retries
MOD_HOST_BUSY with WriterFence.recoverStale for the Goal writer. The unit harness
uses only WriterFence.acquire, so a real-kill fixture must use the production
stale-writer contract rather than misreporting a harness-only lock failure.
Next unresolved recovery case is Forge's running/incomplete manifest. Existing
recovery deliberately refuses it; the objective still requires useful recovery,
not indefinite supervisor retries or fabricated zero cost. Preserve ledger and
unknown-cost evidence. Do not mistake controlled cancellation for SIGKILL.

Next parity trace (read-only during full-suite run):
- MCP host absence is NOT a confirmed Goal regression: Goal's manifest declares
  no MCP tool. Do not add a new MCP surface merely to make the host decorators
  symmetrical. CLI, TUI and Cesar are the declared Goal execution surfaces.
- deriveRoutingHints reads current working-directory scope, classification,
  ratings and cost estimates; only three pure decision fields reach Goal's
  chooseImplementRoster. Its full 200-line UI context function must not be copied
  into Goal. Existing GoalHostServices already provides authority-bound injected
  policy reads (reviewDefaults), a likely seam for routing inputs. This is an
  architectural inference, not a completed move or a decision to add dependencies.
- Smallest routing continuation to test: inject existing CLI routing hints through
  Goal's authority-bound host; call Goal-owned chooseImplementRoster in the mod;
  keep explicit rosters and repair attempts unchanged. Route escalation through
  the existing engine dispatch service, validate/deduplicate the judge subset,
  and retain the heuristic when routing fails. No new package is needed for this
  compatibility slice. Before implementation, verify effect ordering and routing
  call costs rather than inheriting legacy omissions. Broader physical ownership
  of Cesar hints is a separate ledger check, not permission for a duplicate.
- CLI commands/goal.ts:420-461 derives routing hints for a non-fix task only when
  the roster was not explicit and contains more than one engine. It applies
  Goal-owned chooseImplementRoster, optionally asks the judge for a subset on
  escalation, and otherwise preserves the full roster. Explicit roster bypasses
  all narrowing. Fix context retains the full roster. Preserve these rules.
- chooseImplementRoster already belongs to mod-goal/src/policy.ts and has tests
  in tests/unit/goal-policy.test.ts. Do not duplicate it.
- deriveRoutingHints remains in CLI cesar/routing.ts:61-278. It combines task
  classification, current changed-file scope, deterministic flow hints, and
  advisory cost/rating reads. Goal only consumes recommendedFlow,
  recommendedForgeScope and escalationHint. MCP must not import CLI internals.
- support-dedup already owns task-classifier; it has no runtime dependencies.
  Do not silently add a dependency or move the entire UI hint subsystem just to
  reuse three fields. Trace existing capability injection and ownership before
  deciding the smallest shared boundary. No routing changes made in this pass.

2026-10-19 oracle attempt/recovery continuation (uncommitted):
- Move task-start and attempt increment after the oracle probe. Strict baseline
  rejection, probe budget exhaustion and cancellation no longer consume an
  implementation attempt. Resume can still perform attempt 1.
- Reuse Task.competition with purpose=oracle and frozen verify identity. Save
  before dispatch. Completed-ledger recovery folds cost once and NEVER harvests
  the probe patch. Resume preserves a strict hole decision even after receipt
  storage failure. Unknown purpose/changed verify, missing oracle ledger and
  running ledger are refused. Incomplete-ledger/SIGKILL recovery is still open.
- Probe execution exceptions now retain the checkpoint and propagate. A warn
  probe whose receipt cannot be stored also stops rather than overwriting the
  pending checkpoint with implementation. Strict rejection remains stopped with
  its checkpoint available for receipt retry. Returned inconclusive manifests
  still use the legacy continue policy.
- Negative controls goal-oracle-attempt-order-red (3 failures), SHA
  87a44b88b89bf3c2ddfc035738c69bcafb08ae399ea89429a9dce3adba4ee1e4;
  goal-oracle-checkpoint-red (missing checkpoint), SHA
  1459516425820f6f6d7971689286d069f178f3af115abe1c8572b1e08846d389.
- PASS goal-oracle-attempt-order-green (9 cases), SHA
  b81db322cec636fc5519c5cd427fc1b528f2dd842b711b578338581afcc8305d.
- PASS goal-oracle-checkpoint-green (10 cases), SHA
  b5c8638ffee2d2fe22539a62900158751e6724d5c95e4547ea763f4d68984891.
- PASS goal-oracle-recovery-controls (20 cases including existing competition
  recovery), typecheck/focused lint/diff, 51.008 seconds, zero provider launches.
  SHA 9a302e52dc621d35d63dbb1df24902abfda65973881e05b0be2633dd8cca5d47.
- COMPLETE: isolated Codex review goal-oracle-recovery, exit 0. Packet SHA
  25a4fd808d1b0c43d11f3f80923effea1f2448542c03a8b398e67fd7c0a34a1a;
  log SHA 8b79da1be20adfa0efe94f16f926edcf64416be0371d43c4b4b72ff63b958392.
  Temporary auth copy verified absent after exit. Static review, not release
  acceptance. Findings queued for executable reproduction after active suite:
  1. Initial verify runs on retained candidate each attempt; review-blocked valid
     implementation can trigger strict-oracle on retry/resume. Also probe snapshot
     currently includes retained implementation. Use task verification baseline.
  2. Legacy task with attempts>0 and no task worktree bypasses pending recovery,
     whose condition requires runnable.worktree. Do not overwrite pending ledger.
  3. Removing purpose but retaining verify may downgrade an oracle checkpoint to
     ordinary recovery. Reject inconsistent discriminator/field combinations.
  4. Live probe lacks candidate HEAD/patch comparison before checkpoint removal.
     Reproduce parent mutation; preserve checkpoint/operator edits on refusal.
  Additional controls: accounting save failures, repeated warn receipt failures,
  cancellation after receipt callbacks, per-launch failed-probe retry cap.
- PASS: goal-oracle-recovery-integration, 335 Goal tests then types/lint/diff,
  439.343 seconds, zero provider launches. Log SHA
  de5d0420a6739c69f52563593fbd83256f75c4a9e3d6d8abe2279b6abd4294f0.
  This precedes the review fixes below and is not their integration evidence.
- Reproduced review F1 (strict retry and resume) and F4 (parent candidate mutation):
  goal-oracle-review-findings-red fails all three cases, SHA
  d83688753e155018483663d0eb37d231da8aa7f0629efde1dcd99826a1206cc5.
  Fix uses existing witnessVerifyCommand to inspect the saved baseline, skips
  repeat preflight after conclusive probe this launch, builds probe snapshot
  from task verificationBase instead of retained implementation, and compares
  candidate HEAD/patch before closing the probe checkpoint. Cancellation after
  receipt completion is checked before checkpoint removal.
  PASS goal-oracle-review-findings-green: 12 cases, types/focused lint/diff,
  34.582 seconds, zero provider launches. SHA
  e137329ebd42fdedaeb0f5f524e708f633076251c46e280d081f25edbbd276f1.
  F1 and F4 reproduced and fixed; final broad rerun still needed.
- F2 reproduced with a pre-probe legacy task (attempts=1, no task worktree).
  Cancellation completes a nonzero-cost ledger; resume reported 0.6 rather than
  1.2 because it skipped oracle recovery and overwrote the checkpoint.
  goal-oracle-legacy-recovery-red SHA
  de15d37681242d6aef5b7c9d549a84b223597bc0eb86266234a2599dd0191bb5.
  Fix removes the task-worktree precondition and reopens/validates the recorded
  task worktree, or the accepted worktree for legacy state, before recovery.
  PASS goal-oracle-legacy-recovery-green, 53.776 seconds, types/focused lint/diff;
  existing interrupted competition tests included, zero provider launches. SHA
  6dc5543e5afc7e9415123976cdbc42530bd3d16e05616d96421cbc6b60101bbe.
  No test or review process remains active. Source freeze lifted.
  F3 discriminator-loss controls remain unresolved (not yet a confirmed defect).
  Finish the other source-verified review controls before broad rerun.
  No full repository/release claim, commit, push, or global installation.

Oracle storage/mode follow-up (2026-10-19): narrowed the probe catch to Forge
execution only. Accounting validation and state saves are outside that catch;
a failed accounting write now stops instead of authorizing implementation.
Receipt-only errors have their own oracle-receipt-error event, retaining the
already durable strict decision. Red goal-oracle-storage-red SHA
05654a8bcc32d4b9ec8bc522472171114f1e8e62e65cb497de2bb55445dbc8ab;
green goal-oracle-storage-green SHA
1eb06242ceb88b6ec8dc6bfcebfc9476feece0934f25025783762d5373b5daf4.
Mode controls prove: off dispatches no probe; warn reports a hole and implements;
strict continues after a conclusive clean probe; strict inconclusive records an
error, not a clean pass, and continues (legacy policy). Implementation sees no
cheating file. Real fixture Git worktrees preserve the caller checkout.
goal-oracle-mode-controls: 8 cases plus types/focused lint/diff, 17.28s,
zero provider launches; SHA
ac49dd55329fb43c8b1f45ceeff47e99d5ff561ffa9d8b1434f34869a185a551.

FAILED: goal-oracle-integration-suite completed with 332 passed, one failed.
Log SHA 7dbf65f7226b5c42829c9bf9fbe0ec37a95bba1754d619c0f185ba3d26593c70.
The mutation-witness test expected one total dispatch. The default oracle probe
now adds a red-team dispatch before the implementation dispatch. The assertion
now requires exactly two calls, in order: RED-TEAMING then GOAL: witness command.
The original checks still require mutation rejection and zero accepted commits.
No production behavior changed for this correction. Types/lint were not reached
in the failed full run. Focused rerun goal-oracle-witness-dispatch-controls is
completed: both witness cases, repository types/lint and diff hygiene PASS,
66.561 seconds, zero provider launches. Log SHA
a65b56439ceba3111a1d25f2246e23088673d150b6e412723e3f1d5d05c28c99.
PASS: goal-oracle-integration-suite-corrected, 333 Goal tests, repository
typecheck/lint and diff hygiene, 433.089 seconds, zero provider launches.
Log SHA ea8e6e6c7bea3fe12999889ca00a4b2cf2f4359fc68bcd84b58215ddb9d94654.
The process exited zero; source freeze is lifted. This is component integration
evidence, not full-repository or clean-checkout acceptance. Next: probe attempt
ordering and durable recovery, with failing controls before production changes.
Remaining oracle crash/checkpoint, retry/limit/roster tests and independent review
are still open; no commit/release claim.

Recovery trace (2026-10-19, source verified, not implemented):
- Legacy packages/forge/src/goal/controller.ts probes before markStatus(inflight).
  Modular implementation.ts currently records task-start/attempt before probing.
  Budget exhaustion or cancellation during a probe therefore consumes an
  implementation attempt. Preserve legacy ordering when fixing this gap.
- Task.competition already records a Forge run identity and costAccounted marker.
  Its recovery path adopts a retained competitor patch. Oracle checkpoints must
  never enter that adoption path: cheating edits are evidence, not repair input.
- Reuse that checkpoint contract with an explicit probe purpose and frozen verify
  identity rather than introducing a second run store. Recovery must reconcile
  cost once, preserve strict decisions, and never apply a probe patch.
- Resume and catch currently synthesize attempt errors for running tasks. Test
  both boundaries when moving task-start; an unfinished probe is not an unfinished
  implementation attempt. Existing interrupted-competition tests remain required.
- Forge writes intermediate manifests with status running. Actual process death
  can leave incomplete cost evidence; do not call missing costs zero or report
  successful recovery merely because refusal protects the tree.

Oracle red-team integration started (2026-10-19), NOT fully qualified.
Goal implementation now invokes a separate real Forge probe for a task verify,
using existing buildOracleCheatPrompt/oracleProbeConclusive/oracleGateDecision
owners, exact dirty snapshot, explicit implement roster else review roster,
per-launch conclusive cache and two-attempt error cap. Probe patches are never
adopted. Strict gameable result stops before normal implementation. Successful
receipt persistence is not required to retain that strict stop decision.
Existing baseline strict check remains as a cheap early rejection.
Red goal-real-oracle-redteam-red: probe never dispatched before this change,
SHA c857284b4df85d52e70c1b89ca2e2a555571056da5b15beae695adc60b2360e8.
First green-named run actually FAILED typecheck (runs.finish needs context);
SHA 12f3b3066959d8fc13078cf62b7ea0d6ad57af3e0685cabb3bf0778ec0fb314f.
First controls FAILED because fixture failed every run receipt, including Goal's
final receipt. Scoped injection now fails only the probe receipt; it still
verifies no normal implementation happens and strict stop remains persisted.
Failed controls SHA 31dbbc7795d61965feff642f11af77b434000b85e1c06a04114fdc1317fb9d18.
PASS goal-real-oracle-redteam-controls-second: 3 focused cases, types/focused
lint/diff; 6.218s, zero provider launches. SHA
795a5fdf5bc145e0e0e5f3ed1b59a382e9abee9aa7010f61131aa9357b6974e8.

NEXT for this in-progress change: warn/off/clean/inconclusive/abort coverage,
per-launch and retry-cap parity, budget/time after probe, explicit/default roster
selection, and no source-worktree mutation. Probe execution currently has only
an event/run receipt, NOT a durable resumable cost checkpoint; process-death
accounting remains open. Failed run receipt and state-write behavior need deeper
reconciliation. Narrow catch boundaries must not turn state storage failure into
permission to continue. Finish lifecycle/recovery safety and independent review
before committing. The prior 560-test receipt predates this oracle change.

COMPLETED: goal-forge-usage-combined-regression, terminal session 56969 exited 0.
560 tests passed in nine files; repository typecheck, full lint and diff check
passed. Total 409.307s; zero provider launches. Immutable receipt/log in this
directory. Log SHA 4cffbc919a7e128758d24427fc2e9baa1d947dc5f99e3cd42ee7bb8c34c1fb8e.
The source freeze is released. No test process remains from this command.
Command: vitest Goal implementation, worktree snapshot, modular engine/CLI
contracts, Forge finalize/timeout/E2E, API loop and API fallback suites; then
repository typecheck, full lint and diff check. This is targeted combined
integration, not full repository or clean-checkout release qualification.

Read-only parity preparation while the run was active: actual oracle red-team
can reuse mod-goal/oracle-redteam.ts buildOracleCheatPrompt,
oracleProbeConclusive and oracleGateDecision with the approved Forge dependency.
Legacy implementation lives in CLI goal.ts:638-706. It runs a separate Forge
probe, never applies its patch, uses explicit implement roster else review
roster, distinguishes inconclusive/abort from no-hole success, and folds costs.
The new implementation still has only the baseline verify check; that does not
replace this probe. Preserve per-task/per-launch behavior and strict/warn/off.
Default roster parity is separate: legacy goal.ts:420-461 uses
chooseImplementRoster (already mod-goal-owned) but derives hints in CLI Cesar
routing.ts:61; do not copy that heuristic into Goal or create private imports.

Public adapter controls closed (2026-10-19): both dispatchAgent and
dispatchAgentStream preserve usage through success/failure/timeout/cancel.
An onChunk exception followed by a generator-cleanup exception retains the
original consumer failure and does not invent complete usage. Existing local
provider shims exercised the public adapter methods; no live provider calls.
api-agent-public-usage-controls: 156 tests plus types/focused lint/diff, 2.972s,
zero provider launches. Log SHA
c6c92ee6d1fe6edf4e022c7e4291ae6628b5bacd9e4dbcb11475594d3b75e099.
This closes the two test gaps noted below, not the remaining implementation
queue (output-write result loss, synthesis/oracle, recovery, retirement).

API usage independent review completed and adjudicated (2026-10-19).
First launch api-agent-usage was blocked by nested sandbox creation (exit 71),
not a review result. Authorized host launch api-agent-usage-host-review exited 0.
Both input packets SHA 232339465d79ce44dd6085c37408165132d7b78664eeac1dc72127b4f4c47ef6.
Completed Codex log SHA 2f358e2a163ede4aa6b5eeaa6fd7bb3137191d3a3fb341ed3baca95bec82b7f6.
Temporary review auth copy removed; active/personal state unchanged.
Reviewer used source packet only. Confirmed findings and fixes:
1. Cache field could falsely include partial counts. Omit aggregate cache field
   unless every contributing call reports it. Both orders, missing versus zero
   reproduced; red api-agent-usage-cache-red SHA
   82253f6f328f3fff66f2ad216fce3964b0cf0357ecf75e1b9a392ceece51f1cd.
2. Visible-output callback throws escaped after known usage. Narration/final
   callbacks now return a failed terminal result with usage and stop before
   tools. Never silently accept that run as successful.
3. onChunk exceptions left generators suspended. Loop now closes unfinished
   generators in finally, logging cleanup failure without replacing the
   original outcome. The new control asserts provider-generator finally ran.
   Callback red api-agent-usage-review-callback-red SHA
   907d89a921dc5bbf5ab44a02f4f3744638ac5ae882f00d8cec9d1944abdf1069.
   Green callback log SHA b99f4dd1d53180a5ad45f04637f0cf4c608ea02510e449bc04b3b501f568595b.
   Green cache log SHA ff9e697c83d4f2bfbd0f6dfbadde827b76f5b6167d403267aae57091313da019.
Final api-agent-usage-review-controls: 151 adapter/loop/authority tests, types,
focused lint, diff check; 3.741s, zero provider launches. Log SHA
08714bae337460b94f187db23f01c23f46075b4d16d5366e64fdd7b1f5773ebb.
Added reviewer-suggested reversed provenance, invalid/fractional/negative counts,
invalid source, cache overflow and aggregate-overflow controls. Public adapter
usage propagation assertions and cleanup-that-itself-throws remain to extend;
existing adapter suites passed but are not evidence for unasserted properties.
One independent review done; do not rerun a panel for these local fixes.

Scope check: legacy CLI goal.ts explicitly calls its budget metered best-effort
(around lines 388 and 487) and sums Forge ledger costs with missing entries zero.
Do not silently invent a new billing guarantee or fail-closed provider admission
requirement. Preserve original requirements, make reported/estimated/unknown
accounting honest, and verify recovery against the agreed specification.

API tool-loop usage follow-up (2026-10-19): support-agent-runtime now aggregates
terminal per-call usage, including reported retry usage, through one boundary
around the existing loop. Public ApiAgentResult carries usage only when every
attempt supplied valid counts; missing/malformed/thrown/interrupted calls do not
become falsely complete totals. Mixed provenance retains the least measured
source (estimated, then CLI-reported, then SDK). Cached counts and provider total
are retained. Adapter normalizeApiAgentOutcome passes usage through all terminal
success/failure/timeout/cancel states. No change to tool execution/selection.
Unknown totals remain unknown; known partial counts are NOT exposed as a full
total. This is not a complete budget/recovery solution and requires the next
bounded independent review before being committed as a verified increment.
Red api-agent-usage-red: four missing-usage failures, SHA
50aba6c7f524a2a7c6b9cd39a57e9d83022cc248fe8cc896ff5b270d763ff778.
Green api-agent-usage-green: loop/argument/adapter suites plus build/types/lint,
SHA fc62b5de2c6b78d00fc55fe431b1ee68f98e101fb0d1a9ebd65565a8ef01d924.
Negative-control red api-agent-partial-usage-red: callback interruption exposed
one false-complete aggregate; three missing/malformed/throw controls passed.
SHA 4b61ebced9d5f5cd0c6dc60f5e70fdc910336cbd00047b7ef0279b18a65f2002.
Green api-agent-partial-usage-green: 62 tests plus build/types/lint/diff, SHA
28db41437f9daea404c380ee78709414411daac4e2ae8a32d675840335f6d237.
Final api-agent-usage-retry-controls: 65 tests, types/focused lint/diff,
3.206s, SHA a92d2a11dc6a11e9381d4bd19c5f919992dd25d3f3f413cf9509d80c071614b5.
All runs used provider blockers, zero launches. Evidence in this directory.
Still open: adapter output-write throws after a completed provider result,
unknown costs treated as zero by Goal, durable partial/crash reconciliation,
synthesis/oracle coverage, legacy controller retirement and full qualification.

Patch-capture accounting follow-up verified (2026-10-19): a completed nonzero
dispatch no longer loses tokens when diff extraction/counting or patch writing
throws. It stays failed, keeps usage and worktree location, and reports both
the dispatch and capture error. Failed fitness now advertises only a regular
patch file, not a directory or symlink. Inspection errors do not erase usage.
Red forge-capture-failure-usage-red: two missing-token failures;
SHA 5e890d607cb7249814435c3b525da60d30e5791160f23a9dc05f7cc6e644c5b8.
Green forge-capture-failure-usage-green: 76 Forge tests plus build/types/focused
lint/diff, zero provider launches; SHA
414fb1db2ae99c25ba746287781da27a4d9c028861d745c87b6a9c5ffb3b7217.
Red forge-fitness-patch-directory-red: two invalid patch-path failures with
two prior controls passing; SHA
5dd86b01b9fca579c71968a25a9a6b11bb34aa041eb4c1240abd9e449e0099b7.
Green forge-fitness-patch-directory-green: 78 Forge tests plus build/types/
focused lint/diff, 40.552s, zero provider launches; SHA
5c32334b9e4c860794f254c7a000922c4c96d544e6cf539ae5e9c0ec9732e7cc.
Actual filesystem negative controls create a directory at the expected patch
path in isolated fixtures. Existing fitness-throw tests retain real patch files.
This does not prove atomic patch writes or complete artifact recovery.

Next accounting source findings, verified against source, NOT yet fixed:
- packages/adapter-cli/src/adapter.ts dispatch/stream/agent paths write output
  after receiving a provider result; those writes can throw before returning
  known usage (e.g. dispatchAgent API path around lines 283-296).
- packages/support-agent-runtime/src/agent-loop.ts receives terminal dispatch
  results but ApiAgentResult has no usage field and the loop does not aggregate
  usage. packages/adapter-cli/src/execution-plan.ts normalizeApiAgentOutcome
  consequently cannot pass tool-loop usage through. Fix at these owners, not
  by inventing a cost inside Goal. Cover multi-turn/retry/failure/cancel and
  unknown or incomplete usage honestly; no zero-cost claim from missing data.
- Arbitrary adapter throws still have no complete cost evidence; Goal currently
  treats absent tokens as zero in competitionCost. This remains OPEN.

Forge reported-usage repair verified (2026-10-19): stage1/stage2 now retain
valid adapter token counts, provider total, cache counts and source in the
manifest and tracker. Missing/malformed usage falls back to explicitly labelled
estimates. Existing Core cache-aware pricing is injected into modular and
legacy stage bindings; no duplicate pricing tables or new dependency.
Cost remains an estimate, NOT proof of actual billing or complete Goal budgets.
Red: forge-reported-usage-red, 3 failures demonstrate replaced counts/source,
log SHA 5780116c962e881727e6c69cca26d2a0faa46df24c8ff22a3dbc28eaa3e4da81.
Green: forge-reported-usage-green, 69 Forge tests, mod build, repository types,
lint and diff check; 89.35s, zero provider launches. Log SHA
df31557382806d36ed584546f8e088c573cdf6ac665a187eac05a7ed0b33402a.
Controls: forge-reported-usage-controls, 8 tests, types/focused lint/diff;
11.275s, zero provider launches. SDK/CLI/estimated sources, provider total
distinct from input+output, cache-aware pricing, absent/negative/NaN/cache
overflow/unknown-source controls. Log SHA
8e9e9f0a27655ae281690b01b2ee87dc86fb9f7bd3217035b8933e55e4a9ec48.
All artifacts in this durable directory. Current integration still uncommitted.
Next unresolved accounting paths: adapter throws and artifact-write throws lose
completed work metrics; synthesis/gauntlet/health usage and Goal budget truth
remain open. Then actual process-death recovery, synthesis and oracle coverage,
controller retirement and full clean-subject qualification. No acceptance claim.

Latest full targeted integration PASS before failed plain-dispatch patch capture:
goal-competition-suite-input-fixes, 396 tests, typecheck/repository lint/diff check,
400.335 seconds, zero provider launches. Log SHA
02c61c002e9d99257d808a536b4877ecd8d5ce5595349b9a847e54add74d8fac.
Covers numeric-input and supervised-argument repairs as well as previous fixes.
No full repository/release claim; integration remains uncommitted.

Post-review-fix integration run PASS: goal-competition-suite-review-fixes, 258 tests,
396.825 seconds, typecheck, repository lint and diff check passed; zero provider
launches. Log SHA 4d60cd497eef045ab0ef31cc3b57138963ef82a73413fc5098ea66523437d9e5.
Includes Goal implementation, immutable snapshots and CLI/MCP host contracts.
Not a full repository/release qualification. Remaining review findings below
still prevent committing this integration as a completed increment.

Adjudication follow-up: nonzero exit and timeout now keep review blocked, even
with valid clearing JSON. Valid reported costs still count before this check.
Present malformed costs (null, negative, NaN, Infinity) also keep review blocked.
The previous invalid-cost test supplied blocking=true, so it did not discriminate
this bug; it now attempts to clear the review. Missing cost is a separate OPEN
host-accounting issue: createCliEngineServices.dispatch omits costUsd entirely.
Do not require that absent field until the real host contract is repaired.
Red transport: goal-adjudication-transport-red, 2 failed/2 passed,
SHA a6cd74984a6b5e4d2db26a7b321fbd3e8d9feae301c148c9dcfb12d2dfbf17fe.
Red malformed cost: goal-adjudication-invalid-cost-red,
SHA ca9a59ea575b2962a3e65f0a1efa102388bb70a60a6b8ddb0567db130799d54c.
Green combined: goal-adjudication-cost-transport-green, 12 passed plus
typecheck, focused lint, diff check; zero provider launches; 25.820 seconds.
SHA 5d7df5ac186ec1ffcf7523e9cfd112d6fae1c6b4e43eb8ad145be38cb39d4f70.
Tests include persisted costs and resume, retaining valid/malformed-JSON controls.
This does not close all of finding 9 or qualify the full integration.

Full targeted suite now GREEN at the pre-review-fix working tree:
goal-competition-suite-third: 254 passed, typecheck/lint/diff check passed,
414.630 seconds, zero provider launches. Log SHA-256
8f972e4b04afb21e2b66726994ae030b92c123a4c5560122584a4eae440e793e.
This is not the full repository/release gate and does not supersede open findings.

Independent Codex-only Agon review completed once for this integration:
goal-competition-recovery-codex-review.receipt.json, exit 0;
input SHA-256 f969d25dfc2120542d71bcb4e5c8fa4322e47d730ce45944d62bb1d73a4c6d3c;
log SHA-256 71aafa9c02768f874e46691177bf9f838016272f1294189b43a1a6c82324b77c.
Input/log/receipt are in this durable directory. Verified temporary auth copy
removed. No personal state changes. Reviewer ran no tools; claims need local
reproduction or source verification. Do not run another panel automatically.

Review adjudication and remaining queue (numbers match review):
1. Partial crash ledger can be marked fully accounted: reproduced and guarded,
   but end-to-end crash recovery remains OPEN. A manifest still marked running
   now blocks before charging, copying edits, finishing the run or new dispatch.
   This check also applies when costAccounted was already set; saved usage and
   retained work remain unchanged. Restoring a complete ledger allows recovery
   and exactly-once accounting. A terminal status alone is NOT proof that all
   usage exists (synthesis/throw paths still need reconciliation).
   Red goal-incomplete-ledger-red: partial running checkpoint was accepted,
   SHA 3f42d0cfec74e8d8c7b1d4e8d3c1a7893cb057c2a0dae57563094fca52e6acb4.
   Green goal-incomplete-ledger-green: 10 interrupted recovery cases plus
   types/lint/diff pass; SHA bf93d21ace8a1c2b4049b3ad63a5321432a5c320ab746f28235cae3f716157f0.
   Added already-accounted checkpoint control: goal-incomplete-ledger-controls,
   four cases plus types/lint/diff pass, zero provider launches, SHA
   07097d38d42ad004b93cb335a502c250ddb2ae395bc794fff67f9ac15f95f59a.
   These simulate the saved checkpoint. Actual SIGKILL and automatic recovery
   from surviving provider artifacts still need evidence; do not label complete.
2. Finalize/timeout/throw cost omission: PARTIALLY FIXED. Race winners now drain
   the real attempt before publishing terminal metrics. A settled returned
   dispatch contributes its token/cost estimate even when finalize/timeout won;
   synthetic failed eligibility and timeout/error remain unchanged. One terminal
   callback and one ledger entry remain per engine. No duplicate accounting.
   Red forge-finalize-accounting-red failed on missing slow-worker tokens,
   SHA fc4c4aed8fc168078842c58d6aa013314b1b67f4eb14e06e61b9ae37964606dd.
   Green forge-finalize-accounting-green: built owner, 63 tests, typecheck,
   focused lint/diff pass, zero providers; SHA
   6811f29b8f962535716b7c7edd87653cd7a59cf33b49152dbd2c1ea794e3c2be.
   Real hard-timer control forge-hard-timeout-accounting: 9 finalize tests,
   types/lint/diff pass; SHA d388ad2b7e081e856ed1ae1c45c9cd62eabece0e5e59d23647ade97abc265347.
   Fitness throws after a returned dispatch are now handled inside the attempt:
   the failed result retains the existing patch (if written), completed-dispatch
   flag and token estimate. It remains failed and cannot win. Both one-engine
   and multi-engine paths reproduced zero-cost fallback before the fix.
   Red forge-fitness-throw-cost-red: two failures on undefined cost,
   SHA 55e05fe79bf7f22fb951362e17c0794bba4ec4d9487256979d2e283701a893e8.
   Green forge-fitness-throw-cost-green: rebuilt Forge; 66 timeout/finalize/E2E
   tests plus types/lint/diff; zero providers. Log SHA
   4b9058d9db68fca877f04220c8721da88b4ba46f114766855985a1b3f9ca00d4.
   Throws during dispatch and pre-fitness failed-patch persistence remain OPEN.
   Transport throws without usage cannot be silently priced as known zero;
   failures after a returned dispatch must preserve known usage and recovery state.
   Estimates are not provider invoices: Core signals/token-tracker.ts explicitly
   describes estimateCost as a ballpark/display path, not metered budget truth.
   Goal currently uses these estimates for spentUsd; reconcile with the original
   budget contract, rather than claiming invoice-complete accounting.
3. Non-harvestable returned failure has no patch artifact: CONFIRMED AND FIXED
   for completed returned failures. Forge's failed-dispatch path writes its normal
   engine-patch.diff from the real worktree and attaches path/counts to the failed
   result. Pass/score remain failed/zero; no fitness or harvesting rule is weakened.
   Goal's existing repair-input path now retains those edits through park/resume.
   Red goal-plain-dispatch-recovery-red failed on missing retained partial.txt,
   SHA e457b51f2df9ae02eac7b64be35059edc8b742a6448db56136017ab6a037df21.
   Green goal-plain-dispatch-recovery-green rebuilt Forge, exercised failed plain
   transport, repair/resume, cost retention, budget and parked-work controls plus
   Forge timeout/E2E suites; types/focused lint/diff pass, zero provider launches.
   SHA e599de6e0ddca6f3d95c761f24a19da7b54c550b61051ab378067895338a3860.
   Artifact-write/fitness/transport throws still belong to open finding 2 and
   interrupted-ledger finding 1. Do not claim all failure paths qualified.
4. Existing limits skip competition recovery: CONFIRMED AND FIXED. Previously
   outer stopAtLimit ran before pending reconciliation. It now exempts pending
   competition just as it exempts pending acceptance; per-attempt limits still
   block NEW work. Red goal-review-existing-budget-red, log SHA-256
   a14edd0d02aedab57dd3a7c95d21d4278aacd5b6f1656477a17aa95422479122.
   Green goal-review-existing-budget-green: six checks + typecheck/diff check,
   log SHA-256 ed6eb90fcd3fb9ff3debc8d3e3e3b622e8f3330e672da47e3aa0b5a990975b1b.
   Tests prove recovery completes when already over budget, with zero new dispatch.
5. Default quorum aborts explicit fourth competitor: CONFIRMED AND FIXED.
   Goal passes earlyFinalizeCount:0 to its existing Forge workflow. Standalone
   Forge defaults remain unchanged. Test holds fourth provider until three
   passing results are persisted, then verifies all four passing results and
   all four estimated costs. Red goal-four-competitors-red failed specifically
   on the fourth result (SHA 86e856b1e5a967c33b65f00afde5ce3701533c0a20de99a9ebdfcf32bd81e306).
   Green goal-four-competitors-green: 14 cases, typecheck, focused lint, diff
   check, zero provider launches; 29.338 seconds. Log SHA
   94531342199d533ea55b852d1e7b682fb9a193bc032c4853ce4c13e7e3550dd6.
6. Timeout wiring: CONFIRMED AND FIXED, focused evidence below. Goal now sends
   input.timeout as Forge timeout and gateTimeout as fitnessTimeout. Forge also
   ignored its explicit per-engine override in stage dispatch, using the 480s
   default floor instead. ForgeStageConfig now carries explicitDispatchTimeout
   from the invocation; resolveForgeDispatchTimeout prioritizes a valid value.
   No override preserves existing engine/default-floor behavior. Invalid values
   still fall back at this policy layer; input-boundary validation is finding 7.
   Nonsettling-adapter drain remains a separate lifecycle evidence issue.
   Traced: CLI goal.ts:90-91 distinguishes per-gate from per-engine timeout;
   :341 parses optional implementTimeout and :471 forwards it to Forge.
   Modular implementation.ts instead forwards gateTimeout as Forge timeout.
   Existing ForgeOptions already has independent timeout and fitnessTimeout;
   use those, not a new timeout service. Regression must prove both provider
   timeout forwarding and real fitness termination with separate limits.
   Red goal-separate-timeouts-red proves a real sleeping fitness command wrongly
   passed its one-second limit (SHA 1a804d30863cfeb6d35e82a8cfaffc7007f7e9056f437989462675bababbc455).
   First attempted fix goal-separate-timeouts-green is RED despite its name:
   fitness was corrected, but provider received 480 instead of 7 seconds.
   SHA 1557f60a372495cbf15f2bdb0976074a0bf6382ded47af6ed0c51b2927b99b30.
   goal-forge-timeout-owner-green PASS: rebuilt physical Forge; 15 Goal checks
   and 25 Forge timeout checks; typecheck/focused lint/diff check; no providers.
   SHA 093b44aef5cc7e6dba994cec2d7bffdc6b84b2647a0fde9035bf6d3733e270cf.
   Earlier 258-test suite predates this timeout change. Full qualification remains.
   Broader Forge regression goal-forge-timeout-owner-regression PASS: timeout,
   real-effects E2E, and finalize suites plus repository lint and diff check;
   79.736 seconds, no provider launches. Log SHA
   2aba5b0beecf59f74ad5ebcd1eaf5d993d68cd67cf2e2969692f3e26a174a9e0.
7. Numeric parsing silently coerces malformed budgets/limits: FIXED for supplied
   options. One boundary shared by Goal and supervisor rejects wrong JSON types,
   nonfinite/negative numbers and fractional/unsafe integer counters. Valid finite
   decimal amounts, numeric CLI strings and zero/unlimited controls retain their
   behavior; empty engine timeout retains its absent/default meaning. Status reads
   remain read-only. Supervisor rejects before spawning and disposes listeners.
   Invalid-number messages are deterministic supervisor exits (no retry thrash).
   Red goal-numeric-boundary-red: 98 cases reached Git instead of rejecting options,
   SHA ecab863d5e8b56b6cac812480decc7bb02fd4df63b824889a1ea606f31ee2f6d.
   Green goal-numeric-boundary-controls: 118 checks including real valid dry runs,
   budget stops and supervised retry controls; types/lint/diff pass, zero providers.
   SHA 0c6d639b5e359ee8e827745fdc77b612cd4505810241ded67db0a7cd9f248df6.
8. Supervisor drops arrays/objects/false: FIXED. Task arrays are serialized into
   one --tasks JSON argument and loaded by the existing task parser; CLI owner now
   declares tasks:string and commit:boolean. Engine arrays retain selected IDs;
   singular engine maps to engines. False flags use --no-*, positional intent is
   preserved, resume is forced once, and unsupported structures fail before spawn
   with runtime disposal. No temp queue files or new state owner were introduced.
   Red goal-supervisor-structured-red: both dropped-input tests failed,
   SHA 3fe1009a10c949a5e194d74eef60bbec9daec3037174e4d679ae513f30b22508.
   Green goal-supervisor-cli-controls uses real generated CLI parser with Goal's
   registered declaration, quoted/newline task JSON, false booleans, restart replay
   and invalid-structure controls. Types/lint/diff pass; zero provider launches.
   SHA 6d157f731c7b23102cc4d2165aaf3562ad1f022fb61081f0eb317f643ee045fe.
   Full repository and fresh clean-checkout qualification are still required.
9. Think/PR and healthcheck accounting plus invalid adjudication cost: source
   confirms adjudication verdict can clear despite invalid cost (and no exit
   success check); existing test titles overstate this protection. Reproduce
   with real blocking evidence. Other billed paths need targeted tracing/tests.
Additional reviewer risks (not yet confirmed): intra-Forge Goal lease loss,
partial/deferred cleanup ownership, synthesis/gauntlet costs, clearedBaseline
operator-vs-crash ambiguity. Synthesis is disabled in current fixture; a separate
real-effects synthesis test is required. Known oracle red-team/default routing/
legacy retirement/release gaps remain. No live process, commit, push or install.

Accounting source trace for the next implementation pass: DispatchResult already
has optional usage with prompt/completion/cache tokens and sdk/cli-reported/
estimated source (support-engine-runtime/src/types.ts). CLI and MCP now preserve
that exact usage field, including failed dispatches. Missing usage remains absent;
the projection does not invent zero usage or a dollar charge. Red
engine-host-usage-red reproduced six missing-usage cases (both surfaces, three
sources), SHA 54d4a0553f70c465eb8c4b120340f7e83e7311c632aedf77b5f26ba561ea643d.
Green engine-host-usage-green: 58 host contract checks, types/focused lint/diff,
zero providers, SHA 91e701c1c35b8195750df9670ba02836c1e1ad5e87fd4d9cffe8352c1c52a3a3.
Cost estimation/metering remains unresolved; this is metadata preservation only.
Do not invent a second provider billing model; trace existing token-tracker and
the original Goal budget behavior, preserve usage provenance, and distinguish
missing measurements from a verified zero. Completed-dispatch estimates retained
by the recent stage fixes do not settle that separate host-contract gap.
Existing Core TokenTracker.getStats separates sdk per-token usage from
cli-reported/estimated and flat-rate coding-plan usage. Its documented budget
field is meteredCostUsd, not totalCostUsd. Reuse this billing distinction rather
than treating every token estimate as a charge. Core currently exports pricing
functions and the tracker instance, not the TokenTracker constructor.

Interrupted accounting/finalization now implemented (still WIP): task competition
stores costAccounted alongside spentUsd in the same state write. Recovery reads
the contained manifest, validates run-directory and fitness-command identity,
folds its recorded costs exactly once, then marks the run as interrupted/recovered
before clearing the pending reference. Normal completion sets the same accounting
marker before patch apply. Existing run host owns finalization; no second ledger.
Missing manifest with existing competitor work refuses recovery rather than
assuming free work. A pre-dispatch crash with no manifest/children has no charge.

Shared local cost fold rejects malformed ledger entries, negative/nonfinite
amounts, null or missing cost inside a present token record, and nonfinite sums.
Metrics with NO token record retain existing zero-estimate semantics; this is not
proof of zero real provider spend. Hard-timeout races/throw-without-usage remain
an accounting evidence limitation to assess, not invoice-complete qualification.

Red goal-interrupted-accounting-red: log SHA-256
80c1548697dca0f9e49b38309636c69a4e6af4beaa90de0b4d76cbe5c6663cf7.
Green goal-interrupted-accounting-green: ten targeted cases + typecheck,
log SHA-256 b5614bf55e9354a19cf28260f298d65a16a52bd7e2a13df2f3805a51a94e1d75.
goal-interrupted-accounting-controls: seven recovery cases + typecheck,
log SHA-256 cce8905f2270b4e1bda0fefd9a3f512e0508ebb6cff27aa8745bc5260a75c84f.
Cases prove once-only accounting across saved-cost and already-applied boundaries,
budget stops before another dispatch, run finalization, and invalid-cost refusal
before candidate mutation. A null-cost negative control then caught nullish-zero
coercion: goal-interrupted-null-cost-red (log SHA-256
b667eb592d3f6bf969a65597933392f51ef4c3db4997bc61ca2e8df4863eaa9a).
Fixed the coercion; goal-interrupted-null-cost-green passed both malformed-cost
cases + typecheck, log SHA-256
861092a94ce80cf7dfb1886536c8971556537564a220b95d4837a349c40e1352.
All runs recorded zero provider launches. No live process remains.
Next: fresh full Goal/snapshot/host suite, broader recovery identity/crash checks,
independent review of the whole integration, actual oracle red-team/default
roster parity. No commit, installation or push; original acceptance remains open.

Durable competition recovery WIP now exists in Goal's owned task state:
- Persist run handle, immutable snapshot, candidate HEAD/patch and engine roster
  before provider dispatch. Existing cancellation regression verifies the record
  already exists inside dispatch, before cancellation occurs.
- Persist selected patch and current spend before normal apply. Remove the pending
  reference only after run finalization and valid authority, before cleanup.
- On resume, validate retained Goal worktree identity, snapshot parent, safe engine
  IDs, contained child paths and matching Git common-directory/HEAD. Select the
  first nonempty interrupted child patch in recorded roster order; retain others.
  This is repair input, not winner selection or acceptance.
- Save selected repair input before apply; compare complete expected patch against
  current candidate to make apply replay idempotent. Refuse unexpected parent
  edits. Recover before rebasing a task onto newer accepted work.

The updated cancellation regression first failed at resume after proving durable
linkage: goal-durable-competition-recovery-red, log SHA-256
5776edf0c8f444ae7a313cb9fc8a6dff73a20c79636e13019dd5d98240ee22e9.
After recovery implementation, goal-durable-competition-recovery-first passed
four cases + typecheck (normal/missing-outcome cancellation, fence loss, real
competition), log SHA-256
0641083702d41e8cc7474a75783d07ff609f5d4e9b0560e0fef7b3a01c09e045.
Expanded controls pass in goal-durable-competition-replay-controls: four cases
(recorded cancellation, missing outcome, patch already applied before clearing
pending state, unexpected operator edit), typecheck and diff check; log SHA-256
979ec5112dd6ec0dfb7d0bba0fe6eaf0354063e7706431099e2601681b6c7144.
These simulate persisted crash boundaries; they are NOT a real SIGKILL run.
All receipts recorded zero provider launches; no live test process remains.

Still unqualified: interrupted competition cost accounting and run finalization;
broader invalid-record/child-identity negative controls; real process-death probe;
fresh full suite; independent review; oracle red-team and default roster policy.
In particular cancellation occurs before the normal manifest cost fold, so the
durable run's metrics must be reconciled exactly once on recovery. Do not claim
budget parity for cancelled runs yet. No commit, push or install.

Parking fixture reconciliation: verified Forge's existing policy harvests a
nonzero provider response when its edited candidate passes fitness. The old
parking fixtures returned exit 1 but wrote passing implementations, so expecting
those candidates to park contradicted the approved Forge execution path. Keep
the same final assertions; change inputs to genuine failing implementations:
- uncommitted baseline retry uses a tracked failure marker removed by the repair;
- independent task parking rejects failed-attempt.txt;
- advanced-base recovery requires first.txt when partial.txt exists;
- conflict recovery rejects the failed first edit of base.txt.
The conflict case explicitly selects builder and prices each attempt at $1.
Budget is $2 for the failed + successful attempts, with an explicit spentUsd=2
assertion. This replaces the old fixture's implicit unpriced failed attempt;
no charge is hidden to preserve a one-dollar total. All existing status, commit,
retained-byte, conflict, source isolation and independent-work assertions remain.

goal-competition-parking-real-gates passed all six targeted cases, typecheck and
diff check, 26.167 seconds, zero provider launches. Log SHA-256
ed8aafc6fbe4c6e9401e2403180500e4c993a2584e606327e47d72300bdc5f0a.
No live process. Full suite has not been rerun after these changes; do not infer
its remaining failure count. Cancellation recovery remains the next known real
defect. It needs a durable task-to-competition reference before dispatch, not
just an in-memory catch-path copy, so process-exit recovery can inspect retained
children too. Recovery must check Git identity and parent baseline, preserve
competing patches, apply only to the unaccepted task candidate under a new valid
lease, and be idempotent if interrupted between apply and state persistence.
This is design guidance, NOT implemented or verified recovery. No new package
or parallel scheduler is required. Current integration remains uncommitted.

Failed-dispatch accounting repair (WIP, 2026-10-19): Forge stages threw away a
returned nonzero provider response when it had no edits. The outer failure path
then emitted a metric with no token/cost record, allowing Goal to retry past its
estimated-cost budget. Existing retry-limit cases now explicitly select one
builder, inject cost at Forge's pricing boundary, and use a genuinely failing
fitness gate when edits exist. Added no-edit variants; both failed before repair.
Red goal-failed-dispatch-cost-red: two passed, two failed; log SHA-256
c1f035f35ab769f986c4b316ba7d6f52518251a3a89f63c0d093d434702e17c9.

mod-forge/src/stages.ts now computes the same dispatch pricing record before
branching on returned failure/cancellation. A non-harvestable response returns
the failed result with duration, error, tokens/cost and engine:failed event;
it does not run fitness or become a passing candidate. Returned aborted work
also keeps its metric. Successful/harvested pricing uses the same record.
This covers returned responses, not billing evidence for an adapter that throws
without returning usage or a workflow-level hard-timeout race. Do not claim
provider-invoice accuracy: estimateTokens/estimateCost remain estimators.
goal-failed-dispatch-cost-green passed all five targeted cases plus typecheck,
independent Forge build and diff check; log SHA-256
2e5aa52da6bfdeb2a1359cf27b6e23f23e34d72d57d0ea7da6f1a2bb6e2a54bf.
Both receipts have zero provider launches.

Broader Forge owner regression PASSED: goal-forge-cost-owner-regression,
terminal 11280 exited 0 in 87.471 seconds (Forge timeout unit suite + Forge E2E
+ lint + diff check), zero provider launches. Log SHA-256
3f7b9684f5c855003a813e1a1b44ae6387a58148e80b052b59e47fc7117d82b3.
No live process remains. No review or commit yet for this integration.
All previous unresolved work remains open.

Further triage after full run #2 (all changes still WIP):
- Four witness/oscillation fixtures now explicitly request builder. Their existing
  one-dispatch/two-attempt expectations and all witness, commit and isolation
  assertions stay intact. goal-competition-single-seat-oracles: four passed +
  typecheck; log SHA-256
  52dc8218c8d69c9d2b6c3171e6737d1e1510d39aceb69fe2f9a946c557032c0d.
- Missing run storage previously reached the new Forge call and threw after
  creating Goal state and worktrees. Unfinished execution now returns typed
  GOAL_RUN_STORAGE_UNAVAILABLE before opening a host/lease/worktree. Status,
  dry-run and completed-task replay are not newly storage-gated. Regression
  proves zero dispatch, zero state writes, no goal branch and no source edit.
  Red receipt goal-run-storage-preflight-red, log SHA-256
  a02d2fca564e8c7c0a683964f6ee29b3cc5f82e2dd4bfdb6a303ecc6851e4f2d;
  green goal-run-storage-preflight-green: 17 targeted tests + typecheck,
  log SHA-256 3a9f6957bb59beb87ea9b2992e00bc113a28ea87730cfb740dc7d4ac7dc55af4.
- The ignored-file-dependent candidate now fails its Goal gate before mutation,
  because Forge transfers a patch, not ignored files. Preserve that case and
  also exercise the real mutation baseline with explicit witnessCmd requiring
  the ignored file. Both cases reject, never review/commit/accept the change;
  a call-through spy proves mutation runs only in the second case.
  goal-competition-ignored-file-boundaries: two passed + typecheck,
  log SHA-256 bea7e6a432d981f01bb696b1266fa5ee6fcf364ba7b49d273890b894c6546102.
Zero provider launches; no live process remains from these runs. Full suite
has not been rerun since these changes. Remaining cancellation recovery, parking,
budget/retry accounting and the broader Goal integration still need work and
independent review. No commit, push or installation.

Latest continuation: failed (no-winner) competitors now supply repair input to
the retained task candidate. Selection is highest fitness score, tied by requested
roster order. This does NOT create a winner or permit acceptance. The existing
Goal gate runs against the repaired candidate; its exact failed output/signature
is recorded even when Forge also reports no winner. A successful next attempt
still needs all normal acceptance checks. Failed competitor worktrees remain
available as evidence.

Reproduction goal-competition-failed-baseline-red failed the single-seat retry
test before this repair (log SHA-256
0df64f6714c1853fca17ea1e9d01a39a1bdbb194b5f1f4413ae3b2f97de81d04).
goal-competition-failed-baseline-repair passed three focused tests + typecheck
(log SHA-256 a8d7ac2208d2c03cdc9b73a5b02229e599a58db863277da9faa257d48406dc43).
Strengthened existing retry regression checks exact failed bytes are present
in the next competitor while neither failed file nor implementation enters the
accepted worktree before verification. It passes in
goal-competition-failed-baseline-isolation (log SHA-256
c3d891beb7c9fe486a4a0b51241610015d6e293b4ea2dc376d8406d3b8ab833d).
Zero provider launches in all three runs.

Full focused rerun goal-competition-suite-second FINISHED, terminal 76884 exit 1:
229 passed, 16 failed (245 total), 325.453 seconds, zero provider launches.
Log SHA-256 414e6479f2b826e29632d9d424a1f59f0d54f2dc912f58ca54b30ca80fe69423.
No process remains live from that run. This is measured improvement from the
previous full run (192 passed, 53 failed), not a qualified increment.
Remaining failures: missing-helper witness, uncommitted baseline resume,
deleted-test witness, committed-base retry, missing mutation run storage,
real mutation baseline, parking/independent task (2), oscillation, accepted-base
advance/resume (2), conflicting parked candidate, cancelled recovery (2),
budget-before-retry and no-progress-before-retry. Inspect the full saved log
for exact assertions before changing them. Some are single-seat fixture
assumptions; others are runtime defects. Do not assume all share one cause.
Cancellation/process-exit recovery still needs durable linkage between task and
competition artifacts; deferred deletion alone preserves files but not automatic
resume. No final review, commit, installation or push occurred.

2026-10-19 continuation: approved Goal -> mod-forge dependency remains authorized;
no new permission is needed. Integration is still uncommitted and unqualified.

Pricing fixture correction is verified: implementation costs now enter through
Forge's estimateCost effect, not the old agent response. Existing expected budget
totals remain unchanged. goal-competition-pricing-boundary passed 13 targeted
tests and typecheck (log SHA-256
7e29de0a1816ce7c9008082fb1efe0b598e4921cae8759cba29830dc3fdee01b).
goal-competition-priced-roster passed the real two-competitor test, including
0.2 + 0.4 = 0.6 recorded spend (log SHA-256
1e320c9cb323f5bdd69932494859593fd9fb6425dfe8c9d601618444ace38bc0).

Confirmed recovery defect: Forge removed child worktrees before Goal could check
its execution fence. The existing fence test, explicitly selecting one builder,
reproduced missing partial.txt with no other assertion changed. Receipt
goal-competition-fence-retention-red, log SHA-256
0c289427a5ada1c91ad4cad0f38ff45b25fa59d6f891e1ca35a809c289873d02.
Goal now defers the existing Forge removal effects until a result is adopted and
its run record finishes under valid authority. It does not prune other worktrees.
On failure or authority loss, competitor directories and Forge run artifacts stay
available. No Forge public option or alternate execution loop was introduced.
goal-competition-deferred-cleanup passed typecheck and both focused cases:
fence loss preserves exact partial bytes without state writes/commits; successful
two-seat competition removes both child worktrees. Log SHA-256
5ab846a81b715f6e582180dd9e976e82717a641480d7f6c56e2693a867c75187.
All these receipts recorded zero provider launches. These are focused checks,
not final release evidence. Remaining work includes failed-patch adoption for
resume, cancellation, run finalization, oracle red-team, and full qualification.

Witness/locking fixtures now explicitly select builder where their contract is
one dispatch. No cancellation, generation, fence, process-count, retained-tree,
or source-isolation assertion was weakened. Existing multi-seat test stays separate.
goal-competition-witness-authority passed eight tests, typecheck and diff check;
log SHA-256 f60636b5dd84492af28ef6352585c785bf7ad702cadd918b33a8e554abe2b6bd.
No live processes remain from these runs. Next concrete issue: an interrupted
competitor is now retained, but Goal's persisted task worktree still names the
parent candidate, so automatic resume cannot recover the child's partial edits.
Also trace no-winner failed-patch retry: current integration only adopts winners,
which loses the old retained failure baseline. Preserve acceptance isolation and
authority checks when repairing this, and do not turn failed work into accepted
work merely because it is retained. Do not commit the current WIP yet.

Full focused run terminal 7648 finished, exit 1: 192 passed, 53 failed (245 total),
327.605 seconds. Receipt goal-competition-suite-first, SHA-256
1c6c47cde54562bf894f44257b41990c54196014a27bd16efe890ca895aba3fe.
No process remains live from that run. All failures remain part of acceptance;
do not call the integration green from the single competition case.

First confirmed runtime repair: allow a winning retry with no additional patch
to continue through gate/witness/mutation/review on its retained candidate.
First attempts still require an applied winning patch. Changed two dispatch-path
assertions from equality to inequality because engines now run in Forge children;
retained candidate identity, exact retained file bytes, mutation checks, branch
state, and accepted-state isolation assertions remain unchanged.
Focused retry/real-competition run goal-competition-retained-retry passed with
typecheck, SHA-256
040d53258fc1d1a286499fafca41fcba08b386758eb9c22928fa0807af13ca4f.
No full rerun yet; do not infer the remaining failure count by subtraction.

Next triage batch: budget tests and dispatch metrics. Use the actual Forge pricing
boundary in the fixture, keeping budget assertions and explicit single-seat cost
tests distinct from the already-proven multi-seat execution test. Then address
retained failed work/parking, cancellation/fencing and exceptional run records.
No commit, push, dependency download, or global/personal-state modification.

While terminal 7648 is still running, source tracing identified these distinctions
for triage after exit (no source changes during the test run):
- Retry no-op bug in the new integration: built.exitCode currently requires a
  nonempty applied winning patch. A retained candidate may already contain the
  needed work after a rejected mutation/review. A successful retry with no new
  patch must still run the verification pipeline; do not discard its baseline.
- Test path assumptions: implementation.test.ts:1007 and :1110 assert the engine
  runs directly in the retained Goal candidate. Forge intentionally dispatches
  into separate child worktrees. Preserve content, isolation, retained identity
  and verification assertions; replace only the now-invalid dispatch-path identity.
- Forge intentionally harvests failed/timed-out dispatches with a diff and tests
  their fitness (stages.ts:87-101,159-169). Several parking tests currently use
  exit 1 plus a passing gate to simulate unusable work. Trace legacy Goal behavior
  before changing either runtime or test; do not silently disable Forge harvesting.
- Cost tests currently attach raw costUsd to the agent transport. Forge stages
  price dispatch metrics through estimateCost and estimateTokens (stages.ts:245-256).
  withForgeHost currently drops the raw cost field. Keep tests about budget
  enforcement; inject costs at the actual Forge pricing boundary, not by making
  Goal read an unrelated transport field or accepting zero spend.

Execution integration WIP (2026-10-19, supersedes the pending execution note):
runGoal now calls createForgeWorkflow using the injected Forge host, retains the
full resolved implementation roster, forwards synthesis/judge, accounts from
manifest.dispatchLog, selects a test-bearing winner through existing policy,
and applies the patch only if the retained candidate still matches its baseline.
The single-agent implementation import/call is removed. This is uncommitted and
NOT qualified. Oracle adversarial probes are still not integrated.

New createWorktreeSnapshot in the existing support-worktree forge-arena owner
uses its existing temporary-index patchTree, then writes an unattached commit
object. It moves no branch and preserves the live index. Test checks binary,
new Unicode-named files, deletion, malformed patches, HEAD and index identity.
Snapshot/typecheck receipt goal-competition-snapshot passed, SHA-256
77d9284e6cdf8948d22b787d95330473ab8e0b34bb11d15ae8e135cf279f947a.
The same immutable snapshot is supplied to Forge, so baseline, competitors,
synthesis and gauntlet start from the retained dirty state, not tracked-only HEAD.

Real competition regression now PASSES: goal-real-competition-built, SHA-256
36549fd8eac28212ecdbff45e4e11502d93ae51a5cf82bb705644c1c03ce5713.
Both explicitly requested competitors run through real Forge effects in separate
Git worktrees, with fixture provider transport. No provider processes launched.
Two intermediate failures retained: optional stderr type fixed; runtime missing
export resolved by rebuilding support-worktree (package import uses dist).
The native optional tree-sitter warning is not a qualified native-helper result.

Existing Goal fixture now uses withForgeHost and unique run directories instead
of shared /tmp/forge-run. Full focused Goal/snapshot/host suite is RUNNING as
goal-competition-suite-first, terminal 7648. Source frozen until it exits. Poll
this same session; do not restart because output is quiet. Snapshot and host
tests have passed; Goal results not yet emitted. Whole-suite success is unproven.

Review targets after that run: failed-seat cost accounting and retained failed
candidate semantics, exceptional run finalization, cancellation/authority loss,
winner/no-diff retries, default heuristic roster behavior, synthesis, and exact
baseline adoption. Do not adjust historical assertions merely to fit changed
behavior. Some fixture cost fields used by the old agent path are not the Forge
dispatch pricing boundary; trace each mismatch before changing fixtures.

Current WIP follow-up: CLI and MCP now include agon.goal in their existing
guarded Forge host consumer lists. Existing host-wiring tests include Goal.
The first test run exposed a fixture gap (Core mock lacked Goal oracle/worktree
function exports); added only inert function references used during decoration.
No host is opened and no engine is dispatched by this test. Final host check
passed 50 tests plus typecheck: goal-forge-host-verified, SHA-256
c3a807610af823e6f751ddfe453a154d320df7a7c5b0de934b538198e14f73eb.
Failed runs goal-forge-host-red and goal-forge-host-green are retained.

New real-Forge regression in mod-goal/src/implementation.test.ts uses the existing
tests/helpers/forge-host.ts and isolated Git/run directories. Explicit engines
builder,reviewer must both execute in distinct worktrees. It currently fails:
only builder runs. Receipt goal-real-competition-red, SHA-256
c8eff3d7d11e3875b9e9ff8f1c93ed4d95ae06611a6b3017c907dcc7530ab22f.
This is an intentional failing regression during implementation, NOT an accepted
gate. Do not commit the partial change or claim a green full suite.

Dangerous transition confirmed before replacing execution: Forge workflow calls
effects.stashSnapshot(options.cwd) at workflow.ts:331. The current Core-backed
snapshot documents tracked-only behavior (core/src/blocks/git.ts:349). Goal's
retained task baseline includes untracked/binary files through readWorktreePatch.
Do not lose that baseline by wiring the workflow directly to tracked-only stash.
support-worktree/src/forge-arena.ts already owns patchTree, which reconstructs
exact trees using a temporary Git index without changing the branch/index.
Prefer extending that owner to capture the exact immutable baseline for Forge,
instead of duplicating Git snapshot logic in Goal or staging/committing user work.
All Forge stages (baseline, competitors, synthesis and gauntlet) must see the
same baseline. Winner patches must apply relative to that baseline, not HEAD.

Approval update (2026-10-19): Raphael explicitly approved Goal -> existing
mod-forge@1.0.0, including competition, synthesis and oracle red-team. The
dependency blocker recorded below is resolved. No external dependency or
installation is authorized by that grant. Implementation resumes on 5f3923440.
Backup: backup/goal-forge-approved-5f3923440. Baseline command is recorded in
goal-forge-approved-baseline; typecheck, lint and focused tests passed.

Dependency foundation is now uncommitted WIP on that subject. Canonical owner
generator declares the edge; package, manifest, TS references, graph, catalog,
migration ledger and roadmap have been regenerated. Exact graph-count checks
are 156, with the new edge independently asserted. No external version changed.
This changes 21 files, primarily generated metadata and nine one-line slice
count checks. It does not yet change Goal execution or supply Forge host effects.
Do not claim competition restored. Do not commit until runtime wiring, focused
review, release metadata regeneration and full qualification are complete.

Baseline: goal-forge-approved-baseline, SHA-256
b58c0a66addeca50ebb6002d79748e5d639bb24b829d42b539f6c502b79a82ee.
New edge regression failed before the change: goal-forge-dependency-red,
SHA-256 8729e29bea2ece30f02909f7606c6660fa4cdad4a5cab47e134251225cc1939f.
Two intermediate attempts correctly rejected stale surface catalog and migration
ledger outputs; their logs are retained. All generated checks, roadmap, typecheck,
115 package-graph/platform/activation tests and diff checks now pass in
goal-forge-dependency-gates, SHA-256
d1a3d13a20a13f543c35d52b56acbd4ab28351465767bc946c1b7dac3af3494c.
All test receipts record zero provider launches.

OSV sandbox scan failed DNS. Authorized isolated network retry completed and
reported 16 vulnerability occurrences in nine packages (two critical, seven
high, six medium, one low). The two critical entries affect existing dev
tinypool@1.1.1. No upgrades were made. Network scan receipt/log:
goal-forge-dependency-osv-network, SHA-256
960b073576e1735411c01ee8785e618c45adee13bfa9254bb33e0fdc2b15f859.
Its exit 1 represents findings, not a clean security result.

Next: inject Forge's captured-authority host for agon.goal on CLI/MCP; replace
runAgentTask with createForgeWorkflow, preserving full roster, synthesis,
dispatchLog costs, test-aware winner choice and retained dirty/untracked base.
Use tests/helpers/forge-host.ts for real Forge effects with fixture transport.
Then integrate the actual oracle red-team and finish controller convergence.
Permission is granted; do not ask for this edge again.

Current subject: 5f39234401d7bb07fc330e2d77d5c448da62bbe9. Worktree clean.
Review-default restoration is committed in 191593086, including explicit
roster validation, configured/default selection and cancellation checks.
Artifact formatting ownership is committed in 5f3923440. No review or test
process remains live from those increments. Their receipts appear below.

Latest full gate: goal-artifact-owner-final-full, 10,359 tests passed, six
skipped. Built artifact runtime: five task-state cases passed. Native performance
and sustained-load evidence belongs to 191593086, not to the latest subject.

Acceptance recheck: all nine stored slice reviews fail the current review-input
policy check. See review-subject-status-5f3923440.log (SHA-256
a61c7b7bd83740e65813b8c14373e4a0abf6d9bcc46e5148a2087176316bfc9c).
The reporting command's successful exit does not mean slice acceptance passed.
No contamination or duplicate dependency edges were found at the current subject.
Fresh clean-checkout execution and fresh subject-bound reviews remain required.

Next implementation remains Goal competition and actual oracle red-team through
the existing public Forge workflow. Goal -> mod-forge@1.0.0 has no approval yet.
The separate support-worktree dependency approval does not cover it. CLI's
first-party-services.ts:190 and MCP's first-party-services.ts:31 currently inject
Forge capabilities only into Forge, team-forge and pipeline-orchestration.
Goal needs both its declared dependency and those guarded host capabilities.
Legacy-controller retirement must follow behavior parity, not precede it.
No duplicate competition loop or private import is an acceptable workaround.

## Historical review-default work log

The following snapshot is retained for traceability. It is not live status.

Subject: fix/modular-qualification-continuation at 53c30fc55. Recovery is
committed. Terminal 68061 completed. Current WIP restores review defaults and
validates rosters; four files changed (Goal host/implementation/test and CLI
first-party-services). All 183 Goal tests pass. Codex review is live in terminal
71168; no full gate for this WIP yet. No dependency or lockfile changed.
Prior continuation was a verified wait plus source-traced integration notes.
This continuation completed the full gate, final live probes and local commit.

Verified increments: differential witnessing (740d724a7), retained task isolation
and attempt history (70f62e770), frozen snapshot owner (1a14e2ebe), frozen state
integration (572be2ed3), exhaustive Goal mutation selection (0a03dd6d1).
Detailed historical evidence remains below; do not repeat those completed fixes.

Current review has no unresolved production finding after cancellation repair.
Recovery full gate passed 10,326 tests / six skipped plus all hygiene, generated,
roadmap, release, supply-chain and 85 installed-candidate checks. Duration
642.336s; log SHA256 c9e4ea9bbdc61be5b22ea57c6ef458b4c0a094b7ff09811b817fa801ff832c6d.
Final built-live probe passed three cases after the full build, 0.306s; log
SHA256 1c56d7fe7cee5c7de905ea5f285622ea71552ae5b007ebd332e828f0c1411b76.
Both receipts record zero provider launches. Eight explicit files committed;
no push or global/personal-state change. This does not qualify the full release.

Remaining original Goal gaps, rechecked against source:
- Reproduced explicit-roster loss: missing-only, mixed known/unknown, and empty
  comma-only rosters all invoke the default builder/reviewer instead of failing.
  goal-explicit-roster-red fails three cases, 2.770s, zero provider launches;
  log SHA256 15b00cf381b3bdeaafa339ac9a91b95c1e877e4fc04709417f8a1d40715abaf7.
  Do not mark these red cases as accepted. Backup branch:
  backup/goal-competition-53c30fc55. No production competition change yet.
- Physical runGoal still calls runAgentTask (implementation.ts around 917).
  Legacy CLI uses Forge competition, roster/winner policies, and patch adoption.
  Existing Goal -> mod-forge dependency request remains unanswered. Do not
  replace competition with hand-written dispatch loops or infer approval from
  the separately approved reverse dependency.
- Physical oracleGate still checks an unmodified candidate, not an adversarial
  implementation. Existing Goal oracle-probe/redteam owners are available;
  legacy CLI around 635-706 implements the probe through Forge. Integrate these
  after competition, retaining clean/gameable/inconclusive distinctions and
  per-launch retries, costs, abort and generation fencing.
- Integration seam checked: mod-forge exports createForgeWorkflow and
  ForgeHostServices. Reuse that public workflow with the existing injected
  effects/registry/adapter, not the CLI command's private imports. Its raw
  manifest preserves dispatchLog cost and synthesis needed by legacy Goal.
  runForgeCompetition is a surface translator: it does not currently forward
  legacy Goal's synthEngine/synthesize options or expose dispatchLog in its
  payload. Calling it unchanged would silently narrow Goal behavior.
  Goal already owns pickImplementWinner/chooseImplementRoster. Preserve
  test-bearing candidate choice and explicit roster authority, including fix
  passes; do not copy those policies into a new host callback.
- Pre-approval graph check on 53c30fc55: traverse every workspace package's
  dependencies. Neither Goal -> Forge nor Forge -> Goal exists transitively;
  adding the requested direct edge creates no cycle. Target version is 1.0.0.
  No package file changed. Goal manifest must also require agon.forge so disabled
  Forge cannot remain callable through Goal. Existing CLI/MCP host decorators
  inject Forge effects only for Forge, team-forge and pipeline-orchestration;
  Goal must join those bounded lists, retaining their existing captured surface
  authority checks. Do not inject a second workflow implementation.
- Additional source-backed parity seam: legacy goal.ts around 322 honors
  goalReviewEngines then all non-local active reviewers, with explicit override;
  physical implementation.ts around 675 ignores config and excludes the builder
  plus caps at three. Config ownership is agon.review (generated assignment and
  mod-review schema), not Goal. InvocationContext.config is owner-scoped by
  mod-kernel registry/settings; simply reading context.config.goalReviewEngines
  in Goal would not restore production behavior. Reuse the Review owner's
  configuration transport rather than copying this key into Goal's schema.
  This is a source-confirmed missing path, not yet an executed regression.
  Engine services already expose resolveRequested in the CLI; preserve alias
  and explicit-provider handling instead of checking only listActive defaults.
- Review-panel truncation now reproduced in goal-default-review-panel-red:
  five available engines yield only three review calls; builder and fourth
  reviewer omitted. One failing control, 1.645s, zero provider launches,
  log SHA256 cf37080ecf3e6df863892b264e4fbd3b8100467a2ab67fab4b94c557c92fc269.
  This test joins the three explicit-implementation-roster red cases; no
  production edit or dependency mutation. Current WIP is one test file.
- Existing transport inventory: ModServices has engine resolveRequested but no
  cross-owner settings read. GoalHostServices currently has no config callback.
  Forge effects loadConfig returns a deliberately narrow ForgeWorkflowConfig;
  do not cast it to access unrelated Review-owned keys. A bounded Goal host
  data projection (not a workflow callback), using the existing loadConfig
  owner and registry metadata, can restore review defaults without a new
  package dependency. Keep selection policy in a mod, aliases through existing
  engine services, and authority/cancellation checks around the read. This is
  the next independently actionable implementation while Forge approval waits.

### Review-default restoration WIP

No new dependency. Existing Goal host now accepts an optional, invocation-bound
data projection: configured reviewer IDs, local engine IDs, configured judge.
CLI projects these from existing loadConfig/EngineRegistry. Selection stays in
Goal; state/config storage stays with existing owners. Legacy/default reviewers
are not capped or stripped of the builder. Explicit/configured/default precedence
is retained. Existing engine resolveRequested handles aliases and availability.
Invalid implementation/review rosters fail before model work. This does NOT yet
restore competing implementation: a valid multi-engine implementation roster
still uses only its first engine until the approved Forge integration exists.
Do not label this interim behavior full competition or whole-Goal parity.

goal-review-defaults-red: two failures, explicit override control passed. Hash:
63fc984979e056974ea02c53f8698506ef829d4877fc33e41ad0850f7b1c1463.
First focused run had four failures. Two were a real new ordering regression:
eager engine validation prevented replay of prepared commits when no provider
was available. Resolution is now lazy, before Think/new implementation only;
already-recorded acceptance/publication can finish without engines. Other two
were old default assumptions: reviewer costs now include both default seats,
and a sole builder is an eligible default reviewer as in legacy Goal. Preserve
the unavailable-review safety test by withdrawing the panel after building;
assert concrete review error, review-block attempt, no reviewer dispatch and no
commit. Do not delete this control or turn absence of reviewers into success.
goal-review-defaults-recovery-controls passed 20 controls; hash:
1deafc4a9375a52ed98619396ea7379ce816db8f56ee4a7b84a4d7403d6dca0d.

Added alias resolution, configured-unavailable-before-Think and captured-authority
before/during settings-read controls. Full focused Goal suite plus typecheck
passed 183 tests in 90.035s (goal-review-defaults-final-focused), zero providers.
Log SHA256: 218da87d44f8f72ee421456fbe503aed2a6bcb2ea457f2a8c574e47ccbdf646b.
Isolated Codex review goal-review-defaults is live in terminal 71168.
Next: inspect review, verify findings, built CLI config
projection/live workflow probe, full repository gates, then local commit.
Production paths changed: mod-goal/{host,implementation}.ts and CLI
first-party-services.ts; tests stay in existing Goal suite. No package/lock edit.
- Legacy controller/state ownership and adapter retirement must follow actual
  behavior convergence. Final clean-subject receipts remain outstanding.
- All original release/platform/workflow requirements remain in the roadmap.
  Component green does not close them.

## Current continuation, 2026-10-17

Mutation execution/sandbox ownership and stale-artifact handling have advanced
through8d423b190,e79addb20,cddcd493c,e66dd5250,8d23c7e63. See the durable
integration journal for full gates and real built witnesses; historical paragraphs
below describe the earlier gaps, not current unresolved duplication.
The pending witness-command correction restores explicit witnessCmd/global-gate
selection for mutation. It does not implement differential witnessing.

Source-confirmed next integration seams:
- mod-goal/oracle.ts already owns witnessTest and witnessVerifyCommand through
  injected effects. Reuse these, do not implement a second oracle.
- GoalHostServices currently exposes retained worktree operations, not detached
  oracle worktrees. CLI first-party-services.ts is the production composition.
  Core blocks/git.ts still owns detached worktree creation, exit cleanup and
  error identity; inject/reuse those effects before any ownership retirement.
- witnessVerifyCommand accepts AbortSignal; witnessTest currently does not.
  Add cancellation parity with before/after real-process tests before wiring
  long-running witness calls into physical Goal.
- Physical Goal retains a worktree across tasks. state.baseSha is the whole
  run base, not the current task base. Capture the appropriate committed HEAD
  before implementation; test task2 and retries, not only a one-task fixture.
- Retain current writer-fence and generation checks around asynchronous effects.
  Do not weaken retained failed-work, resume, or publication guarantees to mimic
  the legacy disposable-worktree controller.

Source is frozen during goal-witness-command-full (terminal79249); no additional
production integration was started while that subject is under qualification.

## Verified progress, 2026-10-17

The following historical findings below are now closed, not open blockers:
- Mutation failure admission:69a792d08 rejects failed, incomplete, cancelled or
  budget-exhausted assessments; retry/resume and documentation-only controls pass.
- Canonical generation:c7bc8ba49 moves the existing generator into worktree support
  and removes the second operator table. Core keeps public exports.
- Containment:08c4f50fa moves the existing realpath guard into worktree support;
  tracked and baseline-created symlink escapes are rejected without outside writes.
- Per-file grading:c28ccde57 reuses the existing Goal policy, passes flagged evidence
  to Review/artifacts/adjudication, and rejects unavailable reviewers. Full gate
  10138 passed/6 skipped,85 installed checks; built workflow measured1 kill/3 survivors.

The support-worktree -> support-engine-runtime dependency is explicitly approved.
Its runner ownership move is verified and committed8398a28aa. Remaining
execution consolidation must remove the second assessment loop, not just move it.
Source-confirmed next cases: total budget during setup/generation/mutants,
build/typecheck each mutant, cancellation distinct from kills, source restoration,
baseline-before-semantic-generation, and honest partial/error evidence.
Maintain sampled/default mutation limits separately from legacy Goal completeness.
No whole-controller parity claim follows from the fixes above.

Built witness on8398a28aa confirmed missing per-mutant rebuild (one survivor,
zero kills for a real compiled check) and setup exceeding an explicit1s budget.
Receipt mutation-assessment-parity-confirmed in the durable remediation directory
records the exact fixture command, SHA and output. These defects remain open.

Further source trace during runner-owner qualification: legacy mutate.ts calls
prepareSandboxNodeModules and clearShadowingDist before semantic generation and
runMutants. Shared mutation-runner.ts uses createForgeArena, which repoints the
conventional packages/* workspace links and copies build artifacts, but does not
clear targeted packages' ignored entrypoint outputs. Reproduce with a compiled
fixture before changing anything. This is separate from runner ownership.
Keep original source and external dependencies untouched; reuse existing bounded
mutate-sandbox.ts policies rather than invent new removal logic.

Another confirmed source distinction: runFitnessCommand requests bounded capture
and rejects spawnError. Canonical runMutants directly uses spawnWithTimeout
without that capture option, which suppresses spawnError in its returned shape.
Do not infer spawn failures are always thrown. Reproduce a post-baseline spawn
failure before claiming execution-error handling is complete.

Inspected 2026-10-17. Base64d54b8a8 plus the PR-handoff increment under
verification. This is a source-backed gap inventory, not acceptance evidence.

## Confirmed differences

| Contract | Legacy authority | Physical Goal | Required next evidence |
|---|---|---|---|
| Engine selection | CLI goal.ts `engines` resolves the requested Forge roster | cliSchema declares engines, but execution reads singular input.engine, not input.engines | Distinct requested engines reach the implementation owner; unknown/disabled choices fail before dispatch |
| Witness command | controller.ts uses witnessCmd for copied-test witnessing and mutation | schema declares witnessCmd; no execution read | A dedicated witness command runs, not the global gate |
| Test sensitivity | controller.ts witnesses each changed/new test on a fresh base worktree and candidate | only source/test filename classification | A tautological test is rejected; a real failing-before/passing-after test passes |
| Behavioral verify | witnessVerifyCommand runs the frozen command on fresh base and candidate, even with red-team off | current candidate is checked before building, and only when oracleGate is not off | Off disables red-team, not differential verification; timeouts never prove fail-on-base |
| Red-team | per-task/per-launch probeTaskOracle, bounded retry, explicit inconclusive evidence | oracleGate now controls a pre-build command pass check, not a red-team probe | Gameable, clean and inconclusive probes remain distinct; resume probes again |
| Park/continue | journal/policy park a task, then continue other runnable work; maxParkStreak is optional | maxParkStreak declared but unused; first exhausted task breaks the queue | A hard task does not silently prevent independent easy tasks; dependent tasks stay blocked |
| Attempt history | attemptLog, failure signature, policy-based oscillation handling | attempt counter and last error only | Preserve readable history and deterministic breaker decisions |
| Cost | implementation, red-team and review costs accumulate in journal | builder cost and adjudicator cost counted; no ordinary review cost addition found | Budget reflects every dispatched paid stage, without double counting |
| Frozen oracle | gate/file hash persisted by legacy snapshotOracle; resume compares | gate string compared on resume, no oracleHash/files owner | Same accepted oracle identity survives resume; mismatch does not overwrite prior evidence |
| Implementation | legacy CLI uses Forge competition and returns winner/cost | physical controller directly runs one Agent | Preserve documented workflow or explicitly identify a pre-existing accepted contract change; do not silently narrow |

Sources: packages/cli/src/commands/goal.ts; packages/forge/src/goal/controller.ts;
packages/forge/src/goal/{oracle,oracle-probe,oracle-redteam,journal,policy,types}.ts;
packages/mod-goal/src/implementation.ts. The CLI passes oracleFiles:[] today;
file snapshots are an exported-controller contract, not an existing CLI flag.
input.timeout is used by the think pre-pass, so it is NOT wholly unused.

## Ownership direction

Update after44020650d: journal/policy/oracle now have physical mod-goal owners
and legacy composition exports. This does not close controller convergence.

## Mutation acceptance gap found during controller trace

Physical implementation.ts ignores runMutationAssessment.ok and baselineOk.
support-worktree/mutation-runner.ts returns ok:false and empty outcomes on a
red baseline or caught error. Empty outcomes become zero survivors, so the
physical Goal controller proceeds to review/commit instead of recording failed
verification. Reproduce through its existing real-Git fixture with an injected
assessment failure before fixing. This is a separate behavior fix after the
current ownership-only gate, not a reason to weaken the existing runner.

The physical aggregate grading also differs from the existing per-file Goal
policy: fallback equivalent-prone survivors currently force retry rather than
review, and mixed files can hide a file with no high-signal coverage. Reuse
mutationGateDecision/foldMutationVerdicts instead of adding another policy.
Trace incomplete/budget-exhausted/aborted assessments separately; a missing
outcome is not a killed mutant. Preserve existing tests and lease checks.

Follow-up trace: support-worktree publicly exports changedLinesFromDiff through
index.ts's mutation-runner star export. A caller can recognize a legitimate
zero-target assessment using the SAME parser, without matching error prose or
inventing another file classifier. Failed baseline/process assessments with
mutable targets must not be treated as the legitimate skip.

Rejected hypothesis: new untracked test files necessarily disappear from the
mutation worktree. runGoal calls readWorktreePatch before assessment; that
existing function adds intent-to-add entries, so hydrateAmbientChanges' binary
git diff HEAD includes those files. Do not repair this path based on an
untracked-file assumption without a specific reproducer.

Implementation plan for the confirmed failure-admission gap: extend the existing
Goal real-Git fixture with failed-baseline, failed-process, aborted and incomplete
assessment outputs. Assert no reviewer or commit follows, edits remain available
and resume can succeed after a valid assessment. Keep a documentation-only
positive control. Use the existing parser and state/event machinery, not a new
service. Check per-file grading separately against the original policy; changing
failure admission alone does not establish full mutation-policy parity.

## Remaining mutation ownership and review-evidence trace

Verified source duplication: Core tools/mutant-generator.ts implements canonical
Goal operators, comment/template handling, duplicate-line suppression and the
legacy Mutant shape. Shared support-worktree/mutation-runner.ts has a second
operator table, fewer operators and different increment/decrement matching.
mod-mutate delegates to that second generator; physical Goal uses it via the
assessment runner. Thus runner ownership alone does not prove legacy mutation
coverage parity. Test the concrete differences before consolidating. Core already
declares support-worktree, so moving the existing canonical generator there
need not introduce a dependency. Preserve public legacy shapes and IDs, and
adapt the file-required MutationCandidate shape at the existing shared boundary.
No exact mutant-generator source entry was found in the frozen ownership JSON;
record the destination explicitly instead of claiming a pre-existing assignment.

Review evidence gap: legacy controller.ts grades each source file separately,
folds park > review > land and supplies flagged survivors to its review callback.
Physical Goal currently aggregates all files and never passes survivor evidence
to runReview. mod-review runReview has no supplemental evidence parameter; its
own optional mutation analysis runs AFTER model review. Reusing that flag would
not deliver precomputed Goal evidence to reviewers and would duplicate execution.
Need a bounded internal evidence input on the existing review owner, not a new
Goal-specific reviewer or unconditional duplicate mutation run. Preserve review
cost accounting, fail-closed health, and source-bound evidence on each attempt.

## Further runner parity evidence

Core tools/mutant-runner.ts already has a richer runMutants contract: finite
positive budget validation, deadline-capped subprocesses, baseline/build/typecheck
evidence, cancellation distinct from kills, invalid placements and per-mutant
restoration. Legacy forge/mutate.ts consumes it. Shared mutation-runner.ts owns
a second execution loop that polls total budget only between mutants, and its
25-default/500-maximum selection cap differs from legacy Goal's all-generated
per-file witnesses. Consolidate existing owners rather than recreate these
policies in Goal. Preserve the arena's isolation and the Goal writer fence.
These are source-confirmed differences, not yet exercised parity failures.

Remaining work order after canonical generator gate: verify/converge execution
runner contracts; restore per-file Goal grading and pass flagged survivors into
the existing review owner; then complete witness/oracle/competition and queue
state convergence. A directory move or aggregate survivor count is not closure.

Runner prerequisites: Core's process module is already a compatibility export
of support-engine-runtime. Shared worktree currently declares only verification,
so direct reuse needs an explicit internal worktree -> engine-runtime edge,
not a private/transitive import or re-export added solely to hide a dependency.
Approval requested asynchronously; no dependency was changed.

Containment difference to reproduce safely: shared mutation runner's within()
checks lexical containment only; canonical Core resolveWithinRoot also rejects
final symlinks and symlinked-parent escapes. A tracked symlink in an isolated
candidate can still reference outside that candidate. Prove with a self-created
external fixture, never personal files, before consolidating this boundary.
Existing Core paths module is Node-only; keep one existing implementation rather
than invent another checker during the runner migration.

## Ownership direction (original plan)

Do not recreate all legacy policies inside the physical controller. Trace and
move the existing Goal-owned policy/oracle/journal/controller logic behind the
physical mod boundary, with injected existing worktree/process/persistence
capabilities. Retain compatibility exports for known legacy callers until tests
prove removal is safe. Existing ownership.json explicitly assigns the legacy
Goal journal to mod-goal; package directories alone have not migrated this owner.

Preserve the already verified retained-worktree, writer-fence, publication,
authority and PR-idempotency repairs. A wholesale replacement that discards them
is not acceptable. First identify the narrow reusable verification owner, then
converge execution policy rather than maintaining parallel implementations.

## Existing executable oracles to retain

- tests/unit/goal-verify-oracle.test.ts
- tests/unit/goal-oracle-jit.test.ts
- tests/unit/goal-mutation.test.ts and goal-mutation-gate.test.ts
- tests/unit/goal-breaker-window.test.ts and goal-policy.test.ts
- tests/unit/goal-journal.test.ts, goal-diff.test.ts, goal-supervisor.test.ts
- physical mod-goal implementation tests, including real local Git effects

## Additional source issue to verify, not yet fixed

Update on ec688198f: the frozen-evidence overwrite was fixed in cd6cfdabd.
controller.ts now hashes before any snapshot write and snapshots only a new
oracle. goal-oracle-jit.test.ts covers changed gate/file preservation. The
following paragraph records the earlier finding, not a current open defect.

Legacy snapshotOracle writes gate/hash/copies before runGoalController compares
the new hash against persisted state.oracleHash. A rejected resume may overwrite
the old snapshot. Reproduce in an isolated fixture before changing it. Do not
copy that ordering into the physical owner.

Current full PR gate must finish before editing the tested source. This note
does not authorize skipping its commit or the original final release gates.

## Dependency trace, 2026-10-17 continuation

Verified: the operator-approved Conquer to mod-brainstorm and legacy Forge to
mod-nero edges already exist in their package manifests. No duplicate edge or
install was added for the repeated approval.

Verified: legacy Forge exports Goal types, journal, oracle and policy through
packages/forge/src/index.ts:78-96. Searching packages/core/src for GoalSpec,
JournalState, witnessTest, snapshotOracle and goal/{types,oracle,policy,journal}
found no match. A Core to mod-goal dependency is not indicated by this trace.

Legacy Forge to existing mod-goal@1.0.0 was approved by Raphael and is now
declared in the pending policy-ownership increment, including lockfile and
TypeScript project reference. No external version or installation was added.
Moving Goal-specific policy into generic shared support to avoid that edge
would obscure ownership and is not the proposed approach.

The pure policy currently imports the Mutant type through legacy mutation.ts.
Trace its actual owner before moving it. Oracle and journal also use Core home,
path and worktree effects; use injected existing capabilities rather than adding
a physical-mod import of Core. This note does not claim those seams are migrated.

Verified mutation seam: Core's tools/mutant-generator.ts owns the legacy Mutant
shape and semantic classification, while support-worktree/mutation-runner.ts
exposes MutationCandidate with required file/origin fields. These are not the
same contract. Goal policy's mutationGateDecision reads only class and counts;
its boundary can accept that minimal structural view without copying either
generator or importing Core. Preserve full legacy Mutant exports at their
existing boundary until their own ownership migration is verified.

## Verified progress after this inventory

- a2fc4ebe8 retains ordinary Review seat costs and malformed adjudicator costs.
  The full gate passed 10,076 tests with six skips. A built, file-backed Goal
  run counted builder and both usable/failed review seats once, stopped the
  next task at the budget, and resumed without charging old calls again.
  This closes the ordinary-review accounting finding above, not all future
  pre-pass/red-team accounting or controller parity.
- Pending policy increment moves the five journal types and ten unchanged
  policy bodies to mod-goal. Legacy exports reference that owner. Its focused
  run passed 166 tests; the subsequent export/type compatibility run passed
  63 tests. Codex found no blocking defect; its two coverage suggestions are
  included. Full gate goal-policy-owner-full is running. Not accepted yet.
- Journal persistence, oracle effects and controller convergence remain open.
  Journal uses Core home resolution and paths; oracle additionally uses
  process/worktree effects. Inject those existing effects at the compatibility
  boundary rather than introduce a physical mod-to-Core dependency.

## Controller convergence hazards verified in source

- Legacy controller uses detached per-task worktrees and compare-and-swap
  branch advancement. Physical runGoal uses one retained named worktree, plus
  writer fencing and durable publication records. Copying either controller
  over the other would discard required behavior.
- Removing the physical loop's break after an exhausted task is not a safe
  park/continue fix: failed edits remain in the shared retained worktree, and
  a later task's `git add -A` could include them. Independent-task continuation
  needs explicit per-task isolation while preserving retained failed work.
- Legacy controller still reaches Core for process/worktree/config/attribution
  effects and Forge's result-envelope facade. Extract those through existing
  capability owners, preserving contracts, before retiring compatibility.
- Physical runGoal declares plural engines but selects singular input.engine;
  legacy CLI composes Forge competition. Goal's frozen dependency set currently
  does not include mod-forge. Trace an existing public invocation route or obtain
  the required internal-edge approval; do not copy Forge into Goal.

These are existing acceptance requirements and source-backed transition risks,
not additional release requirements. Journal move a38b9db5a is fully qualified;
oracle ownership is currently under full qualification. Neither closes the
controller differences listed at the top of this document.

## Current mutation prerequisites and next bounded convergence

Verified at c7bc8ba49: the canonical generator has one shared owner. Core
exports remain compatible. The physical runner no longer produces i-+ from
i++; canonical return and array operators are available again. Full gate:
10,127 tests, six skips, 85 installed checks; live strong/weak tests discriminate.
The admission fix at 69a792d08 rejects incomplete mutation evidence.

Containment was separately reproduced: a tracked symlink lets physical
assessment temporarily mutate a file outside its arena. Current uncommitted
fix moves Core's existing Node-only path primitive into support-worktree and
reuses it. Initial negative controls fail for file/parent links. Focused tests
and independent Codex review pass; full gate mutation-containment-full is live.
Configured test commands remain trusted, not sandboxed. Do not overstate this.

Remaining runner consolidation needs the separately requested existing edge
support-worktree -> support-engine-runtime. No answer yet. The repeated
Forge -> mod-goal approval is not that approval. Core's runMutants already
implements per-command deadline caps, build/typecheck-before-each-test, honest
invalid/budget/abort outcomes, and preserved partial results. Reuse it after
approval rather than copying that machinery or hiding a transitive import.

Independent next Goal increment can use existing dependencies:

- Replace aggregate mutation grading in physical implementation.ts with its
  own mutationGateDecision and foldMutationVerdicts policies, per file.
- Preserve current incomplete-evidence rejection. Do not treat missing or
  malformed file identities as successful per-file coverage.
- Send flagged survivor evidence to the existing mod-review implementation.
  Current runReview has no evidence input: its mutate option runs AFTER the
  reviewer, so that option cannot fulfill the legacy pre-review evidence path.
  Prefer an explicit typed optional composition argument; no new CLI flags,
  catalog, reviewer implementation, or dependency needed.
- Match legacy review/park/land semantics, not physical aggregate behavior.
  Example: killed high-signal mutants in A must not mask equiv-prone survivors
  in B. Equiv-prone ratio fallback routes to review, not automatic retry.
- Keep survivor evidence fresh on every attempt. Persist what reviewers saw;
  include evidence in adjudication data, not only ephemeral prompts.
- Tests must distinguish per-file from aggregate grading, default/clamped
  thresholds, review evidence presence/absence, and no stale evidence on retry.
  Existing healthy reviewer costs, permissions and execution fences must hold.

This closes one known parity dimension only. Witness verification, competition,
red-team, per-task isolation/parking, journal and controller convergence remain
required. No final acceptance receipt is justified by these component results.

## Approved runner prerequisite and witness boundary

Raphael approved support-worktree -> support-engine-runtime@1.0.0 while the
per-file grading gate was running. Apply after that frozen gate completes.
Metadata owner: scripts/spec/generate-modular-support-package-metadata.mjs
has worktree dependencies ['verification']; extend that generator, not only
package.json. Package-map packages/dependencyEdges must agree; regenerate
first-party-package-graph.ts with the existing generator. Update the workspace
lock entry without new versions/downloads. Run the authorized OSV scan once.

Next runner move can preserve the Core implementation byte-for-byte apart from
imports, with Core reexports. Shared paths and canonical generator now exist.
Do not copy its deadline, abort, build/typecheck and classification machinery.
Before replacing the assessment loop, resolve baseline ordering: the current
assessment runs baseline before semantic engine dispatch, while runMutants
currently accepts an already-generated array. Blindly moving generation first
would spend provider calls on a known-red baseline. Avoid duplicate baselines
or silently changing that behavior; extend the existing runner only as needed.

Witness source trace: physical witnessCmd is declared but unread. Existing
mod-goal/oracle.ts already owns witnessTest and witnessVerifyCommand, but their
effects require detached worktree creation/removal. Core blocks/git.ts owns
those effects, including active-worktree exit cleanup, dependency/artifact
overlays, and GitError/WorktreeError identity. Do not replace these with an
ad-hoc git subprocess implementation. createGoalHostServices currently receives
only persistent-session operations; the sole production composition is
packages/cli/src/first-party-services.ts:128. Existing tests construct that
host at packages/mod-goal/src/implementation.test.ts. Plan any effect expansion
with authority/fencing checks around each asynchronous command, retained task
base identity, and cancellation; do not weaken current worktree protection.

## Differential witness integration: pending review corrections

Current subject: 97a30e635 plus seven source/test files and three generated
release artifacts. Not accepted or committed. The existing oracle owner is
now composed through the Goal host, with cancellation and execution fences.
Changed/new tests and task verification commands run against the task base and
candidate; persisted events retain the command, base identity and outcomes.

Focused receipt `goal-differential-evidence`: 139 tests plus typecheck passed.
SHA-256: 9bbd528fa286b84f3672aa457d8d0aa203585320215d07831b5b4dfb2063bfcb.
Negative control `goal-differential-base-negative` failed when task base was
replaced with initial run base; the mutation was restored before full gates.
SHA-256: 9e0f1d5c1ded03450dc05e7780585b0457f4d968e6a888bfe50cd5b887274bf1.
Full gate `goal-differential-full` is running in terminal 92817. Keep source
frozen until it finishes. Compiled live fixture is prepared but not yet run.

Codex review `goal-differential` finished successfully in terminal 27652.
Packet SHA-256: 89a724029ab14474aae8cdef85ef6aafc5c3036c126139ebc09b7c9f5519753b.
Log SHA-256: 8d63ec09eb0c7b791cc69498ebc91a650b666d5188d379859528d79c57ad24dd.
Review hypotheses requiring executable reproduction before adjudication:

- With commit=false, the next task still uses unchanged HEAD rather than the
  accepted prior task's dirty state. Do not silently remove commit=false.
- A new test importing a new helper can fail on base for missing setup while
  passing on head without a behavioral assertion. The oracle currently treats
  every nonzero, non-timeout base result as evidence. This is inherited behavior,
  not proof that any failure means a discriminating test.
- Extend authority tests to rejection before spawning, and test modifications
  of an existing tracked test (current examples create new tests).

No new panel is needed after corrections: source-check findings and run local
regressions. Do not claim whole Goal parity or release acceptance from this gate.

### Completed gate and reproduced review findings

`goal-differential-full` passed in 566.928 seconds: 10,192 tests passed,
6 skipped; build, typecheck, lint, reexport/drift, roadmap, release,
supply-chain and npx gates passed. Provider launches: zero.
Log SHA-256: 48dd534e5380ad7e98e98a6f5f04310295e194f99df003e61f310c7470372da3.
Terminal 92817 is complete. Source is no longer frozen for that run.
This receipt predates the two additional regressions below; it does not certify
the current modified test set or resolve either review finding.

Three compiled real Git/process runs passed (`goal-differential-built-live`):
valid differential accepted, simple tautology rejected, already-green task
command rejected. Source remained unchanged and ephemeral witness worktrees
were removed. Log SHA-256:
5b7f3a6a36c2ebe41553f7308aa0c7f90b51adc154aac6c54b7330545f76d1bd.

Both review findings are now confirmed, not opinions:

- `goal-differential-uncommitted-red`: two tasks with commit=false returned
  success although task two's command already passed after task one.
  Real Git/process fixture, source unchanged, no provider launches.
  Log SHA-256: dfb8188d0dc7699d6b6f49f89ae148762b545e583f70b89763973661024fa186.
- `goal-differential-helper-red`: a tautological test importing newly created
  helper.mjs returned witnessed=true and Goal exitCode=0. Base could not load
  that helper. Real Git/process fixture, source unchanged, no provider launches.
  Log SHA-256: c7dae25e3981097dda1965f747704ebc436eedddfa38869ac5a122efc93f8b7e.
- Added both regressions to packages/mod-goal/src/implementation.test.ts.
  `goal-differential-review-regressions-red` fails for both defects; the
  commit=true control passes. Log SHA-256:
  c2c031713b01b3c8e149e8fa0ac2f4a56d30fe28cbbf7544395f0d4bf221d483.
  Terminal 51620 is complete. No verification or reviewer process remains live.

Next correction must preserve commit=false and distinguish accepted task-start
state from HEAD. It must not snapshot dirty failed attempts as a fresh valid
baseline on retry/resume. Existing support-worktree readWorktreePatch and
applyPatchToTree can capture/apply binary and untracked contents; inspect their
index and containment effects before reuse. No existing write-tree/commit-tree
snapshot helper was found under packages. Do not add a duplicate Git owner or
silently make task commits mandatory. Changed-file detection also needs the
same task-start basis, not just the verify command.

The helper failure requires setup/load failure handling, not copying every
production file onto base (which would erase the behavioral difference).
Arbitrary shell exit codes alone cannot prove that an assertion ran. Preserve
that limitation explicitly; do not claim a generic regex proves correctness.
Review also requests pre-spawn authority loss and tracked-test modification
coverage. Current changes remain uncommitted; no push or global mutation.

### Review corrections under full qualification

The baseline correction stores `{sha, patch}` on each Task before its first
attempt. Retry/resume reuse that snapshot. Older attempted runs without a
snapshot cannot safely recover an uncommitted predecessor; those fail closed
with a retained-worktree recovery message. Current snapshots preserve
commit=false without adding task commits or moving the branch.

Existing support-worktree `readWorktreePatch` now accepts an optional base
patch. It reconstructs that baseline in a private temporary Git index, obtains
its tree and diffs the candidate against it. The private index is removed in
finally. The oracle replays the saved baseline through existing Apply ownership
before copying candidate tests. Events include basePatchHash; the exact patch
remains in the existing persisted task state. No new store or dependency.

The shared oracle now rejects known module-load failures, command launch exits
126/127, cancellation exits 130/143, explicit aborted/spawn-error results, and
timeouts as behavioral evidence. Both witness routes share that decision.
This rejects the reproduced ESM/CommonJS missing-helper cases. It does not
claim to classify every possible shell failure or prove an assertion ran.
The code comments now state this limitation instead of claiming proof.

Pre-spawn cancellation/generation/fence tests pass. Existing tracked-test
modifications exposed a deletion-only classification gap: changed-line parsing
had omitted them. Selection now uses changed paths whose files still exist,
with shared realpath containment; fully deleted tests still do not qualify.
New and tracked ASCII/Unicode tests, legitimate and tautological, are covered.

`goal-differential-final-boundaries`: 163 tests plus typecheck passed in41.433s.
Log SHA-256: 41d9678b91bbbab0bd066831edac752fea852341e374448cb63814b5e0180118.
Saved-baseline tests also replay binary/deleted/untracked Unicode files, check
branch/index preservation, and reject invalid baseline patch input. Earlier
`goal-task-baseline-matrix` failure found --allow-empty accepting garbage; that
flag was removed from the private-index reconstruction, and the test passes.

Source frozen for `goal-differential-reviewed-full`, terminal22359. No commit
yet. After it finishes, rerun the three compiled live controls and the two
previously failing live reproductions; those are stored in functions state as
goalDifferentialBuiltLive, goalUncommittedBaseReproduction and
goalMissingHelperReproduction. Both red reproductions assert the correct
behavior, so they should now pass unchanged. Preserve their old red receipts.

### Next convergence seam, source inspection only

CLI legacy Goal uses Forge competition for implementation AND oracle red-team.
Physical Goal's plural engines remains declared but unused. `runForgeCompetition`
already owns the physical execution and returns winningPatch plus candidates;
reuse it, do not implement another competition loop. It requires Forge host
services; direct package invocation alone is not the whole integration.
Goal currently has no mod-forge package/manifest dependency. Any added internal
dependency still needs the operator's grant; do not silently bypass ownership
through a parallel host implementation.

Core `stashSnapshot` is NOT a suitable replacement for the task-baseline fix:
its explicit contract excludes untracked files and falls back to HEAD on errors
(packages/core/src/blocks/git.ts:351). Forge uses that effect today. Integration
must therefore verify accepted uncommitted/new files remain visible to competing
candidates, not blindly route commit=false through this lossy snapshot.

Existing mod-goal/oracle-probe.ts owns the bounded red-team policy, journal and
cleanup. It expects JournalState, unlike the physical controller's current
Task/GoalState. Reconcile that ownership deliberately; do not add a second
red-team policy or label current preflight as a real red-team probe.

### Codex review adjudication

F1 (commit=false baseline): confirmed by compiled reproduction; corrected with
persisted first-attempt patch identity, shared snapshot diffing and replay.
Controls include genuine task2 work, repeated/failed attempts, resume, unchanged
branch and no task commits. Final full/live evidence is still pending.

F2 (missing helper certifies tautology): confirmed by compiled reproduction.
Known ESM/CommonJS loader errors now return baseInvalidReason=module-load and
cannot produce witnessed=true. Supplying the helper explicitly makes both sides
pass and still fails the differential requirement. Known command-launch and
cancellation results also cannot count as evidence. This is not a universal
failure classifier; self-contained operator verification, mutation checks and
review remain required, and true oracle red-team is still pending integration.

Q1 (caller-supplied assertOwned callback): qualification, not a reproduced
security boundary escape. Production runGoal supplies the acquired lease's
assertion plus generation check; host composition is bundled Goal only.
Arbitrary in-process trusted code can call these public helpers directly. No
claim of sandboxing or protection against malicious fully trusted code is made.
Both pre- and post-spawn loss tests cover the actual production call path.

Q2 (coverage): addressed with pre-spawn generation/fence/cancellation cases and
new/tracked ASCII/Unicode tests. The tracked deletion-only case uncovered and
corrected the source classification defect, rather than weakening assertions.

Accepted local increment:740d724a7. Final full gate passed10,216 tests/6 skips
and all existing release/installed gates. Full log SHA256:
8f1c40b6e70a5096fd2a2c4409eea189d51f40ad2f45e4ac7f682ffdee2780b1.
Five built real-Git/process probes passed, including both previously failing
review reproductions unchanged. Live log SHA256:
5b659add0638c90b0ed5cfba1ac2fee2f35e524f8524b398aa75886c06444962.
No provider launches, global/personal state changes or push. This closes
differential witnessing integration, not competition, real red-team, parking,
full journal ownership, frozen-oracle identity or overall release acceptance.

Next increment has executable red evidence on740d724a7: two added tests in
implementation.test.ts (`records each gate attempt...`, `parks exhausted work...`).
goal-attempt-parking-red fails with missing attemptLog and statuses
failed/queued/queued instead of parked/done/queued. Source tracing agrees:
implementation.ts breaks after any exhausted task; maxParkStreak is unread.
The existing journal recordAttempt and policy taskParkDecision/globalBreaker
are the owners to reuse. Preserve physical pre-dispatch crash accounting and
failed-work retention; merely continuing the loop would contaminate later work.
Initial red receipt SHA256:
51cd880a2d4b93f1631159061559217a907e997a86b23f7bf46bad90000ed993.

### Attempt recording and isolation work in progress

Subject: 740d724a7 plus five uncommitted Goal source/test files. Not accepted
or committed; the independent-task parking test remains red.

The existing journal recordAttempt now accepts an already-counted attempt.
The physical controller counts before dispatch for crash safety, then records
the outcome without incrementing twice. Failure records carry actual gate
diagnostics and the existing normalized gate signature. Interrupted runs
record an error; resume fills a missing outcome once, without duplicating an
outcome already saved. Legacy three-argument callers keep their counting.

An additional reachable branch missed recording: flagged mutation evidence
without an available reviewer. Added an assertion to its existing test,
observed undefined attemptLog, then wired the same concludeAttempt path with
review-block. Red log SHA256:
c0308676591c6978a0c28c21ded640d4aad3befa72b8c7080bd57ae7f8836acb.
Build/typecheck and focused checks passed in
goal-attempt-history-review-boundary (5.755s). Additional cancellation/resume
controls cover both saved and missing outcomes and repeated resume. Five
selected checks passed in goal-attempt-history-crash-resume (2.143s), SHA256:
efc2582a72832533e02921d08844c99ba2c76c9d9ea76aa20e1284b6f4752f83.
All these runs used provider blockers and recorded zero provider launches.

Parking is not solved by this change. Its regression now requires retaining
the failed task's untracked file AND an ignored generated marker. The next
independent task must run at a different path, see neither, and commit only
its own work. The failed path must remain readable afterward. Red receipt:
goal-parking-retention-isolation-red, SHA256
ecb3337bc0b70c10cc2331896dbd25f431017231d83ea14fd904f193bf18dd64.

Implementation direction: retained per-task candidates with explicit accepted
Goal state, using existing session-worktree and patch owners. Do not reverse
only a Git patch in the shared worktree: ignored artifacts survive that.
Do not rename/detach the existing retained worktree without migrating its
manifest: openWorktree verifies path, repository, symbolic branch and ancestry
before rehydration. Do not use nested task refs below an existing Goal ref
(Git ref file/directory collision). Preserve old-run failed-work resume;
new candidate creation and accepted-patch adoption need durable recovery
boundaries, including commit=false and interruption during adoption. These
are unresolved implementation details, not waived requirements.

Whole affected test files (not a name filter): typecheck passed, 170 tests
passed and the one parking regression failed in
goal-attempt-history-complete-paths (34.065s). Log SHA256:
1549c20d009ae94e41aa12502ac103d2f838ae9f502090ecebace47b9a7b2611.
This run covers implementation, journal and policy. No full repository gate,
independent review or acceptance commit has been made for this increment.

### Task isolation implementation, still under qualification

Worktree remains /Users/ra/dev/agon-audit-qualification on 740d724a7.
Backup branch: backup/goal-task-isolation-740d724a7. Original uncommitted
attempt-history diff preserved outside Git as
goal-attempt-history-before-isolation.patch in this evidence directory.

Implemented, not committed:
- Each new task gets a retained session-worktree candidate. Goal's main
  worktree contains accepted work only. Failed edits and ignored artifacts
  stay in task.worktree, not result.worktree. Exhaustion becomes parked;
  independent tasks continue and dependent children remain queued.
- The host prepares a candidate at a captured commit plus baseline patch.
  Initialization is idempotent and refuses changed retained content.
- A task acceptance records base, incremental patch, resulting patch hash
  and optional candidate commit before adoption. Replay validates exact
  candidate and target identities and content. Uncommitted acceptance uses
  the existing Apply owner. Committed acceptance uses protected fast-forward.
- A dirty accepted baseline can be reversed for fast-forward because the
  persisted acceptance and candidate commit retain it. Failed fast-forward
  restores the baseline when the target still matches the prepared state.
  Git's no-overwrite-ignore protects unrelated ignored files.
- Interrupted acceptance replays without another builder and resumes the
  existing publication path. Attempt history records completion once.
- The existing taskParkDecision and globalBreaker now govern oscillation and
  maxParkStreak. No second policy implementation was introduced.
- A parked candidate whose accepted base advanced is retained in
  previousWorktrees. Existing private-index snapshot machinery composes its
  task delta onto the new accepted baseline, then a new candidate resumes.
  composeWorktreePatch uses the same private-index owner as readWorktreePatch.
  Shared Apply gained an optional reverse flag, delegated to native Git.
- Existing old runs without task candidates keep their retained-worktree
  retry path. Full legacy controller retirement is still open.

Important test contract updates: failed files are asserted at task.worktree;
result.worktree must exclude them. Verification-worktree cleanup now asserts
three named retained worktrees and no detached worktree instead of assuming
one Goal worktree plus source. No assertions about file preservation,
publication, source safety or rejection were removed.

Evidence (all provider launches zero):
- goal-task-candidate-preparation-red: missing preparation method.
- goal-task-candidate-acceptance-red: missing acceptance method.
- goal-task-isolation-integration-typed: original parking regression passes.
- goal-task-isolation-retained-contracts: 174 tests passed, 57.613s.
- goal-task-acceptance-recovery-red: three failures exposed ignored-file
  overwrite and duplicate attempt outcome on acceptance interruption.
- goal-task-acceptance-recovery-fixed: focused recovery/protection passes.
- goal-task-parking-policy-red/fixed: maxParkStreak and oscillation controls.
- goal-task-acceptance-publication-red/fixed: acceptance replay must publish
  to the fixture's local bare remote without another engine dispatch.
- goal-task-advanced-resume-red/fixed: both committed and uncommitted
  accepted-state advancement; original candidate bytes remain readable.
- goal-task-dirty-base-commit-red/fixed: commit after accepted dirty baseline.
  Snapshot controls cover binary data, Unicode names, deletions and conflicts.
- goal-task-isolation-focused-all: 185 tests pass plus typecheck/diff check,
  64.153s, log SHA256
  b9fed76bf0b7da2adae832c57e285855e5195fc6aaf28b1925357f5cda2dc84f.

Full gate goal-task-isolation-full finished with exit 1 after 10,233 passing
tests and six skips. The first-party generator lacked the new GoalTaskAcceptance
export, so its drift gate failed. Generator and exported surface now agree;
spec:modular-first-party:check passes. Later release gates did not run in that
failed invocation. Log SHA256:
9438cdc24799a09183f2580bb4b1d1a9cc1ed11eb36ccb851ce1031406701685.

Codex-only isolated Agon review goal-task-isolation completed (terminal
54097, exit 0). Packet SHA256:
68552230de9bf55d5a9bebd01597a58d6bcc67e96f6777c677bf5560cd832410.
Review log SHA256:
a35b7f88c4d8328fc4299beec3936eda08473dc940b4703df36916517524188a.
Full log: goal-task-isolation-codex-review.log in this directory. The helper
used its existing temporary auth-copy cleanup. No Kimi or browser login.

Review findings (original hypotheses, now reproduced below):
1. Crash after durable task-done but before publishTask leaves no publication
   record. Resume selects only queued tasks, so requested push can disappear.
2. Budget/time/breaker checks occur before pending acceptance replay. A
   completed acceptance can remain queued after limits are reached.
3. A carried-patch conflict during stale-base refresh throws out of the whole
   Goal instead of parking that task and allowing independent queued work.
4. Limits are checked only between tasks, not between attempts. The new
   parking reset makes no-progress ineffective for distinct retry failures.
5. Git commit can complete before acceptance is durably prepared. At the
   same attempt cap, resume parks that completed commit instead of recovering.
All five findings reproduced. Corrections and discriminating evidence:

1. Publication intent is prepared in the same saved state as task-done.
   Resume executes only a prepared intent, bound to its commit, remote and
   destination hash. Pending effects still become unknown, never blind retries.
   goal-task-durable-publication-red failed (succeeded 0 instead of 1).
   goal-task-durable-publication-fixed passed publication, push and acceptance
   tests plus typecheck (17.421s).
2. Pending acceptance and prepared commits precede new-work limits. Recovery
   does not require an implementation engine. Budget/time controls remain in
   force for new attempts. goal-task-acceptance-limits-red failed four cases;
   goal-task-acceptance-limits-fixed passed. Missing engines reproduced twice
   in goal-task-recovery-engine-independence-red; fixed invocation passed.
3. Patch composition failure parks that task with a retained-path diagnostic;
   later independent work runs. Identity checks remain outside that catch.
   goal-task-refresh-conflict-red failed at git apply. The fixed run passed
   conflict, advanced-base resume and invalid-identity tests (5.361s).
4. One stopAtLimit check is shared between task and attempt boundaries.
   Stopped retry tasks stay queued and retain their candidate and history.
   goal-task-retry-limits-red made five calls instead of one and failed the
   no-progress stop. Fixed run passed both controls, existing task-boundary
   budget tests, typecheck and generator drift checks (3.481s).
5. Before Git commit, persist its expected parent, tree, message and verified
   acceptance snapshot. Resume uses the existing Git action if the commit has
   not run, or verifies the exact parent/tree/message/clean state before
   accepting an already-created commit. Changed contents or message fail closed.
   goal-task-commit-intent-red stranded a committed candidate at maxAttempts=1.
   goal-task-commit-intent-fixed passed. Expanded before/after/tampered tests
   passed in goal-task-recovery-engine-independence-fixed (10.540s).

Each named run has a durable .log and .receipt.json beside this report,
including SHA-256 and exit code. All report zero provider launches. No
additional Agon panel was run after corrections. These focused checks do not
accept the whole release. Final qualification for this increment:
- goal-task-review-fixes-focused: 199 tests plus typecheck/diff checks passed,
  211.944s including package rebuild; log SHA256
  643d7fe8b819b37283fc1471859cbd38984ffca10c4b8c445c94192440a864e5.
- goal-task-review-fixes-full: build, typecheck, 10,247 tests (six skipped),
  lint, re-export guard, generated/surface/roadmap checks, release and
  supply-chain self-tests, npx checks and diff check passed, 575.051s.
  Log SHA256:
  88e6494280be4f044bb3497038e71e075c77719767b0cd9b624ed3f7ecc7d612.
- goal-task-isolation-built-live: two compiled-package real-Git/file-state
  workflow runs passed (commit=true/false), 2.486s; log SHA256
  b4a4e693e8c695f0122d0436960d767a53f98df76eec2f5b2447d29e6f552b0e.
  Both prove parking, independent continuation, retained failed/ignored
  artifacts, newer-base resume and unchanged source checkout. Model dispatch
  is a deterministic fixture, not a live-provider quality claim.
All three runs report zero provider launches. npm provenance remains external.
No global/personal changes or pushes. Local commit follows these results;
whole-release acceptance and remaining controller gaps stay open.

Executed: functions store goalTaskIsolationBuiltLive. It derives
from the existing built-runtime, file-backed-state fixture. Run after the
final corrected gate, with GOAL_COMMIT=true and false. It verified parking,
independent continuation, newer-base resume, persisted state and unchanged
source through built packages and real Git, with deterministic engine shims.

## Frozen-oracle snapshot owner, qualified 2026-10-17

Parent commit: 70f62e77013888f35d2280892524881a7de514bd. Backup branch:
backup/goal-oracle-70f62e770. No production runtime cutover or new dependency.
Current files: mod-goal/src/oracle.ts, forge/src/goal/controller.ts,
tests/unit/goal-verify-oracle.test.ts, tests/unit/goal-oracle-jit.test.ts.

Source-confirmed gaps: snapshotOracle rewrote existing evidence and skipped
missing/unreadable files; oracleTampered treated deletion of an empty file
as unchanged. Six initial negative cases failed in
goal-oracle-snapshot-integrity-red (a59c9d1e054d0484f65665620db77e8e5a0431c17e5986823ec62e1336ff3989).

Implementation stays in the existing physical oracle owner. It captures regular
files through opened, nonblocking descriptors, then writes a temporary sibling
directory and renames it into place. Existing snapshots are verified, never
rewritten. files.json records the original copy mapping; historical snapshots
without it still verify through their original paths. Concurrent publication
verifies the winner. Ordinary failure removes staging; combined operation and
cleanup failures retain both errors. Exact byte comparison verifies integrity;
the historical digest remains byte-for-byte compatible, including its original
UTF-8 decoding. That digest is not sufficient security evidence on its own.

Codex-only Agon review completed once:
- packet SHA256 eb22ad08b88c4e56db2e74ef196321b442f9304ce3668a3040bf7eaef192c784
- log SHA256 a00d2380db345ea0936df4bda8ea1e127f3b38579506a417cb06034ecdb64ed1
- receipt goal-oracle-snapshot-codex-review.receipt.json

Adjudication:
1. Reordered inputs: reproduced, fixed with stored copy mapping. Original
   files are unchanged on repeat calls.
2. Input-open race: descriptor capture uses O_NONBLOCK then fstat/read of
   that descriptor, with close in finally. A controlled FIFO substitution
   test rejects non-regular input without blocking or publishing evidence.
3. Concurrent same-input publication: reproduced, fixed by verifying the
   winning snapshot after rename conflict. Differing winners still reject.
4. Inherited ambiguous newline framing: reproduced with two byte-different
   input pairs whose legacy digests match. Snapshot/tamper checks compare
   saved bytes. The legacy controller now calls that same oracle owner on
   resume, so it cannot rely on the colliding hash alone. Its former bypass
   reproduced in goal-oracle-controller-collision-red before correction.
5. Cleanup masking: reproduced and fixed; both original and cleanup errors
   survive in AggregateError. Write/rename fault tests prove staging cleanup.
6. Compatibility: independent legacy digest fixtures cover valid and invalid
   UTF-8. Historical snapshots without files.json remain readable. Corrected
   the test comment that overstated differential evidence as proof.

Evidence: goal-oracle-snapshot-review-red failed six cases; fixed passes.
goal-oracle-cleanup-diagnostics-red failed both routes; fixed passes.
goal-oracle-final-focused passed 97 tests, typecheck and diff check, 16.556s:
870efedfd3a2dedf34c99b3e39ad12fbbfead0010cb80d441faade1063c46b5f.
All tests report zero provider launches. The earlier intermediate
goal-oracle-snapshot-integrity-fixed run is superseded by final focused
evidence; final source was rebuilt before these assertions.

Final qualification:
- goal-oracle-snapshot-full passed 587.736s: build, typecheck, 10,278 tests
  (six skipped), lint, re-export/generated/surface/roadmap gates, release and
  supply-chain self-tests, npx and diff checks. Log SHA256:
  c608846a0252213dc95f37156df7a02269688d67cfe64eb00a60b555e175c646.
- goal-oracle-snapshot-built-live passed 0.441s. Four real subprocesses
  exercised identical and conflicting snapshot publication through built
  packages. Mapping, framing-collision rejection, original-byte preservation
  and staging cleanup also passed. Log SHA256:
  7138de3685eca2318d019e442821abcdcc28fdd1e0c181878fd7249afb1b7f8b.
Both provider-launch lists are empty. Review auth-copy absence checked.
Committed locally as 1a14e2ebe00b3f7d346bdcbedd362c319319f503; worktree clean.
No live process remains. Continue physical Goal frozen-oracle integration.
No new Agon panel after corrections.

Remaining integration fact: physical runGoal prevents a changed branch/gate
on resume, but does not yet call snapshotOracle or persist its frozen evidence.
Legacy runGoalController still owns that step. CLI currently passes
oracleFiles: [] to legacy controller; do not invent a new UI requirement while
closing this ownership seam. Goal -> mod-forge approval remains pending.

## Physical frozen-state integration WIP, 2026-10-17

Subject remains 1a14e2ebe; no new commit, push or global installation. Five
source/test files are dirty. Backup: backup/goal-frozen-integration-1a14e2ebe.
The support-worktree -> support-engine-runtime grant was already implemented
in 8398a28aa; it is not a Goal -> mod-forge grant.

Added optional verification-only snapshot mode to the existing oracle owner.
The host wraps capture with lease/generation/cancellation checks. Physical
runGoal persists FrozenOracle and checks it before baseline/task execution.
Historical states without the field capture the recorded gate once. Explicit
null/malformed records fail closed; missing recorded evidence is not recreated.
This freezes the gate STRING, not arbitrary files the command references.

Evidence under this directory (all test providerLaunches empty):
- goal-frozen-state-integration-red: six expected failures, missing persistence
  and recreation of missing evidence.
- goal-frozen-state-integration-first: seven focused cases pass.
- goal-frozen-state-integration-focused: 235 tests pass, 85.968s, log SHA256
  27c1f818c51da72f7dfaa19dcf45d992cf043766c28d5a11f4c5dc13f9a158d6.
- goal-frozen-state-types: typecheck/diff check pass BEFORE review fixes.

One isolated Codex Agon review is complete. Do not launch another panel after
local corrections. Packet SHA256
16b357f79653d4bfe975820181d684d651859b96aa3a587358405f82dea3bf09;
log SHA256 b575cd02b50c936df859f2cd6ca18cac6c08758fd1a9e3cc3fb1aad76003569a.
Files: goal-frozen-state-review-input.txt and goal-frozen-state-codex-review.log.
Temporary review auth copy was checked absent after review.

Review findings and CURRENT dispositions:
1. Confirmed: state-write failure after capture was labeled deterministic
   corruption. Moved persistence outside validation catch. Remaining: snapshot
   operational failures (ensureHome/write/rename/cleanup) still need distinct
   classification from actual invalid evidence. Use the existing oracle owner,
   not string guessing or a parallel validator.
2. Confirmed from source, NOT FIXED: save() checks lease but not generation;
   outer interruption catch can persist after generation revocation. Add red
   tests for revocation during post-capture assertion and during async lease
   assertion. Distinguish allowed cancellation bookkeeping from revoked
   generation writes. Existing PR fallback tests intentionally allow a cancelled
   optional draft to record its outcome; inspect those before choosing policy.
3. Confirmed: pre-run Think preceded admission. Moved existing Think block
   after snapshot persistence and into retained worktree, with execution checks
   before and after dispatch. Rebuild tasks only after successful refinement.
   Missing-host, denied-lease, existing-id tests now prove zero dispatch.
   Still add successful Think and generation-loss-during-Think controls; do not
   pretend its prompt text is an enforced no-tools capability restriction.
4. Source-confirmed, NOT FIXED: oracle-invalid persistence/release failures can
   mask primary deterministic cause. Preserve both primary and cleanup errors.
   Changed resume gate message is also not classified deterministic. Add
   negative controls including supervisor one-child/no-backoff behavior.
5. Strengthened tests: frozen-state resume now starts from dryRun with genuinely
   queued work, so unchanged evidence permits dispatch while changed evidence
   blocks it. Historical migration now resumes twice and proves removed evidence
   is not recreated. Still cover prepared acceptance/publication effects,
   first-dispatch persisted evidence, and matching/conflicting orphan snapshots.

goal-frozen-review-boundaries-red reproduced four failures (state-write and
three Think admission cases). goal-frozen-review-boundaries-first-fixed passed
all 11 selected cases, 3.399s, log SHA256
90bfd1d21c3b3f5b07d4105c69146de4aa83cd2e3b93474c006a9c13d2c300a4.
No terminal remains running. Latest fixes have NOT had full gates or built
live verification. Continue remaining findings, then focused/full/build-live,
refresh release artifacts, record adjudication and commit verified increment.
The whole project is NOT accepted; original six-stage goal remains active.

### Frozen-state review corrections, 2026-10-17 continuation

Source-reproduced review findings are now corrected, awaiting full gates/live:
- F1: only GoalOracleInvalidError is treated as deterministic invalid evidence.
  Snapshot persistence and operational filesystem errors propagate as failures,
  retaining recovery evidence. Existing missing/malformed evidence is typed in
  the oracle owner; no second validator was added. Verification-only reads do
  not call ensureHome. A transient save can be resumed using the original bytes.
- F2: host assertStateCurrent uses the captured generation authority without
  aborting cancellation bookkeeping. save checks it after each async lease
  assertion; interruption handling refuses stale-generation persistence too.
  Older host implementations fall back to assertCurrent. Three tests revoke
  authority during capture, pending save, and Think. A retired optional PR draft
  now rejects rather than persisting through a stale generation. This changes
  the existing draft-retired fixture because its former success was the bug;
  cancellation-only bookkeeping still passes.
- F3: successful Think now sees persisted evidence, runs in retained worktree,
  requests the existing textOnly dispatch control, and cannot advance after
  revocation. CLI forwards that flag to the adapter. This is not a universal
  provider sandbox: companion textOnlyArgs are provider-dependent and the CLI
  fallback still uses the engine's configured execution mode. No new sandbox
  or provider support was invented in this increment.
- F4: primary oracle failure survives rejection-save and lease-release errors
  in AggregateError. Its stable marker remains in the outer message so the
  existing supervisor stops once, without backoff. Explicit changed resume
  gate/branch messages are classified deterministic too. Both cleanup failures
  remain observable. Fixed a test-only lease wrapper to bind class methods;
  the first red run's two cleanup cases had a fixture error, superseded by the
  separate goal-frozen-rejection-errors-red receipt proving the actual defects.
- F5: queued-work controls, prepared acceptance before/after commit controls,
  remote-ref checks, historical second resume, matching/conflicting orphan
  snapshots, first Think/builder persisted evidence, and witness-only old hosts
  now discriminate ordering and recovery. No new standalone test harness.

Receipts (all providerLaunches empty):
- goal-frozen-authority-errors-red: six failures, with the noted fixture issue.
- goal-frozen-rejection-errors-red: two corrected-fixture failures, log SHA256
  5ce65f3f67c3eb128cf535e32f556a833d2e7533375d40a9857ec1e656481f33.
- goal-frozen-authority-errors-fixed: 14 pass, 3.778s, log SHA256
  c5b453a170b0cac1fbd40e2a763d3427b272cd5255a6e5724a9bfcfd6813fddd.
- goal-frozen-review-focused: Goal build, typecheck, 267 tests, diff check pass,
  90.753s, log SHA256
  45743ab019448378ac87f356a02df59b68726422c0a8455ea3d5095c76cb95a0.
- goal-frozen-final-controls: three extra host/supervisor cases pass, 1.189s,
  log SHA256 71f71c3473b9df07250b0f1e7c499e31aa077d780e3e0a86e46904724e667712.

Full gate goal-frozen-state-full is running at terminal 40412; source frozen.
Built-live probe is prepared in functions store goalFrozenStateBuiltLive:
six modes valid/tampered/missing/legacy/write-failure/generation, real Git and
file-backed state, built mod exports, no provider launches. Execute after full
gate, not concurrently. New Codex panel is not required after local corrections.

While waiting, read-only next-seam inspection reconfirmed shared mutation-runner
defaults to 25 and caps at 500, but legacy Goal tests every generated mutant.
Smallest candidate fix is an explicit exhaustive selection on the existing
runner, used only by Goal, preserving sampled default for standalone Mutate.
Do not change timeout/budget/failure accounting to manufacture a pass.
No source change for this next seam has been made during qualification.
An async approval request for Goal -> existing mod-forge@1.0.0 was sent during
this continuation; no answer yet, and no dependency edit was made.

### Frozen-state qualification complete

goal-frozen-state-full passed in 639.427s: build, typecheck, 10,308 tests
(six skipped), lint, re-export guard, generated/first-party/surface drift,
roadmap, release-set, supply-chain and npx gates. Log SHA256
cb7287f203d1c131a8cf72bfbd16a06f5b6dfdc66a955fdefd551415e15123f3.
All provider blockers recorded zero launches. npm provenance remains external.

goal-frozen-state-built-live passed in 2.861s, log SHA256
7799b4b32a02c67e8442366475924b7f5861e032958da4aa6c7ae68fb9012a85.
Six separate built-runtime processes used real Git worktrees and file-backed
state: valid resume, changed gate bytes, missing snapshot, historical migration,
transient record-write failure, and generation loss during Think. Invalid
evidence triggered zero engine calls; generation loss allowed no later write.
Engine calls in these fixtures were local injected stubs, not live providers.
The original repository HEAD and working tree remained unchanged in every run.
Full executable probe source is retained in the receipt's command array.

Both terminal handles are complete. No source changed during the full gate.
Release-set, SBOM and launcher channel were regenerated by the build and are
part of this increment. This establishes the frozen-state seam, not overall
Modular Agon acceptance. Remaining Goal competition/red-team, mutation selection,
legacy-controller convergence and final subject-bound qualification stay open.

Frozen-state increment committed as 572be2ed37bd3c5c8724889f8b709628021c2be6.
Worktree was clean after the commit. No push, installation or personal-state change.

## Exhaustive Goal mutation selection, WIP 2026-10-17

Backup: backup/goal-mutation-selection-572be2ed3. Four source/test files:
support-worktree/src/mutation-runner.ts, mod-goal/src/implementation.ts and its
existing test, mod-mutate/src/implementation.test.ts. No new dependency or helper.
Legacy controller generates every changed-line mutant; physical Goal inherited
the shared runner's default sample of 25 and hard numeric cap of 500. This is a
verified fidelity gap, not a new requirement to make tests stricter.

Existing maxMutants now accepts literal 'all'; Goal selects it. Numeric/omitted
selection and standalone Mutate CLI policy remain unchanged. Existing baseline,
execution budget, cancellation, per-file grading and cleanup owners stay intact.
Exhaustion of the budget still fails Goal; no unexecuted mutant becomes a kill.

goal-exhaustive-mutation-red reproduced three failures: two Goal forwarding
cases plus exhaustive selection. Numeric/default controls passed. Log SHA256
2f42d3ac797b78bc3a5c0580c65e45f6195e779b2c647f01e86bbfdc2f8ee9a4.
goal-exhaustive-mutation-focused passed build/typecheck, 215 tests and diff check
in 93.819s, log SHA256
e48ab2b67356d049b570a5cc166e65f86031f03e40c58a7b6398ddc303701b8a.

One isolated Codex review: no concrete production regression found. Packet SHA256
722e1e1aa4174b8258ea18b1caca610dfd662d79ccd83a516ec81416970043a9;
log SHA256 0eda9b8d91bb4fe26fd03963b0b22c47ed8ae56f48cbe87d74d20c7d859c2905.
Temporary auth copy absence checked. No further panel after these test changes.
Review gaps addressed:
- compare exact unique mutant identities; assert one intended line changed per
  execution, not just a count;
- ten survivors after index 500 must appear in outcomes/survivors/byFile;
- actual Git diff across two files selects 520 changed-line mutants and excludes
  mutable unchanged neighboring lines;
- cancellation in exhaustive execution retains full selected count, zero kills,
  notRun accounting, original source and worktree cleanup;
- existing Goal per-file grading/failed-assessment tests cover routing/rejection;
  unchanged runner tests cover baseline, invalid classification and timeouts.
Test location suggestion is not a production defect: public support API is tested
through an existing consumer package suite, with no private import or new harness.

goal-exhaustive-mutation-review-controls passed all 20 Mutate integration tests,
4.961s, log SHA256
626526a2ce7feadccb1c7f9f2e990b701d06df3ff438779a06b2b89dc1b9f0ee.
All test receipts have empty providerLaunches.

Full gate goal-exhaustive-mutation-full passed: 10,314 tests, 6 skipped;
build, types, lint, guards, generated projections, roadmap, release, supply-chain
and npx checks passed. Duration 573.938s. Log SHA256:
3cde839bc5bad446e0d0a9a39c3c83bab0cfba16083141b1ed73ae7d6b340174.
Built-live probe goal-exhaustive-mutation-built-live passed four cases in 4.829s:
real subprocess default (25), numeric cap (500), all (510), and exhaustive budget
failure. Caller source and worktree cleanup checked after every case.
Log SHA256: a0b941ea322303d9a0571802218462ac4f38a11220f83e70d03a8b12a202239a.
Both receipts record zero provider launches. This is component evidence, not
final clean-checkout release acceptance.

Source-confirmed inherited follow-up from review: runMutants promises never to
throw but generation/progress callbacks and filesystem writes can throw; outer
runMutationAssessment then loses prior outcome evidence in an empty failure
report. It fails closed, but can lose receipts. Reconcile that recovery contract
after this bounded selection increment; do not call overall acceptance complete.
Generation's synchronous CPU time is checked between files and after generation,
not preempted mid-file; do not claim a hard generation CPU deadline.
Goal -> mod-forge remains pending approval; no dependency change made.

### Next recovery check, read-only while terminal 68988 qualifies

Trace: support-worktree/src/mutant-runner.ts has an outer try/finally with no
catch. Generation/progress callbacks and writeFileSync can reject after one or
more recorded outcomes. mutation-runner.ts catches that rejection and returns
an empty outcomes array. Its own artifact-write/recordReceipt failures also
replace a completed report. These are source-grounded predictions; reproduce
before changing production code. This is evidence loss, not a demonstrated
false-green (assessment returns ok:false).

Use existing tests/owners. Candidate discriminating cases:
- generation callback failure: zero verdicts and named operational failure;
- progress callback failure after one observed verdict: preserve that verdict,
  generated count and remaining notRun, restore original source;
- write/placement failure after earlier verdict: no fabricated kill for the
  interrupted mutant, preserve earlier evidence;
- recordReceipt/artifact failure after full execution: return ok:false with
  original report instead of empty replacement;
- source restoration and sandbox cleanup still happen.
Consider existing baselineError operational-error channel before adding fields
or another error wrapper. Do not weaken timeouts or mark these failures passing.
### Mutation evidence recovery increment (after 0a03dd6d1)

Previous continuation made progress: committed exhaustive selection, full gate
and real-process probes. The next source prediction is now reproduced.
Five red cases: generation callback, progress after one verdict, placement after
one verdict, artifact write after completion, receipt write after completion.
Red receipt mutation-evidence-recovery-red: five failures, SHA256
d0f0b2fd02771d2da79bbebd720e4beb1bbf841e1fdcd99cba511af23ea208fc.

Small fix in existing shared owner: catch operational errors without erasing
recorded verdicts; use existing baselineError failure channel and calculate
notRun from actual outcomes. Assessment keeps its completed report if persistence
fails and still returns ok:false. No new package, dependency or error schema.
Best-effort disposable cleanup remains unchanged. No full-release claim.

Focused build/typecheck/runner/Mutate/Goal tests passed in 89.594s.
Receipt mutation-evidence-recovery-focused, log SHA256
7f24a556eb85badf4da846f3c352d0a81d72eff46cb23fe50c135df64929b051.
Both test receipts have zero provider launches.
Isolated Codex review mutation-evidence-recovery completed. Packet SHA256:
8832fb5ec9ff1fc495b4a414ce80f370c010effac78f32b1e4519d462656658f.
Review log SHA256:
5a4670e806dbf2df84088dd57940404e3ab519ffabd9d462398eb72d79681a8f.
Temporary auth copy removal checked. No second panel after local corrections.

Review adjudication:
- Confirmed: rejection after cancellation dropped the aborted flag. Red test
  mutation-evidence-cancel-red reproduced false instead of true; existing catch
  now reads the signal. Red log SHA256
  0cd9c9e39882ed6cd3aefb81570748ea20af0868b5cb83ec411a2a23d41cff30.
- Added exact survivor/invalid/final-outcome accounting, file-write failure
  (not just mkdir failure), and persisted JSON equality after receipt rejection.
- Added real Mutate command failure and Goal rejection of an otherwise complete
  all-killed report whose assessment is ok:false. Goal must not review or commit.
- Inherited immediate restoration failure does not record the interrupted
  mutant. This remains conservative notRun, not a fabricated kill.
- Arena cleanup hypothesis: actual forge-arena.ts catches Git/fs cleanup errors;
  its normal failure paths cannot override the returned report as hypothesized.
  Best-effort cleanup does not prove a damaged sandbox was restored.
- CLI run-finish failure and target discovery outside try are inherited, not
  acceptance of failed mutation evidence; no unrelated wrapper added here.

mutation-evidence-review-controls passed, log SHA256
9c884bb10c6c1550b15fe13601ad8677a4f29e72d54cc0f8235aed95ad118020.
First consumer control used files rather than the command's path input; fixed
the fixture against targetOf, not production behavior. Preserved failed receipt.
Corrected consumer controls passed, log SHA256
bb60148af7afb4b0347673855062fe13b1052d9cba6ab1acdb8a42d0e1052de4.
Built live: three real-process cases (progress/receipt/artifact failure), all
failed closed, preserved measured outcomes and verified caller bytes/worktree
cleanup. Log SHA256
1c56d7fe7cee5c7de905ea5f285622ea71552ae5b007ebd332e828f0c1411b76.
All local test/probe receipts record zero provider launches.
Full gate mutation-evidence-recovery-full started; source frozen until exit.
Next: inspect full receipt, commit verified explicit paths only, then continue
original remaining Goal ownership/execution requirements. Do not push.

### Dependency approval reconciliation, 2026-10-17

Raphael explicitly approved support-worktree -> support-engine-runtime@1.0.0.
The edge already exists in commit 8398a28aa and mutant-runner.ts uses its public
spawnWithTimeout export. No duplicate edit, download or installation performed.
Current HEAD is 53c30fc55; Goal review-default restoration remains uncommitted.
One isolated regression run passed: worktree-runtime-approval-confirmation,
86.817 seconds, providerLaunches empty, exit 0, diff check passed.
Log SHA256: 04899a3568a9c42ce5ee2698b2f365472b0f641ce3b24540d621d62b1467e1d7.
Scope: mutant-runner, mod-mutate implementation, mod-goal implementation tests.
The five review-context/authority controls also passed in
goal-review-defaults-context-controls. Temporary review auth copy is absent.
Legacy resolveId returns unknown nonempty IDs unchanged, not an empty fallback;
therefore the alleged unknown-judge fallback is not supported by that source.
This approval does not authorize the separate proposed Goal -> mod-forge edge.
Full-release acceptance remains open; these are component receipts only.

### Goal review defaults and roster preflight, current increment

Physical Goal previously ignored configured goalReviewEngines, selected at most
three reviewers, and excluded the builder. Legacy CLI selects explicit reviewers,
then configured reviewers, then all active nonlocal engines, with all-active
fallback when every engine is local. Restore that policy through a narrow
Goal host projection. Configuration remains with its existing owner; no new
settings store or dependency. Validate implementation roster inputs before Think
or implementation. This does not yet restore competing implementations: the
first selected implementation engine still runs. Competition remains open.

Review: goal-review-defaults-codex-review, packet SHA256
81caa61131d5b1f2e5d84c0b32b379211fb888e66ca69c39a9896d1c80a81b11,
log SHA256 a38726541281f20f55310427326b71b561b95e31fb838610214cc51b2d79910d.
Both actionable findings reproduced in five red cases, then fixed:
- Cross-repository cwd must select configuration and resolve engines in the
  same target repository. Task execution still uses its isolated worktree.
- Cancellation, generation revocation and lease loss must propagate rather
  than become ordinary roster errors. Reassert authority before translating
  a genuine selection error.
Red receipt: goal-review-defaults-review-red, log SHA256
52baa26bac1731111c3ebb8a6edc8dfca01355e21da96d3ba48b29d807bc511a.
Green receipt: goal-review-defaults-context-controls, log SHA256
cc25cb7c63944734ecce10e83f276acf4073ae51c42e22736f16fc2648d53c7a.
An intermediate cross-repository fixture rejected legitimate target worktrees;
fixed its oracle to compare Git common directories, retaining the explicit
initial target-cwd assertion. The failed receipt is retained.

Additional controls cover configured local reviewers, all-local fallback,
explicit override of an unavailable configured panel, unavailable judges and
explicit judge override. Publication replay now makes provider discovery and
resolution throw if called. Existing accepted publication still completes.
goal-review-precedence-final-controls passed six tests, typecheck and diff check;
log SHA256 3b7d32b402962b493ba4e6ee1f047eb66c63781b15585276c5e20578a7c8f71f.
Actual CLI decorator tests cover target-cwd config, owner-scoped decoy rejection,
local-engine classification and Forge/Cesar/undefined judge precedence.
goal-review-host-projection-controls passed with typecheck and diff check;
log SHA256 e92bc1f24f5ab970155b596ec835dc0e2ebb9f971b205ddc8c0affc6d7fce5fd.
All receipts above have no provider launches. No second review panel started.

Full gate goal-review-defaults-full is running; source frozen until exit.
Next: inspect full receipt, run built real-Git/state probe for configured,
explicit, all-local and unavailable reviewer cases, commit verified paths only.

Qualified and committed as 191593086e34b7fa1d6364fb8eab150472dd0441,
fix(modular): restore Goal review selection. Worktree clean; nothing pushed.
Full gate: goal-review-defaults-full passed in 633.476 seconds, 10,350 tests
passed, six skipped; build, typecheck, lint, re-export guard, generated drift,
first-party ownership, surface catalog, roadmap, release, supply-chain and
npx candidate gates passed. Installed candidate: 85 checks, cache-deletion
survival and idempotence passed. npm provenance remains externally blocked.
Full log SHA256: 380784dd14179ee660e993b872bbf97a916d385df1d1972a5a306480701d17b5.
Built probe: goal-review-defaults-built-live passed all four cases in 2.337s,
real Git worktrees, writer locks, persisted state, frozen gate and shell gate;
provider transport was a fixture, not live-provider evidence. Verified selected
reviewers, successful completion or zero-dispatch rejection, unchanged caller
HEAD and worktree, and cleanup. Log SHA256:
207bf37a6bcc3fe0ee1c75b1a2ba652bd662b5a44642c71ebda67a6d9013d1ab.
Both receipts record zero provider launches. Active installation untouched.

Next original requirement is implementation competition and oracle red-team.
Source recheck: legacy CLI goal.ts:464 forwards synthEngine, synthesize:always
and records dispatchLog costs; :529 selects a passing test-bearing candidate;
:664 runs adversarial oracle probes. Physical runGoal still calls runAgentTask.
runForgeCompetition omits synthesis inputs and full dispatchLog from its surface
contract. Reuse createForgeWorkflow through existing ForgeHostServices rather
than adding a second competition engine or widening an unrelated surface.
Goal -> mod-forge approval remains pending; do not treat support-worktree's
approved edge as permission for this separate package edge.

### Native release performance and sustained load, 191593086

goal-review-defaults-release-performance passed in 280.503s on native
darwin-arm64 / Node v26.3.0. All eight existing release-performance suites
passed, then both 120-second load phases passed. Worktree stayed clean.
Transport: 26,752 verified jobs, request p95 2.424ms, peak daemon RSS
184,958,976 bytes, 100 retained jobs, shutdown 19.283ms.
Workflow: 728 verified local-fixture jobs, peak concurrency four, request p95
9.872ms, peak daemon RSS 181,354,496 bytes, process-tree RSS 954,220,544 bytes,
settled daemon growth 1,818,624 bytes, shutdown 22.717ms. Failure, cancellation,
engine termination, recovery, shutdown termination and host-file cleanup all
passed. No live-provider evidence is claimed. Other native platforms and Node
versions remain separate cells. Log SHA256:
48b1a290009c18e41de11012e5dbc7274054dc228517d728cbb46460f7cf78ac.

### Goal artifact formatting ownership, in progress

Pending Goal -> Forge permission does not block this existing ownership seam.
Impact search: rg -l 'summarizeGoal|writeGoalArtifacts' packages tests returned
the legacy controller, Forge barrel and CLI Goal command. Planned source/test
paths: new mod-goal/src/artifacts.ts, mod-goal/src/index.ts, legacy controller,
and existing goal-journal.test.ts; generated release metadata follows build.
Backup branch: backup/goal-artifact-owner-191593086.

Move summary formatting and raw result projection into Goal. Legacy controller
retains its public summary export as the same function identity, and delegates
raw result construction. Paths, file writes, envelope construction and control
flow stay unchanged. This retires the old formatting implementations, not the
entire legacy controller or persistence adapter. No new dependency. The narrow
legacy forwarding export remains until its public consumers move with the
controller; existing CLI and Forge callers are the removal condition.

Green-before-refactor: previous full and native load gates above. New literal
historical summary/result baseline passed before movement:
goal-artifact-owner-baseline, SHA256
b525aafd0f991bd1164c68c10ea983a7d3c02c5a1e0798db305f4e17ef17d030.
Focused package build, typecheck, journal and real-Git oracle-controller tests
passed after movement: goal-artifact-owner-focused, SHA256
60e51d53ac7f104e29968ea19e2727df7ca10b261573feb8867b41e65a84a021.
Owner identity and raw result equivalence passed in
goal-artifact-owner-identity-controls, SHA256
64628bd6c27d892d1a3b210286202dd57eae057cfb6eafb0c8c4fbb467dbc47b.
Source equivalence against committed 191593086 proves the summary body and raw
result expression are unchanged: goal-artifact-owner-body-equivalence, SHA256
1f7244563e1de31ea3737eb88c86ac3078fdf3ddbe9b97517ebe6a5bd84c5144.

One isolated Codex review found no functional defect. Packet SHA256
a9ae7ecf21cc1020ae5cc7cf99f9efd9b3f7ebc62646c29e3dc10d593223d8e7;
review log SHA256 cfe9dc1ccb77aefac275ef3c5846d1ec7b4925c5fb57e34414e2c081c9661381.
Confirmed review observation: test title overstated exact envelope-byte
coverage. Renamed it to raw bytes and envelope metadata; added owner/version,
contribution, populated hash/timestamp, zero timestamp, completion status, and
parked lastError fallback checks. Passed goal-artifact-owner-review-controls,
SHA256 12948ca95870459cd45215ea7685c1d7d9919f0dd23b98f7af0f5ae02c101b16.
Inherited complete semantics for parked/failed-only queues remain unchanged.
Review auth copy absence verified. No second panel. All test receipts have
zero provider launches.

Full gate goal-artifact-owner-full is running, terminal 91494. Source frozen.
After exit, run the prepared built live probe (functions store key
goalArtifactOwnerBuiltLiveCommand), inspect all receipts, commit verified paths.

First full gate exited 1 at lint after 10,359 tests passed (six skipped).
Cause: extraction left unused isDone import in legacy controller. No waiver;
removed that sole unused binding. Focused ESLint with zero warnings, typecheck,
35 journal tests and diff check passed in goal-artifact-owner-lint-repair.
Failed full log SHA256:
383dc6f0509317e9aa07172b0609527478691caf4421942ac93dc7808817cdb4.
Repair log SHA256:
b015a86d882319adefe4a1a1a992717ea273144d7d40bfd5c7de01ab678d01f4.
Process correction: run focused zero-warning lint before the long full gate
after moving imports. Full gate restarted as goal-artifact-owner-qualified-full;
the failed receipt is retained. No commit yet. Run built probe after full exit.

Second full gate (goal-artifact-owner-qualified-full) passed build, typecheck,
10,359 tests/six skips, lint and re-export guard, then failed the first-party
generation check. Cause: Goal's barrel is generated; the extraction changed
its output but omitted the canonical generator entry. Added exactly the same
artifact export to generate-modular-first-party-packages.mjs. No runtime change
or weakened oracle. The existing drift gate supplies the negative control.
Second failed log SHA256:
afdad88bec1efb9205ab44f61978ca238270c04843fe770cf6c25dd4b9f487dc.
Generator, generated-artifact, re-export and focused lint gates now all pass:
goal-artifact-owner-generator-controls, SHA256
88066dbf682b100d58a3a15579e84d53ea1ab79c960e364767bcefd81a30d8ef.
Scope now five source/test files plus generated release metadata, not four.
Process correction: qualify generator drift and lint before long builds/tests
when moving a generated public export. Full gate goal-artifact-owner-final-full
uses that order and is running. Keep both failed receipts. No commit yet.

Qualified and committed as 5f39234401d7bb07fc330e2d77d5c448da62bbe9,
refactor(modular): assign Goal artifact formatting. Worktree clean, no push.
goal-artifact-owner-final-full passed all gates in 587.006s: 10,359 tests passed,
six skipped, full lint/types/build, generated and ownership checks, re-export
guard, catalog/roadmap, release/supply-chain, installed candidate and diff check.
Log SHA256: 5efda493448fe8302833e963edff8da427d630bfc5f3d9269543471c44a9f6a7.
Built runtime: goal-artifact-owner-built-live passed five task-state cases
(queued/inflight/done/parked/failed) using actual built public packages and real
artifact files. Verified shared function identity, raw result bytes, summary,
envelope payload/owner/status, state immutability and cleanup. Log SHA256:
fd89bb90016558dc2d2ff7e2f5e2fb40219b49fdc134d900caa0a583450e9d69.
All receipts record zero provider launches. Two failed full receipts remain
durable. Global Agon and personal state were not modified.

Remaining central Goal work is unchanged: real Forge competition and oracle
red-team, legacy-controller/state convergence, then final clean-subject release
qualification. Goal -> mod-forge remains pending the explicit async approval
question; no permission is inferred from the support-worktree dependency grant.
