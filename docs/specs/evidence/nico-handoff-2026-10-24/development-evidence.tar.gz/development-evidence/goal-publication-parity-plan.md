# Goal publication parity

Subject: `fix/modular-qualification-continuation`, following the retained-worktree
increment based on `36819ca76`. Source inspection: 2026-10-17.

## Confirmed gap

`packages/mod-goal/src/implementation.ts` marks each task done and returns a
`promotion.requiresOperatorApproval` object for `--push`/`--pr`. It never pushes.
The existing test named "keeps push/PR as an explicit operator promotion plan"
therefore proves a different contract, not legacy parity.

Legacy `packages/forge/src/goal/controller.ts` pushes the selected remote after
each completed task. A failed push keeps the completed local task and records
`push-failed`. `packages/cli/src/commands/goal.ts` prepares PR text after successful
work when push is requested; `--pr` additionally invokes `gh pr create`.
Do not copy its unconditional "commits pushed" message or its hook bypass.

## Small dependency-ordered increments

1. Per-task publication: honor explicit `push`, preserve the chosen remote,
   verify retained branch/commit identity, check captured authority and git.write
   before effects and after awaits. Record attempted/succeeded/failed/unknown
   outcomes without undoing completed local work. Do not retry an uncertain push
   automatically within the same task. A later completed task can push its new tip.
2. PR handoff: use the existing Forge-owned prose service through injection and
   existing support-worktree link helpers. Only generate a success link from
   verified publication. Explicit `pr` must not silently publish without `push`.
   Preserve template fallback, selected remote, and disabled-Forge enforcement.

No new external or internal dependencies are needed. Goal already depends on
engine-runtime and support-worktree. CLI already depends on Goal and Forge.
Conquer's publication function stages and commits and hardcodes origin, so it is
not the right owner for Goal's already-committed per-task push.

## Discriminating evidence

- Real local bare remote: two tasks produce two pushed tips; source unchanged.
- No push flag: remote stays unchanged; completed work remains local.
- Selected non-origin remote receives commits; origin stays unchanged.
- Rejecting remote: local task remains done, failed publication is visible.
- Denied/revoked permission, cancelled signal, changed generation or lost fence:
  no subsequent remote effect; retained local work survives.
- Branch/commit changed before publication: refuse rather than push other work.
- Dry run never pushes or invokes PR tooling.
- Commit-disabled path does not claim that uncommitted work was published.
- Mocked lost response after effect: label remote outcome unknown, not failed-safe.
- Review packet and negative controls stay outside the shipping tree.

Tests must use local fixture repositories and isolated homes, never live remotes
or providers. Existing whole-repository gate runs before each verified commit.
Final packed acceptance remains separate from these development receipts.

## PR handoff source tracing

Existing `mod-conquer/src/pull-request.ts` prepares a draft with capped Git diff,
optional engine prose, fallback body and a bounded compare link. Its Git ref is
hardcoded to origin; Goal must preserve its selected remote. Do not import
Conquer into Goal. CLI already injects Forge's `runPrText` through Conquer host
services with disabled-Forge and captured-generation checks. The same existing
owner can serve Goal through an injected callback, without a workspace edge.

`support-worktree/src/pr-links.ts` already owns `defaultBaseBranch`,
`githubRepoUrl` and `prefilledPrUrl`. A new consumer must not duplicate these.
One source-verified defect to cover when adding the handoff: githubRepoUrl uses
`git remote get-url`, which returns the fetch URL even if pushurl differs.
An initial `git -c remote.fixture.url=... remote get-url fixture` probe returned
"No such remote" on this Git version; it did not prove the behavior. The
successful reproduction used only a new disposable local repository. No remote
was contacted and no existing repository configuration was changed:

```
pr_probe_dir=$(mktemp -d /tmp/agon-pr-remote-XXXXXX)
git -C "$pr_probe_dir" init -q
git -C "$pr_probe_dir" remote add fixture https://github.com/example/read-source.git
git -C "$pr_probe_dir" remote set-url --push fixture https://github.com/example/write-target.git
git -C "$pr_probe_dir" remote get-url fixture
git -C "$pr_probe_dir" remote get-url --push fixture
```

They return read-source and write-target respectively. A post-push link must
name the actual publication repository. Check all helper consumers before
changing its semantics, and cover differing fetch/push URLs with a regression.
This is not changed in the frozen per-task publication increment.

Consumer scan (`rg -n 'githubRepoUrl\\(' packages -g '*.ts' -g '!*.test.ts'`)
found only the helper definition, physical Conquer, legacy Conquer CLI, and legacy
Goal CLI. All three call sites use it for post-push PR links. Existing public
Core exports re-export the support owner. This supports correcting the helper
in place rather than creating a second competing URL resolver.

For PR preparation, retain Conquer's public function/types for compatibility.
If extracting shared preparation, put its Git log/diff cap, optional-draft
fallback and link assembly with existing worktree PR support. Parameters must
carry explicit remote, title/body/context; no hidden origin default in Goal.
Conquer's wrapper supplies its existing origin/claim policy. Goal supplies its
persisted task summary and selected remote. Forge still owns prompt/parser.
This has two current consumers; no hypothetical registry/service layer is needed.

Goal PR creation is a separate effect from drafting. Only explicit --push --pr,
a known successful publication of the current branch tip, and current authority
may invoke gh. Use an explicit repository target and base/head; never let cwd's
default remote silently select another repository. Missing/unsupported repository
metadata must return manual handoff information, not open a browser or infer a
target. Preserve full PR text in the result even when a compare URL is truncated.

Test axes: selected remote/base; differing fetch/push URL; no push/no successful
tip/no tasks; optional Forge missing/disabled; prose parse/failure fallback;
cancellation/generation/fence changes between reads/draft/create; explicit gh
argv and failure result via injected process effects; no automatic PR retry;
long Unicode text; retained completed work and publication receipts. Tests use
no live gh, remote service, provider or browser login.
