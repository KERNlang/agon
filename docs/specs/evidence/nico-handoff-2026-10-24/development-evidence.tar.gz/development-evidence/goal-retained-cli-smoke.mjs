import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const checkout = '/Users/ra/dev/agon-audit-qualification';
const root = mkdtempSync(join(tmpdir(), 'goal-retained-cli-'));
const repository = join(root, 'repo');
const home = join(root, 'home');
mkdirSync(repository);
mkdirSync(home);
const git = args => execFileSync('git', args, { cwd: repository, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
git(['init', '-b', 'main']);
git(['config', 'user.name', 'Goal fixture']);
git(['config', 'user.email', 'goal@example.invalid']);
writeFileSync(join(repository, 'base.txt'), 'base\n');
git(['add', 'base.txt']);
git(['commit', '-m', 'base']);
const id = 'retained-cli-smoke';
const lock = join(home, 'goal-locks', `${createHash('sha256').update(id).digest('hex')}.lock`);
const kernelUrl = pathToFileURL(join(checkout, 'packages/mod-kernel/dist/index.js')).href;
const child = spawnSync(process.execPath, ['--input-type=module', '-e',
  `import { WriterFence } from ${JSON.stringify(kernelUrl)}; await WriterFence.acquire(${JSON.stringify(lock)}, 'fixture-dead-goal');`],
  { cwd: repository, encoding: 'utf8', timeout: 15_000 });
assert.equal(child.status, 0, child.stderr);
assert.ok(existsSync(lock), 'dead writer must leave a real lock');
const previousLock = JSON.parse(readFileSync(lock, 'utf8'));
assert.throws(() => process.kill(previousLock.pid, 0), error => error.code === 'ESRCH');
const env = { ...process.env, AGON_HOME: home, AGON_MODULAR_HOST_ROOT: join(home, 'modular-host') };
const cli = args => spawnSync(process.execPath, [join(checkout, 'packages/cli/dist/index.js'), 'goal', ...args],
  { cwd: repository, env, encoding: 'utf8', timeout: 30_000 });
const first = cli([id, '--gate', 'test -f base.txt', '--dry-run']);
assert.equal(first.status, 0, `${first.stderr}\n${first.stdout}`);
assert.equal(existsSync(lock), false, 'successful invocation must release its fence');
const worktrees = git(['worktree', 'list', '--porcelain']);
assert.match(worktrees, /branch refs\/heads\/goal\/retained-cli-smoke/);
const retained = worktrees.split('\n\n').find(block => block.includes('branch refs/heads/goal/retained-cli-smoke'));
const retainedPath = retained.split('\n').find(line => line.startsWith('worktree ')).slice('worktree '.length);
assert.equal(readFileSync(join(retainedPath, 'base.txt'), 'utf8'), 'base\n');
writeFileSync(join(retainedPath, 'inspection.txt'), 'operator work\n');
const resumed = cli(['--id', id, '--resume', '--dry-run']);
assert.equal(resumed.status, 0, `${resumed.stderr}\n${resumed.stdout}`);
assert.equal(readFileSync(join(retainedPath, 'inspection.txt'), 'utf8'), 'operator work\n');
assert.equal(existsSync(lock), false);
const changed = cli(['--id', id, '--resume', '--gate', 'false', '--dry-run']);
assert.notEqual(changed.status, 0, 'changed acceptance gate must fail');
assert.match(`${changed.stderr}\n${changed.stdout}`, /cannot change the recorded branch or gate/);
assert.equal(readFileSync(join(repository, 'base.txt'), 'utf8'), 'base\n');
assert.equal(existsSync(join(repository, 'inspection.txt')), false);
console.log(JSON.stringify({ passed: true, root, retainedPath,
  checks: ['real-dead-writer', 'built-cli-stale-recovery', 'retained-worktree', 'built-cli-resume', 'changed-gate-refusal', 'source-untouched'] }));
