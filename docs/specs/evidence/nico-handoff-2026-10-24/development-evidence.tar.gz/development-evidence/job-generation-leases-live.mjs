import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, readdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { DurableModHost } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { hostLock } from '/Users/ra/dev/agon-audit-qualification/tests/helpers/modular-host.ts';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const root = await mkdtemp(join(tmpdir(), 'generation-lease-processes-'));
const host = new DurableModHost(root, { kernelVersion: '1.0.0' });
await host.commitGeneration({ operation: 'install', lock: hostLock(), desiredState: {}, installedIndex: {} });
const code = `
  import { DurableModHost } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
  const host = new DurableModHost(process.argv[1], { kernelVersion: '1.0.0' });
  const lease = await host.leaseGeneration(1, 'fixture-worker');
  process.on('message', async message => {
    if (message !== 'release') throw new Error('unexpected fixture message');
    await host.releaseGenerationLease(lease.leaseId);
    process.disconnect();
  });
  process.send({ leaseId: lease.leaseId, pid: process.pid });
`;
const workers = Array.from({ length: 8 }, () => {
  const child = spawn(process.execPath, ['--input-type=module', '-e', code, root], {
    stdio: ['ignore', 'ignore', 'pipe', 'ipc'], env: process.env,
  });
  let stderr = '';
  child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-8000); });
  const ready = new Promise((resolve, reject) => {
    child.once('message', resolve);
    child.once('error', reject);
    child.once('exit', code => reject(new Error(`worker exited before readiness: ${code}: ${stderr}`)));
  });
  const done = new Promise(resolve => child.once('exit', (code, signal) => resolve({ code, signal, stderr })));
  return { child, ready, done };
});
const timeout = setTimeout(() => { for (const worker of workers) worker.child.kill('SIGKILL'); }, 15_000);
const records = async () => Promise.all((await readdir(host.paths.leases)).filter(name => name.endsWith('.json'))
  .map(async name => JSON.parse(await readFile(join(host.paths.leases, name), 'utf8'))));
try {
  const ready = await Promise.all(workers.map(worker => worker.ready));
  const active = (await records()).filter(lease => lease.releasedAt === null);
  assert.equal(active.length, 8);
  assert.equal(new Set(active.map(lease => lease.leaseId)).size, 8);
  assert.deepEqual(active.map(lease => lease.pid).sort(), ready.map(item => item.pid).sort());
  assert.ok(active.every(lease => lease.generation === 1));
  for (const worker of workers) worker.child.send('release');
  const results = await Promise.all(workers.map(worker => worker.done));
  assert.ok(results.every(result => result.code === 0), JSON.stringify(results));
  assert.equal((await records()).filter(lease => lease.releasedAt === null).length, 0);
  console.log(JSON.stringify({ builtKernel: true, processes: 8, acquired: 8, released: 8, providers: 0, installs: 0 }));
} finally {
  clearTimeout(timeout);
  for (const worker of workers) if (worker.child.exitCode === null && worker.child.signalCode === null) worker.child.kill('SIGKILL');
  await Promise.all(workers.map(worker => worker.done));
}
