import { spawn } from 'node:child_process';
const child = spawn(process.execPath, ['/tmp/amr-runtime/tmp/agon-job-child-admission-fkWcWk/worker.mjs'], {
  env: { ...process.env, AGON_JOB_GENERATION: 'generation-one' },
  stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
});
const log = (event, detail) => console.log(JSON.stringify({ event, detail, exitCode: child.exitCode, signalCode: child.signalCode, connected: child.connected }));
child.stdout.on('data', data => log('stdout', String(data)));
child.stderr.on('data', data => log('stderr', String(data)));
child.on('message', value => { log('message', value); child.disconnect(); });
child.on('disconnect', () => log('disconnect'));
child.on('exit', (code, signal) => log('exit', { code, signal }));
child.on('close', (code, signal) => log('close', { code, signal }));
child.on('error', error => log('error', String(error)));
child.stdout.on('end', () => log('stdout-end'));
child.stderr.on('end', () => log('stderr-end'));
setTimeout(() => {
  log('deadline');
  if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
}, 2000);
