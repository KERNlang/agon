import assert from 'node:assert/strict';
import { mkdtemp, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DurableModHost, ManagedLifecycleService, createManagedLifecyclePlan } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { artifact, installer, lifecycleLock, request, verifier } from '/Users/ra/dev/agon-audit-qualification/tests/helpers/modular-lifecycle.ts';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const root = await mkdtemp(join(tmpdir(), 'lifecycle-commit-live-'));
let fail = false;
const host = new DurableModHost(root, { kernelVersion: '1.0.0', fault: point => {
  if (fail && point === 'after-pointer-switch') throw new Error('isolated post-commit failure');
} });
const service = new ManagedLifecycleService(host);
await service.apply(await createManagedLifecyclePlan(host, request([artifact('@test/app')])), installer, verifier);
const update = artifact('@test/app', [], { version: '2.0.0', sourceLocator: 'cache:@test/app@2.0.0',
  contentHash: `sha256:${'2'.repeat(64)}`, manifestHash: `sha256:${'3'.repeat(64)}` });
fail = true;
await assert.rejects(service.apply(await createManagedLifecyclePlan(host, request([update], {
  operation: 'update', lock: lifecycleLock([update], '9'),
})), installer, verifier), { code: 'MOD_RESTART_REQUIRED' });
const restarted = new DurableModHost(root, { kernelVersion: '1.0.0' });
assert.equal((await restarted.boot()).pointer.generation, 2);
const recovered = new ManagedLifecycleService(restarted);
async function verifyVersion(expected) {
  const selected = await recovered.readSelectedInstallation();
  const pkg = JSON.parse(await readFile(join(root, selected.prefix, 'node_modules', '@test/app', 'package.json'), 'utf8'));
  assert.equal(pkg.version, expected);
  assert.equal(selected.packages[0].version, expected);
}
await verifyVersion('2.0.0');
await recovered.rollback(1); await verifyVersion('1.0.0');
await recovered.rollback(2); await verifyVersion('2.0.0');
console.log(JSON.stringify({ passed: true, root, postCommitPrefixPreserved: true,
  restartRecovery: true, previousVersionRollback: true, candidateReentry: true }));
