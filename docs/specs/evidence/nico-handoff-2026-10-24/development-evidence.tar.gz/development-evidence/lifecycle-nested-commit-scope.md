# Nested host commit and installation cleanup

Status: building; authorized by the existing implementation goal.
Date: 2026-10-11. Baseline: `23876c9d7c543ab05c5d273e96fbd9eaf187ab1e`.
No push, global installation, personal-state changes, installs or Pipeline.

## Confirmed defect

`ManagedLifecycleService.apply` assigns `selectedGeneration` only after the
nested `host.commitGeneration` call resolves. The host can commit its pointer,
then throw `MOD_RESTART_REQUIRED` while persisting cleanup/receipts. The outer
catch still sees null and deletes the immutable selected installation prefix.
The host generation remains selected, but its executable package prefix is gone.

`lifecycle-nested-commit-red` reproduces both `after-pointer-switch` and
`after-installed-index` nested host faults. Both fail on a real fixture prefix:
"selected installation prefix is missing or escapes the managed host".
Eleven older lifecycle fault tests pass. Log SHA-256:
`36c08300fad5cf1a62c4fdd111ec55e8966d8282a006074b338a30cffbcb35a1`.
Zero provider launches. Only own isolated fixture packages/files were removed.

The regression tests and production repair are in the qualification checkout.
Backup branch: `backup/lifecycle-commit-23876c9d`.

## Required repair and acceptance

Use authoritative pointer/generation state, not promise completion or an error
message, to decide whether the promoted prefix may be removed. If that state
cannot be verified, retain the prefix and recover rather than delete speculatively.
Preserve a recoverable journal state when the outcome remains uncertain.
`recoverManagedLifecycle` currently skips terminal `failed` journals, so merely
suppressing deletion but writing a failed journal is insufficient for recovery.
Known-committed failures need correct generation attribution and restart behavior.

Reuse current lifecycle journal, writer fence, generation validation and recovery.
Do not add a parallel transaction store or trust mutable installed-index snapshots
as the canonical pointer. Preserve pre-commit cleanup and previous-version boot.
Test nested post-commit faults, unreadable outcome, journal repair/re-entry,
rollback, and previous-prefix retention. Then default independent Agon review,
source-verified adjudication, full gates and live fixture filesystem checks.

Related hypothesis to examine within this same commit-point boundary: the host
sets `committed = true` only after `atomicWrite(current)` resolves; atomicWrite
renames then fsyncs the parent. A post-rename fsync failure could switch the
pointer before the flag changes. Do not label that hypothesis verified until a
fault-injected IO test discriminates it. Avoid fixing only the outer symptom.

Sources read: managed-lifecycle.ts apply/readSelectedInstallation;
durable-host.ts commitGeneration; host-io.ts atomicWrite;
lifecycle-recovery.ts journal parser/recovery; existing lifecycle fault and
recovery tests. Original config-schema ownership and migration lifecycle wiring
remain pending after this safety correction.

## Confirmed boundary classes and repair

The post-rename directory-sync hypothesis reproduced in
`lifecycle-pointer-sync-red` (three failures including the two original nested
cases), SHA-256 `87dde6d926c0450bc27e90f4f2d7acf869c86e37985f6fd69dc6bb2cc6f5eb6e`.
Both canonical pointer writers were traced: durable-host.ts and host-rollback.ts.
Rollback had the same error classification defect. `rollback-pointer-sync-red`
failed both readable/unreadable outcome tests, SHA-256
`3304328fe1b19e18050d762a2d86384b6d4430c86e2c1d069038e9378bd8ea7c`.

The host and rollback now read the canonical pointer after an unsuccessful
selection attempt. A matching pointer means committed/restart-required; an
unreadable result preserves the verified journal and requires recovery. The
outer lifecycle verifies generation/installation identity before deleting a
promoted prefix, and retains recoverable journal state for unknown outcomes.
Existing recovery resolves those journals when IO becomes readable again.

`lifecycle-unknown-commit` passed actual fixture recovery on both sides of the
rename, including rollback to old packages and re-entry to the new packages.
SHA-256 `4a53ed25ffff799b81ae14d2faf0a45b331dd216ddc5f14324d74e8fc04ec6ec`.
`lifecycle-commit-boundary-focused` passed targeted tests, types and lint,
SHA-256 `99895059887b791542b68773f7086db9bbd797924ee5edcc26b1f64339661a50`.

The same acknowledgement ordering existed for prefix promotion: rename succeeded
but a freeze/chmod error happened before `promoted=true`, leaving an orphan that
blocked retry. `lifecycle-prefix-freeze-red` failed with two prefixes instead
of one, SHA-256 `fb33397ed80e3293ddade7cfee3fa8157df75148bfeb6f5bfeaba86cabf9f86e`.
Move that flag immediately after successful rename, before freeze/fsync. This
retains normal pre-commit cleanup instead of introducing a new recovery store.

Scope: three existing Kernel transaction files, two existing test files, plus
generated release metadata. No API/dependency changes. No installs or providers
in verification runs. Independent review and full gates still required.

## Independent review and recovery scope correction

Reviewed staged tree `33c63a66ab4c19a0cd7c418d05e91c95ba77c729`.
Packet SHA-256 `3c8c2b059b404250edcde21daf5e385732d0a7a5e47325df603063a71d0ebc82`.
Codex exited 0, log SHA-256
`a24bad36891995a07eb0a05c1131d0a45dc108fbc53a6f115fa2091835131aff`.
Kimi exited 1 without a review, not counted as a passing review.

All three high review findings reproduced before recovery changes:
1. Restart with the pointer still unreadable deleted the protected generation.
2. A failed rollback deleted its preexisting target, including after a successful
   retry selected that target.
3. Installation recovery deleted a prefix referenced by a retained generation,
   and allowed a concurrent rollback to select it during destructive cleanup.

`lifecycle-recovery-review-red` failed the first two classes, SHA-256
`3bb35d18fc1ba63aefda98bb98bcec1203a17ed6c914a0333e1a0455e8c24692`.
`lifecycle-retained-prefix-red` failed retained-reference and deterministic
concurrent rollback controls, SHA-256
`a3834c002631b142e20326046d704330b7e32b3e0998040b2a2759efc6dd1ce4`.

Repair follows the same existing transaction ownership rules through recovery:
unknown pointer means no destructive reconciliation; rollback does not own its
target generation; later transaction base references prove a generation was
selected and prevent deletion of that history. Historical cleanup must not
restore old snapshots over the current selection. Lifecycle recovery acquires
the host writer fence after its lifecycle fence, matching apply's lock order,
and reuses the retained-installation scanner. It rejects unreadable ownership
rather than interpreting it as no reference. Retained but uncommitted generation
state requires host recovery first. Purge shares the same stricter scanner.

Failed outer completion now retains a `verified` lifecycle journal even when
selection is known, allowing normal recovery to produce a committed receipt;
it does not write a terminal committed journal with failed-only evidence.

`lifecycle-recovery-review-fixed`: 33 tests and typecheck passed, log SHA-256
`7b66f473b6825928139a1b6e5494c4b358cada2154bf92e9d10050ea44406e16`.
Scope now includes lifecycle-recovery.ts and its existing tests because the
original preservation repair was insufficient without them. No new store, API,
dependency or feature. Final delayed-recovery ordering and full gates pending.

## Qualified increment

Commit `fe6e6c8e55c86bdbbc29a29891f49e741a6cac21`, tree
`b3c765dcb37ab2abb3540b176bbfc04889a5b6c8`.
`lifecycle-commit-boundary-qualified` passed in 340.256 seconds:
build, typecheck, lint, re-export guard, public API compatibility, release-set,
supply-chain gates and self-tests, 8,531 tests passed and 6 skipped.
Log SHA-256 `bab42df56becdc6f687fbd841e773d19f32b3f6cc56899519e4d1bd18d0977e4`.
Provider launches: zero. This is one full run, not native crash/power-loss proof.

Built-runtime probes passed: 121-field legacy config parity, seven isolated CLI
invocations, migration alias/output preservation, and filesystem-backed managed
update failure followed by restart, previous-version rollback and candidate
re-entry. `lifecycle-delayed-recovery` also passed the ordering where rollback
precedes both recovery passes, without replacing current snapshots with history.

Candidate ref advanced by compare-and-swap; index updated without changing its
working files. Before/after preservation checks passed for 281 baseline paths.
Qualification checkout is clean. No push, installation or personal-state change.
This qualifies this repair only; whole-release acceptance remains outstanding.
