// Diagnostic baseline, not a release acceptance gate.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { pathToFileURL } from 'node:url';

const repo = '/Users/ra/dev/agon-audit-qualification';
const durationMs = Number(process.argv[2] ?? 30000);
assert.ok(Number.isSafeInteger(durationMs) && durationMs >= 30000 && durationMs <= 300000);
const controlsOnly = process.argv[3] === 'controls';
const fullWorkflow = controlsOnly || process.argv[3] === 'workflow';
const home = mkdtempSync('/tmp/aml-');
for (const name of ['HOME', 'AGON_HOME', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_STATE_HOME']) {
  process.env[name] = home;
}
process.env.AGON_MODULAR_HOST_ROOT = join(home, 'modular-host');
if (fullWorkflow) {
  delete process.env.AGON_DAEMON_ECHO;
  mkdirSync(join(home, 'engines'));
  writeFileSync(join(home, 'engines/load-fixture.json'), JSON.stringify({ schemaVersion: 3, id: 'load-fixture', displayName: 'Local load fixture', binary: process.execPath, isLocal: true, tier: 'user', timeout: 10, exec: { args: ['/Users/ra/dev/modular-agon-remediation/load-provider-fixture.mjs', '{prompt}'] } }));
} else process.env.AGON_DAEMON_ECHO = '1';
delete process.env.AGON_MOD_SAFE_MODE;
const dist = join(repo, 'packages/cli/dist');
const modules = readdirSync(dist).filter(name => /^daemon-[\w-]+\.js$/.test(name));
assert.equal(modules.length, 1, 'exactly one built daemon module');
const { sendDaemonRequest } = await import(pathToFileURL(join(dist, modules[0])));
const { JobService, createDaemonWorkflowRuntime } = await import(pathToFileURL(join(repo, 'packages/mod-jobs/dist/index.js')));
const samples = [];
const latency = [];
const report = { diagnostic: true, subject: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(), probeSha256: createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'), node: process.version, platform: process.platform, arch: process.arch, daemon: {}, scheduler: {} };
let daemon;
let exit;
let stderr = '';
let jobs;
const start = performance.now();
async function request(message, type) {
  const at = performance.now();
  const result = await sendDaemonRequest(message, 3000);
  latency.push(performance.now() - at);
  assert.equal(result?.type, type, JSON.stringify({ message, result }));
  return result;
}
try {
  daemon = spawn(process.execPath, [join(dist, 'index.js'), 'daemon', 'run', '--foreground'], { cwd: repo, env: process.env, stdio: ['ignore', 'ignore', 'pipe'] });
  exit = new Promise((resolve, reject) => { daemon.once('exit', (code, signal) => resolve({ code, signal })); daemon.once('error', reject); });
  daemon.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-16000); });
  const deadline = performance.now() + 10000;
  while (!existsSync(join(home, 'daemon/agond.sock'))) {
    assert.equal(daemon.exitCode, null, stderr);
    assert.ok(performance.now() < deadline, 'daemon startup deadline');
    await delay(50);
  }
  const first = await request({ type: 'ping' }, 'pong');
  const started = performance.now();
  let rounds = 0;
  while (!controlsOnly && performance.now() - started < durationMs) {
    const submitted = await Promise.all(Array.from({ length: 8 }, (_, n) => request({ type: 'job-submit', kind: fullWorkflow ? 'think' : 'brainstorm', payload: { input: `load-${rounds}-${n}`, cwd: repo, ...(fullWorkflow ? { engine: 'load-fixture', steps: '1' } : {}) } }, 'job-accepted')));
    for (const { job } of submitted) {
      let result = await request({ type: 'job-result', jobId: job.id }, 'job-result');
      const jobDeadline = performance.now() + 15000;
      while (!result.ready && performance.now() < jobDeadline) {
        await delay(25);
        result = await request({ type: 'job-result', jobId: job.id }, 'job-result');
      }
      assert.equal(result.ready, true);
      assert.equal(result.outcome?.state, 'succeeded', JSON.stringify(result));
      const events = await request({ type: 'job-events', jobId: job.id }, 'job-events');
      assert.ok(events.events.some(event => event.type === 'succeeded'));
      if (fullWorkflow) assert.ok(events.events.filter(event => event.type === 'stdout').map(event => event.data.text).join('').includes('LOCAL_LOAD_FIXTURE_OK'), JSON.stringify(events));
    }
    const listed = await request({ type: 'job-list' }, 'job-list');
    assert.ok(listed.jobs.length <= 100, 'terminal retention remains bounded');
    const pong = await request({ type: 'ping' }, 'pong');
    assert.equal(pong.sessionId, first.sessionId);
    if (rounds % 10 === 0) {
      const rssKiB = Number(execFileSync('ps', ['-o', 'rss=', '-p', String(daemon.pid)], { encoding: 'utf8' }).trim());
      assert.ok(Number.isFinite(rssKiB) && rssKiB > 0);
      samples.push({ elapsedMs: performance.now() - started, rssKiB, retainedJobs: listed.jobs.length });
    }
    rounds++;
    await delay(25);
  }
  latency.sort((a, b) => a - b);
  report.daemon = { elapsedMs: performance.now() - started, rounds, jobs: rounds * 8, requests: latency.length, p95Ms: latency[Math.ceil(latency.length * 0.95) - 1], maxMs: latency.at(-1), samples, coverage: fullWorkflow ? 'Built daemon, generated Think workflow, actual CLI adapter and local fixture engine. No echo seam or live model.' : 'Built daemon, real socket/registry/admission/events/retention. Existing echo seam replaces provider execution.' };
  if (fullWorkflow && !controlsOnly) {
    const events = readFileSync(join(home, 'fixture-launches.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
    const running = new Set();
    let peak = 0;
    for (const event of events) {
      if (event.phase === 'start') { assert.ok(!running.has(event.pid)); running.add(event.pid); }
      else assert.ok(running.delete(event.pid));
      peak = Math.max(peak, running.size);
    }
    assert.equal(running.size, 0);
    assert.equal(events.length, rounds * 8 * 2);
    assert.ok(peak > 1 && peak <= 4, 'actual fixture processes overlap within concurrency limit');
    report.daemon.fixture = { events, peak };
  }
  if (controlsOnly) {
    const submitted = await request({ type: 'job-submit', kind: 'think', payload: { input: 'LOAD_CANCEL', cwd: repo, engine: 'load-fixture', steps: '1' } }, 'job-accepted');
    const launches = join(home, 'fixture-launches.jsonl');
    const startupDeadline = performance.now() + 5000;
    while (!existsSync(launches)) { assert.ok(performance.now() < startupDeadline, 'fixture started'); await delay(25); }
    const fixture = JSON.parse(readFileSync(launches, 'utf8').trim().split('\n')[0]);
    const cancelled = await request({ type: 'job-cancel', jobId: submitted.job.id }, 'job-cancelled');
    assert.equal(cancelled.job.state, 'cancelled');
    const result = await request({ type: 'job-result', jobId: submitted.job.id }, 'job-result');
    assert.equal(result.outcome.state, 'cancelled');
    const cancelledAt = performance.now();
    let alive = true;
    while (alive && performance.now() - cancelledAt < 3500) {
      try { process.kill(fixture.pid, 0); } catch (error) { if (error.code !== 'ESRCH') throw error; alive = false; }
      if (alive) await delay(25);
    }
    report.cancellation = { fixturePid: fixture.pid, elapsedMs: performance.now() - cancelledAt, jobState: result.outcome.state, engineStillAlive: alive };
    assert.equal(alive, false, 'cancelled job must stop its engine process');
  }
  await request({ type: 'shutdown' }, 'bye');
  const shutdown = await Promise.race([exit, delay(5000).then(() => { throw new Error('daemon shutdown deadline'); })]);
  assert.equal(shutdown.code, 0);

  jobs = new JobService();
  const runtime = createDaemonWorkflowRuntime({ defaults: { jobLabelMaxChars: 160, jobOutputChunkChars: 1024, jobCancelGraceMs: 200 }, buildCommands() { throw new Error('No plan compiler replacement used'); }, validateEngineRoster() { throw new Error('No provider roster allowed'); } });
  const schedulerStart = performance.now();
  let completed = 0;
  let peakRunning = 0;
  const schedulerSamples = [];
  while (!controlsOnly && performance.now() - schedulerStart < durationMs) {
    const batch = Array.from({ length: 8 }, (_, n) => {
      const label = `local-fixture-${completed + n}`;
      return jobs.submit('brainstorm', label, runtime.createDaemonWorkflowExecutor({ kind: 'brainstorm', label, cwd: home, commands: [['fixture', label]] }, { script: '/Users/ra/dev/modular-agon-remediation/load-workflow-fixture.mjs' }));
    });
    assert.equal(jobs.list().filter(job => job.state === 'running').length, 4);
    assert.equal(jobs.list().filter(job => job.state === 'queued').length, 4);
    peakRunning = Math.max(peakRunning, jobs.list().filter(job => job.state === 'running').length);
    const results = await Promise.all(batch.map(job => jobs.wait(job.id)));
    assert.ok(results.every(result => result?.state === 'succeeded'), JSON.stringify(results));
    assert.equal(await jobs.waitForIdle(3000), true);
    for (const job of batch) {
      const events = jobs.events(job.id).events;
      assert.ok(events.some(event => event.type === 'stdout' && event.data.text.includes(job.label)));
      assert.ok(events.some(event => event.type === 'command-finished' && event.data.exitCode === 0));
    }
    assert.ok(jobs.list().length <= 100);
    completed += batch.length;
    schedulerSamples.push({ elapsedMs: performance.now() - schedulerStart, rssBytes: process.memoryUsage().rss, retainedJobs: jobs.list().length });
  }
  report.scheduler = { elapsedMs: performance.now() - schedulerStart, completed, peakRunning, samples: schedulerSamples, coverage: 'Real Jobs scheduler and workflow subprocess/output path; local fixture replaces model command. Not full model-workflow or daemon execution evidence.' };
  report.passed = true;
} catch (error) {
  report.passed = false;
  report.error = String(error?.stack ?? error);
  report.stderr = stderr;
  process.exitCode = 1;
} finally {
  if (jobs) {
    jobs.cancelAll('probe cleanup');
    if (!await jobs.waitForIdle(5000)) { report.passed = false; report.cleanupError = 'scheduler did not drain'; process.exitCode = 1; }
  }
  if (daemon && daemon.exitCode === null && daemon.signalCode === null) {
    daemon.kill('SIGKILL');
    await exit;
  }
  if (controlsOnly && existsSync(join(home, 'fixture-launches.jsonl'))) {
    for (const event of readFileSync(join(home, 'fixture-launches.jsonl'), 'utf8').trim().split('\n').map(JSON.parse)) {
      if (event.phase !== 'start') continue;
      try { process.kill(event.pid, 'SIGKILL'); }
      catch (error) { if (error.code !== 'ESRCH') throw error; }
    }
  }
  const generations = join(home, 'modular-host/generations');
  if (existsSync(generations)) for (const entry of readdirSync(generations, { withFileTypes: true })) {
    if (entry.isDirectory()) chmodSync(join(generations, entry.name), 0o700);
  }
  rmSync(home, { recursive: true, force: true });
  report.elapsedMs = performance.now() - start;
  console.log(JSON.stringify(report, null, 2));
}
