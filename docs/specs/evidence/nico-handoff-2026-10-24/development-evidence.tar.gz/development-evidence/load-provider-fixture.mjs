import { appendFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout } from 'node:timers/promises';
const path = join(process.env.AGON_HOME, 'fixture-launches.jsonl');
const record = phase => appendFileSync(path, JSON.stringify({ phase, pid: process.pid, at: Date.now() }) + '\n');
record('start');
await setTimeout(process.argv.at(-1).includes('LOAD_CANCEL') ? 8000 : 250);
console.log(JSON.stringify({ thoughts: [{ thoughtNumber: 1, totalThoughts: 1, thought: 'Local fixture completed.', kind: 'decision', nextThoughtNeeded: false }], summary: 'LOCAL_LOAD_FIXTURE_OK', openQuestions: [], refinedSpec: 'Local fixture only.' }));
record('end');
