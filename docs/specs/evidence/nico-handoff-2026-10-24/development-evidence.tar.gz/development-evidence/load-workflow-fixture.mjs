import { setTimeout } from 'node:timers/promises';
await setTimeout(100);
console.log(process.argv.at(-1));
