import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = '/Users/ra/dev/agon-audit-qualification';
const base = '253a53af0ddd2e9bd75b9793a06592f426a28ba6';
const map = JSON.parse(readFileSync(resolve(root, 'docs/specs/evidence/modular-agon-package-map.json'), 'utf8'));
const { validateManifest } = await import(pathToFileURL(resolve(root, 'packages/mod-api/dist/index.js')));
const results = [];
for (const entry of map.packages.filter(item => item.class === 'user-toggleable-mod-package')) {
  const directory = 'packages/' + entry.id.replace('@kernlang/agon-', '');
  const relative = directory + '/src/index.ts';
  const old = execFileSync('git', ['show', base + ':' + relative], { cwd: root, encoding: 'utf8' });
  const current = readFileSync(resolve(root, relative), 'utf8');
  const manifestStart = old.indexOf('validateManifest(') + 'validateManifest('.length;
  const manifestEnd = old.indexOf(');\nexport const SOURCE_OCCURRENCES', manifestStart);
  const occurrenceStart = old.indexOf('Object.freeze(', manifestEnd) + 'Object.freeze('.length;
  const occurrenceEnd = old.indexOf(');\nexport const IMPLEMENTATION_KIND', occurrenceStart);
  assert(manifestEnd > manifestStart && occurrenceEnd > occurrenceStart, relative);
  const manifest = JSON.parse(old.slice(manifestStart, manifestEnd));
  const occurrences = JSON.parse(old.slice(occurrenceStart, occurrenceEnd));
  // The package gate exposed these existing public declaration omissions.
  // This is the only allowed metadata delta from the frozen source.
  if (entry.id === '@kernlang/agon-mod-plan') {
    const position = manifest.pack.include.indexOf('dist/implementation.d.ts');
    assert(position >= 0);
    manifest.pack.include.splice(position + 1, 0,
      'dist/agent-review-step-execution.d.ts', 'dist/forge-step-execution.d.ts',
      'dist/pipeline-step-execution.d.ts', 'dist/self-step-execution.d.ts');
  }
  const tail = 'export const IMPLEMENTATION_KIND';
  assert.equal(current.slice(current.indexOf(tail)), old.slice(old.indexOf(tail)), relative + ': export tail');
  assert.deepEqual(JSON.parse(readFileSync(resolve(root, directory, 'agon.mod.json'), 'utf8')), manifest);
  assert.deepEqual(JSON.parse(readFileSync(resolve(root, directory, 'ownership.json'), 'utf8')).assignments, occurrences);
  const loaded = await import(pathToFileURL(resolve(root, directory, 'dist/index.js')));
  assert.deepEqual(loaded.MANIFEST, validateManifest(manifest), relative + ': runtime manifest');
  assert.deepEqual(loaded.SOURCE_OCCURRENCES, occurrences, relative + ': runtime occurrences');
  assert(Object.isFrozen(loaded.MANIFEST) && Object.isFrozen(loaded.SOURCE_OCCURRENCES));
  assert.equal(loaded.IMPLEMENTATION_KIND, 'physical');
  assert.equal(typeof loaded.createMod, 'function');
  const changed = structuredClone(loaded.SOURCE_OCCURRENCES);
  assert(changed.length > 0, relative + ': mutation needs an occurrence');
  changed[0].source += ':incorrect';
  assert.throws(() => assert.deepEqual(changed, occurrences));
  results.push({ package: entry.id, beforeLines: old.split('\n').length - 1,
    afterLines: current.split('\n').length - 1, occurrences: occurrences.length });
}
assert.equal(results.length, 36);
console.log(JSON.stringify({ base, packages: results.length,
  removedSourceLines: results.reduce((sum, item) => sum + item.beforeLines - item.afterLines, 0),
  exactMetadataAndExportTail: true, allowedMetadataDelta: 'Plan public declaration allowlist: four added paths',
  sameCountNegativeControls: results.length, results }, null, 2));
