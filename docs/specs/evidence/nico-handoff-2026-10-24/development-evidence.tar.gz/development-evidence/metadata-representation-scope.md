# F4: remove embedded copies of first-party metadata

Status: implemented, reviewed, qualified and committed locally. No change to
requirements or mod behavior. Base 253a53af0ddd2e9bd75b9793a06592f426a28ba6.
Date: 2026-10-11. Allowed: isolated local code/tests, default isolated Agon review,
verified local commit. No push, install, new dependency or personal-state writes.

## Purpose and authority

Audit F4 asks to reduce repeated manifest/ownership representations without
changing public exports or code-free static discovery. The user authorized safe
audit simplifications after consumer tracing. Existing JSON files retain all
metadata; no evidence files or oracle inputs are removed or untracked.

## Source evidence and bounded scope

`rg -l SOURCE_OCCURRENCES packages scripts tests --glob '*.{ts,mjs,json}'`
finds 38 files: 36 generated indexes, their generator and package verifier.
The verifier reads exported occurrence counts. The kernel's
first-party-surface-bootstrap.ts:139-145 consumes exported MANIFEST, validates
package identity and creates/decorates services before activation. Implementations
do not import MANIFEST from their index (the initial assumption was refuted by
search). Manifest validation/freeze and bootstrap behavior must remain unchanged.
Generator expectedFiles already emits both agon.mod.json and ownership.json from
the same inputs. This is duplicated representation, not independent authoring.
Historical inventory authority (audit F6) is a separate issue, not claimed fixed.

Candidate: generated indexes import those package-local JSON files using native
JSON import attributes. Keep validateManifest, SOURCE_OCCURRENCES and the exact
remaining export tail. No runtime JSON filesystem loader, new dependency, global
config or new metadata manager. Existing tsup bundles imported JSON; deployed
module loading must not gain an untracked asset or a source-tree dependency.

Read-only TypeScript createProgram prototype for mod-ask reported zero diagnostics
with existing config, without adding JSON to include. Old index 121 split lines,
candidate 9. resolveJsonModule is already true in tsconfig.base.json. This is a
prototype only; actual build/pack and all package exports remain to be proven.

Blast radius: one generator, 36 mechanically regenerated indexes, existing package
verification checks as needed. No manifest, ownership, schemas, package.json,
tsconfig, lockfile, legacy oracle or workflow implementation changes intended.
Stop and reassess if more generated files drift or public type signatures change.
The file count is generated fan-out of the already-approved F4 remediation, not
36 independent redesigns. Start with one actual package build before broad gates.

## Acceptance

- Exact deep equality of all exported metadata against embedded literals in the
  immutable base Git objects, not two regenerated oracles.
- Exact unchanged non-metadata export tail for every package.
- Source declarations and packed public exports remain usable; JSON assets remain
  included at their existing paths. Static discovery stays code-free.
- Generator --check, independent builds and packs, all five surface registrations,
  disposal and disabled registration tests pass for all 36 mods.
- Useful negative control catches a same-count metadata change, not only ID/count.
- Full build/types/lint/tests, performance, independent review and final live
  fixture checks pass. No provider launches except the approved isolated review.
- Report measured source savings separately from bundle/package savings.

Keep the original JSON evidence, generator inputs, frozen legacy fixtures and
archive. No historical evidence is deleted. Compatibility catalog F5 and inventory
authoring F6 are not silently removed as part of this slice.

## Corrections and prerequisite (2026-10-11)

Pilot receipt metadata-import-pilot passed (2.749s, zero providers), log hash
737554053c184a65d2c9b808bc1f5c792a1ff3597a9024b527b3e385756166b1.
Actual index delta: 36 indexes, 8,427 to 478 lines, net reduction 7,949.
JSON metadata is retained. Regeneration initially changed only those indexes and
the generator. Metadata verification now checks deep values/freeze, not only
manifest ID and occurrence count, with negative controls for same-count changes.

All-package gate metadata-all-packages failed at Plan pack validation after
46.143s, log hash c133e8a289dba052f772eabb0a1eaba6a1beb77d6122d5a1721ec48beb75052d.
Source at immutable base already exported agent-review-step-execution,
forge-step-execution, pipeline-step-execution and self-step-execution declarations
but omitted them from manifest.pack.include. Existing files:['dist', ...] also
packed internal dependency-graph.d.ts and execution-record.d.ts. Neither internal
file is referenced by any emitted public declaration (rg over dist/*.d.ts); their
runtime implementation is bundled. This drift predates the JSON import change.

Bounded prerequisite: declare the four public declarations, and replace Plan's
broad dist pack entry with its explicit JS/declaration allowlist. The two internal
declarations remain in source/build output but are not published. No ignore rule,
test skip or broader exclusion. Packed public type compilation must still pass.
Added paths to scope: packages/mod-plan/agon.mod.json and package.json. Generator
already in scope. Total 40 repository paths, including 36 mechanical indexes.
Independent parity against base Git permits exactly the four added Plan pack paths
and no other metadata delta; remaining export tails must remain byte-identical.
This corrects a package-contract defect rather than treating an existing red gate
as acceptable. Other mods retain their existing pack policy.

## Verification and frozen review subject

metadata-pack-boundary passed in 111.417s, zero providers. Generator, independent
36-package builds/packs, 344 ownership occurrences, 259 registrations, all five
projections, disposal and disabled registration checks passed. Runtime values and
unchanged export tails matched immutable-base evidence with the explicit Plan
pack delta. Typecheck passed. Log hash
cee1c725c75e34d00adff0e3511489b9803679ed3aa2dfff06ce980409e39407.

metadata-public-types passed in 4.806s, zero providers. TypeScript compiled a
consumer of all four exported Plan step factories while the compiler filesystem
denied unpublished Plan declarations. Removing each required public declaration
produced TS2307. Both internal declarations remained unavailable. This is a
compile-only pack-boundary probe, not a fresh npm installation. Log hash
b0409184d58b3ba2c1f0f0b6e015d09ce11ca2418641260f00febc1e0b369d76.

Frozen staged tree efb4c45a209649cff705e15c467ffbb5079be18e; 40 exact scoped
repository paths. No unrelated dirty files. Default isolated Agon reviews used
packet hash d19acff731c5ad8c23191169466c937d31075231cb9096b864f0c2cd5420bd63.
Codex log hash 3e09fe17c31e8794b9753d08de72f672602ee43fff39ca4f780c965e9e58bf9e.
Kimi returned no answer, exit 1, unchanged unavailable-auth log hash
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
Full frozen gate metadata-full-qualified (exec 70412) has local-socket escalation,
no-login preload and provider blockers. Do not edit the frozen tree while running.
Read its terminal receipt; no commit or whole-release claim yet.

## Review adjudication and reproduced daemon failure

Codex found no blocking F4 regression. Confirmed limitations: normal metadata
verifier compares generated values to current JSON, while the external Git-base
probe provides independent parity; Plan type probe constrains dist only and uses
a paths alias, so it is not a complete isolated install; helper results need the
separately captured tree binding above. Thirty-six mutation probes exercise the
deep assertion, while the Ask self-test directly exercises verifyMetadata.
Static-discovery concern checked against kernel/discovery.ts: it parses JSON and
calls validateManifest at lines 159/166, not TypeScript literal scanning. Source
search found no production SOURCE_OCCURRENCES literal scanner. Compatibility
generation remains unchanged; scope is the 36 physical packages only.

metadata-full-qualified failed after 278.752s, zero providers, log hash
695bc39c3854fb564fe986e2885311ef26fab6bba5b3a5cc429223a4c1429e54.
Build/types/lint/re-export/generated gates passed; 8,411 tests passed, 6 skipped,
one failed. Performance and final probes did not run because the suite stopped
the command chain. Do not accept or commit this staged metadata subject yet.

The failure reproduces the original daemon flake with new diagnostic evidence:
daemon-survival.test.ts cancel case received no job-submit reply. Trace reports
ECONNREFUSED, connected=false, bytes=0, elapsedMs=1. Child exitCode/signalCode
were null at the assertion snapshot, stderr empty. This proves connection refusal,
not protocol/parse failure, timeout or provider behavior. It does not establish
the child stayed alive after that snapshot.

Source explains a readiness mismatch: test line 159 waits only for socket path
existence. Actual daemon writes ready:true only inside server.listen's callback,
after permissions; production startDaemon already waits for matching PID plus
ready:true. Next action: verify this test readiness race with a discriminating
control, use the existing ready contract without retrying job-submit or increasing
timeouts, and qualify the diagnostic correction separately from F4. Preserve the
staged metadata changes and all failure receipts; no production fix is inferred
merely from an unchanged rerun. Frozen metadata tree remains efb4c45a... above.

## Qualified local commit

Readiness correction is separate commit 072d75536bb1afefc4507cddb1683e01fc4478da.
F4 and Plan pack correction: 754170e91ecabe68c3bc157b467e4aa4a697593c.
Combined tree 1aab0ceffe5667f9379fd89217b854825df0bb77 exactly matches the
full qualified subject. `metadata-readiness-qualified` passed in 333.07s with
zero provider launches. Log SHA-256:
bd198f1f726428b488f1f7f7be3041af4f7b87ca501cd5e26dc4e45a357b92d6.

Full rebuild/types/lint/re-export/generator checks, 8412 tests (six skips),
performance budgets, all 36 immutable-base metadata comparisons and unchanged
export tails passed. Public Plan consumer and four omission controls passed.
Four live Brainstorm sessions produced completed/aborted/crashed/completed
receipts, six checkpoints, no replacement-session messages and stopped timers.
Final daemon/readiness suites passed 22 tests. Preserve the earlier failed run.

Net generated-index source reduction: 7949 lines (8427 to 478), across 36 mods.
The entire F4/Plan commit removes 7887 net lines after verifier and pack fixes.
No runtime speedup or bundle-size reduction is claimed. JSON metadata, schemas,
ownership evidence, legacy oracle and generator inputs remain available.

Candidate branch now points to 754170e9 without replacing its working files.
Before/after preservation checks pass; qualification worktree is clean.
No push or installation. F5/F6/F7, remaining ownership retirement and final
clean-checkout release qualification remain open; F4 does not close the goal.
