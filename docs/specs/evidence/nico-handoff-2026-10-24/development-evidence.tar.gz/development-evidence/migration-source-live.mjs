import assert from 'node:assert/strict';
import { mkdtemp, readFile, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { migrateStagedCopy } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const root = await mkdtemp(join(tmpdir(), 'migration-source-live-'));
const source = join(root, 'source');
const original = Buffer.from([0, 255, 17, 42]);
await writeFile(source, original);
const alias = join(root, 'alias');
await symlink(root, alias);
let callbacks = 0;
const migrate = () => { callbacks++; return Buffer.from('migrated'); };
const invoke = stagedPath => migrateStagedCopy({
  ownerId: 'example.fixture', sourcePath: source, stagedPath, fromVersion: 1, toVersion: 2,
  migrations: [{ id: 'v2', fromVersion: 1, toVersion: 2, migrate }],
});
for (const staged of [source, join(alias, 'source')]) {
  await assert.rejects(invoke(staged), { code: 'MOD_MIGRATION_FAILED' });
  assert.deepEqual(await readFile(source), original);
}
assert.equal(callbacks, 0);
const staged = join(root, 'staged');
const receipt = await invoke(staged);
assert.equal(callbacks, 1);
assert.equal(receipt.sourcePreserved, true);
assert.deepEqual(await readFile(source), original);
assert.equal(await readFile(staged, 'utf8'), 'migrated');
await assert.rejects(invoke(staged), { code: 'MOD_MIGRATION_FAILED' });
assert.equal(await readFile(staged, 'utf8'), 'migrated');
assert.equal(callbacks, 1);
console.log(JSON.stringify({ passed: true, root, sourceBytesPreserved: true,
  directAndSymlinkAliasesRejected: true, existingOutputPreserved: true, validMigration: true }));
