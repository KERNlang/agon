# Migration source preservation

Status: building. Authorized by the existing complete-modularization goal.
Date: 2026-10-11. Baseline: `86a87d8284360775e88c7719b1b2cd07949882ac`.
Spec: bug, source-derived. Agon default review allowed; no installs, push,
personal-state changes, global installation or promotion.

## Contract and current evidence

Runtime contract: "Run declarative data/config migrations against staged copies."
(`docs/specs/modular-agon-runtime-contract.md:236`). The public migration receipt
claims `sourcePreserved: true`. The current engine compares source bytes before
writing staged output; it does not check that the destination differs from the
source. Its catch cleanup removes the supplied staged path even if the callback
failed before staging. Hypothesis: equal paths can overwrite source on success
or delete it on failure. Reproduce before correction.

## Scope and acceptance

Preserve the existing migration engine, output format, injected IO boundary and
monotonic path semantics. Do not introduce a second store or migration engine.
Reject source/destination aliases before executing callbacks or cleanup. Keep
existing staged-copy success and failure behavior for distinct valid paths.
Consider lexical equality, symlinked parent aliases and already-existing staged
files. Prove original source bytes survive negative cases. Preserve current API
compatibility and capture a built-Kernel filesystem check.

Expected files: Kernel migration engine, its existing tests; HostIo only if the
existing injected filesystem interface lacks the necessary identity operation.
Generated release files change only through existing build. No new dependencies.
Search `rg -n migrateStagedCopy packages tests`: production declaration/export
only, plus two existing test files. Installation/activation integration is a
separate unfinished requirement; this repair makes the existing owner safe to
connect, not proof that it is connected.

Completion: meaningful red controls, local correction, default independent Agon
review with findings verified, full repository/package gates, built runtime
source preservation, clean local commit and unrelated-work preservation.

## Reproduction and review

`migration-source-alias-red` failed both added cases: successful callback
overwrote source and returned `sourcePreserved: true`; throwing callback deleted
source (read returned ENOENT). SHA-256:
`f3cc862bcdee255a88a6109003165c48a025d45517dba2f7d49b7c48d1e4c301`.

Initial exists-check passed bounded aliases but leaves a check/write race. It
was replaced before review by exclusive `wx` output reservation. Failed
reservations cannot invoke the callback or reach destructive cleanup. This
uses the existing HostIo write boundary; no API expansion or new helper.
Fixtures cover competing writers, preexisting output and a symlinked parent.

Reviewed tree `331365c422b5f230ccdb4917d52298edf08b859a`.
Packet SHA-256 `da5324bf48088324aca8fd4230ca173deba07b75d006dc02af6a0f334c62225c`.
Codex exited 0; log SHA-256
`40dadff3b6a2037188ad47cc9f05cd82972987d42e8918d689870572c5b212de`.
Kimi exited 1 with no review, not a passing review.

One review finding reproduced: initial mkdir escaped the typed failure boundary.
`migration-source-review-red` failed that typed-code assertion; SHA-256
`2846be10f47195492789b8e875d3def4e40ca2c464cab76873a259ed488f6f68`.
Moved reservation mkdir inside the non-cleaning reservation catch. The injected
EACCES test now proves typed failure, no callback, no rm and exact source bytes.
`migration-source-review-fixed` passed migration tests and typecheck; SHA-256
`852d251dcce8361f645035e030ea75636d89bea2773254cc000f0e2054a9ed08`.

Recovery limitation, not release certification: reservation creates an empty
staged file while the migration runs. A process crash can leave that reservation.
Lifecycle wiring must discard abandoned staged generations on recovery, never
blindly delete a reservation from another live transaction. Trusted full-code
callbacks are not sandboxed. Full qualification currently running.

## Next lifecycle check, not yet verified by execution

Source-grounded hypothesis: `ManagedLifecycleService.apply` sets its local
`selectedGeneration` only after `host.commitGeneration` resolves. The host can
switch the canonical pointer and then throw `MOD_RESTART_REQUIRED` from cleanup.
The lifecycle catch still sees null and removes the promoted installation
prefix. Existing tests inject `after-generation-selected` in the outer service,
which is after assignment; they do not cover the host's `after-pointer-switch`
failure nested inside apply. Reproduce with a real fixture installation, update
through a host fault hook, then assert selected installation files still exist
and boot/recovery succeed. Do this before connecting config migration to the
transaction. Sources: managed-lifecycle.ts apply/cleanup; durable-host.ts
commitGeneration; modular-lifecycle-fault-injection.test.ts and recovery tests.

## Committed result

Commit `23876c9d7c543ab05c5d273e96fbd9eaf187ab1e`, tree
`8feeb378b49efbb4836d1423d1acd9d2fc11f296`. Qualification checkout clean;
candidate ref/index advanced without changing its working files.
Before/after preservation checks passed all 281 baseline paths using the existing
authorized exception list (log SHA-256
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`).

`migration-source-qualified` passed in 309.412 seconds. Build/types/lint,
re-export guard, API compatibility, release-set and supply-chain verification
plus self-tests, 8,518 tests passed/six skipped, 121-field historical config
parity, seven CLI subprocess checks, and built-Kernel filesystem migration
checks all passed. The built probe verifies direct and symlinked source aliases,
unchanged source bytes, valid migration, and retained preexisting output.
Log SHA-256: `e5216ad5a1d15d7e6ae242e84fa94d19086e75e6268d9fe3d1965c0020b4e594`.
Zero provider launches. No global installation changes or push. Lifecycle
integration and the nested commit/recovery hypothesis above remain unfinished.
