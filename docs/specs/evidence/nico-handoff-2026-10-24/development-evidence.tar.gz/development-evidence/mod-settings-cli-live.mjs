import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { inspectFolderMod, TrustGrantStore, ExternalActivationStore, sha256Canonical } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

// Isolated fixture only. Never point this at an operator home.
assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const root = await mkdtemp(join(tmpdir(), 'mod-settings-cli-'));
const project = join(root, 'project');
const hostRoot = join(root, 'modular-host');
const packageRoot = join(root, 'mods', 'settings-fixture');
await mkdir(project); await mkdir(join(packageRoot, 'dist'), { recursive: true });
const modId = 'example.settings';
const manifest = {
  schemaVersion: 2, id: modId, name: modId, version: '1.0.0', apiRange: '^1.0.0',
  execution: 'executable', compatibility: { kernelRange: '^1.0.0', nodeRange: '>=22 <27' },
  packageClass: 'user-toggleable-mod-package', entrypoints: { runtime: 'dist/index.js', types: 'dist/index.d.ts' },
  display: { group: 'test', order: 1 }, dependencies: { required: [], optional: [], conflicts: [] },
  permissions: [], platforms: ['darwin-arm64', 'darwin-x64', 'linux-arm64', 'linux-x64'], assets: [],
  contributes: { cliCommands: [{ id: 'settings-fixture', aliases: [] }], tuiActions: [], mcpTools: [], cesarTools: [], lifecycleHooks: [], resultTypes: [], configKeys: [], generatedDocs: [] },
  pack: { include: ['dist/index.js', 'dist/index.d.ts', 'agon.mod.json', 'package.json'], executable: [] },
};
for (const [path, content] of Object.entries({
  'agon.mod.json': JSON.stringify(manifest), 'package.json': '{"type":"module"}', 'dist/index.d.ts': 'export {};',
  'dist/index.js': `export default () => ({ apiVersion: '1', activate(registrar) { registrar.command('cli', { id: 'settings-fixture', description: 'Fixture settings reader', inputSchema: { type: 'object' }, run: async (_input, context) => ({ exitCode: 0, stdout: JSON.stringify(context.config) }) }); } });`,
})) await writeFile(join(packageRoot, path), content);
const candidate = await inspectFolderMod(packageRoot);
const publisher = { registryOrigin: 'local-user-folder', packageName: modId, provenanceIdentity: 'local-user', provenanceStatus: 'not-applicable' };
const identity = { modId, version: manifest.version, source: candidate.source, sourceLocator: candidate.sourceLocator, contentHash: candidate.contentHash, manifestHash: candidate.manifestHash, publisherHash: sha256Canonical(publisher) };
const trust = new TrustGrantStore(hostRoot);
const trustPlan = trust.previewTrust({ modId, version: manifest.version, source: candidate.source,
  sourceLocator: candidate.sourceLocator, contentHash: candidate.contentHash, manifestHash: candidate.manifestHash,
  publisher, decision: 'trusted', decidedAt: '2026-10-11T00:00:00.000Z', scope: 'exact-artifact', reason: 'isolated fixture' });
await trust.apply(trustPlan, { approvedPlanHash: trustPlan.planHash });
const activation = new ExternalActivationStore(hostRoot);
const enabled = activation.preview(identity, true, 'isolated fixture', '2026-10-11T00:00:01.000Z');
await activation.apply(enabled, enabled.planHash);
const paths = [join(root, 'config.json'), join(project, '.agon.json'), join(project, '.agon.local.json')];
const values = [
  { private: 'not for mod', mods: { [modId]: { global: true, value: 'global' }, other: { private: true } } },
  { mods: { [modId]: { project: true, value: 'project' } } },
  { mods: { [modId]: { value: 'private' } } },
];
for (let i = 0; i < paths.length; i++) await writeFile(paths[i], JSON.stringify(values[i]));
const execute = () => spawnSync(process.execPath, ['/Users/ra/dev/agon-audit-qualification/packages/cli/dist/index.js', 'settings-fixture'], {
  cwd: project, env: { ...process.env, AGON_HOME: root, AGON_MODULAR_HOST_ROOT: hostRoot }, encoding: 'utf8', timeout: 30000,
});
const first = execute(); assert.equal(first.status, 0, first.stderr);
assert.deepEqual(JSON.parse(first.stdout), { global: true, project: true, value: 'private' });
const disabled = activation.preview(identity, false, 'isolated disable', '2026-10-11T00:00:02.000Z');
await activation.apply(disabled, disabled.planHash);
const second = execute(); assert.notEqual(second.status, 0, 'disabled fixture remained callable');
for (let i = 0; i < paths.length; i++) assert.equal(await readFile(paths[i], 'utf8'), JSON.stringify(values[i]));
console.log(JSON.stringify({ passed: true, root, cliInvocations: 2, ownerSettingsOnly: true, allLayers: true, disabledRejected: true, configBytesPreserved: true }));
