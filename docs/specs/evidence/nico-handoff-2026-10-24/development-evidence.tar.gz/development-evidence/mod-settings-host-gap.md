# Mod settings host integration gap

Checked subject: `77d6b300201ea5309f6188788d0b611169630b37`.
Status: owner-only layered transport committed at f01298af; schemas, defaults
and migration integration remain incomplete.

## Verified facts

- Runtime contract, `docs/specs/modular-agon-runtime-contract.md:406`, requires
  canonical mod namespaces, owner schemas/defaults and pure versioned migrations.
  Disabled/absent settings remain retained. Project settings cannot activate code
  or change trust/permissions.
- `packages/cli/src/surface-authority-runtime.ts:229` supplies
  `config: Object.freeze({})` to generated execution.
- `packages/mcp/src/surface-authority.ts:92` supplies the same empty config.
- `packages/mod-kernel/src/desired-state.ts:479` implements
  `projectRepositoryModSettings`; repository-wide package/test reference search
  found its declaration, public export and unit tests only. This function is not
  wired into execution through a static named reference.
- Core retains nine fields owned by five user-toggleable mods. Moving those
  fields into Kernel would violate the frozen ownership map.

## Next investigation / implementation boundary

Trace other execution surfaces, invocation construction, configuration
registrations and consumers before selecting the shared composition boundary.
Preserve the flat historical Core API/default order through a compatibility
projection, not by giving Core runtime authority over user mods. Determine how
owner defaults and schemas can be read without executing disabled mod code.
Do not introduce Core-to-mod runtime dependencies as an unreviewed shortcut.

Acceptance must exercise actual CLI and MCP invocation, not only the projection
helper: scoped overrides reach the correct enabled owner; disabled/unknown
settings persist but never cause activation; trust/permission escalation is
rejected; historical Core defaults and scope order remain unchanged. Check
schema/default/migration behavior and all other surfaces before claiming the
configuration contract complete.

No new dependency, install, production edit or personal-state change was made
for this investigation. This note records a remaining original requirement,
not an expansion of scope.

## Follow-up transport design trace

The TUI boundary repair is separate and currently under verification. The next
transport increment can reuse the same Kernel namespace selector in the four
empty-context constructors: generated CLI lazy command, CLI Cesar route, CLI
Cesar tool, and MCP tool. Resolve availability first and select by the resulting
registry record owner, never by a caller-provided owner ID. Retain existing stale
generation and capability checks. Documentation rendering has no invocation
config parameter and must not read settings merely for discovery.

Existing `loadConfig(cwd)` uses Kernel `createScopedConfigStore` and three-layer
merge in Core. A shallow root merge currently replaces all `mods` values when
any later layer contains `mods`; blindly feeding this to the four constructors
would lose unrelated owner settings. Resolve this in the existing merge owner,
not with a second filesystem reader or another cache. Merge the namespace map
and each selected namespace's top-level fields in global/project/private order;
preserve legacy non-mod merging and original defaults unchanged. Retain unknown
and disabled namespaces as data; activation still comes only from selected
registry generation. Nested field values retain ordinary replace semantics,
matching existing config behavior rather than inventing recursive merges.

Tests must include two owners across all three layers (to catch whole-map
replacement), partial owner overrides, malformed namespace shapes, absent mods,
cache cloning, actual generated CLI/MCP/Cesar calls, and disabled owners with
settings present. Existing external-surface fixtures can return context.config;
extend them rather than creating another integration framework. A subprocess
fixture should exercise the built CLI with an explicitly trusted local fixture
mod and isolated home, with no providers or personal state.

This design still does not claim owner schema/default or versioned migration
completion. Keep those acceptance cells open until executable owner contracts
are wired to this transport; avoid a second config authority for them.

## Transport increment started

Base: a3ebba913ab6e1d9a1a7c69942f661479321ee4e, clean qualification checkout.
Baseline: tui-settings-boundary-final passed 8,495 tests, six skipped, full
repository/package gates and live config CLI checks.
Implementation authorized by the standing remediation goal. No new dependency.
Expected authored footprint: nine files (Kernel settings/export, Core merge,
four CLI/MCP transport sites, existing config-store and external-surface tests).
Generated release metadata adds three files. Risk: medium; real invocation
payloads and namespace precedence change, non-mod config behavior stays intact.
Use existing cache/store and selected-owner checks. No filesystem state or
activation is created by reading settings. Final full gate follows peer review
and its local corrections, to avoid rebuilding a known rejected subject.

## Transport verification in progress

Test-first failures:
- `mod-settings-layers-red`, SHA-256
  `e1034b92ba7b09550f6c1f44e97e8817df723a840a2ccef14becf0e93b57e5cf`.
- `mod-settings-transport-red`, SHA-256
  `5143731336f235a42929c4e157df3c9288d72a9a1bd9e3393f2b9fca0960b42d`.

Focused build/test/types passed (`mod-settings-transport-focused`, 34 tests).
Expanded route, unknown-value, disabled-owner and namespace checks plus types,
lint and reexports passed (`mod-settings-transport-controls`), log SHA-256
`9a6f61ca1641245189dfaf1733b46ecb141bb648be5d545675dc8e654e9a3d79`.

Default Agon review tree `177e402cb2f983b96c86ab24bb7ff050792ff2cf`.
Packet SHA-256 `cccc2ba30ddb6664a5dc5542656b31c3770095a4468fb44301dad7e810b1c85e`.
Codex found no concrete blocker, moderate overall confidence; raw log SHA-256
`a4324d7642fbf74c8a591432de32e6e11935ba236bd67d23fd85a9cb83adbbd7`.
Kimi exit 1/no answer, not a pass. No authentication repair.
Added requested malformed-settings and stale-generation controls across all four
invocation paths. `mod-settings-review-controls` passed tests/types, log SHA-256
`a5e84e92d17e4a2bfdbb1228ceb8afedeed11cb50e3de3ac825c276a5e9e6d5d`.
The existing store still clones the entire merged config before selection. This
is a cost characteristic, not a measured regression or reason for another cache.

Built-CLI fixture: first attempt failed in fixture setup because a trust record
wrongly included the activation-only publisherHash field; that is harness error,
not product evidence. Corrected to the strict trust shape. The corrected old-
binary run (`mod-settings-cli-old-binary-v2`) reached the command and reproduced
empty settings instead of the expected three-layer values. Log SHA-256
`835977c76249b389b1ac6ea8d4e52fc30b20c08496f498c90e48d90c350c8d85`.
The same fixture must pass after fresh CLI build, then reject invocation after
disable and preserve exact config bytes. Its isolated trust/activation data lives
only below the test runtime temporary directory, never the operator's home.

## Remaining schema/migration source trace

Follow-up source checks (2026-10-11, settings-schema increment in progress):
the nine remaining flat field definitions/defaults live at
`packages/core/src/models/types.ts:50-58` and its default object. Their ledger
owners are Forge (autoReviewAfterForge, forgeFitnessTimeout), Review
(autoReviewAfterImpl, goalReviewEngines), Agent (cesarAgenticContinuationLimit),
Mutate (cesarMutateReflex), Synthesis (forgeEnableSynthesis,
forgeSynthesisTimeout, skillSynthesisThreshold). This is ledger-derived, not a
name-based reassignment. Several actual consumers still read the flat settings
in `packages/forge/src/forge.ts`, `stages-impl.ts`, `team-forge.ts`,
`packages/cli/src/handlers/forge.ts`, `commands/goal.ts`, and `cesar/brain.ts`.
Preserve those public values and optional types while connecting namespaces;
moving literals alone will not make namespace settings affect those workflows.

The package generator emits generic config JSON with `$id`, but the runtime
validator's allowed keyword set does not include `$id`. Published schema use
must account for this annotation before using generated files as registration
payloads. Current first-party implementations register separate generic object
schemas, so changing the generated JSON alone does not alter runtime validation.

No migration reference appears in `managed-lifecycle.ts`,
`activation-service.ts`, or the public Mod API. The existing `config` registrar
accepts schemas only. Do not claim the staged-copy migration engine is integrated
because it has isolated tests. Next work must reconcile the frozen migration
contract with actual lifecycle inputs and preserve N-1/N-2 compatibility.

Verified during the transport gate, without changing its source subject:

- First-party generator `generate-modular-first-party-packages.mjs:109` emits
  generic object/additionalProperties schemas, then hashes/packs them at lines
  172/175. It does not derive nine remaining mod-owned defaults or field types.
- Registrar config payloads are schemas only (`mod-api/src/index.ts:146`). The
  registry stores them as config records (`registry.ts:203`); transport currently
  selects namespaced data without invoking those schemas. Transport green does
  not prove schema enforcement or default application.
- `rg -n migrateStagedCopy packages --glob '*.ts' --glob '!*.test.ts'` finds only
  the Kernel declaration and barrel export. The staged-copy migration engine
  exists, but this scan shows no named production caller. Its isolated tests
  cannot prove config migration is integrated into installation/activation.

Next design must connect existing owners rather than create a second migration
engine. Trace lifecycle staging and static schema assets, preserve the nine flat
legacy field defaults/public types, and avoid foundational Core imports of
disabled mod runtime merely to access defaults. Generated compatibility metadata
from owner-authored static schemas is a candidate, not an accepted implementation
or evidence of completion. Any runtime API extension must retain frozen API and
N-1/N-2 compatibility and the existing trust/registration boundary.

## Transport committed

Commit `f01298af`, tree `5b46259233e9b5948a68f991ef44491ee63d52ed`.
Authored test-expanded subject before generated metadata:
`ff31c457f86a7ab69e193f88ba589cad4225b30c`.
`mod-settings-transport-qualified` passed in 308.976 seconds with zero provider
launches. Log SHA-256
`337c4d1988aa09a880b80c75b0f01e3b35e72e58e477584808d6f996a9305f41`.
Build, typecheck, lint, reexports, API compatibility, release/SBOM validation and
self-tests passed. Repository suite: 8,500 passed, six skipped. Historical
121-field type/default/order comparison passed unchanged.

One four-subprocess legacy config CLI check and one two-subprocess external
fixture CLI check passed after the build. The latter proves three-layer values
reach only the selected owner, explicit disable rejects the command, and all
three config files retain their exact original bytes. It does not prove owner
schema enforcement, migrations or native TUI rendering.

Twelve explicit paths committed (nine authored, three generated release files).
Qualification checkout clean. Candidate branch/index advanced without updating
its working files. The original 281-path preservation check passed before and
after, both log hashes
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
No push, install, global Agon change or personal-state mutation.

## Next ownership and migration boundaries (2026-10-11)

Forge's two definitions are being extracted from fe6e6c8e using its existing
schema as owner input and generated Core compatibility types/defaults. This is
not a runtime import of a disabled mod. Seven fields remain after that slice:
Review owns goalReviewEngines ([]), autoReviewAfterImpl (true); Agent owns
cesarAgenticContinuationLimit (12); Mutate owns cesarMutateReflex (true);
Synthesis owns forgeEnableSynthesis (false), forgeSynthesisTimeout (300), and
skillSynthesisThreshold (3). All remain optional in the legacy public interface.

Current consumer trace (`rg` across package TS excluding generated barrels and
declarations): forge/src/forge.ts:54,787 and cli/src/handlers/forge.ts:634 read
synthesis settings; cli/src/commands/goal.ts:322 reads goalReviewEngines;
cli/src/cesar/brain.ts:2498,2963 reads Mutate/Agent fields. No executable consumer
was found for autoReviewAfterImpl or skillSynthesisThreshold in that scan.
Retain these public fields, not evidence-based deletion candidates in this slice.

Namespace-to-flat compatibility must run per layer before the existing
global/project/private merge. Mapping only the final merged object could allow
a lower-priority namespaced value to override a higher-priority legacy value.
Explicit namespace data within one layer should supersede its legacy alias;
retain unknown/disabled namespaces without activation. This is a planned
compatibility policy requiring executable precedence tests, not implemented fact.

Migration source trace now confirms runtime-contract.md:236 explicitly calls for
declarative data/config migrations on staged copies, and security-and-distribution
lines 295-301 require retained config snapshots and schema versions. Host
CommitGenerationInput already carries immutable extra files; managed lifecycle
currently passes installation.json only. Activation copies its builder's files.
Core config store still reads/writes the mutable legacy config path; it does not
read a generation config snapshot. Connecting migrateStagedCopy only to installer
without connecting readers, ordinary writes and rollback would be incomplete.
Do not label schema ownership or in-memory aliases as durable migration evidence.

Read/write parity risk for the upcoming alias bridge: configSet currently calls
the Kernel store's single-key setter, which retains the namespace unchanged. If
same-layer namespaces win, updating a flat alias while that namespace exists
would silently leave the effective value unchanged. Bridge reads and writes in
one increment, not a read-only mapping advertised as compatibility. Retain the
existing single lock and atomic rename; do not perform two independent writes
or move filesystem mechanics back into Core. An optional owner-policy callback
inside the existing store write transaction is a candidate additive seam; it
needs public compatibility checks and a test for stale-alias updates before use.

## Durable migration integration trace, 2026-10-11

Verified at 257fb2df plus the separately qualifying settings-alias bridge.
The spec skill is used to preserve the original migration requirement; this
section records implementation research, not a claim that migration works.

Owner schemas/defaults are now extracted for all 121 historical fields. The
current bridge addresses only the nine user-mod aliases, in-memory precedence
and atomic ordinary writes. It does not create a durable schema-version record.

Verified production entrypoints and seams:

- `packages/cli/src/commands/setup.ts:49,77-82` constructs the lifecycle service,
  plans and applies installation. Its already-qualified early return at 70-75
  compares package versions and desired selection, not config schema state.
  Migration integration must not be bypassed by this idempotence shortcut.
- `packages/mod-kernel/src/managed-lifecycle.ts:115,145,494,580` defines request,
  plan, apply and host commit. A migration input must be part of the hashed plan,
  not an unbound callback supplied after approval. Existing installer/verifier
  boundaries must still qualify the exact staged candidate before selection.
- `packages/mod-kernel/src/first-party-activation.ts:12,47-54` builds enablement
  generations and retains installation.json only. Adding a settings snapshot to
  setup without carrying it here would lose it on the next enable/disable action.
- `packages/mod-kernel/src/durable-host.ts:90,240-277` already accepts and hashes
  extra immutable files. Reuse that manifest and pointer rather than another
  settings pointer. Reserved files and containment checks remain enforced.
- `packages/mod-kernel/src/host-rollback.ts:80-81` and `durable-host.ts:550`
  restore installed-index/desired-state snapshots only. There is no config
  restore at these locations. Existing rollback recovery must cover any added
  materialization, including failure after the generation pointer switches.
- `packages/mod-kernel/src/scoped-config-store.ts:39-79` reads mutable global,
  project and private files, caches by path/mtime and writes under the legacy
  synchronous config lock. Merely adding a snapshot to a generation leaves
  actual readers unchanged. A changed selected generation must invalidate any
  generation-sensitive cache, and writes must not target an obsolete generation.
- `rg -n 'migrateStagedCopy' packages --glob '*.ts'` still finds only declaration
  and barrel export. `rg -n 'new ManagedLifecycleService|new ModActivationService'
  packages --glob '*.ts'` finds setup and first-party activation respectively.

Required acceptance, not additional product scope:

1. Existing flat config migrates idempotently with exact source backup, unknown
   and disabled namespaces retained, owner versions and receipt hashes recorded.
2. Plan binds source bytes/version and migration descriptors. A concurrent user
   edit causes refusal/replan, never silent overwrite. Callback execution must
   not precede trust or turn declarative discovery into executable mod loading.
3. Actual CLI/MCP/TUI consumers read the selected settings schema; existing
   config commands write through the same authority. Project settings retain
   their current non-activation/non-permission-escalation rules.
4. Enable/disable preserves snapshots; ordinary config edits remain recoverable.
   Update failure preserves the old config, and rollback/recovery restores the
   verified prior schema/config bytes without destructive down-migration.
5. Tests cover existing setup's early return, source edits during preview/apply,
   stale caches/hosts, failure at pointer commit and snapshot restoration, and
   independent old-generation operation followed by re-entry.

Open implementation decision: mutable config materialization versus generation-
selected config with versioned edits. Both need source-concurrency checks and a
single authority; no option is accepted simply because its helper tests pass.
Do not introduce a second config store, silently overwrite post-install user
edits on rollback, or advertise the alias bridge as durable migration completion.

Additional concurrency evidence after alias commit ddf4b761:

- `support-persistence/src/file-lock.ts:97` implements a synchronous callback;
  its records use pid/uuid/hostname/acquiredAt and allow TTL reclamation.
  `mod-kernel/src/writer-lock.ts` uses a different fenced record and asynchronous
  API. Pointing both implementations at the same path is not mutual exclusion.
  Holding the old lock over long async staging is not safe reuse.
- Core `configSet` is synchronous and publicly exported. Converting it to an
  unawaited asynchronous write would break callers; any new managed path must
  preserve that public completion contract.
- CLI and MCP currently select settings from Core loadConfig after checking the
  pinned surface. Generation-aware config cannot quietly switch schemas inside
  that call while executing the old owner implementation.

Options remain under source review, not user-visible product changes:

| Option | Reuses | Additional risk to prove |
| --- | --- | --- |
| Materialize selected snapshot at existing config path | Existing sync API, cache and file layout | Cross-file commit recovery; old pinned reader sees new schema; backup post-install edits before rollback |
| Select settings through existing generation pointer, with version-bound mutable edits outside immutable generation | Existing atomic generation selection and retained rollback generations | Sync write path and lock coordination; cache selection; legacy fallback; retain later edits without mutating hashed generation files |

Neither option may introduce a second independent activation pointer. Exact
source hashes and negative controls must prove preview/apply concurrent edits
cannot be lost. The historical migration receipt in
`evidence/modular-agon-state-migration-qualification.json` only ran nine helper
and envelope tests on the old implementation checkout. Its passed flag is not
evidence of the missing runtime integration; retain it as historical evidence.

## Remaining host composition, source recheck

While activation qualification runs, `rg -n createBrainstormHostServices packages
--glob '*.ts'` confirms CLI and MCP decorators call Core's public facade. The
facade at `core/src/blocks/brainstorm-host.ts` is now 25 lines, not the earlier
large workflow owner. It injects registry/adapter constructors, loadConfig,
classifier, ratings and protocol prompt functions into mod-brainstorm's actual
factory. `mod-brainstorm/src/host.ts` owns dispatch/retry/preflight/dedup/rating
policy and per-invocation binding. Core classifier and glicko files already
forward to their physical owners. Do not mistake those old paths for duplicate
algorithm implementations.

The facade still labels itself A06-HOST-CAPABILITIES with a removal condition:
both decorators must use final effect owners, including configuration. Runtime
loadConfig composition still lives in Core. Removing only the facade today
would duplicate its composition across CLI/MCP or require a deliberate owner
boundary change; it would not itself complete durable config migration.
Reconcile this precise remaining responsibility against the public compatibility
window before deleting a public export. This is not a waiver of owner retirement.

## Config-consumer trace on c2b4c115

`rg -l 'configSet\(' packages --glob '*.ts' --glob '*.tsx'` finds the Core
definition plus eleven caller files: CLI controls, permission-resolver, app,
app-lifecycle, info, intent-meta, cesar-router, config command, onboarding,
models command and engine command. Synchronous completion is observable by
these callers. An async return silently ignored by them is not compatible.

Two additional direct legacy-path readers were confirmed:
`core/src/guards/config.ts:63` reads guardModes from config.json; and
`cli/src/handlers/info.ts:588` reads raw permission scopes for the user-visible
table. The latter separately calls loadConfig for effective permissions. Moving
all settings behind another path would make those views disagree unless they
are migrated too. This is an argument for tracing the whole boundary, not for
weakening guard or permission semantics. No direct production consumer of the
GLOBAL_CONFIG_PATH constant was found beyond declaration and Core re-export in
the corresponding package TS/TSX search.

One isolated default Codex Agon architecture review is running as
`durable-config-design`. It compares materialization and generation-selected
mutable settings against the same full requirements; no alternative is accepted
yet. Its packet reads committed c2b4c115 objects, not ambient source. This is a
bounded design challenge for the unfinished vertical integration, not a second
review of the completed activation-artifact change and not a full paid panel.

## Design review adjudication on c2b4c115

The bounded Codex review completed with exit 0. Packet SHA-256:
`9941a7d004fdc6c60dd640f4270833420b988ea8fc449dfd2ef21762e209f1f3`.
Log SHA-256:
`a3e066b17f98630f124ed860089caa3b03157a3b61466a1cc7158606ca1aca55`.
The log and receipt are `durable-config-design-codex-review.*` beside this note.
It is architectural advice, not an implementation or release receipt.

Source-confirmed findings:

- `scoped-config-store.ts:46-76`: synchronous three-file reads and global writes;
  no generation/schema version in cache identity. Direct project edits remain
  observable existing behavior. Sparse layers must stay sparse.
- `migration-engine.ts:6-11`: arbitrary async callbacks are not a purity boundary.
  `rg -n 'migrateStagedCopy|VersionedMigration' packages --glob '*.ts'` found only
  the implementation and barrel export. There is no production integration.
- `setup.ts:50-51`: installation errors are collapsed to absence; desired state
  comes from a mutable mirror. `host-rollback.ts:83-90` switches the pointer
  before restoring that mirror. An interrupted rollback can expose stale choices
  to a subsequent update. This needs a discriminating production-entrypoint test.
- `mod-api/src/index.ts:146` exposes schema registration, but no migration
  descriptor; manifest schema version 2 is not a settings schema version.
- `security-and-distribution.md:295-307` requires retained config schema snapshots,
  versioned backups and tested downgrade compatibility. It does not say that a
  downgrade must see all edits made by a newer schema.

Do not silently accept review proposals as new requirements:

- A new immutable activation generation for every newly opened project was a
  reviewer inference, not a frozen normative clause. The runtime contract says
  project settings narrow existing mods, cannot activate code, and retain unknown
  values. Read-time pure schema projection with unchanged source bytes remains
  an alternative to evaluate before adding scope-enrollment transactions.
- Historical values versus earlier-generation compatible edits must be checked
  against byte-preserving rollback requirements. Neither deletion of newer edits
  nor destructive down migration is authorized.
- A second synchronous publication lock is a proposed mechanism, not a given.
  Any selected design must prove mutual exclusion across existing writer, rollback
  and recovery paths, with no independent activation pointer.

Next concrete prerequisite: make setup/update derive desired state from the
verified selected generation, not its recoverable mirror. Test actual
`runManagedSetup` with stale and missing mirrors using isolated fixture installs.
No npm install, live provider or personal-state operation is needed for that test.
This prerequisite does not complete durable settings migration.

## Smaller publication mechanism to evaluate next

The review compared the old support-persistence TTL lock with WriterFence and
proposed a second publication gate. Source inspection of
`mod-kernel/src/writer-lock.ts:47-83,85-121,123-147` shows an alternative:
WriterFence already uses exclusive creation, a versioned ownership record,
fence/process identity checks and explicit dead-owner recovery, with no TTL
reclamation. A synchronous client of **that same protocol** could serialize
configSet with host commit, rollback and recovery without a second lock authority.

This is not permission to point the incompatible old config lock at WriterFence's
path. Record creation/validation and recovery semantics must be shared; sync fs
operations must match durability and release behavior. Synchronous configSet can
fail with a typed busy/conflict error rather than block the event loop awaiting
an async lifecycle operation. Staging stays outside the host pointer-commit lock;
source revisions are revalidated while holding that lock before publication.

Status: engineering hypothesis, not implemented or accepted as proven. Verify
all writer/recovery call sites, kill/re-entry, paused owner and concurrent sync/
async clients before selecting it. It may avoid the review's extra gate and the
resulting two-lock-order protocol while preserving the synchronous public API.

## Publication fence completed; migration remains red

2026-10-11, committed 72f50beeb4388a1c4d61729e261b1a747927e830.
The synchronous client of the existing WriterFence protocol is now used by Core
config writes. See config-publication-fence-scope.md for the independent review,
negative controls, 8,603-test full gate and actual multi-process checks. This
removes the need for a second publication lock; it does not add settings snapshots.

New production-entrypoint reproduction: config-migration-source-live.mjs.
It calls the built CLI's setup --plan against an isolated home, changes config.json,
then applies that exact plan through the built ManagedLifecycleService using a
metadata-only fixture installer/verifier. No npm install or provider is invoked.

Receipt config-migration-source-red: exit 1, 0.668 seconds, zero provider launches.
Log SHA-256: f8c026e1144947061bcd2eb5ffc852da3850ba44160a94600434543a5407e840.
Verified result: no error; generation 1 selected. Its complete file list is
desired-state.json, installation.json, installed-index.json and mods.lock.json.
The changed source bytes remain exact, but no config migration output is selected.
Thus this is missing source-bound migration qualification, not demonstrated data
loss. The red assertion requires refusal of a stale source-bound preview.

Source trace for next implementation:
- setup.ts builds a lifecycle request without reading/binding config bytes.
- ManagedLifecyclePlan has no config source/version/hash field; plan hashing
  cannot bind information absent from the plan.
- ManagedLifecycleService.apply only contributes installation.json to the host.
- CommitGenerationInput supports immutable files but no source precondition.
  A check solely before staging would leave a preview-to-commit race.
- The new Core fence now supplies the required serialization boundary. Check
  source revisions under that same host writer fence before pointer selection;
  retain revalidation for external editors that do not participate in the lock.
- No production caller of migrateStagedCopy has yet been introduced. Do not
  substitute a source-hash field alone for migration/read/write/rollback coverage.

Next vertical acceptance remains the five requirements in "Durable migration
integration trace": staged versioned output and exact backup, source binding,
selected-generation consumers, retained edits/rollback, and failure/re-entry
coverage. The existing red probe is the first production-source negative control.

## Reader integration constraints verified during source-binding qualification

Source: qualification checkout based on 72f50bee plus the config-source change.
`rg -l 'loadConfig\(' packages --glob '*.ts' --glob '*.tsx' | wc -l` returns 69
files. This count includes definitions and tests are outside packages; it is not
a count of 69 independent entrypoints.

Four direct owner-context constructors still use selectModSettings(loadConfig):
CLI lazy-commands.ts:145, cli/cesar/tools.ts:70,
cli/surface-authority-runtime.ts:231 and mcp/surface-authority.ts:95.
Their selected surface guards run before invocation, but InvocationContext
(mod-api/src/index.ts:44-51) has no generation identity. Registry.ts:300-304
validates/defaults context.config with the active owner's registered schemas.
Legacy workflow calls into Core loadConfig remain separate from that payload.

The final migration design must bind schema-sensitive reads for in-flight work,
not merely replace globalPath with a latest-generation filename. It also must not
freeze permission/guard revocations into an old settings snapshot. Direct guard
reader core/guards/config.ts:63-68 and permissions inspection
cli/handlers/info.ts:581-615 remain live legacy-file consumers. Preserve their
existing security semantics while moving only the intended owned settings.
No new context mechanism or second store has been implemented by this note.
These are traced integration constraints, not an expansion of the agreed scope.

Source binding is now committed at d7562383. The original stale-preview probe
rejects with MOD_TRANSACTION_CONFLICT, no generation selected and edited source
bytes preserved. The full 8,616-test gate and live checks pass; see
config-source-revision-scope.md for review correction, receipts and exact limits.
The helper migrateStagedCopy still has no production caller. This remains the
next missing vertical integration, not a completed migration subsystem.
