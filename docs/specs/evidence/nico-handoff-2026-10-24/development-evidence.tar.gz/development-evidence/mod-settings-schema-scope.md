# Registered mod settings enforcement

Status: building under the existing remediation goal.
Base: f01298af6e7f65e2bfbca732204b06f6201d8fae, clean qualification checkout.
Baseline full gate: 8,500 tests passed, six skipped; live CLI settings/disable
fixture and historical flat config parity passed.

## Purpose and boundary

Wire owner-registered configuration schemas into actual contribution execution.
Use the registry, which already owns contributions and config registrations,
rather than repeat validation at six host constructors. Existing host selection
continues to provide owner-only settings. Before a registered command, intent,
tool or plan step runs, resolve defaults and validate against its own owner's
committed config schemas. Return an immutable snapshot and preserve other context
fields, cancellation and stream return shape. Disposed owners cannot execute a
retained contribution. This does not replace selected-generation host checks.

Defaults apply only to absent fields, never explicit false/zero/null. Use the
existing supported JSON schema subset and existing validator. Detect conflicting
default proposals rather than let registration order choose. Unknown namespaces
remain retained in storage; no configuration file is rewritten. Schema errors
must stop execution, with owner attribution and no configuration value dump.

Expected scope: Kernel mod-settings and registry, registry/external-surface
tests; generated release metadata follows build output. Medium/high risk because
the shared registration boundary handles every executable contribution. Preserve
all existing public API signatures and N-1/N-2 compatibility. No new dependency,
installer, migration registry, external config surface or activation path.

## Acceptance and remaining work

Test the absent/default/explicit/invalid/other-owner/disposed cases, async and
streaming outputs, and registration-order-independent conflict refusal. Extend
the external CLI/MCP/Cesar fixture to register a real schema, with defaults and
an invalid setting control. Full repository/package gates, default Agon review
and built CLI invocation must pass before committing.

Still separate original requirements: owner-authored concrete schemas/defaults
for nine remaining first-party fields, flat compatibility generation, and
versioned migration lifecycle integration. Generic first-party schemas do not
become complete merely because the registry enforces them.

## Current implementation evidence

Test-first `mod-settings-schema-red` failed against the previous registry's
unmodified execution payload. Log SHA-256:
`f40d3ffd760636eaed98d4d26655bc3fd3340c71e68349acb38bbbba19c773fc`.

Registry wrappers preserve synchronous/async/stream return shapes and only inspect
the invoked owner's config records, using the existing owner-key index rather
than scanning every registry record. Owners with no schema keep their context
unchanged; disposed records fail before invoking the retained run callback.
Default resolution retains explicit values, applies object/property defaults,
rejects conflicting field proposals independent of registration order, and uses
the existing schema validator. No settings persistence or activation is added.

`mod-settings-schema-focused` passed 11 registry tests and typecheck, log hash
`9d3896c1b85dd9ff4524235c2ecd6d2ff352e1b9a2231ce2920f59e8d49f6ac8`.
`mod-settings-schema-controls` passed Kernel build, 72 tests across registry,
CLI parity, external surfaces and Brainstorm TUI, plus typecheck. Log hash
`da23315760e2516925cd3d675d15260576b79cc9b131754ed62f643630b2c073`.

The external surface fixture now registers a real schema and expects a default
in CLI/MCP/Cesar outputs. Its verification is running. Peer review, full gates,
and a built-CLI schema/default/invalid-value check remain required before commit.

## Independent review and correction

Reviewed staged tree: `13247c7bcd3d618052d56000175991b0c9b0e2e2`.
Packet SHA-256: `9309077404f300b406ecbc179b0bec66e684d2d4d472a737926281a738dbfc76`.
Codex review exited 0; log SHA-256:
`33814c23f79dce42370141cfe7587262f8f549130f391054880591b56b0673e7`.
Kimi exited 1 with no review; not counted as a passing reviewer.

Both reported correctness findings reproduced before correction:
disjoint nested defaults were rejected as conflicts, and defaults below an
additionalProperties schema were skipped. `mod-settings-schema-review-red`
failed exactly those two tests (13 passed), log SHA-256:
`9d9d6926e30dc976b1d7aa97999feecd7b00efad568a6ee2856aff55120bbdc9`.
The resolver now combines compatible nested proposals and traverses existing
additional properties under their declared schema. Explicit values still win;
overlapping conflicting leaves still fail in both registration orders.
Tests also cover defaults inside array items. Local re-verification is running.

`mod-settings-schema-invalid-surfaces` passed actual CLI/MCP/Cesar rejection and
typecheck, SHA-256 `dcc095a4c66ac4f6fc472f964ff794e7905523dfda867e051bb430b80ff2c0bb`.
`mod-settings-schema-surfaces` passed tests/types/lint/re-export checks,
SHA-256 `419ef1b1359a2f128e5186337cbc7623abfe4ec5e0f26483ebaaf5a67a3838b1`.

The receipt named `mod-settings-schema-old-binary` is NOT a negative control:
the existing built CLI loads the newly built Kernel, so all three subprocess
checks passed (default, invalid-value refusal, disabled-mod refusal). Preserve
the misleadingly named receipt, but classify it as current runtime evidence.
SHA-256 `3296c1ce82f80bd7bfe4674b9e396269fc42596c288814a3c869c96e3852ff5a`.
The original test-first receipt remains the pre-implementation negative control.
All these verification runs recorded zero provider launches.

Review caveat: validation errors include property paths, not scalar values.
Property names can be user-controlled. This is not a claim of full error-text
redaction. First-party schema authoring and migration wiring remain unfinished.

## Committed qualification

Commit `86a87d8284360775e88c7719b1b2cd07949882ac`, tree
`bebe9b7aed88a934706e610276850e94b02bea8d`.
The qualification checkout is clean. Candidate branch advanced by compare-and-
swap plus index-only read-tree; candidate working files were not replaced.
Both preservation checks passed all 281 tracked baseline paths with the existing
authorized exceptions; both log hashes are
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.

`mod-settings-schema-qualified` passed in 309.056 seconds: build, typecheck,
lint, re-export guard, API compatibility, release-set and SBOM verification plus
self-tests, full repository suite (8,512 passed, six skipped), exact historical
121-field config parity, four legacy CLI subprocess checks, and three registered
schema CLI subprocess checks. No providers launched.
Log SHA-256: `9e7b1481ec5c4673732a54193eda143a5588b6abdc687cf5b140dd90a86a293f`.

Additional coverage verifies all six executable kinds, other-owner schema
isolation, synchronous results, invalid-value refusal before execution, and
retained-handle refusal after owner disposal. Focused receipt:
`mod-settings-schema-all-kinds`, SHA-256
`b5eb0e413fb024d38240d9588d2bf7073923581ead787b9665af8e4d0b0fd1d2`.
Both peer defects are corrected and included in the full gate. This is component
qualification, not clean-install or whole-release acceptance. Nothing pushed.
