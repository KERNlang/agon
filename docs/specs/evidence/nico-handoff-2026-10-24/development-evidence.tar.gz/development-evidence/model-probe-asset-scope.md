# Model-probe asset ownership

Status: locally committed and qualified under the existing remediation goal. No release acceptance.
Base: 2e6dacb2c4d58a5696283f9fd6a76681971749cb (clean qualification worktree).

## Verified gap and bounded correction

The engine-runtime package ships python/agon-model-probe-wrapper.py. Catalog's
resolveAgonModelProbeWrapper searches four legacy CLI locations and never that
physical owner. Claude model refresh calls it before falling back to the upstream
probe. Existing tests cover the installed CLI sibling but not runtime-only assets.

Move the existing resolver to engine-runtime, next to its asset. Catalog imports
and reexports the same function. Add the canonical python location first. Preserve
the optional module URL argument and every legacy candidate in its current order.
No dependency, installation, Python implementation, provider invocation, or asset
deletion. Engine catalog already depends on engine runtime. This is one migration
prerequisite, not retirement of every copied asset.

## Blast radius and contracts

Four authored files: runtime model-probe resolver and barrel, catalog registry,
existing cli-model-probe test. Release metadata may require three generated files.
Search: rg -n 'resolveAgonModelProbeWrapper' packages scripts tests, excluding dist:
one production caller (catalog refresh), one implementation, two test references.
Core and catalog public wildcard exports must remain compatible. Runtime gains an
additive export. Risk: locating the wrong package asset or losing legacy fallback.

Binding rule: refactor skill says "Keep public entry points stable during the
migration"; repo source rule requires exports at their physical owner.
Current build/type/lint/full-test baseline: plan-artifact-qualified receipt, 8,440
passing tests, six skips; post-commit architectural checks at this exact base pass.

## Acceptance

Existing legacy resolution and provider-stub tests remain green. Tests first prove
runtime src/dist layouts fail; then prove canonical precedence and absent null.
Default resolver must return the actual physical runtime asset without launching
providers. Independent package builds, repository gates, public compatibility,
pack-content and generated metadata checks must pass. Default isolated Agon review
required before commit; fixes get local verification. No global installation or push.

## Remaining scope

Copied Python retirement, TUI path ownership, Doctor's history-search resolver,
Brainstorm configuration binding, full ownership ledger and release qualification
remain separate open requirements. No broad claim from this resolver fix.

## Evidence and review

Negative control: model-probe-owner-red failed exactly three canonical lookup /
precedence cases; 20 passed. Log SHA-256:
b351d765d935b4fa257356a6a5363bc11f550e696d2cd53fde3d45aca35a0780.
Focused independent builds, 24 tests, types, lint and re-export guard passed in
72.412 seconds (model-probe-owner-focused). Log SHA-256:
5bb103e797c11e66b7bdaffd11b0f1fe586b0b7f225a33bd670527056c237cbe.

Agon review subject: staged tree 57cc564ffbe2a8dff2478225eb6f5592f0fea0fe.
Packet SHA-256: 7f7a5be63d2a9ea4b464f3f8092195615050724854c6e25784f7cc0a7e678d08.
Codex found no blocking defect; raw log SHA-256:
f6a83dd74e70784e97867945da10ba207f7eddb8dd0e73badbe455256209a5e8.
Kimi returned no answer, exit 1; no auth repair attempted. Raw log SHA-256:
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.

The review correctly identified that synthetic path fixtures do not prove built
package behavior. Added all three other legacy layout fixtures. The external
model-probe-packed-proof.mjs packs and extracts actual runtime/catalog tarballs
outside the repository, copies the existing zod dependency without installing,
imports both built exports, verifies identical resolver identity and exact asset
bytes with no CLI package, then withholds only its fixture asset and requires null.
This is a package-resolution proof, not live-provider or complete installation
qualification.

Final receipt model-probe-owner-qualified passed in 334.482 seconds: full build,
types, lint, re-export guard, eleven independent support builds/packs, compatibility
check, 27 asset pairs, release-set and supply-chain checks with self-tests, and
8,448 repository tests (six skipped). Log SHA-256:
92f23e5b8c1fb48faaaad6134357dd493a27c1d75c53bb2d7a6f47603d7db856.

First packed proof failed on macOS /tmp versus /private/tmp path identity, not
missing bytes. The fixture now canonicalizes its freshly created directory before
constructing expectations; production code unchanged. The corrected actual
tarball-load proof passed, including the missing-asset negative control, in
0.775 seconds. Receipt model-probe-owner-packed-realpath; log SHA-256:
a4f38cb144d2a3b6bd24981d29f46ad0c4199daf4a6f1173364b6d3c40dd657c.
All local gate/proof receipts record zero provider launches. Agon source review
is separately identified above; it is not included in that zero-launch statement.

Commit: 7cb51822c2f111932938c8d8499f479033edce1e.
Tree: 8aa403dc44a9d7461bc8762404db09a7a9ff8169.
Seven paths: four authored, three generated release metadata. The reviewed
production source is unchanged; review follow-up adds only three fallback cases.
Candidate branch/index advanced without writing its working files. Original WIP
preservation checks before/after both pass with log SHA-256:
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
No install, push, personal-state change, global Agon change, or copied-asset deletion.

## Next verified consumer mismatch

At 7cb51822, cli/src/commands/doctor.ts:268 resolves every EXPECTED_SIDECARS
entry through resolveDedupSidecar, including history-search.py. Its success sample
at line 283 uses that same legacy path. Actual semantic history execution in
support-persistence/src/history-search-bridge.ts calls resolveHistorySearchSidecar,
which accepts only the persistence-owned python/history-search.py. The persistence
barrel exports that resolver; CLI already declares support-persistence.

Verified source mismatch: Doctor can examine a different file than the executing
bridge. Inferred runtime consequence, not yet reproduced: a missing physical
persistence asset can be masked by a healthy legacy dedup copy; absent legacy
history copy can falsely fail Doctor despite an available physical owner.

Next bounded fix: reproduce both directions with existing Doctor tests, then use
the actual history resolver for that filename, preserving other sidecar checks and
Python dependency probing. Error/repair wording must identify physical owners
rather than promising all five scripts reside in agon-dedup. No dependency edge
is needed. Do not remove the legacy asset until its other consumers are migrated.
