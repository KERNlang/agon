import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, renameSync, rmSync } from 'node:fs';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = '/Users/ra/dev/agon-audit-qualification';
const fixture = realpathSync(mkdtempSync(join(tmpdir(), 'agon-model-probe-packed-')));
const modules = join(fixture, 'node_modules');
const require = createRequire(join(root, 'package.json'));
const packages = ['engine-runtime', 'engine-catalog'];

function run(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8', timeout: 60000,
    env: { ...process.env, npm_config_ignore_scripts: 'true', npm_config_offline: 'true',
      npm_config_cache: join(fixture, 'cache') } });
  assert.equal(result.status, 0, result.error?.message ?? result.stderr);
  return result.stdout;
}

try {
  const packed = [];
  for (const name of packages) {
    const payload = JSON.parse(run('npm', ['pack', '--json', '--ignore-scripts',
      '--offline', '--pack-destination', fixture], join(root, 'packages', `support-${name}`)))[0];
    const destination = join(modules, '@kernlang', `agon-support-${name}`);
    mkdirSync(destination, { recursive: true });
    run('tar', ['-xf', join(fixture, payload.filename), '--strip-components=1', '-C', destination], fixture);
    packed.push({ name, integrity: payload.integrity, files: payload.files.length });
  }
  // Copy the installed dependency into this fixture. Do not resolve or install it.
  cpSync(dirname(require.resolve('zod/package.json')), join(modules, 'zod'), { recursive: true });
  const runtime = await import(pathToFileURL(join(modules, '@kernlang/agon-support-engine-runtime/dist/index.js')));
  const catalog = await import(pathToFileURL(join(modules, '@kernlang/agon-support-engine-catalog/dist/index.js')));
  const wrapper = join(modules, '@kernlang/agon-support-engine-runtime/python/agon-model-probe-wrapper.py');
  assert(!existsSync(join(modules, '@kernlang/agon')));
  assert.equal(catalog.resolveAgonModelProbeWrapper, runtime.resolveAgonModelProbeWrapper);
  assert.equal(catalog.resolveAgonModelProbeWrapper(), wrapper);
  assert(readFileSync(wrapper).equals(readFileSync(join(root,
    'packages/support-engine-runtime/python/agon-model-probe-wrapper.py'))));

  // Missing packed bytes must not resolve to a workspace copy.
  renameSync(wrapper, wrapper + '.withheld');
  assert.equal(catalog.resolveAgonModelProbeWrapper(), null);
  renameSync(wrapper + '.withheld', wrapper);
  assert.equal(catalog.resolveAgonModelProbeWrapper(), wrapper);
  console.log(JSON.stringify({ packed, outsideWorkspace: true, cliAbsent: true,
    sharedPublicFunction: true, ownedAssetBytesMatch: true, missingAssetControl: true,
    providersInvoked: 0, installs: 0 }));
} finally {
  rmSync(fixture, { recursive: true, force: true });
}
