// Diagnostic guard for isolated fixture runs; not a security sandbox.
const cp = require('node:child_process');
const { syncBuiltinESMExports } = require('node:module');
const { readFileSync, realpathSync, existsSync } = require('node:fs');
const { dirname, basename, join } = require('node:path');
const blocked = /(?:^|[\s/])(agon|kimi|claude|codex|opencode|gemini|agy|mistral|openrouter|open|osascript)(?=\s|$)/;
function isProviderFixture(file) {
  const normalized = file.replace(/^\/tmp\//, '/private/tmp/');
  if (!/^\/private\/tmp\/(?:amr-runtime|agon-pressure-[a-z0-9_]+\/runtime)\/tmp\/agon-provider-stubs-[^/]+\/(claude|codex|agy|opencode|mistral|openrouter)$/.test(normalized)) return false;
  const expected = `#!/bin/sh\necho "${basename(file)} $*" >> "${join(dirname(file), 'calls.log')}"\nexit 97\n`;
  return realpathSync(file) === normalized && readFileSync(file, 'utf8') === expected;
}
function check(command) {
  const text = String(command);
  const normalized = text.replace(/^\/tmp\//, '/private/tmp/');
  if (/^\/private\/tmp\/(?:amr-runtime|agon-pressure-[a-z0-9_]+\/runtime)\/tmp\/agon-s9-npx-[^/]+\/Agon Home ü with spaces\/bin\/agon$/.test(normalized)) return;
  if (isProviderFixture(text)) return;
  if (['claude', 'codex', 'agy', 'opencode', 'mistral', 'openrouter'].includes(text)) {
    const first = (process.env.PATH || '').split(':').map(dir => join(dir, text)).find(existsSync);
    if (first && isProviderFixture(first)) return;
  }
  if (blocked.test(text)) throw new Error('Fixture run refused external CLI/browser launch');
}
for (const method of ['spawn', 'spawnSync', 'exec', 'execSync', 'execFile', 'execFileSync']) {
  const original = cp[method];
  cp[method] = function(command, ...args) { check(command); return original.call(this, command, ...args); };
}
syncBuiltinESMExports();
