import { createHash } from 'node:crypto';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';

const repo = '/Users/ra/dev/agon-audit-qualification';
const evidence = '/Users/ra/dev/modular-agon-remediation';
const source = readFileSync(join(repo, 'tests/unit/modular-candidate-process.test.ts'), 'utf8');
const block = source.slice(source.indexOf("  describe('installed payload file limit'"), source.indexOf("  it('bounds descendants"));
assert(block.includes('await setup?.catch'));
const root = mkdtempSync(join(evidence, 'payload-hook-controls-'));
const results = [];
for (const scenario of ['late-root', 'late-writes', 'write-failure', 'assertion-failure']) {
  const dir = join(root, scenario);
  mkdirSync(dir);
  const events = join(dir, 'events.json');
  const prelude = `
import { beforeAll as registerBeforeAll, afterAll, describe, it, expect } from ${JSON.stringify(join(repo, 'node_modules/vitest/dist/index.js'))};
import * as fs from 'node:fs/promises';
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { hashInstalledPackagePayload as hashPayload } from ${JSON.stringify(join(repo, 'packages/mod-kernel/src/folder-mod-bounds.ts'))};
const scenario = ${JSON.stringify(scenario)};
const state = { root: null, inFlight: 0, writes: 0, cleanupStarted: false, writesAfterCleanup: 0, cleanupWithPending: false, removed: false };
const save = () => writeFileSync(${JSON.stringify(events)}, JSON.stringify(state));
const delay = () => new Promise(resolve => setTimeout(resolve, 100));
const tmpdir = () => ${JSON.stringify(dir)};
const beforeAll = fn => registerBeforeAll(fn, scenario.startsWith('late-') ? 20 : 30000);
const mkdtemp = async prefix => {
  if (scenario === 'late-root') await delay();
  state.root = await fs.mkdtemp(prefix); save(); return state.root;
};
const writeFile = async (...args) => {
  state.inFlight++; state.writes++;
  if (state.cleanupStarted) state.writesAfterCleanup++;
  try {
    if (scenario === 'late-writes') await delay();
    if (scenario === 'write-failure' && args[0].endsWith('/file-0.js')) throw new Error('INJECTED_WRITE_FAILURE');
    return await fs.writeFile(...args);
  } finally { state.inFlight--; save(); }
};
const rm = async (...args) => {
  state.cleanupStarted = true; state.cleanupWithPending = state.inFlight !== 0; save();
  await fs.rm(...args); state.removed = true; save();
};
const { readdir, unlink } = fs;
const hashInstalledPackagePayload = path => scenario === 'assertion-failure'
  ? Promise.reject(new Error('INJECTED_ASSERTION_FAILURE')) : hashPayload(path);
`;
  writeFileSync(join(dir, 'fixture.test.ts'), prelude + block);
  writeFileSync(join(dir, 'vitest.config.mjs'), 'export default {test:{include:["fixture.test.ts"],hookTimeout:30000,testTimeout:30000,maxWorkers:1}};');
  const result = spawnSync(process.execPath, [join(repo, 'node_modules/vitest/vitest.mjs'), 'run', '--root', dir,
    '--config', join(dir, 'vitest.config.mjs')], { cwd: repo, env: process.env, encoding: 'utf8', timeout: 60000, maxBuffer: 2 ** 20 });
  const log = `${result.stdout ?? ''}\n${result.stderr ?? ''}`;
  writeFileSync(join(dir, 'run.log'), log);
  assert.equal(result.error, undefined);
  assert.equal(result.status, 1, `${scenario}: expected a failing suite`);
  const expected = scenario.startsWith('late-') ? 'Hook timed out in 20ms' : scenario === 'write-failure' ? 'INJECTED_WRITE_FAILURE' : 'INJECTED_ASSERTION_FAILURE';
  assert(log.includes(expected), `${scenario}: wrong failure`);
  const state = JSON.parse(readFileSync(events, 'utf8'));
  assert.equal(state.inFlight, 0);
  assert.equal(state.cleanupWithPending, false);
  assert.equal(state.writesAfterCleanup, 0);
  assert.equal(state.removed, true);
  assert.equal(existsSync(state.root), false);
  if (scenario === 'late-root') assert.equal(state.writes, 0);
  if (scenario === 'late-writes' || scenario === 'write-failure') assert.equal(state.writes, 32);
  results.push({ scenario, exitCode: result.status, state, logSha256: createHash('sha256').update(log).digest('hex') });
}
const receipt = { sourceSha256: createHash('sha256').update(source).digest('hex'),
  fixtureBlockSha256: createHash('sha256').update(block).digest('hex'), root, results, passed: true };
writeFileSync(join(root, 'receipt.json'), JSON.stringify(receipt, null, 2));
console.log(JSON.stringify(receipt));
