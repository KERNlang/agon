# Plan Agent/Review physical ownership

## Scope

Next bounded extraction after Cesar/Self acceptance. Keep the current qualified
inline executors as the compatibility oracle. Move Review, Agent and Team Agent
step orchestration into the existing mod-plan package; leave CLI session effects
in the composition root. Do not execute the Pipeline or live providers.

Read-only consumer tracing found the candidate factory at
`packages/mod-plan/src/agent-review-step-execution.ts`, its exports in
`packages/mod-plan/src/index.ts` and the first-party generator, one CLI consumer,
two owner/parity test files, and a frozen fixture. Expected integration surface:
eight paths including the generated migration ledger. Existing admission tests
must continue unchanged unless adding discriminating assertions.

Risk: high at cancellation, authority and result boundaries. The candidate draft
is older than accepted Agent fixes. Its host returns Promise<unknown> and both
Agent branches ignore terminal outcomes. Its tests regard undefined output as
success. Importing it unchanged would restore the false-success defect already
covered by `modular-plan-step-admission.test.ts`.

## Required retained behavior

- The qualified CLI wrapper retains withProcessSurfaceAuthority and its child
  signal. Merely moving the assertion into the factory is insufficient.
- Agent and Team Agent keep executionRefusal, parent-signal forwarding, terminal
  status checks, incurred usage and bounded captured output on failure.
- Review keeps uncommitted target selection, intent-enriched labels, explicit
  reviewer selection, parse-failure refusal and stateless backend operation.
- No mutable HandlerContext or private legacy import crosses into mod-plan.
- Preserve current backend calls and public exports. Do not add dependencies.

## Evidence required

Use existing tests and frozen current-source fixtures. Prove the draft fails
terminal-outcome controls; correct the owner contract before composition.
Compare raw results and host calls against the exact accepted inline bodies.
Run real durable-generation admission and existing compiled provider barriers.
Run full build, types, lint, re-export, generator and roadmap checks plus tests.
Request one bounded default-review pass through isolated Agon; adjudicate each
finding from source and controls. Missing authentication is external evidence,
not permission to change personal credentials or bypass review isolation.

No production edits started in this slice. Cesar/Self final qualification is
still running; its subject stays frozen until completion.

## Implementation and controls

Cesar/Self was committed as f91bd221 before these changes. The older candidate
factory and owner tests were copied selectively, not its CLI or frozen fixture.
Thirteen new controls failed against that draft: ten false-success outcomes
and three calls that began effects with an already-aborted signal. Receipt
`plan-agent-review-draft-red`, log SHA-256
`0304f3256fe99a804844fb153ca8a56ebf6c14c61476cb421932350b14c0f8aa`.

The owner now uses a narrow outcome contract and the qualified terminal-status
checks. Entry checks cancellation before host effects. Positive fixtures now
return actual completed outcomes rather than undefined. Current CLI composes
three physical executors while retaining its monitor wrapper and live refusal
closures. No dependencies or ownership assignments changed.

`plan-agent-review-composition`: package build, types and 172 owner/admission
tests passed; log SHA-256
`35d941006323ba8a3023c6e7fd3b7dcaf104493ec5ca35eb75c80e358cfa3d4f`.
`plan-agent-review-raw-parity`: 87 tests (35 owner, 51 raw comparisons, one
boundary assertion), types and focused lint passed; log SHA-256
`ea775e6abd158686e3f08decf17b955f243349d3022dc7b458e54032cf4ba70a`.
The fixture contains the current f91bd221 bodies, not the stale candidate
oracle. All result fields and serializable host calls are compared unchanged;
callback behavior and signal/context identity are asserted at the boundary.

Eight paths staged at tree `1b1ad46db38837428768e7d31beb69d5008d52a6`.
Generated first-party and roadmap checks passed (`plan-agent-review-generated-check`,
SHA-256 `2bf72fbbabe2e87694b7a723a8315a3013d06904ad1e83bde0b9439f591e4ae7`).
Full qualification `plan-agent-review-integration-full` runs on handle 10820.
Default Agon review handles: Codex 16420, Kimi 34493. Source stays frozen until
the gate and reviews finish. No acceptance or commit claimed yet.

## Independent review

Frozen packet SHA-256
`99c7d66b76f5f7b12d67aaeec27ade27e78b140aed455ad9c3ac603fb46303a5`.
Codex found no concrete production regression, but identified a real evidence
weakness: assertions inside backend mocks can be caught by both executors and
converted into matching failures. Those assertions need to run after execution,
and positive scenarios need independent success assertions. Review log SHA-256
`7c891ae6faa03bf294d227dfa1fdf7f891478e44fb9a56b70733c64dc10d88fa`.

The second question asks for retained refusal/monitor cleanup evidence. Existing
`modular-plan-step-admission.test.ts` lines 134-160 checks the same retained
executionRefusal callback before and after real Plan/Agent generation changes
for both Agent modes, with observations asserted outside the backend. Lines
428-445 prove cooperative cancellation of a pending backend after generation
revocation; lines 473-495 verify monitor and parent-listener cleanup on success,
rejection and cancellation. These tests remain in full qualification, but a
combined Agent-mode pending-backend control would make the composition evidence
more direct. No production defect is inferred from this coverage question.

Kimi again returned no answer (Agon exit 1); log hash matches the prior isolated
authentication failure exactly. No login attempted. Its wrapper exited zero,
so wrapper completion alone is not review success; the engine receipt records
the failure. Missing Kimi review remains external. Both review handles ended.
Do not rerun a model panel after local evidence corrections.

## Review adjudication and final snapshot

Confirmed the swallowed-assertion finding with a deliberate false context
assertion inside both backend mocks. All 52 parity tests still passed. Receipt
`plan-agent-review-swallowed-assertion-control`, SHA-256
`52a5b5ad1e74d5ed47971b9ccd6eb18332bf70736741c63ec50a5cbd48ebc291`.
That receipt is evidence of a weak oracle, not a correct implementation.

Moved observations outside executor catches and added independent expected
success/failure assertions. The same false context assertion outside the catch
now fails: `plan-agent-review-boundary-negative`, SHA-256
`fb66bfecbd84b1ab5320b0e95ffbdd43f14c8b598e5deb6c3bd2802c148ef205`.
The deliberate mutation was restored immediately in finally.

Added two direct pending-backend checks to the existing admission suite: Agent
and Team Agent retain the same refusal callback, a real generation disable
aborts their monitored child signal, the parent stays unmodified, the callback
refuses after revocation, no successful context is exported, and the monitor
and parent listener are removed. No production change was needed.
`plan-agent-review-evidence-fixed` passed 191 tests, types and focused lint;
SHA-256 `75cff99599b155cdd5342f8b6056aedeee00c06377e72058e1cc69d5bf55fbd3`.

Exact fixture provenance was checked against f91bd221: full-source SHA-256
`2e2fa6d1022a43f9ecaa86a85dee6b1667c748f1e66f94f328fe6690233726aa`,
body SHA-256 `5aebe8d6afe9193f9eab22ee114830aa8f0dbaf3be5ae7b223bf36d0607035eb`,
fixture SHA-256 `5590ec409bd479da5b00321a15f81017b9f1e2aed22ee85aefde4250a1374479`.
The fixture contains that raw body unchanged.

Pre-correction full qualification passed 7,965 tests plus six skips and 21
compiled-process checks. Receipt `plan-agent-review-integration-full`, SHA-256
`87eaf821a25321a5988c115239537d183113d08261d6cf6a78ee8f38c3aa223d`.
Final nine-path subject is tree `4de2cc7d987873efb28246c2e81195e789ca4053`.
`plan-agent-review-reviewed-full` is running on handle 41550. Only test evidence
changed after the review; production source is unchanged. No commit yet.

## Qualification failure: Forge finalize investigation

`plan-agent-review-reviewed-full` failed: 7,966 tests passed, six skipped,
one failed. `forge-finalize.test.ts` reported e4.pass=false in the explicit
earlyFinalizeCount=0 test. Build/types/lint/structural gates passed, but compiled
post-suite checks did not run because the shell stopped on failure. Receipt
SHA-256 `d0e7b109930d041c914ead779f393ddce7c10b5f8ad0e324dd4661fa244abed3`.
No commit or candidate ref advancement is permitted from this result.

Standalone reproduction passed all seven Forge tests (`plan-agent-review-forge-failure-repro`,
SHA-256 `8e8930ad92b21d518a0a5bc60665f144efc699fe050548a65d0be1ce06b46477`).
The failing full-suite case took 6,278ms versus 1,272ms standalone. Its fixture
sets forgeFitnessTimeout=1 second, but timeout is only a hypothesis: the original
assertion omitted the result and fitness log, and teardown removed the files.
No timeout or result oracle was changed.

Added a diagnostic assertion message with the actual EngineResult and fitness
log in this one test. First full diagnostic run passed all 7,967 tests plus six
skips (`plan-agent-review-forge-diagnostic-suite`, SHA-256
`d6a6175935ee34f5329d9568fd2834e808d9ff74e10feb0667b6b684c70f2d17`).
This does not prove the intermittent defect fixed. Three sequential full-load
diagnostic runs are running through handle 29304, IDs
`plan-agent-review-forge-diagnostic-load-1` through `-3`, stopping on first
failure. The diagnostic is unstaged; the nine-path extraction remains staged.
Do not treat a later green rerun as root-cause evidence on its own.

All three additional diagnostic full-load runs passed 7,967 tests plus six
skips. Log SHA-256 values:

- load-1: `3324504d9e8c678ae0184c3c2a8971b9b1dcae0d3d96dfa315972a8d61532682`
- load-2: `5bf78c3dff73debf42c1e508c6818dd7e86dc9c539b839e4887d844cce938170`
- load-3: `ed91383ee4e94d7983be37d6a973d86f274a0a9d344669f6c735316b2202cc05`

Handle 29304 has ended. No test runners from this investigation remain active.
A read-only process check during load-3 showed only that full-suite runner,
not overlapping qualification runs. A temporary-artifact search has also ended.
Forge writes its manifest, result bundle, fitness logs and sidechain inside
the per-test forgeDir, which the test's afterEach deletes. No retained original
fitness log was found. Engine memory retains scores, not the missing failure
reason, so it cannot discriminate timeout from other fitness failures.

Current verdict: extraction behavior verified by focused tests and raw parity;
qualification is not accepted because the intermittent Forge failure remains
unexplained. Four later full passes do not erase the failed receipt. Keep the
diagnostic assertion. Do not change production logic, increase timeouts, weaken
assertions or commit this slice merely to obtain green. Next investigate the
one-second fitness subprocess boundary with bounded, discriminating controls
and retained raw failure artifacts; avoid more blind whole-suite reruns.

Qualification HEAD and candidate ref remain f91bd221. Nine-path staged tree is
`4de2cc7d987873efb28246c2e81195e789ca4053`; only the Forge diagnostic assertion
is unstaged. Candidate worktree bytes remain untouched. Remaining Plan build-step
scope is recorded in `plan-build-step-extraction-scope.md`, not started.

## Controlled fitness-boundary evidence

The first timeout control matched an earlier repeated fixture command, not the
selected case; `forge-finalize-fitness-deadline-control` is INVALID evidence for
the hypothesis. It was restored. Subsequent patches include the unique
earlyFinalizeCount=0 context, preventing that targeting mistake.

The corrected control adds 1.2 seconds only to e4's fitness command. At the
fixture's one-second budget it fails with e4 engineCompleted=true, dispatchStdout
`e4 done`, diff gate passed, syntax valid, exit 124 and Timed out=true.
This proves the assertion can fail from subprocess timing despite correct
finalize behavior. It does NOT retrospectively prove the missing original log
had the same reason. Receipt `forge-finalize-fitness-deadline-targeted`, SHA-256
`321db55f85d5c4dfe4343df28a496496885a18f696a578fcbdc322f20cee01ff`.

Changed only this suite's fitness fixture budget from one to five seconds,
within its unchanged 15/30-second test budgets. No production timeout, pass
assertion, quorum threshold or global test deadline changed. Added an explicit
engineCompleted assertion and retained the raw failure diagnostics. This
supersedes the earlier no-timeout-change precaution with a demonstrated
fixture-coupling correction, not a claim that the original cause is proven.

The same 1.2-second e4 control now passes:
`forge-finalize-fitness-budget-control`, SHA-256
`bccde91dd2db424bef9e7151784c1cbde1e72783f200815ac0858da48b8df49f`.
Changing only earlyFinalizeCount from 0 to 1 with that valid delayed candidate
makes the test fail: `forge-finalize-early-cancel-negative`, SHA-256
`6d416a93ce87c844496b4a24350f6a940a896b328ce949070901273d3af2c293`.
Both temporary mutations were restored. The policy oracle still detects early
cancellation; it no longer requires valid fitness to finish inside one second.

`forge-finalize-fixture-check` passed all seven Forge tests, typecheck and lint;
SHA-256 `bfaa1e78166a9774057bd9595cabf9233fa1b75661980675f8c240392a09d648`.
The controlled evidence supports the fixture correction. Original sporadic
failure cause remains inferred because the initial raw fitness log is absent.
Preserve that distinction if it recurs; do not infer that every future Forge
failure is a timeout. The pass and quorum assertions remain unchanged, with
an additional engineCompleted assertion. This is not a production-timeout fix.

Ten paths are now staged, including the diagnostic/fixture correction.
Final full qualification `plan-agent-review-qualified-full` is in progress.
Do not edit the frozen checkout or commit until its complete receipt passes.

## Accepted local increment

Final qualification passed on tree
`cb0f8bc7e78ab8dd2decb8be401921d99a6846f4`: build, typecheck, lint,
re-export guard, generated first-party check, roadmap verifier, 7,967 tests
(six existing skips) and 21 compiled native-process checks. No provider launch.
Receipt `plan-agent-review-qualified-full`, 308.654 seconds, log SHA-256
`cbc88bf7476031d94488ed8212eb9a351184ee1c505b5da2eb4a72f099b63291`.

Committed exactly that tree as
`7a9178e2db129800b8245de740bbf01328c4f9a6`:
`refactor(modular): extract Plan agent and review steps`.
Qualification checkout is clean. Candidate branch/index advanced using
expected-old update-ref and read-tree without -u; candidate working files were
not written. Before/after preservation receipts passed the unchanged baseline
and allowlist (281 paths), log SHA-256
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.

Codex review findings were fixed and locally verified. Kimi authentication
remains unavailable, not a passing review. The original Forge flake cause stays
inferred; the controlled fixture-coupling evidence and negative control remain
available above. Git whitespace check flags legacy blank-line whitespace in
the extracted source and byte-frozen fixture; lint passed, and fixture bytes
were preserved. This increment is not whole-release acceptance. Nothing pushed
or installed, and global Agon/personal state were not changed.
