import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';
import * as plan from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = 'b6149df7d63dced828b2ee6c459c092a68c3fe05';
const source = execFileSync('git', ['show', `${base}:packages/cli/src/cesar/auto-approve-policy.ts`], { cwd: repo, encoding: 'utf8' });
let trace = [];
let reviewCost = 3;
let actionMode = 'allow';
const estimate = () => { trace.push(['estimate']); return reviewCost; };
const evaluate = (action, text) => {
  trace.push([action, text]);
  if (actionMode === 'throw') throw new Error('lease evaluation failed');
  const allowed = actionMode === 'allow' || (actionMode === 'deny-shell' && action !== 'Bash');
  return { decision: allowed ? 'allow' : 'ask', reason: allowed ? 'allowed' : 'needs approval' };
};
const legacy = {};
const compiled = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
new Function('exports', 'require', compiled)(legacy, name => {
  if (name === '@kernlang/agon-core') return { planCostEstimator: { estimate: () => ({ costUsd: estimate() }) } };
  if (name === '../lib/kern-host.js') return { hostStringSet: values => new Set(values ?? []) };
  if (name === './task-execution-lease.js') return { evaluateTaskAction: (_lease, action, text) => evaluate(action, text) };
  throw new Error('Unexpected old dependency: ' + name);
});
const effects = { estimateReviewCostUsd: estimate };
const record = plan.createCesarPlan('policy parity', []);
const mutating = { ...record, autoApprove: true, totalEstimatedCostUsd: 14,
  steps: [{ id: 'self', type: 'self', description: 'work', estimatedTokens: 1, estimatedCostUsd: 14 }] };
const legacyTypes = [...legacy.MUTATING_STEP_TYPES];
legacy.MUTATING_STEP_TYPES.clear();
assert.equal(legacy.applyAutoApprovePolicy(mutating, { cesarAutoApproveMode: 'safe-only' }).approve, true);
for (const type of legacyTypes) legacy.MUTATING_STEP_TYPES.add(type);
const publicTypes = [...plan.MUTATING_STEP_TYPES];
try {
  plan.MUTATING_STEP_TYPES.clear();
  assert.equal(plan.evaluatePlanAutoApproval(mutating, { cesarAutoApproveMode: 'safe-only' }, effects).approve, false);
} finally { for (const type of publicTypes) plan.MUTATING_STEP_TYPES.add(type); }
function observe(run) {
  trace = [];
  let result;
  try { result = { returned: run() }; }
  catch (error) { result = { error: error.message }; }
  return { ...result, trace };
}
let comparisons = 0;
for (const types of [[], ['self'], ['review'], ['forge', 'review'], ['brainstorm', 'campfire'], ['team-agent']]) {
  for (const mode of [undefined, 'off', 'safe-only', 'cost-bounded', 'always', 'misspelled']) {
    for (const ceiling of [undefined, null, 0, 14, 20, 100]) for (const autoApprove of [undefined, false, true]) {
      for (const selfReview of [undefined, false, true]) for (const command of [undefined, ' ', 'npm test']) {
        for (const cost of [0, 3]) {
          reviewCost = cost;
          const config = { cesarAutoApproveMode: mode, cesarAutoApproveMaxCostUsd: ceiling };
          const value = { ...record, autoApprove, selfReview, totalEstimatedCostUsd: 14,
            steps: types.map((type, index) => ({ id: String(index), type, description: 'discuss production deletion',
              fitnessCmd: command, verifyCmd: 'npm run lint', estimatedTokens: 1, estimatedCostUsd: 14 })) };
          assert.deepEqual(observe(() => plan.evaluatePlanAutoApproval(value, config, effects)),
            observe(() => legacy.applyAutoApprovePolicy(value, config)));
          comparisons++;
          for (const action of ['missing', 'allow', 'deny-step', 'deny-shell', 'throw']) {
            actionMode = action;
            assert.deepEqual(observe(() => plan.evaluateAgenticPlanAutoApproval(value, config, effects, action === 'missing' ? undefined : evaluate)),
              observe(() => legacy.applyAgenticAutoApprovePolicy(value, config, action === 'missing' ? undefined : {})));
            comparisons++;
          }
        }
      }
    }
  }
}
let compiledCliChecks = 0;
if (process.argv.includes('--compiled-cli')) {
  const directory = join(repo, 'packages/cli/dist');
  const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
  async function loadOwner(symbol) {
    const matches = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
    assert.equal(matches.length, 1, symbol);
    const module = await import(pathToFileURL(join(directory, matches[0])).href);
    assert.equal(typeof module[symbol], 'function', symbol);
    return module;
  }
  const host = await loadOwner('handleProposedCesarPlan');
  for (const [autoModeQueued, config, reason] of [
    [false, { cesarAutoApproveMode: 'safe-only' }, 'safe-only mode rejects mutating step types: self'],
    [false, { cesarAutoApproveMode: 'off' }, 'autoApprove disabled (cesarAutoApproveMode=off)'],
    [true, { cesarAutoApproveMode: 'off' }, 'autoApprove disabled (cesarAutoApproveMode=off)'],
    [true, {}, 'agentic task lease unavailable'],
    [false, { cesarAutoApproveMode: 'cost-bounded', cesarAutoApproveMaxCostUsd: 0 }, 'estimated cost $14.00 exceeds ceiling $0.00'],
  ]) {
    const proposed = { ...mutating, selfReview: false };
    const events = [];
    const selected = [];
    const ctx = { config, autoModeQueued, cesar: { proposedPlan: proposed } };
    await host.handleProposedCesarPlan(proposed, {
      ctx, dispatch: event => events.push(event), setActivePlan: value => selected.push(value),
    });
    assert.deepEqual(selected, [proposed]);
    assert.equal(ctx.cesar.proposedPlan, undefined);
    assert.deepEqual(events, [
      { type: 'info', message: `Plan requested autoApprove but policy rejected: ${reason}` },
      { type: 'info', message: 'Plan awaiting approval. Press Y to approve, N to reject — or type /approve / /cancel.' },
    ]);
    compiledCliChecks++;
  }
}
console.log(JSON.stringify({ passed: true, comparisons, compiledCliChecks, base, oldSourceSha256: createHash('sha256').update(source).digest('hex'),
  exportedSetMutation: 'old bypass reproduced; new snapshot cannot change authority', tracesCompared: true }));
