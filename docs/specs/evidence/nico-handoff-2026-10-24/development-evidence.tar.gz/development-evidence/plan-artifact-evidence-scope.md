# Plan artifact completion evidence

Status: implemented, reviewed, qualified and committed locally; no release acceptance.
Date: 2026-10-11. Base: 33510c6e0af34a4393e993e6d91b41ee87326292.
Allowed: isolated code/tests, default Agon review, verified local commit.
Forbidden: installs, pushes, promotion, personal/global changes, live Pipeline.
Spec: bug, self-written from the accepted completion roadmap.

## Authority and verified cause

Claude completion plan Phase 2 explicitly requires applied-artifact evidence to
replace the dirty-tree proxy. docs/specs/modular-agon-completion-progress.md:570
retains this as an unaccepted limitation, not a future feature.

packages/mod-plan/src/execution-coordinator.ts:372 uses dirty status to decide
whether Forge output was applied. Existing unrelated edits can satisfy it.
Conversely createForgeStepExecutors deliberately succeeds for already-satisfied
work and empty patches, yet the coordinator pauses those plans in a clean tree.
The pipeline step produces a winner and a Tribunal summary but neither calls
patch application nor records its outcome. These are separate reachable cases.

Reuse: existing CesarStepResult, execution-record validation, Forge patch host,
coordinator, raw legacy fixtures and owner tests. No parallel receipt store,
new dependency or replacement execution engine.

## Bounded implementation

Add an optional, validated execution-result artifact outcome. Only execution
owners emit it after successful patch application or explicit no-change outcome.
Include content hash and target for an applied patch; never infer application
from stdout text, dirty status, winner selection or unrelated edits.
Retain historical records for reading. Missing evidence cannot prove application.
Keep dirty status only for whether an ordinary review has changes to inspect.

The pipeline's missing apply step needs the same existing patch effects and
authority rechecks; no live model workflow is authorized by this work.
Record its apply outcome before claiming completed execution.

## Blast radius and verification

Moderate runtime risk: Plan result model/validator; Forge and pipeline step owners;
coordinator; CLI patch-effect injection; existing owner, parity and record tests.
Expected 8–12 paths, one concern: truthful application/no-change outcomes.
No unrelated host reshuffling or registry/schema rewrite.

Red controls first: unrelated dirty files do not prove application; an actual
already-satisfied/empty-patch owner result completes in a clean workspace.
Then applied hash/target, failed apply, revoked authority, malformed evidence,
historical missing evidence, pipeline settlement and persistence round trip.
Keep raw legacy fixtures unchanged; explicitly assert intended additive evidence
and the verified behavior correction, not a broad normalization/exclusion.
Run real Git application in isolated state, full gates and one default review.

Binding rule (AGENTS.md): "All handlers support `AbortSignal` for cancellation."
Binding goal: "Use regression tests and meaningful negative controls."
Binding goal: "Keep existing behavior unless a verified defect requires correction."

Baseline: release-verifier-qualified passed the exact base tree with 8,417 tests,
six skips, full build/types/lint, performance and live CLI/PTY checks.
This work is not evidence of clean-install or whole-modular completion.

## Reproduction and implementation evidence

`plan-artifact-evidence-red-verified`: three intended failures on the prior
coordinator: unrelated dirty work wrongly completed; actual empty-patch and
already-satisfied executor results wrongly paused. The earlier `-red` run was
a PATH/setup failure, not a valid negative control.

`plan-artifact-evidence-controls`: passed (6.156 seconds), log SHA-256
f2220e92321abd6972a31b7b3759a50e15585cd2194efd7e02251f9033a359d5.

`plan-pipeline-artifact-red`: two intended failures (32 existing tests passed).
Tribunal observed no apply call; a refused apply still returned pipeline success.
Log SHA-256 d68434143ec01660f206aba2c31f7eec1d44767a2c7fb31c5ca54ceb18bad713.

The existing Forge application helper is now shared internally with Pipeline.
Pipeline applies the selected patch before its Forge-completed event and before
Tribunal. It rechecks parent/Forge authority around patch reading. Later review,
tracking, or authority failure retains the application evidence in the failed
result. No live Pipeline or provider was invoked.

Contract delta: the non-shipping public PlanPipelineHost now requires the same
readPatch/applyPatch effects as PlanForgeHost. The only production constructor
is CLI plan-mode.ts; it injects the existing support-worktree functions. This is
an explicit host-contract correction, not a claim of source compatibility with
external consumers of the incomplete foundation. No new package dependency.
Historical saved results without artifact remain readable; they cannot certify
application during final verification. The receipt records observed application,
not a guarantee that a user has not subsequently edited/reverted the workspace.

`plan-artifact-six-files`: passed (5.477 seconds), six targeted test files and
typecheck; zero provider launches. Log SHA-256
58ce30006975a3ee9b2c9651e7f778d46bbd7c904e1f071acb777434e9fd4e95.
Tests cover revoked parent/child/cancellation during patch read, failed apply,
missing/unreadable/empty patches, retained evidence after later failures, and
exact legacy parity except the declared application/receipt behavior change.
Frozen legacy fixtures remain unchanged. Twelve source/test paths currently.

Full repository gates started as `plan-artifact-full-tests`; read its terminal
receipt before claiming this increment qualified. Live Git/persistence evidence,
independent review, regenerated release artifacts and local commit remain due.

The full run failed: 8,425 passed, ten failed, six skipped. Nine failures came
from old pipeline fixtures with no patch path; the tenth was stale generated
source hashes. No authority assertion was relaxed. Added explicit fixture patch
paths and regenerated the existing ledger (same 344 assignments).

The first fixture rerun exposed a real integration mismatch: readPatchFromPath
intentionally rejects empty files for interactive Apply. Plan's explicit empty
artifact outcome was unreachable through that reader. Plan now injects the
existing readPatchContent API (strict UTF-8, exact bytes), mapping read failure
to its existing null contract. Apply's reader and behavior are unchanged.
This also makes the receipt hash identify original input bytes, not normalized
text. Raw legacy parity still preserves non-artifact results and effects.

Expanded touched paths: two existing workflow/admission test files plus the
generated migration ledger, 15 total. This stays below twice the initial estimate.
`plan-artifact-reader-controls` currently has 335 passing tests, including a real
Git apply/reapply and raw saved-envelope round trip; final lint is still running.
Read the receipt for its terminal status. All providers remained blocked.

## Independent review and adjudication

Review subject: staged tree db58494be5e789f73d8eceaa27ff8fd3b5ca53ed.
Packet SHA-256: 24a684e319486bbe007f5410a09de0c9f2ce8d9b388e55d1c96a6575db905fe7.
Codex returned a review through isolated candidate Agon, log SHA-256
479003de71a9e30c1e98a8276c8a2af24a56bc137db44167ab1e3ef046f0a642.
Kimi returned no answer (Agon exit 1), log SHA-256
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No login or personal-state repair was attempted. One default review panel only.

P1 verified: fallback and ordinary resume discarded a failed Pipeline result
after patch application and later Tribunal timeout. Both policies now retain the
saved record and require inspection/explicit restart. No phase continuation
engine was added. The existing explicit restart remains the operator decision.
P2 verified: Pipeline rejected an already-satisfied manifest with no winner.
It now shares Forge's existing classification and records a no-change outcome,
then completes the required Tribunal phase with an accurate prompt/label.

`plan-artifact-review-red-complete`: all three targeted tests failed for their
intended assertions (fallback, resume, already-satisfied Pipeline), SHA-256
0ed26de611bb652211d25c7107d66287e3e377177c87304e41e25f6ac34becec.
`plan-artifact-review-fixed`: passed, SHA-256
95813bc197cfb778dad10ee2f0ba44d4fce77f466803c3be02556604b2794d78.
Additional coverage: historical unproven Forge result with a prior successful
review; failed Pipeline receipt and cumulative accounting through real JSON
storage; refusal leaves in-memory and on-disk records unchanged.
`plan-artifact-review-final-controls`: passed (6.001 seconds), SHA-256
a83700de637680ef3050d28022578e8cddb84c857d31140f9c09af95308ad192.

Pre-review-fix full suite: `plan-artifact-suite-corrected` passed 8,435 tests,
six skips, CLI build and performance budgets. SHA-256
8589752f141bad4f2d636c6dfdb2e7f1aad61bbf4ac353ecb975a020a6c831b2.
It is not evidence for the subsequent retry/no-change fixes. Final gates must
run on the corrected subject. Source/test/ledger/progress files total 17; release
metadata regeneration adds the same three existing generated paths (20 total).
Backup ref: backup/plan-artifact-33510c6e. Nothing committed or pushed yet.

## Final component qualification

Commit: 2e6dacb2c4d58a5696283f9fd6a76681971749cb.
Exact qualified tree: 19cd0a58a79808906be855289cdd9498f9d591af.
Message: fix(modular): record Plan artifact application.
20 paths, 599 additions/290 deletions including regenerated artifacts.

`plan-artifact-qualified` passed in 367.331 seconds: full build/typecheck/lint,
re-export guard, migration-ledger reproducibility, release-set and supply-chain
generation/check/self-tests, full suite (8,440 passed, six skipped), release
performance budgets, and final 185-test real-Git/authority regression run.
Zero provider launches. Log SHA-256
16c94d08a5ce0a17dd877209297df7c9fdeacbcd1311fa500d99bbc3f7f60160.
Real Git application and persisted outcome checks ran for successful review and
Tribunal timeout; this is not a live-model Pipeline or installed-tarball claim.

Qualification worktree is clean. Candidate branch advanced by compare-and-swap
from 33510c6e, then index-only read-tree (no working-file writes). Preservation
checks before/after both passed for the established 281-path baseline with hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Global Agon, personal state and durable evidence archive were not modified.
No installation, promotion, push, or second reviewer panel occurred.

Remaining goal is unchanged: complete ownership/adapter retirement, truthful
current ownership evidence, safe conditional simplifications and final clean
release qualification. This receipt proves this component, not those dimensions.
Next traced seam: CLI/MCP first-party-services still call Core's
createBrainstormHostServices facade; its mod owns runtime bindings, but the
facade's declared removal condition has not been satisfied. The migration ledger
still records legacy-runtime authority from path existence, not a full runtime
ownership proof. Both need source-driven reconciliation, not counter-only claims.
