# Remaining Plan build-step ownership

## Next bounded scope

After Agent/Review qualification, extract Forge, Team Forge and the existing
Plan pipeline-step orchestration into mod-plan. This is migration of existing
code. It does not authorize using the Multi-AI Build Pipeline. Verification
must use provider-blocked fixtures and local processes only.

Consumer tracing: candidate `forge-step-execution.ts` owns progress reporting,
winner application and Forge step policy; candidate `pipeline-step-execution.ts`
imports two of its progress functions. CLI still has all these algorithms in
the accepted tree. Moving both removes the shared CLI helper owner without
adding a backward dependency. Expected surface: 12 paths (two owners, two
frozen fixtures, four owner/parity tests, CLI composition, public exports,
existing generator and source-hash ledger), plus existing admission tests if
needed. Risk: high for patch writes, nested-phase authority, progress timers,
workflow event ordering and partial-failure receipts.

## Retained constraints

- Keep the accepted CLI's withProcessSurfaceAuthority wrapper and guarded
  adapters. The older candidate composition omits the monitor wrapper.
- Recheck owner authority after awaits and host callbacks before new effects.
  Keep independent child-owner checks for Brainstorm, Forge and Tribunal.
- Preserve Forge winner/no-winner/already-satisfied semantics, empty patches,
  application errors, timer cleanup, output text and metered usage.
- Preserve pipeline conformance checks, event ordering, partial output,
  cancellation and thrown-validator refusal. Do not infer successful work from
  a completed workflow event alone.
- Public surface exports factories and needed host types. Progress helpers have
  only same-package consumers; do not expand root public exports without need.
- Freeze fixture bodies from the newly accepted commit, not candidate WIP.
  Keep assertions outside catches and require independent expected statuses.

Inspect the whole candidate owners and existing tests before import. Use the
accepted inline implementations as behavioral truth except proven defects.
No production changes started. The current Agent/Review subject remains frozen.

## Source checks during Agent/Review qualification

Read both candidate owner files and all four owner/parity test files. Do not
copy their composition or parity expectations unchanged:

- Accepted inline pipeline code distinguishes SurfaceGenerationError from user
  cancellation. Candidate owner treats every aborted signal as cancellation.
  Preserve the distinction through an injected classification boundary; do not
  import CLI/kernel-private error classes into mod-plan.
- Accepted inline code already checks authority after each backend. Candidate
  parity expects an older abort behavior and is stale. Freeze fresh fixtures
  from the accepted subject and compare the current behavior.
- Both candidate parity suites assert inside caught backend callbacks. Record
  boundary observations and assert after execution, with independent expected
  statuses, following the verified Agent/Review false-green correction.
- Accepted final workflow verification can emit issues but still return
  success. Candidate fixes this. Prove the defect with a focused negative
  control rather than describe this behavior change as extraction parity.
- Candidate pipeline relies on host.assertAvailable to reject pre-aborted
  signals. Test a no-op host guard and retain explicit owner cancellation.

This inspection changed no production files and ran no pipeline workflow.

## Extraction started after Agent/Review acceptance

Accepted predecessor: 7a9178e2db129800b8245de740bbf01328c4f9a6.
Copied only the two physical owners and their focused tests from candidate WIP.
Fresh combined legacy fixture preserves accepted Forge/TeamForge/pipeline
branches and shared helpers once, rather than duplicate their setup across two
fixtures. Provenance hashes are in the fixture header. Expected scope shrank by
one fixture. All edits are in qualification; candidate file bytes are unchanged.

Source correction to the initial scope note: the current candidate CLI does
have a final withProcessSurfaceAuthority wrapper. The accepted composition is
still retained rather than replaced: factory executors each use its existing
wrap, entry guard, guarded adapter, live refusal and generation checks.

Owner negative control found a real draft defect: pre-aborted pipeline plus
no-op host guard still invoked the backend before returning failure. Added
explicit throwIfAborted at owner entry. Receipt plan-build-step-owner-draft-red
has 34 passes/one intended failure; fixed owner/typecheck has 38 passes.
Failure/cancellation classification is injected by the CLI, preserving its
SurfaceGenerationError distinction without importing kernel into mod-plan.
Added three phase-specific tests for the distinction.

Both raw parity suites now assert boundary observations outside executor
catches and assert independently expected success/failure states. Old abort
expectations were removed: the accepted predecessor already checks return
authority. A tribunal failure now names both completed phases in partial output;
the exact old/new difference is asserted, not broadly normalized.

Initial composition typecheck caught legacy workflow UI events missing from
the broad CLI OutputEvent type. The injection seam retains the legacy cast,
bounded to Parameters<Dispatch>[0], instead of spreading any into the owner.

First composition parity run was INVALID runtime evidence: root package
exports were stale because only typecheck ran, not build. 217 failures report
createForgeStepExecutors is not a function. No oracle was changed. Current
run plan-build-step-built-parity rebuilds before the same tests. Do not edit
the qualification source while that run is live.

## Review and local adjudication

Rebuilt composition passed all 275 focused tests (owner, raw parity, durable
admission), build and types. Log SHA-256
`5d77382c17b83863e72ce7062e3c028cce53f80f3e7f4d68f5c1ac4cb83626f0`.
Five added frozen-legacy controls prove: final validation issues formerly
returned success; thrown validators could lose terminal events; cancellation
in patch reading could still apply the patch. Both parity suites then passed
103 tests, log `52874917d3abbd28e4a53b3651eb00e5d7a9a6fb066429baececedcdd8b7d51b`.
Lint, re-export guard, generator checks and roadmap verifier passed.

Default review packet binds tree a603cc3ff8db3bc6d3b7f1ed72bd0aa8560a8b0b,
packet SHA-256 86df672bd9e540422ad228d2158681f1a68523e869b82a1311bf3ebba224e855.
Codex log cc0b958a2a0d5dfefc7cc1bff970dab1d12cfaedec048e868a71865981ed81dc.
Kimi failed authentication (exit 1, not passing), log
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No login, credential changes or global state writes were attempted.

All five review dimensions reproduced through 16 failing controls:
plan-build-step-review-red, SHA-256
760bff268874d0bc69ad814d0e72e611c0b177043e8067fee261b7b6c9c09e5b.

- Real new defect: Forge entry check preceded initial progress callbacks.
  Combined signal/parent/child check now occurs immediately before backend
  entry and after return. Parent-only revocation gets its own three tests.
- Real new public-host defect: detached activeEngines lost its method receiver.
  Both owners now use the existing panel owner's closure pattern.
- Real inherited defect: UI exceptions could replace computed results or
  interrupt closure. One same-package notification wrapper records event-type
  warnings without raw exception text and preserves execution results. UI
  delivery is best effort: one terminal delivery ATTEMPT, not a guarantee that
  a throwing consumer received it. Cleanup remains unconditional.
- Confirmed missing precedence: validation failure after no-winner, backend
  exception or cancellation could conflict with the returned error. Failed
  final verification now wins in both terminal event and returned failure.

Fixed owner tests: 54 pass plus types, plan-build-step-review-fixed, SHA-256
d510e2374f8b102a5a1dcfb3e5f1f52ff08df8c6cdff46f7d50316243806c01d.
Added two frozen-legacy comparisons for cancellation during initial Forge
progress, with independent zero-backend-call assertions. No repeat model panel.

Full reviewed qualification is now running as plan-build-step-reviewed-full
on staged tree c88093f0387da3ebfff72fd9ae6c39cfce7da9d0. Do not edit source
until it ends. Eleven staged paths, candidate bytes untouched. Not committed
or accepted yet. No pipeline workflow or live provider was launched by tests.

Fixture provenance independently rechecked against accepted Git object:
both Forge and pipeline branch bytes match exactly. Combined fixture SHA-256
8313a3e1fba70db2687a049f68ce451f351ea1c618552fe08e6688cc78b18ae3.

## Next bounded requirements, not started

Read-only comparison found remaining candidate work in Plan checkpoint/store
and headless ownership. Do not mistake every candidate diff for desired code;
some candidate files are older than accepted repairs. Start from qualification.

1. Persistent execution checkpoints: candidate adds required onCheckpoint before
   effects and after results, flush(snapshot), and refusal to auto-resume steps
   with unknown outcomes. Verify against accepted executor/coordinator before
   adopting. Test storage failure before dispatch, after effects, parallel batch
   completion, cancellation, stale timers and re-entry with real files.
2. Headless/TUI Plan storage: accepted mod-plan/implementation.ts has a distinct
   Plan shape and uses generic support-persistence. It omits CesarPlan totals
   and stepContext. Candidate execution-record.ts requires these fields, so
   blindly unifying stores would reject records produced by the accepted
   headless implementation. Preserve both historical shapes in a frozen corpus;
   prove readable history and an explicit safe migration path before cutover.
   Never invent successful execution, context or unknown results.
3. Candidate execution-store changes prevent invalid IDs from aliasing another
   record and prevent corrupt canonical state from reviving a stale legacy copy.
   Reproduce these defects; pair fail-closed execution with honest read/recovery
   diagnostics and byte-preservation tests. No personal histories are test data.

The roadmap prose still describes pre-implementation status, despite later
source and evidence. Reconcile it at final acceptance; do not treat that old
table as proof that implemented components are absent or that anything passes.

## Accepted local increment

Full qualification passed on exact staged tree
c88093f0387da3ebfff72fd9ae6c39cfce7da9d0: build, types, lint, re-export guard,
first-party drift, roadmap verifier, 8,126 tests (six existing skips) and 21
compiled native-process checks. Zero provider launches. Receipt
plan-build-step-reviewed-full, 308.247 seconds, log SHA-256
a88c5ba9ceeb54ac66a54b81f49111d3863e049ccba1d780d44d59b3ad7bab6b.

Local commit 77835e323fc74c7e1a40560d1ab6e26601e84370:
`refactor(modular): extract Plan build-step policies`.
Clean qualification checkout, committed tree equals qualified tree. Candidate
branch/index advanced with expected-old update-ref and read-tree without -u.
Before/after preservation checks passed the same 281-path baseline and unchanged
allowlist, log bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
No candidate working bytes were changed, and nothing was pushed or installed.

Diff accounting: 1,600 additions / 402 deletions in eleven paths. Production
packages net +161 lines (typed host contracts, isolated policies and verified
boundary fixes); tests add 611 lines; one exact legacy fixture adds 422;
generator exports add four; source-hash ledger changes are net zero. Plan CLI
is now 193 lines, with build policies physically owned by mod-plan. Detailed
review logs and receipts remain outside the shipping tree.

This is not final release acceptance. Kimi remains externally unavailable;
the next bounded Plan storage/checkpoint requirements above remain actionable.
