import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdtempSync, writeFileSync, readFileSync, existsSync, rmSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const root = mkdtempSync(join(tmpdir(), 'agon-callback-errors-'));
process.env.AGON_HOME = root;
const owner = await import(join(repo, 'packages/mod-plan/dist/index.js'));
console.log(JSON.stringify({ helperSha256: createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex') }));
let create = owner.createPlanCallbacks;
if (process.argv.includes('--legacy')) {
  const source = execFileSync('git', ['show', '856de710:packages/mod-plan/src/execution-callbacks.ts'], { cwd: repo, encoding: 'utf8' });
  const code = ts.transpileModule(source, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
  } }).outputText;
  const exports = {};
  new Function('exports', 'require', code)(exports, () => owner);
  create = exports.createPlanCallbacks;
}
if (process.argv.includes('--bad-warning-payload')) {
  const original = create;
  create = (plan, host) => original(plan, { ...host, warn: message => host.warn(message, 'incorrect payload') });
}
let cases = 0;
try {
  for (const value of [null, undefined]) for (const failure of ['save', 'markdown']) {
    for (const delivery of ['manual', 'timer']) for (const brokenWarning of [false, true]) {
      rmSync(root, { recursive: true, force: true });
      mkdirSync(root);
      const plan = { ...owner.createCesarPlan('real best-effort writes', []), state: 'running', planFilePath: join(root, 'plan.md') };
      const attempts = [];
      const reported = [];
      const callbacks = create(plan, {
        dispatch: () => {}, setActivePlan: () => {}, todos: () => [],
        save: current => {
          attempts.push('save');
          if (failure === 'save') throw value;
          writeFileSync(join(root, 'plan.json'), JSON.stringify(current));
        },
        writeMarkdown: (path, content) => {
          attempts.push('markdown');
          if (failure === 'markdown') throw value;
          writeFileSync(path, content);
        },
        warn: (_message, error) => {
          attempts.push('warn');
          reported.push(error);
          if (brokenWarning) throw Error('warning unavailable');
        },
      });
      if (delivery === 'manual') callbacks.flush();
      else {
        callbacks.onPlanUpdate(plan);
        await new Promise(resolve => setTimeout(resolve, 350));
      }
      assert.deepEqual(attempts, failure === 'save' ? ['save', 'warn', 'markdown'] : ['save', 'markdown', 'warn']);
      assert.deepEqual(reported, [value]);
      assert.equal(existsSync(join(root, 'plan.json')), failure !== 'save');
      assert.equal(existsSync(plan.planFilePath), failure !== 'markdown');
      if (failure === 'save') assert.equal(readFileSync(plan.planFilePath, 'utf8'), owner.formatCesarPlanMarkdown(plan));
      else assert.deepEqual(JSON.parse(readFileSync(join(root, 'plan.json'), 'utf8')), JSON.parse(JSON.stringify(plan)));
      cases++;
    }
  }
  // Required initial persistence remains fail-closed, unlike callback reporting.
  for (const value of [null, undefined]) {
    let executions = 0;
    const messages = [];
    const coordinator = owner.createPlanCoordinator({
      createExecutors: () => { throw Error('must not construct executors'); },
      executePlan: async plan => { executions++; return plan; },
      callbacks: () => { throw Error('must not create callbacks'); },
      setActivePlan: () => {}, setAbort: () => {}, releaseAbort: () => {},
      save: () => { throw value; }, writeMarkdown: () => {},
      hasWorkingTreeChanges: () => false, estimateReview: () => ({ tokens: 0, costUsd: 0 }),
      takeFallback: () => undefined, notify: (_level, message) => messages.push(message), warn: () => {},
    });
    await coordinator.executeApprovedPlan({ ...owner.createCesarPlan('required storage', []), state: 'running' });
    assert.equal(executions, 0);
    assert.ok(messages.some(message => message.includes('No work started')));
    cases++;
  }
  console.log(JSON.stringify({ passed: true, cases, compiledOwner: true, realFiles: true,
    realTimers: true, requiredStorageFailClosed: true, storageFaultsInjected: true }));
} finally {
  rmSync(root, { recursive: true, force: true });
}
