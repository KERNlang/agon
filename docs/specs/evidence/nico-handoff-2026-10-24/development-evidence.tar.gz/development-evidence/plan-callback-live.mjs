import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = '5a0e9b8cd0377e83c4ae9847e6ef72ba7f8779a9';
console.log(JSON.stringify({ helperSha256: createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex') }));
const root = mkdtempSync(join(tmpdir(), 'agon-callback-live-'));
process.env.AGON_HOME = root;
const core = await import(join(repo, 'packages/core/dist/index.js'));
const owner = await import(join(repo, 'packages/mod-plan/dist/index.js'));
const source = execFileSync('git', ['show', `${base}:packages/cli/src/signals/dispatch/plan-execution.ts`], { cwd: repo, encoding: 'utf8' });
const start = source.indexOf('export function buildPlanCallbacks(');
const body = source.slice(start, source.indexOf('\n}\n', start) + 3);
const transpile = value => ts.transpileModule(value, { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText;
const todos = steps => steps.map(step => ({ id: step.id, state: step.state }));
const dependencies = { writeFileSync, saveCesarPlan: core.saveCesarPlan,
  formatCesarPlanMarkdown: core.formatCesarPlanMarkdown, todosFromPlanSteps: todos };
const legacy = {};
new Function('exports', ...Object.keys(dependencies), transpile(body))(legacy, ...Object.values(dependencies));
let physical = owner.createPlanCallbacks;
if (process.argv.includes('--mutant')) {
  const original = readFileSync(join(repo, 'packages/mod-plan/src/execution-callbacks.ts'), 'utf8');
  const changed = original.replace('clearTimeout(pendingWriteTimer);', '/* negative control: do not clear pending timer */');
  assert.notEqual(changed, original);
  const exports = {};
  new Function('exports', 'require', transpile(changed))(exports, () => owner);
  physical = exports.createPlanCallbacks;
}
const current = (plan, cb) => physical(plan, {
  dispatch: cb.dispatch, setActivePlan: cb.setActivePlan, todos,
  save: core.saveCesarPlan, writeMarkdown: writeFileSync,
  warn: (...args) => console.warn(...args),
});
function files(path = root, prefix = '') {
  return Object.fromEntries(readdirSync(path, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).flatMap(entry => {
    const relative = join(prefix, entry.name);
    return entry.isDirectory() ? Object.entries(files(join(path, entry.name), relative)) : [[relative, readFileSync(join(path, entry.name), 'utf8')]];
  }));
}
const RealDate = Date;
const originalWarn = console.warn;
globalThis.Date = class extends RealDate {
  constructor(...args) { super(...(args.length ? args : ['2026-10-10T00:00:00.000Z'])); }
  static now() { return 1791590400000; }
};
let comparisons = 0;
try {
  for (const scenario of ['debounce', 'done', 'paused', 'cancelled', 'success', 'failure', 'save-error', 'write-error', 'missing-step', 'no-markdown', 'multi-engines']) {
    const results = [];
    for (const factory of [legacy.buildPlanCallbacks, current]) {
      rmSync(root, { recursive: true, force: true });
      mkdirSync(root);
      const plan = { ...owner.createCesarPlan('callback parity', [{ id: 's', type: 'self', description: 'work', estimatedTokens: 0, estimatedCostUsd: 0 }]),
        id: 'fixed', state: 'running', planFilePath: join(root, 'plan.md') };
      if (scenario === 'no-markdown') delete plan.planFilePath;
      if (scenario === 'multi-engines') plan.steps[0].engines = ['alpha', 'beta'];
      if (scenario === 'save-error') writeFileSync(join(root, 'plans'), 'not a directory');
      if (scenario === 'write-error') mkdirSync(plan.planFilePath);
      const events = [], active = [], warnings = [];
      console.warn = (...args) => warnings.push(args);
      const callbacks = factory(plan, { dispatch: value => events.push(value), setActivePlan: value => active.push(value) });
      callbacks.onStepStart(scenario === 'missing-step' ? 'absent' : 's');
      const status = scenario === 'paused' ? 'paused' : scenario === 'failure' ? 'failure' : 'success';
      callbacks.onStepDone('s', { status, actualTokens: 2, actualCostUsd: 0.1, durationMs: 1500,
        output: 'x'.repeat(4100), error: status === 'success' ? undefined : 'e'.repeat(90) });
      callbacks.onPlanUpdate({ ...plan, totalActualTokens: 1 });
      callbacks.onPlanUpdate({ ...plan, totalActualTokens: 2 });
      assert.deepEqual(Object.keys(files()).filter(path => path.endsWith('.json')), []);
      if (['done', 'paused', 'cancelled'].includes(scenario)) {
        callbacks.onPlanUpdate({ ...plan, state: scenario, totalActualTokens: 3 });
      } else {
        await new Promise(resolve => setTimeout(resolve, 350));
      }
      callbacks.onBudgetWarning(2, 1);
      const short = await callbacks.summarizeStepOutput('s', 'short');
      const long = await callbacks.summarizeStepOutput('s', 'z'.repeat(501));
      callbacks.flush();
      const flushed = files();
      if (scenario === 'no-markdown') assert.ok(!Object.keys(flushed).some(path => path.endsWith('.md')));
      if (scenario === 'multi-engines') {
        assert.equal(events.find(event => event.type === 'spinner-start').engineId, 'alpha');
      }
      const warningCount = warnings.length;
      // A pending timer must not write after the caller releases the callbacks.
      // Replace storage with directories: an extra write now becomes observable.
      if (scenario === 'done' || scenario === 'paused' || scenario === 'cancelled') {
        rmSync(join(root, 'plans'), { recursive: true, force: true });
        writeFileSync(join(root, 'plans'), 'released');
        rmSync(plan.planFilePath, { force: true });
        mkdirSync(plan.planFilePath);
        await new Promise(resolve => setTimeout(resolve, 350));
        assert.equal(warnings.length, warningCount, 'write occurred after terminal flush');
      }
      results.push({ events, active, warnings, short, long, files: flushed });
    }
    assert.deepEqual(results[1], results[0], scenario);
    comparisons++;
  }
  let coordinatorRuns = 0;
  for (const fallback of [false, true]) {
    rmSync(root, { recursive: true, force: true });
    mkdirSync(root);
    const plan = { ...owner.createCesarPlan('coordinator callback integration', [{
      id: 's', type: 'self', engine: 'primary', description: 'work', estimatedTokens: 0, estimatedCostUsd: 0,
    }]), id: 'coordinator', state: 'running', selfReview: true, planFilePath: join(root, 'plan.md') };
    let work = 0, reviews = 0;
    const warnings = [];
    console.warn = (...args) => warnings.push(args);
    const result = status => ({ result: { status, actualTokens: 2, actualCostUsd: 0,
      durationMs: 1, output: status === 'success' ? 'checked' : '',
      ...(status === 'failure' ? { error: 'timeout' } : {}) } });
    const coordinator = owner.createPlanCoordinator({
      createExecutors: () => ({
        self: { execute: async () => { work++; return result(fallback && work === 1 ? 'failure' : 'success'); } },
        review: { execute: async () => { reviews++; return result('success'); } },
      }),
      executePlan: owner.createPlanExecutor({ recordStepCompletion: () => {} }),
      callbacks: value => current(value, { dispatch: () => {}, setActivePlan: () => {} }),
      setActivePlan: () => {}, setAbort: () => {}, releaseAbort: () => {},
      save: core.saveCesarPlan,
      writeMarkdown: value => writeFileSync(value.planFilePath, core.formatCesarPlanMarkdown(value)),
      hasWorkingTreeChanges: () => true, estimateReview: () => ({ tokens: 1, costUsd: 0 }),
      takeFallback: () => fallback && work === 1 ? { engine: 'fallback', stepId: 's' } : undefined,
      notify: () => {}, warn: (...args) => warnings.push(args),
    });
    await coordinator.executeApprovedPlan(plan);
    const saved = core.loadCesarPlan(plan.id);
    assert.equal(saved.state, 'done');
    assert.equal(work, fallback ? 2 : 1);
    assert.equal(reviews, 1);
    assert.equal(saved.reviewCyclesUsed, 1);
    assert.equal(saved.steps.length, 2);
    assert.ok(saved.steps.every(step => step.state === 'done'));
    assert.deepEqual(warnings, []);
    const final = files();
    await new Promise(resolve => setTimeout(resolve, 350));
    assert.deepEqual(files(), final, 'old phase overwrote final verification');
    coordinatorRuns++;
  }
  console.log(JSON.stringify({ passed: true, comparisons, coordinatorRuns, base,
    realFiles: true, realTimers: true, compiledOwner: true, realExecutor: true,
    providerStepsStubbed: true, worktreeObservationStubbed: true }));
} finally {
  globalThis.Date = RealDate;
  console.warn = originalWarn;
  rmSync(root, { recursive: true, force: true });
}
