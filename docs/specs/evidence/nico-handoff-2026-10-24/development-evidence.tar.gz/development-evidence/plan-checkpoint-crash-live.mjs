import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const repo = '/Users/ra/dev/agon-audit-qualification';
const moduleUrl = pathToFileURL(join(repo, 'packages/mod-plan/dist/index.js')).href;
const childSource = String.raw`
import { appendFileSync } from 'node:fs';
import { join } from 'node:path';
const [moduleUrl, root, scenario, action, requestedId] = process.argv.slice(1);
const api = await import(moduleUrl);
const result = { status: 'success', output: 'effect recorded', actualTokens: 1, actualCostUsd: 0, durationMs: 1 };
const stop = planId => {
  process.send({ type: 'checkpoint', planId });
  process.kill(process.pid, 'SIGSTOP');
};
let plan;
if (action === 'crash') {
  plan = { ...api.approveCesarPlan(api.createCesarPlan('durable checkpoint fixture', [
    { id: 'first', type: 'self', description: 'first effect', estimatedTokens: 1, estimatedCostUsd: 0, exports: ['proof'] },
    { id: 'second', type: 'self', description: 'second effect', estimatedTokens: 1, estimatedCostUsd: 0 },
  ])), selfReview: false };
} else {
  const saved = api.loadCesarPlan(requestedId);
  if (!saved) throw new Error('saved fixture missing');
  try { plan = api.prepareCesarPlanResume(saved, action); }
  catch (error) {
    console.log(JSON.stringify({ refused: true, error: error.message }));
    process.exit(0);
  }
}
const save = snapshot => {
  api.saveCesarPlan(snapshot);
  if (action !== 'crash') return;
  const first = snapshot.steps[0];
  if ((scenario === 'before-effect' && first.state === 'running' && !first.result)
    || (scenario === 'after-result' && first.state === 'done' && first.result)) stop(snapshot.id);
};
const coordinator = api.createPlanCoordinator({
  createExecutors: () => ({ self: { execute: async step => {
    appendFileSync(join(root, 'effects.txt'), step.id + '\n');
    if (action === 'crash' && scenario === 'after-effect' && step.id === 'first') stop(plan.id);
    return { result, contextExport: 'effect proof' };
  } } }),
  executePlan: api.createPlanExecutor({ recordStepCompletion() {} }),
  callbacks: value => api.createPlanCallbacks(value, {
    dispatch() {}, setActivePlan() {}, todos: () => [], save, writeMarkdown() {}, warn() {},
  }),
  setActivePlan() {}, setAbort() {}, releaseAbort() {}, save, writeMarkdown() {},
  hasWorkingTreeChanges: () => false, estimateReview: () => ({ tokens: 0, costUsd: 0 }),
  takeFallback: () => undefined, notify() {}, warn() {},
});
await coordinator.executeApprovedPlan(plan);
console.log(JSON.stringify({ state: api.loadCesarPlan(plan.id)?.state, id: plan.id }));
`;

function run(root, scenario, action, planId = '') {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['--input-type=module', '-e', childSource, moduleUrl, root, scenario, action, planId], {
      cwd: repo, env: { ...process.env, AGON_HOME: root }, stdio: ['ignore', 'pipe', 'pipe', 'ipc'],
    });
    let stdout = '';
    let stderr = '';
    let checkpoint;
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; child.kill('SIGKILL'); }, 15000);
    child.stdout.on('data', chunk => { stdout = (stdout + chunk).slice(-65536); });
    child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-65536); });
    child.on('message', message => {
      checkpoint = message;
      child.kill('SIGKILL');
    });
    child.on('error', error => { clearTimeout(timer); reject(error); });
    child.on('close', (code, signal) => {
      clearTimeout(timer);
      resolve({ code, signal, checkpoint, timedOut, stdout, stderr });
    });
  });
}

console.log('helperSha256', createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'));
for (const scenario of ['before-effect', 'after-effect', 'after-result']) {
  const root = mkdtempSync(join(tmpdir(), 'agon-checkpoint-crash-'));
  try {
    const effects = () => existsSync(join(root, 'effects.txt')) ? readFileSync(join(root, 'effects.txt'), 'utf8') : '';
    const killed = await run(root, scenario, 'crash');
    assert.equal(killed.timedOut, false, JSON.stringify(killed));
    assert.equal(killed.signal, 'SIGKILL', JSON.stringify(killed));
    assert.equal(killed.checkpoint?.type, 'checkpoint', JSON.stringify(killed));
    const id = killed.checkpoint.planId;
    assert.match(id, /^cplan-[a-zA-Z0-9_-]+$/);
    const file = join(root, 'plans', id + '.json');
    const before = readFileSync(file);
    const oldEffects = scenario === 'before-effect' ? '' : 'first\n';
    assert.equal(effects(), oldEffects);
    const resumed = await run(root, scenario, 'resume', id);
    assert.equal(resumed.timedOut, false, JSON.stringify(resumed));
    assert.equal(resumed.code, 0, JSON.stringify(resumed));
    const output = JSON.parse(resumed.stdout.trim());
    if (scenario === 'after-result') {
      assert.equal(output.state, 'done');
      assert.equal(effects(), 'first\nsecond\n');
    } else {
      assert.equal(output.refused, true);
      assert.match(output.error, /first.*outcome.*unknown/i);
      assert.deepEqual(readFileSync(file), before);
      assert.equal(effects(), oldEffects);
      const restarted = await run(root, scenario, 'restart', id);
      assert.equal(restarted.timedOut, false, JSON.stringify(restarted));
      assert.equal(restarted.code, 0, JSON.stringify(restarted));
      assert.equal(JSON.parse(restarted.stdout.trim()).state, 'done');
      assert.equal(effects(), oldEffects + 'first\nsecond\n');
    }
    console.log(JSON.stringify({ passed: true, scenario, compiledPublicApi: true, realSigkill: true }));
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
}
