# Plan durable execution checkpoints

Status: accepted increment, not release acceptance. Implementation authorized by the active modular remediation goal.
Date: 2026-10-11
Verified base: 77835e323fc74c7e1a40560d1ab6e26601e84370, isolated qualification checkout.
Allowed: local source/tests, isolated evidence, default Agon review, verified local commits.
Not allowed: push, installs, Pipeline activation, personal-state changes or promotion.
AI data mode: Agon allowed; default reviewers in isolated state.

## Purpose and authority

Preserve execution intent and known results before later effects. An interrupted
step with no durable result must not silently become a retry. This implements
the accepted persistence/recovery requirements, not a new workflow.

Spec stays beside the existing external evidence, not in personal settings or
the shipping diff, following the task's preservation constraints.

## Verified source and hypothesis

At the base commit, executor.ts invokes only best-effort onPlanUpdate before
work and after results. Coordinator wraps that observer in report(), which
catches errors; execution-callbacks.ts debounces running writes for 300ms and
catches save errors. Only initial and final coordinator writes are required.
Therefore a failed intermediate write does not stop the next workspace effect.
Confirm this through real-file tests before changing production code.

Candidate WIP has an onCheckpoint draft, flush(snapshot) and resume refusal.
Read all affected functions; do not copy unrelated review-budget or storage
validation changes from candidate. Accepted code is the baseline.

## Contract gate

| Binding rule | Source | Application |
| --- | --- | --- |
| "All handlers support AbortSignal for cancellation." | repo AGENTS.md | Persist failures stop the phase and retain cancellation semantics. |
| "Do log ... anything where silent failure could corrupt state or leak resources" | repo AGENTS.md | Required writes report failure; observer failures remain best effort. |
| "Preserve existing work and active/global Agon." | user goal | Isolated synthetic plans only; candidate bytes untouched. |

## Blast radius

Six production files in mod-plan: executor.ts, execution-coordinator.ts,
execution-callbacks.ts, execution-state.ts, resume-policy.ts, resume-workflow.ts. No package/dependency
or public export changes. Additive optional onCheckpoint and optional flush
snapshot preserve non-persistent callers. Persistent coordinator provides the
required checkpoint. CLI calls this coordinator through plan-execution.ts.
Core re-exports executor types; plan-queries and CLI dispatch re-export resume
helpers. No import owner changes in this increment.

Trace: rg -n 'PlanExecutorCallbacks|createPlanCoordinator|createPlanCallbacks|
prepareCesarPlanResume|skipCompletedSteps' packages --glob '*.ts' --glob '*.tsx'.
Seven directly matching existing unit suites were found; alias-based CLI
persistence tests and the full suite also apply. Add the candidate's bounded
checkpoint test after removing its unrelated assertReviewAvailable field.
Update existing tests only for demonstrated intentional contract changes.

## Acceptance

- Required intent write occurs before sequential/parallel backend entry.
- Failed intent write starts no backend and retains retryable pending work.
- Required result write occurs before later effects, including context exports.
- Failed result write cannot turn a known success into a retryable failure.
- Permanent failure leaves durable running/unknown evidence and blocks resume.
- Transient failure can persist the known result without repeating the effect.
- Timer flush cannot overwrite newer recovery state with older UI state.
- Settled phases reject retained callbacks. Cancelled phases reject new work but
  retain late results from work admitted before cancellation.
- Resume refuses running/no-result and done/no-result states without mutation;
  explicit restart remains a separate operator-approved action.
- Existing cancellation, fallback, review-cycle caps and observer isolation stay.
- Full gates, default review adjudication and compiled real-file/crash evidence.

## Not this increment

Headless/TUI store unification, historical record migration, strict ID validation,
review-owner budget admission, installation and final release qualification.
Those requirements remain active; this increment does not certify them.

## Baseline

Previous full receipt plan-build-step-reviewed-full: 8,126 pass, six existing
skips, build/types/lint/structural gates and 21 compiled-process checks passed.
Exact committed tree c88093f0387da3ebfff72fd9ae6c39cfce7da9d0, log SHA-256
a88c5ba9ceeb54ac66a54b81f49111d3863e049ccba1d780d44d59b3ad7bab6b.

## Evidence and implementation progress

All nine baseline controls failed for the expected reasons, including persisted
pending state at backend entry and two effects despite intermediate write
failure. Receipt plan-checkpoint-baseline-red, log SHA-256
ac86637207fc8779206c46d5a0d1410831c1846a3d1095cd1268d12db0b198f6.

Applied only the five scoped candidate changes. Excluded the independent
assertReviewAvailable API and review-budget behavior. The existing coordinator
now owns synchronous required writes, aborts its phase on failure and retains
known results. Callback flush accepts the latest recovery snapshot. Resume
refuses incomplete outcomes without changing the saved object.

Initial focused run: 156 pass plus typecheck, log
68aa22341e65e2a5600905cfea30c872d8111671f2df48975966db0ceb4f7b53.
Expanded tests cover parallel permanent result-write failure, both missing-result
resume cases through the approval workflow, and stale debounce replacement.
Expanded checkpoint suite/typecheck passed, log
67f9db07576de0370df42c665960bf2904904e485029a382f84505251e30b5a1.
Barrel-imported existing suites still need a rebuilt run, not stale dist claims.

Created external supplementary helper plan-checkpoint-crash-live.mjs. It uses
the compiled public API in isolated subprocesses and synthetic AGON_HOME.
Each child stops itself at a known checkpoint before parent SIGKILL, eliminating
the kill-before-next-effect race. Cases: before effect, after effect but before
result, and after persisted result. Fresh processes must refuse uncertain
resume without changing file bytes, or resume known success without repeating
it. Explicit restart is tested separately and may deliberately repeat effects.
This tests process crashes, not power-loss durability or disk fsync guarantees.

Run plan-checkpoint-built-native passed: 160 focused tests, types, build and
three SIGKILL scenarios (eight subprocesses including resume/restart controls).
Log SHA-256 d105d277096f14e6ba25a5ee863d847fbf806d96ac6d6e84c2cd2c62b3c5c7dd.
Lint and structural gates passed separately in plan-checkpoint-lint-structure.

## Independent review and local adjudication

Default isolated Agon review used Codex and attempted Kimi. Codex completed;
Kimi authentication failed. No personal credentials or settings were changed.
Reviewed tree: 1ee169470262350ff57c078ed3a40aa919134aa9.
Review packet SHA-256: 52567369a91fe09e5354a4c262c53f259443dca80f79163a80ff5e5473d3d95e.
Codex log SHA-256: e88effd37d68a730fb1d4f19f26955f4cf739feb6aaa80fd8836fc7869bb088a.
Kimi log SHA-256: a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
This was a source-fed review, not an independent test execution.

All three review findings reproduced against source. Four controls failed in
plan-checkpoint-review-red, log e1dc12beddcd360385b84a148660f98c3379f920e49c4f1449cf705c6930322e.

1. Parallel results and raw exports were delayed until the slowest sibling or
   summarizer completed. The scheduler now checkpoints each result before that
   wait. It drains all started tasks even after a write fails. Backend exceptions
   and checkpoint exceptions stay separate. Existing raw-event parity passes.
2. Cancellation discarded late success. The coordinator now aborts admission,
   preserves current execution evidence over stale cancellation views, and
   collects only new results from already-started steps. The plan stays cancelled.
   Cancelled steps with unknown effects require explicit restart, not resume.
3. Resume converted completed prerequisites to skipped, but dependency checks
   accepted only done. Successful skipped results now satisfy dependencies.
   Missing and failed skipped results do not.

A further timer control failed in plan-checkpoint-debounce-red, log
c404cc5d966308da650fae274b1213eed1735559e14d348fbd002123d72b5a1d.
The UI debounce could overwrite a newer checkpoint while summarization waited.
The coordinator now refreshes the existing callback buffer at each checkpoint,
including a failed write. No parallel storage implementation was added.

One new test incorrectly expected an immediate recovery write after a refused
write. Corrected the oracle: disk remains uncertain until recovery succeeds;
the phase must stay open and later retain both mixed outcomes with exact costs
and exports. This changes no existing test or accepted storage guarantee.

plan-checkpoint-expanded-verified: 99 focused tests and typecheck pass, log
799a0639864aee06c655b9374eee614fccf5239239aa1408af4d28e3be2bed83.
The first full run on tree 2d5412240e4bf538790e5321b89ac479a3c75db6
failed one positive CLI fixture after build/types/lint/structural gates passed.
The fixture claimed a completed step without any result. The new guard correctly
refused it. Added a real success result to that positive fixture, retaining its
exact-object and immutability assertions. Added two separate CLI refusal controls
for running/done steps with missing results. No production guard was relaxed.
Failed full log: 9e3c98675bdd8f45265f67cbd0f6c09cb1a28975685c2cd7841853a97ba19852.

Added required intent/result write failures inside both fallback and appended
review phases. These assert predecessor evidence, zero backend calls after an
intent refusal, unknown-result refusal after a result-write failure, and rejection
of a prior phase's retained callback. Shared public scheduler tests already cover
calls without onCheckpoint. Cancellation tests abort the actual phase signal and
then let the backend finish. Independent concurrent writers remain a separate
storage concern; these tests do not claim cross-process fencing.

plan-checkpoint-phase-controls: 53 tests and typecheck pass; log
a728819f8aad6feb174d5abd217d9f7f95d82185b9f47a7127d672a74a9ffb03.
Final qualification passed on tree d6f0e22d5e8b41ab2371cb9f220f5dbbcef6a498.
Receipt: plan-checkpoint-qualified-final, 311.467 seconds, exit 0.
Log SHA-256: 998b71090b2e826e23f0c79f4165267b5d99396b026626d8f5182e37125731a1.
Build, types, lint, re-export and generated-ledger/roadmap checks passed.
8,150 tests passed; six existing skips. Compiled checks passed: three crash
scenarios (eight processes), seven provider-admission processes and fourteen
step-admission processes. Provider launches: zero. Crash tests prove process
recovery, not power-loss or cross-process writer fencing.

Committed locally as 54af546cbb56d5d023f0691194916bb8278514a7:
`fix(modular): checkpoint Plan effects before continuation`.
The committed tree equals the qualified tree; qualification checkout is clean.
Production growth is 50 net lines across six files; the scheduler shrank.
Two test files add the checkpoint corpus and valid/missing-result CLI controls.

Advanced the candidate branch ref and index without writing its working files.
Before/after preservation receipts check all 281 baseline paths with the existing
allowlist, unchanged log hash bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
No pushes, installs, personal-state or global Agon changes in this slice.
Next bounded requirement: plan-store-precedence-scope.md. Headless format
unification and the full release acceptance remain unfinished.
