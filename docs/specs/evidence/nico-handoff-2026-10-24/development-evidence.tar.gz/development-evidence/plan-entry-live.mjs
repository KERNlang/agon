import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = 'fc921e826de51851b6aebd74415046d9972c2751';
assert.equal(readFileSync(join(repo, 'packages/mod-plan/src/executor.ts'), 'utf8'),
  execFileSync('git', ['show', `${base}:packages/mod-plan/src/executor.ts`], { cwd: repo, encoding: 'utf8' }),
  'The empty-plan baseline must remain unchanged');
if (!process.argv[2]) {
  let runs = 0;
  for (const scenario of ['disabled', 'enabled', 'changed']) {
    for (const route of scenario === 'changed' ? ['1', '2'] : ['approve', 'automatic', 'resume']) {
      process.stdout.write(execFileSync(process.execPath, [process.argv[1], scenario, route], { encoding: 'utf8', timeout: 30000 }));
      runs++;
    }
  }
  console.log(JSON.stringify({ passed: true, nativeProcesses: runs }));
  process.exit(0);
}
const root = mkdtempSync(join(tmpdir(), 'agon-entry-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const plan = await import(join(repo, 'packages/mod-plan/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const helper = readFileSync(join(repo, 'tests/helpers/modular-surface-lock.ts'), 'utf8');
const fixture = {};
new Function('exports', 'require', ts.transpileModule(helper, { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
async function owner(symbol) {
  const files = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
  assert.equal(files.length, 1, symbol);
  const module = await import(pathToFileURL(join(directory, files[0])).href);
  assert.equal(typeof module[symbol], 'function', symbol);
  return module;
}
const authority = await owner('initializeProcessSurfaceAuthority');
const cli = await owner('handleProposedCesarPlan');
assert.equal(typeof cli.approvePendingCesarPlan, 'function');
assert.equal(typeof cli.resumeCesarPlan, 'function');
const NOW = '2026-10-10T00:00:00.000Z';
let checks = 0;
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isDirectory()) unlock(join(path, entry.name));
  }
}
try {
  const scenario = process.argv[2];
  const route = scenario === 'changed' ? 'resume' : process.argv[3];
      const hostRoot = join(root, `${scenario}-${route}`);
      const host = new kernel.DurableModHost(hostRoot, { kernelVersion: '1.0.0', processIdentity: 'native-entry' });
      const install = async disabled => {
        const catalog = kernel.createFirstPartyModCatalog();
        const full = kernel.createFullCompatDesiredState(catalog, NOW);
        const desired = disabled ? kernel.planDesiredStateChange(catalog, full, { kind: 'disable', id: 'agon.plan' }, NOW).nextState : full;
        await host.commitGeneration({ operation: disabled ? 'disable' : 'install', lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
      };
      await install(scenario === 'disabled');
      await authority.initializeProcessSurfaceAuthority(hostRoot);
      const value = { ...plan.createCesarPlan(`${scenario}-${route}`, []), id: `${scenario}-${route}`,
        state: 'awaiting_approval', selfReview: false, autoApprove: true };
      const events = [];
      const selected = [];
      let answer;
      const cb = { ctx: { config: {}, cesar: { proposedPlan: value }, setActiveAbort() {} },
        dispatch: event => {
          events.push(event);
          if (event.type === 'question') {
            answer = event.resolve;
            if (scenario === 'enabled' || scenario === 'disabled') answer('1');
          }
        }, setActivePlan: value => selected.push(value) };
      let result;
      if (route === 'approve') result = await cli.approvePendingCesarPlan(cb);
      if (route === 'automatic') result = await cli.handleProposedCesarPlan(value, cb);
      if (route === 'resume') {
        const pending = cli.resumeCesarPlan({ ...value, state: 'paused' }, cb);
        if (scenario === 'changed') { assert.equal(typeof answer, 'function'); await install(true); answer(process.argv[3]); }
        await pending;
      }
      const stored = plan.loadCesarPlan(value.id);
      if (scenario === 'enabled') {
        // The unchanged executor deliberately pauses empty plans; it cannot claim completed work.
        assert.equal(stored?.state, 'paused', JSON.stringify(events));
        assert.ok(selected.some(value => value?.state === 'running'));
        assert.ok(!events.some(event => event.type === 'error'), JSON.stringify(events));
      } else {
        assert.equal(stored, null);
        assert.ok(events.some(event => event.type === 'error'), JSON.stringify(events));
        assert.ok(!selected.some(value => value?.state === 'running'));
        if (route === 'automatic') assert.equal(selected[0], value);
      }
      if (route === 'approve') assert.equal(result, true);
      assert.equal(value.state, 'awaiting_approval');
      checks++;
  console.log(JSON.stringify({ passed: true, checks, compiledCli: true, realDurableHost: true,
    realExecutionBoundary: true, executed: scenario === 'enabled', scenario, route }));
} finally {
  process.chdir(repo);
  unlock(root);
  rmSync(root, { recursive: true, force: true });
}
