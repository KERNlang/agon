import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

const repo = '/Users/ra/dev/agon-audit-qualification';
const subject = 'ca3b88d85e73fea8ab619e9c4cfcfad31d224e69';
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(), subject);
assert.equal(execFileSync('git', ['status', '--porcelain'], { cwd: repo, encoding: 'utf8' }).trim(), '');
const output = '/Users/ra/dev/modular-agon-remediation/plan-headless-corpus-ca3b88d8';
mkdirSync(output);
const home = join(output, 'synthetic-home');
mkdirSync(home);
process.env.AGON_HOME = home;
const { createMod } = await import(`${repo}/packages/mod-plan/dist/index.js`);
const tools = new Map();
let dispatches = 0;
const noOp = () => {};
const services = {
  identity: { id: 'agon.plan', version: '1', contentHash: `sha256:${'a'.repeat(64)}` },
  source: 'bundled', logger: { debug: noOp, info: noOp, warn: noOp },
  receipts: { record: async () => 'synthetic-plan-receipt' },
  permissions: { check: noOp }, state: { read: noOp, write: noOp },
  engines: { dispatch: () => { dispatches++; throw new Error('Unexpected engine dispatch'); } },
};
const registrar = {
  command: () => noOp, intent: () => noOp, planStep: () => noOp,
  tool: (_surface, value) => { tools.set(value.id, value); return noOp; },
};
const mod = await createMod(services);
const dispose = await mod.activate(registrar, services);
const context = { invocationId: 'synthetic-corpus', cwd: repo, platform: 'darwin-arm64', signal: new AbortController().signal, config: {} };
const records = [];
const capture = (name, plan) => {
  const relativePath = `plans/${plan.id}.json`;
  const bytes = readFileSync(join(home, relativePath));
  const destination = `${name}.json`;
  writeFileSync(join(output, destination), bytes, { flag: 'wx' });
  assert.deepEqual(readFileSync(join(output, destination)), bytes);
  const envelope = JSON.parse(bytes);
  assert.deepEqual(envelope.payload, plan);
  records.push({ name, file: destination, originalRelativePath: relativePath, bytes: bytes.length,
    sha256: createHash('sha256').update(bytes).digest('hex'), state: plan.state,
    missingCanonicalFields: ['totalEstimatedTokens', 'totalEstimatedCostUsd', 'totalActualTokens', 'totalActualCostUsd', 'stepContext'].filter(key => !(key in plan)) });
};
try {
  const input = { intent: 'Synthetic historical Plan capture', steps: [
    { id: 'inspect', type: 'self', description: 'Inspect synthetic input', estimatedTokens: 10, estimatedCostUsd: 0.01 },
    { id: 'review', type: 'review', description: 'Review synthetic input', dependsOn: ['inspect'], estimatedTokens: 20, estimatedCostUsd: 0.02 },
  ] };
  const normal = await tools.get('mcpTools:0018').run(input, context);
  assert.equal(normal.plan.state, 'awaiting_approval');
  capture('awaiting-approval', normal.plan);
  const cancelled = await tools.get('mcpTools:0008').run({ planId: normal.plan.id, reason: 'Synthetic cancellation' }, context);
  assert.equal(cancelled.plan.state, 'cancelled');
  capture('cancelled', cancelled.plan);
  const automatic = await tools.get('mcpTools:0018').run({ ...input, autoApprove: true }, context);
  assert.equal(automatic.plan.state, 'running');
  capture('auto-approved-without-execution', automatic.plan);
  assert.equal(dispatches, 0);
  const manifest = { subject, syntheticOnly: true, normalized: false, dispatches, records };
  writeFileSync(join(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(manifest, null, 2));
} finally {
  await dispose();
}
