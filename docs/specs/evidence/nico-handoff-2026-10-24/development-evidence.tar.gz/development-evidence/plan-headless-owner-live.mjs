import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const home = mkdtempSync(join(tmpdir(), 'agon-headless-live-'));
process.env.AGON_HOME = home;
const api = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
const tools = new Map();
let dispatches = 0;
const services = { receipts: { record: async () => 'synthetic-receipt' },
  engines: { dispatch: () => { dispatches++; throw new Error('Unexpected provider'); } } };
const noop = () => {};
const registrar = { command: () => noop, intent: () => noop, planStep: () => noop,
  tool: (_surface, value) => { tools.set(value.id, value); return noop; } };
const dispose = await (await api.createMod(services)).activate(registrar, services);
const context = { invocationId: 'synthetic-live', cwd: home, platform: 'darwin-arm64', signal: new AbortController().signal, config: {} };
try {
  const output = await tools.get('mcpTools:0018').run({ intent: 'compiled public owner', autoApprove: true,
    steps: [{ id: 'fixture', type: 'self', description: 'synthetic result', estimatedTokens: 5, estimatedCostUsd: 0.02 }] }, context);
  let plan = api.loadCesarPlan(output.plan.id);
  assert.equal(plan.state, 'awaiting_approval');
  assert.equal(plan.totalActualTokens, 0);
  assert.equal(plan.totalEstimatedTokens, 5);
  plan = api.approveCesarPlan(plan);
  api.saveCesarPlan(plan);
  const path = api.cesarPlanJsonPath(plan.id);
  const runningBytes = readFileSync(path);
  await assert.rejects(tools.get('mcpTools:0008').run({ planId: plan.id }, context), /RUNNING/);
  assert.deepEqual(readFileSync(path), runningBytes);
  const completed = api.advanceCesarStep(plan, 'fixture', {
    status: 'success', output: 'synthetic outcome, no provider', actualTokens: 3, actualCostUsd: 0.01, durationMs: 1,
  });
  api.saveCesarPlan(completed);
  const saved = api.loadCesarPlan(plan.id);
  assert.equal(saved.state, 'done');
  assert.equal(saved.totalActualTokens, 3);
  assert.equal(saved.totalActualCostUsd, 0.01);
  assert.equal(saved.steps[0].result.output, 'synthetic outcome, no provider');
  assert.equal(dispatches, 0);
  console.log(JSON.stringify({ passed: true, compiledPublicFactory: true, realFilesystem: true,
    falseRunningPrevented: true, runningBytesPreserved: true, numericAccounting: true, providerLaunches: dispatches }));
} finally { await dispose(); }
