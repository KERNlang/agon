import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const corpus = '/Users/ra/dev/modular-agon-remediation/plan-headless-corpus-ca3b88d8';
const manifest = JSON.parse(readFileSync(join(corpus, 'manifest.json'), 'utf8'));
const { loadCesarPlan, advanceCesarStep } = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
for (const record of manifest.records) {
  const bytes = readFileSync(join(corpus, record.file));
  assert.equal(createHash('sha256').update(bytes).digest('hex'), record.sha256);
  const envelope = JSON.parse(bytes);
  const home = mkdtempSync(join(tmpdir(), 'agon-historical-replay-'));
  process.env.AGON_HOME = home;
  mkdirSync(join(home, 'plans'));
  const file = join(home, record.originalRelativePath);
  writeFileSync(file, bytes, { flag: 'wx' });
  const loaded = loadCesarPlan(envelope.payload.id);
  assert.ok(loaded, 'Historical inspection must remain available');
  assert.equal(loaded.id, envelope.payload.id);
  assert.equal(loaded.state, envelope.payload.state);
  assert.deepEqual(readFileSync(file), bytes, 'Reading must not rewrite historical evidence');
  const advanced = advanceCesarStep(loaded, 'inspect', {
    status: 'success', actualTokens: 1, actualCostUsd: 0.001, output: 'Synthetic result',
  });
  assert.ok(Number.isNaN(advanced.totalActualTokens));
  assert.ok(Number.isNaN(advanced.totalActualCostUsd));
  assert.deepEqual(readFileSync(file), bytes);
  console.log(JSON.stringify({ name: record.name, readable: true, bytesUnchanged: true,
    executionAccountingInvalid: true, savedAfterExecution: false }));
}
