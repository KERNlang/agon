# Headless Plan writer and historical execution records

Status: writer consolidation committed; historical execution admission remains open.
Base: ca3b88d85e73fea8ab619e9c4cfcfad31d224e69. Active remediation goal applies.
No personal histories, installs, providers, push or active Agon changes.

## Source facts

The physical Plan factory in implementation.ts still has private Step/Plan shapes
and uses support-persistence's generic Plan writer. The interactive owner uses
execution-model.ts and execution-store.ts. Both write the same plans directory.
The headless shape lacks totalEstimatedTokens, totalEstimatedCostUsd,
totalActualTokens, totalActualCostUsd and stepContext. A strict canonical shape
guard would therefore reject records this accepted factory already produced.

Candidate WIP contains a 59-line execution-record validator and proposed writer
unification. Do not copy that change wholesale: first preserve actual old outputs
and test historical readability. Existing record bytes must not change on read.

## Required invariants

- One physical Plan writer and one domain state owner for new records.
- Proposing a plan is not proof that execution started or succeeded.
- Headless ExitPlanMode must not overwrite in-flight execution state.
- Historical records remain inspectable, including when the producer is disabled.
- Unknown historical outcomes/costs must not become invented successful results.
- Execution requires a valid, dependency-aware record and current authority.
- Canonical/legacy selection keeps the accepted precedence repair.
- Migrations operate on staged copies and retain original payload evidence.

Normative references: modular-agon-migration-and-verification.md, Historical
replay and Compatibility policy; modular-agon-combined-followup-plan.md, disabled
Plan aliases and historical read-only status. Public signatures and existing
command names remain compatible.

## Next evidence step

Invoke the accepted compiled factory with a synthetic registrar and receipts.
Capture raw envelopes for a normal proposal, autoApprove proposal and cancellation.
Bind the fixture bytes to this commit and SHA-256. Do not mine personal plans.
Then choose and test the smallest compatibility path before changing the writer.
The general support Plan store also serves core's older worktree Plan exports;
trace those consumers before retiring its adapter or narrowing its payload shape.

## Captured evidence, 2026-10-11

Verified on the clean committed subject above. The compiled public createMod
factory produced three synthetic records: awaiting approval, cancelled, and
auto-approved without execution. Engine dispatch count was zero. All five
canonical accounting/context fields are absent in all three payloads.

Raw envelopes are retained without normalization in
`plan-headless-corpus-ca3b88d8/`, outside every Git worktree. Its manifest records
the original relative paths, subject, byte lengths and SHA-256 digests. Each
copy was compared byte-for-byte immediately after capture. No personal data
was read. Do not delete this corpus without Raphael's approval.

Capture: `plan-headless-historical-capture.receipt.json`, exit 0;
log SHA-256 `1d5d58e8f43f9a1bb154f5203364dc74433cac6b045ef86cc103be5fc8501f78`.

Independent replay retrieved and hash-checked each envelope, loaded each through
the compiled canonical store, and proved that the record bytes did not change.
It then called the real advanceCesarStep with a synthetic successful result,
without persisting the result or executing a provider. Both accumulated actual
totals became NaN on all three payloads. This is a reproduced execution-contract
defect, not evidence that a live provider workflow ran.

Replay: `plan-headless-historical-replay.receipt.json`, exit 0;
log SHA-256 `2f75ed5a889104e920c55ddb959b9115217a1cbb86d3b55b6460f7a6db52308a`.

Implementation consequence: preserve inspection separately from execution
admission. A strict shape filter in loadCesarPlan would hide these records and
is not an acceptable repair. New proposals must use createPlanProposal and the
canonical writer. Historical execution needs an explicit compatibility path;
do not assign zero to unknown historical spend merely to satisfy the type.

Original pre-implementation work: trace the registered step-type contract and
execution admission consumers; pin regression cases to the captured corpus;
consolidate proposal/exit mutations without narrowing historical readers.

## Writer consolidation and review history

One production file changes: `packages/mod-plan/src/implementation.ts`.
The existing execution state/store and exit refusal are reused. New tests and
three captured historical fixtures exercise the registered factory. No loader
shape narrowing or read-time migration is added. The support generic Plan API
remains because core's public worktree Plan adapter still exports it.

Source trace: private control() is called only by proposal, read, list and exit
contributions in this file. Interactive approve, retry, cancel and auto controls
already call runPlanSession. Removed private mutation branches had no caller.
The executable Plan type table is fixed; executor.ts reports an absent executor
as failure. Unknown new headless step types now fail proposal validation.

Four tests failed before the repair, then passed with the canonical owner.
Baseline receipt: `plan-headless-owner-red.receipt.json`.
Focused receipts: `plan-headless-owner-fixed.receipt.json` and
`plan-headless-owner-historical.receipt.json` (both exit 0, no providers).

Review subject tree: `653698b65526743352f20976e021949fbe4e01ce`.
Packet SHA-256: `3c75db3ab668574d0e866ccefcdef22663683ba020622864317dfa73ce57829d`.
Codex review succeeded; Kimi returned isolated-profile authentication failure.
No personal authentication changed. Findings to reproduce and adjudicate:
aggregate estimate overflow, missing planning filter state, retained caller
execution fields, historical exit policy, and read/list/route coverage gaps.
Cross-process stale-write fencing remains an inherited open requirement; atomic
rename alone does not establish exclusive execution ownership.

The first full gate passed on the frozen review subject: 8183 tests passed,
6 existing opt-in tests skipped, build/types/lint/structural checks passed,
historical replay and all three compiled SIGKILL checkpoint scenarios passed.
Receipt `plan-headless-owner-full.receipt.json`, 296.269 seconds, no providers;
log SHA-256 `bbe34682500bb5ca43af95f14591a144466113804278ea0f2551b68164eef040`.
This does not qualify the later review fixes.

Review adjudication so far:

- Aggregate overflow: confirmed by failing regression; reject before saving.
- Planning filter: confirmed by schema validation; model now owns the state
  tuple and the headless schema derives its enum from it.
- Forged execution evidence: confirmed; new proposal validation drops result,
  timestamps, runDir and selfReviewCycle. Historical reads remain unchanged.
- Dead private branches: reviewer confirmed the source trace; removal stands.
- Cross-process stale-write fencing: inherited and still open; not solved here.
- Historical mutation policy: explicit exit remains a cancellation, not an
  execution-shape migration. It retains identity, creation time, intent and step
  contents, records cancellation reason/time, and does not invent absent totals
  or context. The canonical writer's contribution ID is not execution eligibility.
  Covered by the historical cancellation test; original fixtures stay unchanged.
- Paused-result preservation: completed/failed steps retain exact results,
  timestamps and existing actual totals; only unfinished steps become cancelled.
  Covered by a dedicated test against the real state/store owner.

`plan-headless-review-red` failed the three reproduced defects. The first fixed
run passed behavior tests but exposed a readonly-array/Json type mismatch in
the schema; corrected with a mutable enum copy, not a type escape.
`plan-headless-review-qualified-focused` then passed focused tests/types/diff
checks. At that checkpoint source remained uncommitted; final qualification follows below.

Fixture correction: removed an extra blank EOF line introduced while adding
the captures. All three tracked fixture byte sequences now exactly equal the
durable raw originals and their original SHA-256 hashes. README states that
fact. No raw evidence was changed.

Final review-resolution controls passed in
`plan-headless-cancellation-controls.receipt.json` (no providers). Exact final
staged subject is tree `a466d18d8c73045a31cbd59db683b18d7d019ac0`.
`plan-headless-owner-qualified` was the full post-fix gate. Its recorded failure
and the completed follow-up qualification are described below.

## Accepted writer increment

Commit `f5ee4eff27c829e89c4ab893f4ec6b9ff8cc2dfd`, tree
`e7bb00cae05912a1230ae7a7ab88afd88718329e`.
Message: `fix(modular): unify headless Plan storage ownership`.
Qualification worktree is clean. Remediation branch/index advanced with
expected-old ref checking and read-tree without checkout; working bytes were
not overwritten. Preservation checks before/after both verified 281 paths with
the unchanged allowlist and identical output hash
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.

Post-fix gate initially stopped on a stale generated migration ledger after
build, types, lint and re-export checks passed. The state model file hash had
changed. Generator output changed exactly 31 definition/assignment hash values,
no keys, ownership assignments or counts. Source and tests stayed identical.
Receipt `plan-headless-owner-qualified` records that failure honestly.

After regeneration, `plan-headless-owner-qualified-tail` passed the ledger,
roadmap, full suite (8192 passed, 6 existing opt-in skips), compiled factory
lifecycle, all three byte-preserving historical reads, and three real SIGKILL
checkpoint scenarios. No providers launched. Log SHA-256:
`90f3140832371dc7e98211929c6640b4559a7238fbc341cae7f95685b51d51b2`.
These two receipts jointly cover the committed source; the only intervening
change was the verified generated hash ledger. This is component acceptance,
not clean-install release qualification or native multi-platform evidence.

The generic support Plan API remains for the older public worktree Plan export.
Historical execution shape and cross-process writer fencing remain actionable.
No personal state, active/global installation or remote branch was changed.

## Next execution-boundary increment

Read trace: execution-coordinator.ts executeApprovedPlan currently saves the
approved object before any shape check; all CLI approved execution uses this
coordinator through signals/dispatch/plan-execution.ts. resume-workflow.ts builds
its prompt before preparing the record. The stored loader intentionally only
validates envelope and identity to retain historical inspection.

Candidate WIP has execution-record.ts and dependency-graph.ts, but using its
strict validator in the loader would regress historical inspection. Reuse the
validator at an execution boundary instead, with explicit old-format handling
and no writes before refusal. Audit public executor and finalize entrypoints as
well; a coordinator-only check must not be claimed universal admission.
No implementation for this next increment is included in the current subject.
