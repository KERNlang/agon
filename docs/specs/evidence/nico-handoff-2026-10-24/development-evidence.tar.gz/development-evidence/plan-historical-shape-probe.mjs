import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

// Probe the old compiled producer against the pending validator, without activation.
const root = mkdtempSync(join(tmpdir(), 'agon-historical-plan-'));
process.env.AGON_HOME = root;
const candidate = '/Users/ra/dev/agon-audit-remediation/packages/mod-plan/src/';
const urls = new Map();
function moduleUrl(name) {
  if (urls.has(name)) return urls.get(name);
  const source = readFileSync(candidate + name.replace(/\.js$/, '.ts'), 'utf8');
  let code = ts.transpileModule(source, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  } }).outputText;
  code = code.replace(/from ['"]\.\/([^'"]+)['"]/g, (_all, dependency) => `from '${moduleUrl(dependency)}'`);
  const url = 'data:text/javascript;base64,' + Buffer.from(code).toString('base64');
  urls.set(name, url);
  return url;
}
try {
  const { createMod } = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
  const { loadPersistedPlan } = await import('/Users/ra/dev/agon-audit-qualification/packages/support-persistence/dist/index.js');
  const { isPersistedCesarPlan } = await import(moduleUrl('execution-record.js'));
  const tools = new Map();
  const noop = () => () => {};
  const dispose = await createMod({ receipts: { record: async () => 'isolated-receipt' } }).activate({
    intent: noop, command: noop, planStep: noop,
    tool: (surface, tool) => { tools.set(`${surface}:${tool.id}`, tool); return () => {}; },
  });
  for (const autoApprove of [false, true]) {
    const result = await tools.get('mcp:mcpTools:0018').run({
      intent: 'Historical producer compatibility probe', autoApprove,
      steps: [{ id: 'one', type: 'self', description: 'fixture step' }],
    }, {});
    assert.equal(result.receiptId, 'isolated-receipt');
    const persisted = loadPersistedPlan(result.plan.id);
    assert.ok(persisted);
    assert.equal(persisted.state, autoApprove ? 'running' : 'awaiting_approval');
    assert.equal(isPersistedCesarPlan(persisted, persisted.id), false);
    console.log(JSON.stringify({ actualLegacyProposal: true, autoApprove,
      oldReaderAccepts: true, pendingValidatorAccepts: false,
      missingFields: ['totalEstimatedTokens', 'totalEstimatedCostUsd', 'totalActualTokens',
        'totalActualCostUsd', 'stepContext'].filter(key => !(key in persisted)) }));
  }
  await dispose();
} finally { rmSync(root, { recursive: true, force: true }); }
