import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const api = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
process.env.AGON_HOME = mkdtempSync(join(tmpdir(), 'plan-outcome-live-'));
const noop = () => {};
const good = { status: 'success', output: 'known', actualTokens: 2, actualCostUsd: 0.1, durationMs: 1 };
const callbacks = () => ({ onStepStart: noop, onStepDone: noop, onPlanUpdate: noop, onBudgetWarning: noop, flush: noop });
for (const parallel of [false, true]) {
  let release;
  let started;
  const barrier = new Promise(resolve => { started = resolve; });
  const wait = new Promise(resolve => { release = resolve; });
  const calls = [];
  const plan = { ...api.approveCesarPlan(api.createCesarPlan('invalid result recovery', ['bad', 'good'].map(id => ({
    id, type: 'self', description: id, estimatedTokens: 2, estimatedCostUsd: 1, parallel,
  })))), selfReview: false };
  const execute = async step => {
    calls.push(step.id);
    if (step.id === 'bad') return { result: { status: 'success', output: 'unknown cost' } };
    started();
    await wait;
    return { result: good };
  };
  const host = { createExecutors: () => ({ self: { execute } }),
    executePlan: api.createPlanExecutor({ recordStepCompletion: noop }), callbacks,
    setActivePlan: noop, setAbort: noop, releaseAbort: noop, save: api.saveCesarPlan,
    writeMarkdown: noop, hasWorkingTreeChanges: () => false, estimateReview: () => ({ tokens: 1, costUsd: 0 }),
    takeFallback: () => ({ engine: 'fallback', stepId: 'bad' }), notify: noop, warn: noop };
  let settled = false;
  const task = api.createPlanCoordinator(host).executeApprovedPlan(plan).finally(() => { settled = true; });
  if (parallel) {
    await barrier;
    assert.equal(settled, false);
    release();
  }
  await task;
  const saved = api.loadCesarPlan(plan.id);
  assert.equal(saved.state, 'paused');
  assert.equal(saved.steps[0].state, 'running');
  assert.equal(saved.steps[0].result, undefined);
  assert.equal(saved.totalActualCostUsd, parallel ? good.actualCostUsd : 0);
  assert.deepEqual(calls, parallel ? ['bad', 'good'] : ['bad']);
  if (parallel) assert.deepEqual(saved.steps[1].result, good);
  const path = api.cesarPlanJsonPath(plan.id);
  const before = readFileSync(path);
  assert.throws(() => api.prepareCesarPlanResume(saved, 'resume'), /unknown/);
  assert.deepEqual(readFileSync(path), before);
  console.log(JSON.stringify({ parallel, compiled: true, realStorage: true, unknownOutcomePreserved: true, calls }));
}
