# Plan returned-outcome and review-estimate contract

Status: locally qualified and committed. Base commit caa97b71f0c65ce6d094bccca98efb3f68d8e98e.
Original acceptance remains unchanged. This increment addresses the confirmed
third finding in the record-admission review, not whole-release qualification.

## Reproduction

`plan-outcome-contract-red2` reproduced five failing cases: undefined backend
response became a synthetic failed step, incomplete success became a done plan,
and NaN/Infinity/negative review estimates were persisted before validation.
Log SHA-256: 376c6a21e400b0e0d217be4261cf6266ac279ee6b2ff166fac2de9c44043c5c8.
The preceding `plan-outcome-contract-red` failed to locate vitest and is not
defect evidence. The corrected invocation uses the installed binary path.

## Design

Reuse the existing saved-result validator at the backend return boundary.
Reject malformed returned outcomes outside the backend exception catch. Keep
the started marker rather than invent a failure, result, or cost. Coordinator
uses existing checkpoint-failure recovery for unknown outcomes. Parallel work
must drain and preserve valid sibling results. Review plan validation occurs
before publishing, persisting, or spending the review cycle.

## Remaining verification

- `plan-outcome-contract-focused` tested stale public package output: its five
  failures reproduced the old behavior after source edits. Public imports resolve
  to dist; rebuild is required. The original baseline was current at that point.
  Corrected `plan-outcome-contract-built` rebuilds modular packages before tests
  and typecheck (live process handle 62658 when launched).
- Expand coverage: malformed fields/context, parallel drain and sibling outcome,
  fallback refusal, resume refusal, valid backend exceptions unchanged.
- Validate both estimate fields, missing estimates, and recovery/re-entry.
- Default isolated Agon review once the change is complete.
- Full gates, compiled filesystem runtime evidence, preserved-work verification.
- No commit until complete. No push, installs, or personal-state changes.

Do not claim malformed raw output is archived: this implementation preserves
the unknown-outcome marker, not a new quarantine store. Review whether existing
backend artifacts provide sufficient recovery information before acceptance.

## Local results

`plan-outcome-contract-built` passed modular package builds, 112 focused tests,
and typecheck. SHA-256:
`74458ba194bd607204f268c494b7f49f746ba97e1170aa4cc6559c473cd7286e`.
`plan-outcome-contract-live` passed one real compiled/filesystem process with
sequential and parallel scenarios. It verifies fallback cannot repeat unknown
work, successful sibling cost/results survive, resume rejects unknown outcomes,
and rejected resume leaves stored bytes unchanged. SHA-256:
`b89d2d40f9ba9781027e3f4f43a58a09197b0a9b9852ffb652224afa38285ce1`.
Both runs recorded zero provider launches.

Expanded tracked tests cover invalid numeric results/context, both estimate
fields, resume refusal, and real-file parallel drain. The expanded test run is
`plan-outcome-contract-expanded` (process 29983 at launch). No production edits
since the successful build. Still requires full gates and independent review.

Expanded tests/typecheck/diff check passed; log SHA-256:
`83d4eb60d6584465e93ffbe537b95a11605dffe05354fdab81788b3617f74a45`.
Full qualification launched as `plan-outcome-contract-full`; do not edit source
or tracked tests while this command is live. Review packet is not prepared yet.

## Independent review (received, not yet adjudicated)

Frozen staged tree: `ab2cfd02123157327381e0abc52e97c101f8ad5f`.
Agon Codex packet SHA-256:
`91ac41165a0cd9735879ae55b058d317bf6bf95510fc93b911573a8e0ba95f3b`.
Codex log SHA-256:
`23ae79ab92d00a1c535689216fb39089445528ce118ca079457ae3d32baf9300`.
Kimi failed isolated authentication; no personal settings were changed.

Review hypothesis: parallel malformed A + valid timeout B + queued fallback B
can start another phase despite A being unknown. A failed first checkpoint in
the next phase resets all running/not-started-in-this-phase steps to pending,
including A. Reproduce before acceptance. Source confirms both predicates exist,
but full sequence needs an executable regression. Proposed narrow repair: block
fallback on any unresolved started outcome and only reset running markers newly
admitted by the current phase. Also correct generic resume advice for unknown
outcomes. Additional checks: reversed completion order, cancellation during bad
return, and no invalid review publication. No second panel after local fixes.

Separate documentation debt observed while waiting: acceptance-roadmap.md still
labels substantial implemented slices as specified-only, and S5 ledger adapter
text is historical. Reconcile against source during final qualification rather
than silently treating old prose as current implementation evidence.

Current handoff: full gate process 62224 remains live, last observed in lint
after build/types. Both review processes are terminal (Codex success, Kimi auth
failure). Working tree has no unstaged changes; five explicit paths are staged
at the frozen tree above. After the gate ends, add mixed-fallback regression to
the existing checkpoint suite, demonstrate red, then repair and rerun. Existing
full-gate success cannot accept the pending review finding. Preserve all logs.

Compiled in-memory reproduction confirmed the review sequence on 2026-10-11.
Actual output: `{"calls":2,"failed":true,"steps":[{"id":"a","state":"pending"},{"id":"b","state":"pending"}],"resumable":true}`.
The host save stub failed exactly once when fallback B reached running state;
both A and B then became pending. No providers or filesystem persistence were
used by this reproduction. Add this as a durable tracked regression after the
current full gate stops; its result alone does not satisfy final verification.

## Review adjudication and corrective verification

The first full gate passed (log `267625a71989dcfca776ee4f4cd2e0355f05b5074caf85976f5233ef6ac322ff`),
but does not accept the confirmed review defect. Both durable regression tests
failed before the follow-up repair (`plan-outcome-review-red`, hash
`6efb5365b2c3cb8471365c5da03b5cde6dc9dd7bf6d3c1c27f6e60d160c3d265`).

Repair: reuse one unknown-outcome predicate for resume, fallback, and operator
advice. Refuse all automatic fallback while any started outcome is unknown.
Checkpoint recovery resets only running markers not present at phase entry and
not actually started in this phase. Existing unknown markers survive. No new
state store or public package export was added.

`plan-outcome-review-fixed` passed the checkpoint suite/types/diff gate (hash
`565c20f28324c38767f3cc8cc03afb17a807e2cfab04406b58cd36fbc58e788b`).
`plan-outcome-review-matrix` additionally passed reverse sibling order and
cancellation during malformed return (hash
`bfbef5f76b27ca591804382d63516b4dbe997543c5ec17974f0faa046f7704e3`).
Invalid-estimate tests also assert the rejected review never reaches active-plan
publication. Those public-import tests require the next rebuild to qualify.

New frozen staged tree: `8bd89abe5769be371d8adcba6e2e9726e9a18237`.
Full final command `plan-outcome-contract-qualified` launched, handle 36536.
It includes both compiled filesystem probes and three SIGKILL scenarios.
No source changes during that run. No second review panel is required by the
one-review-per-change rule; locally verified adjudication remains mandatory.
No commit yet. Candidate working-tree bytes remain unchanged.

## Final receipt

Commit `4726ab50034384a82299191a423c1e2af9a06353` has the exact final frozen tree
`8bd89abe5769be371d8adcba6e2e9726e9a18237`. Qualification checkout is clean.
`plan-outcome-contract-qualified` passed in 299.178 seconds: full build/types/lint,
re-export, first-party ledger and roadmap gates; 8,239 tests passed, 6 skipped;
two compiled filesystem probes and three real SIGKILL scenarios passed. No
provider launches were recorded. Log SHA-256:
`cfb1301cda65a4405686d779164c2eca2ade6f3bd43cbf0c0584f2788c8e3b5f`.
Six skips remain the previously recorded provider, pyte and opt-in compiler
cases, not passing evidence. Kimi isolated review remains unavailable.

The source-verified review finding is fixed with failing-before/passing-after
controls and final compiled runtime proof. Codex reviewed the pre-adjudication
tree; do not label its review as a fresh review of the final commit.

Candidate branch/index advanced with an expected-old ref check and index-only
read-tree. Its working-tree bytes were not overwritten. Before/after preservation
checks passed over 281 recorded paths with the existing allowlist; log hash
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
No push, installation, or promotion. This qualifies the outcome-contract repair,
not the release. Continue original ownership and release work; see
`remaining-ownership-source-check.md` for verified follow-on consumers.
