import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import * as api from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';
process.env.AGON_HOME = mkdtempSync(join(tmpdir(), 'plan-outcome-review-'));
const noop = () => {};
const timeout = { status: 'failure', output: '', error: 'timeout', actualTokens: 1, actualCostUsd: 0.01, durationMs: 1 };
const plan = { ...api.approveCesarPlan(api.createCesarPlan('mixed outcome regression', ['a', 'b'].map(id => ({
  id, type: 'self', description: id, parallel: true, engine: 'original', estimatedTokens: 1, estimatedCostUsd: 1,
})))), selfReview: false };
let failed = false;
let calls = 0;
const host = {
  createExecutors: () => ({ self: { execute: async step => { calls++; return { result: step.id === 'a' ? {} : timeout }; } } }),
  executePlan: api.createPlanExecutor({ recordStepCompletion: noop }),
  callbacks: () => ({ onStepStart: noop, onStepDone: noop, onPlanUpdate: noop, onBudgetWarning: noop, flush: noop }),
  setActivePlan: noop, setAbort: noop, releaseAbort: noop,
  save: value => {
    if (!failed && value.fallbackRetriesUsed?.b && value.steps.find(step => step.id === 'b').state === 'running') {
      failed = true;
      throw Error('intent write failed');
    }
    api.saveCesarPlan(value);
  },
  writeMarkdown: noop, hasWorkingTreeChanges: () => false, estimateReview: () => ({ tokens: 0, costUsd: 0 }),
  takeFallback: () => ({ engine: 'fallback', stepId: 'b' }), notify: noop, warn: noop,
};
await api.createPlanCoordinator(host).executeApprovedPlan(plan);
const saved = api.loadCesarPlan(plan.id);
assert.equal(calls, 2);
assert.equal(failed, false);
assert.equal(saved.steps[0].state, 'running');
assert.deepEqual(saved.steps[1].result, timeout);
assert.throws(() => api.prepareCesarPlanResume(saved, 'resume'), /unknown/);
console.log(JSON.stringify({ compiled: true, realStorage: true, calls, fallbackBlocked: true, unknownMarkerRetained: true }));
