import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { resolve, sep } from 'node:path';
import { readFileSync } from 'node:fs';

const root = '/Users/ra/dev/agon-audit-qualification';
const require = createRequire(resolve(root, 'package.json'));
const ts = require('typescript');
const directory = resolve(root, 'packages/mod-plan');
const manifest = JSON.parse(readFileSync(resolve(directory, 'agon.mod.json'), 'utf8'));
const allowed = new Set(manifest.pack.include.map(file => resolve(directory, file)));
const consumer = resolve(root, 'packed-plan-consumer.virtual.ts');
const source = `import {
  createAgentReviewStepExecutors, createForgeStepExecutors, createPipelineStepExecutor,
  createSelfStepExecutor,
} from '@kernlang/agon-mod-plan';
import type { PlanAgentReviewHost, PlanForgeHost, PlanPipelineHost, PlanPipelineRun, PlanPipelineIssue, PlanSelfStepHost } from '@kernlang/agon-mod-plan';
declare const agent: PlanAgentReviewHost;
declare const forge: PlanForgeHost;
declare const pipeline: PlanPipelineHost<{ logicalPlanId: string }, PlanPipelineRun, PlanPipelineIssue>;
declare const self: PlanSelfStepHost;
createAgentReviewStepExecutors(agent);
createForgeStepExecutors(forge);
createPipelineStepExecutor(pipeline);
createSelfStepExecutor(self);
`;
const options = { strict: true, noEmit: true, skipLibCheck: false,
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  moduleResolution: ts.ModuleResolutionKind.Bundler, esModuleInterop: true,
  resolveJsonModule: true, ignoreDeprecations: '6.0', types: ['node'],
  typeRoots: [resolve(root, 'node_modules/@types')], baseUrl: root,
  paths: { '@kernlang/agon-mod-plan': [resolve(directory, 'dist/index.d.ts')] } };

function diagnostics(removed) {
  const host = ts.createCompilerHost(options);
  const originalRead = host.readFile.bind(host);
  const originalExists = host.fileExists.bind(host);
  const accessible = file => {
    const absolute = resolve(file);
    return !absolute.startsWith(resolve(directory, 'dist') + sep)
      || allowed.has(absolute) && absolute !== removed;
  };
  host.readFile = file => resolve(file) === consumer ? source : accessible(file) ? originalRead(file) : undefined;
  host.fileExists = file => resolve(file) === consumer || accessible(file) && originalExists(file);
  return ts.getPreEmitDiagnostics(ts.createProgram([consumer], options, host));
}

const baseline = diagnostics();
assert.equal(baseline.length, 0, ts.formatDiagnosticsWithColorAndContext(baseline, {
  getCanonicalFileName: file => file, getCurrentDirectory: () => root, getNewLine: () => '\n',
}));
const publicDeclarations = ['agent-review-step-execution', 'forge-step-execution',
  'pipeline-step-execution', 'self-step-execution'];
for (const name of publicDeclarations) {
  const removed = resolve(directory, 'dist', name + '.d.ts');
  assert(allowed.has(removed));
  const failures = diagnostics(removed);
  assert(failures.some(item => item.code === 2307 && ts.flattenDiagnosticMessageText(item.messageText, '\n').includes(name)),
    'Missing packed declaration survived: ' + name);
}
for (const internal of ['dependency-graph', 'execution-record']) {
  assert(!allowed.has(resolve(directory, 'dist', internal + '.d.ts')));
}
console.log(JSON.stringify({ publicConsumerCompiles: true, privateDeclarationsUnavailable: 2,
  missingPublicDeclarationControls: publicDeclarations.length, mode: 'compiler filesystem constrained to Plan pack allowlist' }));
