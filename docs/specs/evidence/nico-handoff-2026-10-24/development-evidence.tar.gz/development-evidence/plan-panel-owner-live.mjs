import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createHash } from 'node:crypto';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const plan = await import(join(repo, 'packages/mod-plan/dist/index.js'));
assert.equal(typeof plan.createPlanProposal, 'function', 'Keep the existing public export');
const fixture = readFileSync(join(repo, 'tests/fixtures/modular-plan-panel-steps-legacy.ts'), 'utf8');
console.log(JSON.stringify({ helperSha256: createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'),
  fixtureSha256: createHash('sha256').update(fixture).digest('hex') }));
const root = mkdtempSync(join(tmpdir(), 'agon-panel-owner-'));
const previousHome = process.env.AGON_HOME;
process.env.AGON_HOME = root;
const now = Date.now;
Date.now = () => 123456789;
let cases = 0;
try {
  for (const kind of ['brainstorm', 'tribunal', 'campfire', 'delegate']) {
    for (const scenario of ['default', 'explicit', 'empty', 'active-throws', 'error', 'string-error', 'aborted', 'revoked-return', 'cancelled-return']) {
      let controller;
      let available = true;
      let reads = 0;
      let calls = [];
      const snapshot = () => ++reads === 1 ? { totalTokens: 10, meteredCostUsd: 1 } : { totalTokens: 17, meteredCostUsd: 1.25 };
      const assertAvailable = (_type, signal) => {
        signal?.throwIfAborted();
        if (!available) throw new Error('revoked');
      };
      const backend = async options => {
        calls.push(options);
        if (scenario === 'error') throw new Error('failed');
        if (scenario === 'string-error') throw 'failed';
        if (scenario === 'revoked-return') available = false;
        if (scenario === 'cancelled-return') controller.abort(new Error('cancelled'));
        return { winner: 'fixture', response: 'x'.repeat(650), summary: 'review', rounds: [{ engineId: 'speaker', content: 'y'.repeat(240) }] };
      };
      const ctx = { registry: {}, adapter: {}, activeEngines() {
        if (scenario === 'active-throws') throw new Error('unavailable');
        return scenario === 'empty' ? [] : ['active', '', ' second '];
      } };
      const exports = {};
      const modules = {
        'node:fs': await import('node:fs'), 'node:path': await import('node:path'),
        '@kernlang/agon-core': { resolveWorkingDir: () => root, RUNS_DIR: root, tracker: { getStats: snapshot } },
        '@kernlang/agon-forge': { runBrainstorm: backend, runTribunal: backend, runCampfire: backend, runDelegate: backend },
      };
      const authority = { assertProcessSurfaceAvailable: () => assertAvailable(), assertProcessPlanStepAvailable: () => assertAvailable(),
        captureProcessSurfaceAuthority: () => () => assertAvailable(), guardProcessEngineAdapter: adapter => adapter,
        withProcessSurfaceAuthority: (_signal, _check, run) => run(_signal) };
      new Function('exports', 'require', ts.transpileModule(fixture, { compilerOptions: {
        target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
      } }).outputText)(exports, id => {
        if (id.endsWith('surface-authority-runtime.js')) return authority;
        assert.ok(modules[id], id);
        return modules[id];
      });
      const options = { outputDir: join(root, 'runs', 'plan-exec-123456789'), assertAvailable,
        snapshot: () => { const s = snapshot(); return { tokens: s.totalTokens, cost: s.meteredCostUsd }; },
        activeEngines: () => ctx.activeEngines(),
        ...Object.fromEntries(['brainstorm', 'tribunal', 'campfire', 'delegate'].map(type => [type,
          value => backend({ ...value, registry: ctx.registry, adapter: ctx.adapter })])) };
      const step = { id: 'step', type: kind, description: 'task', imports: ['source', 'empty', 'absent'],
        tribunalMode: 'steelman', estimatedTokens: 0, estimatedCostUsd: 0,
        ...(scenario === 'explicit' ? { engine: 'selected', engines: ['explicit', ' '] } : {}) };
      const observations = [];
      for (const build of [() => exports.buildLegacyPanelStepExecutors(ctx), () => plan.createPanelStepExecutors(options)]) {
        available = true; reads = 0; calls = [];
        // Each replay receives the same initial cancellation state, not the prior replay's effect.
        controller = new AbortController();
        if (scenario === 'aborted') controller.abort(new Error('cancelled'));
        let outcome;
        try { outcome = await build()[kind].execute(step, { source: 'facts', empty: '' }, controller.signal); }
        catch (error) { outcome = { thrown: error instanceof Error ? error.message : String(error) }; }
        observations.push({ outcome, calls });
      }
      assert.deepEqual(observations[1], observations[0], `${kind}/${scenario}`);
      if (scenario === 'cancelled-return') {
        for (const observation of observations) {
          assert.equal(observation.outcome.result?.status, 'failure');
          assert.equal(observation.calls.length, 1);
          assert.equal(observation.calls[0].signal.aborted, true);
        }
      }
      cases++;
    }
  }
  console.log(JSON.stringify({ passed: true, cases, compiledPhysicalOwner: true, backends: 'observation stubs', legacyOracle: 'frozen Git source' }));
} finally {
  Date.now = now;
  if (previousHome === undefined) delete process.env.AGON_HOME; else process.env.AGON_HOME = previousHome;
  rmSync(root, { recursive: true, force: true });
}
