# Plan panel ownership extraction: qualification in progress

Base commit: `841e27299dbf5c3eba8962d50ed111ab16a2fd4b`.
Worktree: `/Users/ra/dev/agon-audit-qualification`.
This is not a release receipt or a completed-slice claim.

The four panel step algorithms now reside in `mod-plan`. CLI retains process
authority, cancellation monitoring, guarded backend adapters and usage tracking.
The existing `createPlanProposal` public export remains present.

## Verified evidence

- `plan-panel-owner-focused.receipt.json`: typecheck and 128 tests passed.
  Log SHA-256: `d51d6acd7233609fbe7fd2cdf6eba2cc7ab7f29f324a171e5321e2ce299c8143`.
- `plan-panel-owner-native-corrected.receipt.json`: 36 native compiled-owner
  comparisons passed against the frozen Git-source fixture. Backends and
  authority were observation stubs, not live providers or a full CLI host.
  Log SHA-256: `2c4d66191cf2944a479a45bffc322b11781dccd8dbe49c8749f246e69975f976`.
- Helper SHA-256: `607b411fa7b22cb511014e2cbe1704f8a7f64f5bb2abde6eb311ac0591acef1f`.
- Fixture SHA-256: `6f8488bf944ad77f7cd6c0e0dc878a9a7594e433541886c889c0a5c62ee90134`.
- No provider launches occurred in these runs.

## Harness corrections, not product fixes

The draft helper reused an aborted controller for the second cancellation
replay and skipped equality for that case. It now creates a fresh controller
per replay and compares both observations for every case. It also checks that
both cancellation replays called the backend once and returned failure.

The first native run then detected different output paths. The helper supplied
`root/plan-exec-*`; the actual CLI supplies `root/runs/plan-exec-*`. Correcting
the injected helper path made all comparisons pass. The failed receipt remains
available as `plan-panel-owner-native.receipt.json`; it was not overwritten.

## Still required

The first full build passed in 150.98 seconds. Its log SHA-256 is
`800171be5f61009bbb9b3f9e3df115f73881f25ef91160e3a2117e583c8bb800`.
The following full gate stopped at generated package drift. The generator
needed the new declaration allowlist entry and public exports. It is now
updated; the drift gate passes without weakening its check.

Codex reviewed frozen tree `4c6abc07d2fae5c6d3c3b965af19e33a73aeb52a`.
Packet SHA-256: `b22c226a817399839729b6f7077ae9fd3297f40148d255cb8cae70a4c2e52373`.
Review log SHA-256: `d71a1542ff204c01f89b31afe4442aeed432bbe7399f34e63633e14cba5b1b88`.
The reviewer found that standalone host methods lose their receiver when
`activeEngines` is passed bare. Three tests reproduced this. Four more tests
proved that an already-aborted direct-owner call reached the backend when
the host checked availability only. All seven failed before the corrections.
The owner now binds engine selection through the host and rejects cancellation
before host, meter or backend effects. Existing CLI behavior remains unchanged.

`plan-panel-owner-review-green` passes 24 direct-owner tests, generated drift,
typecheck and the independent mod-plan build. Log SHA-256:
`b5d88eedda6145f7c11c4a147852b754f03be6dee9eb060c64ed92f6885b8b39`.
`plan-panel-owner-pack` verifies exact packed-file equality with the manifest.
Log SHA-256: `67c28e0f9aec56832649b7a80e59990f90a72c5808ccef34a0ec7ab9f5a392af`.

Corrected staged tree: `d526752f01a15ae7642758ebfd8dcde6e025d3fd` (nine paths).
`plan-panel-owner-qualified` is running under terminal handle 73831: full build,
types, lint, re-export guard, drift, roadmap, full tests, compiled CLI guard and
admission checks, and native owner parity. Poll this run; do not rebuild while
it is running. Kimi review of the original frozen tree remains live under
handle 32707; Codex finished under handle 88434. Do not rerun either review.

Still needed: finish qualification, read and source-verify Kimi findings,
finish adjudication, preserve candidate WIP and commit the verified slice.
No global installation or candidate WIP was changed here. Continue the original
roadmap after this slice; it does not complete Plan or the whole release.

## Kimi review adjudication in progress

Kimi completed with exit 0, log SHA-256
`360ba6cd2a6f8f2a971ef6f557262885aeb16fce3eb0f03193097dd0b042b688`.
Both reviewers inspected the same original packet. Corrective changes are
verified locally; another panel is not required by the review rules.

- D1: the extra owner admission check is real, including additional synchronous
  authority reads. It deliberately rejects before backend/meter effects. There
  is no asynchronous yield between the CLI and owner admission checks; a
  separate process can still change the pointer between those checks. Do not
  claim identical filesystem-read traces or eliminate this check to hide that
  distinction. Both serial and parallel execution in `mod-plan/src/executor.ts`
  catch admission rejection and persist a failed step with zero usage; they do
  not record a completion estimate for work that never began. Existing CLI and
  monitor admission checks already have this behavior. Tests explicitly pin
  direct-owner rejection before effects. This is a justified boundary check,
  not a demonstrated lost backend charge or release blocker.
- D2: structural signal assertions do not guarantee identity. Add explicit
  identity assertions after the current frozen qualification finishes.
- D3: the parity test configures the tracker spy for each replay. Explicit
  restore between replays will make isolation clear; do not claim an observed
  false pass from the reviewer hypothesis alone.
- D4: native parity already includes backend-triggered cancellation and
  revocation for all four owners; the 77-case initialized-host suite separately
  covers post-return rejection, late dispatch, caller cancellation, generation
  replacement and monitor cleanup. The frozen algorithm oracle intentionally
  does not independently prove the shared authority implementation.
- Proposed initialized-host, guarded-method, monitor cleanup and executor-key
  cases are already covered in `modular-plan-step-admission.test.ts` (including
  six adapter methods, stream return/throw and conflicting caller step types).
  These are verified source references, not claims based on test counts.

`plan-panel-owner-preserved` confirms the 281-path candidate WIP baseline.
Log SHA-256: `bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.

## Qualification completed; final test-only strengthening

`plan-panel-owner-qualified` passed in 281.522 seconds on staged tree
`d526752f01a15ae7642758ebfd8dcde6e025d3fd`: full build, types, lint, re-export
guard, generated drift, roadmap, full repository suite, seven compiled CLI
guard/monitor cases, 14 compiled CLI admission cases, and 36 native owner parity
cases. Zero provider launches. Log SHA-256:
`e99d6178bbc4ea844d6b51d1a77767dafa9c69ff8261caec345a6ab5c31b5aa1`.

D2 and D3 are now addressed: direct-owner and CLI parity tests assert the exact
AbortSignal object with `toBe`; the tracker spy is restored after each replay.
Production source did not change. Final staged tree:
`4df9aa3bc2f6df8e4662479be8dc2fd65e36eec4`.
`plan-panel-owner-final-tests` is running under handle 13614: types, lint, full
repository tests and all native checks again. Do not restart it or modify the
subject during the run. The earlier handles 73831 and 32707 are terminal,
both successful. No commit or candidate fast-forward has happened yet.

## Completed increment

Final rerun passed in 130.767 seconds, 7,559 tests passed and six skipped,
followed by all native checks. Zero provider launches. Log SHA-256:
`afdb546aa2dfca493b0483c01303388bed8398c306fc18fe7a48eaee21a29474`.
Commit `c954b188930c4c5de57b8eeecdf5bcf23e479872` has final tree
`4df9aa3bc2f6df8e4662479be8dc2fd65e36eec4`. Qualification checkout is clean.
Candidate branch fast-forwarded through an expected-old ref update and
index-only read-tree. Working files were not overwritten. Older candidate draft
panel files remain WIP; use the qualified commit for verified behavior.
All run/review handles above are now terminal. Continue Forge post-return
effect authority next; the whole release remains incomplete.
