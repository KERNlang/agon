import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const root = mkdtempSync(join(tmpdir(), 'agon-plan-presentation-'));
process.env.AGON_HOME = root;
try {
  const plan = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
  const core = await import('/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js');
  assert.equal(core.formatCesarPlanMarkdown, plan.formatCesarPlanMarkdown);
  assert.ok(core.planCostEstimator instanceof plan.PlanCostEstimator);
  core.planCostEstimator.reset();
  const parsed = core.sanitizePlanSteps([
    { id: 'first', type: 'self', description: 'First', exports: 'answer', estimatedCostUsd: -999 },
    { id: 'second', type: 'self', description: 'Second', dependsOn: ['first'], imports: 'answer', fitnessCmd: 'human-visible command' },
    { id: 'ignored', type: 'unknown' },
  ]);
  assert.equal(parsed.dropped, 1);
  assert.ok(parsed.steps.every(step => step.estimatedTokens > 0 && step.estimatedCostUsd >= 0));
  const draft = core.createCesarPlan('Cost and display native probe', parsed.steps);
  assert.ok(core.formatCesarPlanMarkdown(draft).includes('human-visible command'));
  const calls = [];
  const finished = await core.executePlan(core.approveCesarPlan(draft), {
    self: { execute: async (step, context) => {
      calls.push(step.id);
      if (step.id === 'second') assert.equal(context.answer, 'shared context');
      return { result: { status: 'success', actualTokens: step.id === 'first' ? 100 : 300,
        actualCostUsd: step.id === 'first' ? 0.1 : 0.3, durationMs: 2, output: 'done' },
        contextExport: 'shared context' };
    } },
  }, { onStepStart() {}, onStepDone() {}, onBudgetWarning() {}, onPlanUpdate: core.saveCesarPlan });
  assert.deepEqual(calls, ['first', 'second']);
  assert.equal(finished.state, 'done');
  const next = core.sanitizePlanSteps([{ id: 'next', type: 'self', description: 'Next', estimatedCostUsd: -999 }]);
  assert.equal(next.steps[0].estimatedTokens, 200);
  assert.equal(next.steps[0].estimatedCostUsd, 0.2);
  const saved = core.loadCesarPlan(finished.id);
  assert.equal(saved.state, 'done');
  assert.equal(saved.totalActualTokens, 400);
  assert.equal(saved.stepContext.answer, 'shared context');
  assert.equal(core.formatCesarPlanMarkdown(saved), plan.formatCesarPlanMarkdown(saved));
  assert.ok(core.formatCesarPlanMarkdown(saved).includes('Actual: 400 tokens'));
  const raw = JSON.parse(readFileSync(core.cesarPlanJsonPath(finished.id), 'utf8'));
  assert.equal(raw.ownerModId, 'agon.plan');
  core.planCostEstimator.reset();
  console.log('PASS public Plan/Core identity, sanitize, two-step execution, history feedback, persisted envelope and Markdown; no provider dispatch');
} finally {
  rmSync(root, { recursive: true, force: true });
}
