import { PlanCostEstimator, createPlanStepSanitizer, formatCesarPlanMarkdown } from '../agon-audit-qualification/packages/mod-plan/dist/index.js';
import type { PlanCostPricing, PlanStepEstimator, CostEstimate, CesarPlan } from '../agon-audit-qualification/packages/mod-plan/dist/index.js';
import { planCostEstimator, sanitizePlanSteps, formatCesarPlanMarkdown as formatCore } from '../agon-audit-qualification/packages/core/dist/index.js';
import type { CostEstimate as CoreEstimate } from '../agon-audit-qualification/packages/core/dist/index.js';

const pricing: PlanCostPricing = (_engine, tokens) => tokens / 1000;
const estimator: PlanStepEstimator = new PlanCostEstimator(pricing);
const compatible: PlanStepEstimator = planCostEstimator;
const estimate: CoreEstimate = estimator.estimate('self', []);
const result: CostEstimate = estimate;
const sanitize: typeof sanitizePlanSteps = createPlanStepSanitizer(estimator);
declare const plan: CesarPlan;
const formatter: typeof formatCore = formatCesarPlanMarkdown;
void [compatible, result, sanitize, formatter, plan];
