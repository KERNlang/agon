import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
if (!process.argv[2]) {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  const scenarios = ['dispatch', 'dispatchAgent', 'dispatchStream', 'dispatchAgentStream', 'isAvailable', 'getVersion', 'monitor'];
  for (const scenario of scenarios) process.stdout.write(execFileSync(process.execPath,
    [process.argv[1], scenario], { encoding: 'utf8', timeout: 30000 }));
  console.log(JSON.stringify({ passed: true, nativeProcesses: scenarios.length }));
  process.exit(0);
}
const scenario = process.argv[2];
const root = mkdtempSync(join(tmpdir(), 'agon-step-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const fixture = {};
new Function('exports', 'require', ts.transpileModule(readFileSync(join(repo,
  'tests/helpers/modular-surface-lock.ts'), 'utf8'), { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
async function owner(symbol) {
  const files = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
  assert.equal(files.length, 1, symbol);
  const module = await import(pathToFileURL(join(directory, files[0])).href);
  assert.equal(typeof module[symbol], 'function', symbol);
  return module;
}
const authority = await owner('initializeProcessSurfaceAuthority');

const host = new kernel.DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0', processIdentity: 'native-step' });
async function install(disabledId) {
  const catalog = kernel.createFirstPartyModCatalog();
  const full = kernel.createFullCompatDesiredState(catalog, '2026-10-10T00:00:00.000Z');
  const desired = disabledId ? kernel.planDesiredStateChange(catalog, full,
    { kind: 'disable', id: disabledId }, '2026-10-10T00:00:00.000Z').nextState : full;
  await host.commitGeneration({ operation: disabledId ? 'disable' : 'install',
    lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
}
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isDirectory()) unlock(join(path, entry.name));
  }
}
try {
  await install();
  await authority.initializeProcessSurfaceAuthority(join(root, 'host'));
  if (scenario === 'monitor') {
    const parent = new AbortController();
    let entered;
    const started = new Promise(resolve => { entered = resolve; });
    const pending = authority.withProcessSurfaceAuthority(parent.signal,
      () => authority.assertProcessPlanStepAvailable('brainstorm'),
      signal => new Promise(resolve => {
        signal.addEventListener('abort', () => resolve(signal.reason), { once: true });
        entered();
      }));
    await started;
    await install('agon.plan');
    const reason = await pending;
    assert.equal(reason.code, 'MOD_GENERATION_MISMATCH');
    assert.equal(parent.signal.aborted, false);
  } else {
    const calls = [];
    const value = { exitCode: 0, stdout: 'fixture', stderr: '', durationMs: 0, timedOut: false,
      diff: '', diffLines: 0, filesChanged: 0 };
    const call = async function(options) { calls.push({ receiver: this, options }); return value; };
    const stream = async function*(options) { calls.push({ receiver: this, options }); yield 'chunk'; return value; };
    const adapter = { dispatch: call, dispatchAgent: call, dispatchStream: stream, dispatchAgentStream: stream,
      isAvailable: async function(options) { calls.push({ receiver: this, options }); return true; },
      getVersion: async function(options) { calls.push({ receiver: this, options }); return 'fixture-version'; } };
    const guarded = authority.guardProcessEngineAdapter(adapter,
      () => authority.assertProcessPlanStepAvailable('brainstorm'));
    const options = {};
    const streaming = scenario.endsWith('Stream');
    if (streaming) {
      const iterator = guarded[scenario](options);
      assert.deepEqual(await iterator.next(), { done: false, value: 'chunk' });
      assert.deepEqual(await iterator.next(), { done: true, value });
    } else {
      assert.equal(await guarded[scenario](options),
        scenario === 'isAvailable' ? true : scenario === 'getVersion' ? 'fixture-version' : value);
    }
    assert.deepEqual(calls, [{ receiver: adapter, options }]);
    const deferred = streaming ? guarded[scenario](options) : undefined;
    await install('agon.plan');
    await assert.rejects(deferred ? deferred.next() : guarded[scenario](options), /restart/);
    assert.equal(calls.length, 1);
  }
  console.log(JSON.stringify({ passed: true, scenario, compiledCli: true, realDurableHost: true }));
} finally {
  process.chdir(repo);
  unlock(root);
  rmSync(root, { recursive: true, force: true });
}
