import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = 'a4a82ce81f2545328f28a10d8406236c38605585';
const root = mkdtempSync(join(tmpdir(), 'agon-publication-live-'));
process.env.AGON_HOME = root;
const core = await import(join(repo, 'packages/core/dist/index.js'));
const physical = await import(join(repo, 'packages/mod-plan/dist/index.js'));
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js') && readFileSync(join(directory, name), 'utf8').includes('function handleProposePlan('));
assert.equal(chunks.length, 1);
const compiledCli = await import(pathToFileURL(join(directory, chunks[0])).href);
assert.equal(typeof compiledCli.handleProposePlan, 'function');
const cliSource = readFileSync(join(directory, chunks[0]), 'utf8');
const estimatorImport = cliSource.match(/import\s*\{[^}]*\bplanCostEstimator\b[^}]*\} from "([^"]+)"/);
assert.ok(estimatorImport);
const compiledCore = await import(pathToFileURL(join(directory, estimatorImport[1])).href);
assert.equal(typeof compiledCore.planCostEstimator.recordStepCompletion, 'function');
const old = execFileSync('git', ['show', `${base}:packages/cli/src/handlers/plan-mode.ts`], { cwd: repo, encoding: 'utf8' });
const body = old.slice(old.indexOf('export async function handleProposePlan('), old.indexOf('\n/**', old.indexOf('export async function handleProposePlan(')));
const fixture = readFileSync(join(repo, 'tests/fixtures/modular-plan-proposal-publication-legacy.ts'), 'utf8');
const stripTrailingSpace = value => value.trim().split('\n').map(line => line.trimEnd()).join('\n');
assert.equal(stripTrailingSpace(fixture.slice(fixture.indexOf('export async function handleProposePlan('))), stripTrailingSpace(body));
const autoSource = execFileSync('git', ['show', `${base}:packages/cli/src/cesar/task-controller.ts`], { cwd: repo, encoding: 'utf8' });
const autoStart = autoSource.indexOf('export function resolveCesarHarnessProfile(');
const autoBody = autoSource.slice(autoStart, autoSource.indexOf('\n/**', autoStart));
const transpile = source => ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
const auto = {};
new Function('exports', transpile(autoBody))(auto);
const legacy = {};
const dependencies = { sanitizePlanSteps: core.sanitizePlanSteps, createCesarPlan: core.createCesarPlan,
  isAgenticAutoMode: auto.isAgenticAutoMode, cesarPlanMarkdownPath: core.cesarPlanMarkdownPath,
  formatCesarPlanMarkdown: core.formatCesarPlanMarkdown, mkdirSync, dirname, writeFileSync,
  saveCesarPlan: core.saveCesarPlan, cancelCesarPlan: core.cancelCesarPlan };
new Function('exports', ...Object.keys(dependencies), transpile(body))(legacy, ...Object.values(dependencies));
let publishPlanProposal = physical.publishPlanProposal;
if (process.argv.includes('--mutant')) {
  const source = readFileSync(join(repo, 'packages/mod-plan/src/proposal-workflow.ts'), 'utf8');
  const mutated = source.replace('  host.persist(plan);', '')
    .replace('  host.publish(plan, markdown, path);', '  host.persist(plan);\n  host.publish(plan, markdown, path);');
  assert.notEqual(source, mutated);
  const exports = {};
  new Function('exports', 'require', transpile(mutated))(exports, name => {
    assert.ok(['./execution-state.js', './formatter.js', './step-validation.js'].includes(name));
    return physical;
  });
  publishPlanProposal = exports.publishPlanProposal;
}
const prior = { ...physical.createCesarPlan('prior', []), state: 'awaiting_approval' };
const effects = [];
assert.throws(() => publishPlanProposal({ intent: 'replacement', steps: [] }, {
  estimator: { estimate: () => ({ tokens: 0, costUsd: 0 }) }, agenticAutoMode: () => false,
  markdownPath: () => 'fixture.md', writeMarkdown: () => {},
  persist: value => { effects.push(value.intent); if (value.intent === 'replacement') throw new Error('storage refused'); },
  proposed: () => prior, active: () => null, clearProposal: () => effects.push('clear'),
  notify: () => {}, publish: () => effects.push('publish'),
}), /storage refused/);
assert.deepEqual(effects, ['replacement'], 'failed replacement must not retire the old proposal');
function files(path = root, prefix = '') {
  return Object.fromEntries(readdirSync(path, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).flatMap(entry => {
    const relative = join(prefix, entry.name);
    return entry.isDirectory() ? Object.entries(files(join(path, entry.name), relative)) : [[relative, readFileSync(join(path, entry.name), 'utf8')]];
  }));
}
const RealDate = Date;
const random = Math.random;
globalThis.Date = class extends RealDate {
  constructor(...args) { super(...(args.length ? args : ['2026-10-10T00:00:00.000Z'])); }
  static now() { return 1791590400000; }
};
Math.random = () => 0.5;
let comparisons = 0;
try {
  const inputs = [
    { intent: 'new', steps: [{ id: 'a', type: 'self', description: 'read' }] },
    { intent: 3, steps: [null, { type: 'invalid' }, { id: '../escape', type: 'review' }] },
    { intent: 'new', steps: [], autoApprove: true, selfReview: false, planningCost: { tokens: 99, costUsd: -1 } },
    { intent: 'new', steps: { bogus: true } },
    { intent: 'new', steps: [{ id: 'a', type: 'review', description: 'check', estimatedCostUsd: -99, estimatedTokens: -1 }] },
    { intent: 'notify changes mode', steps: [null], flipAuto: true },
  ];
  for (const history of [false, true]) for (const args of inputs) for (const autoMode of [false, true]) {
    for (const priorState of [undefined, 'awaiting_approval', 'running', 'paused', 'done']) {
      for (const activeState of [undefined, 'awaiting_approval', 'running']) {
        const outputs = [];
        for (const run of [legacy.handleProposePlan, compiledCli.handleProposePlan]) {
          for (const estimator of [core.planCostEstimator, compiledCore.planCostEstimator]) {
            estimator.reset();
            if (history) {
              estimator.recordStepCompletion('self', 42, 0.01);
              estimator.recordStepCompletion('self', 84, 0.03);
              estimator.recordStepCompletion('review', 100, 0.04);
              estimator.recordStepCompletion('review', 200, 0.08);
            }
          }
          rmSync(root, { recursive: true, force: true });
          mkdirSync(root);
          const record = (id, state) => state ? { ...physical.createCesarPlan(id, []), id, state } : undefined;
          const ctx = { cesar: { proposedPlan: record('prior', priorState) }, activePlan: record('active', activeState), autoModeQueued: autoMode, config: {} };
          const events = [];
          const result = await run(args, event => {
            events.push(event);
            if (args.flipAuto && event.type === 'info') ctx.autoModeQueued = true;
          }, ctx);
          outputs.push({ result, events, proposed: ctx.cesar.proposedPlan, active: ctx.activePlan, files: files() });
        }
        assert.deepEqual(outputs[1], outputs[0], JSON.stringify({ history, args, autoMode, priorState, activeState }));
        comparisons++;
      }
    }
  }
  console.log(JSON.stringify({ passed: true, comparisons, actualCompiledCli: chunks[0], base,
    legacySourceSha256: createHash('sha256').update(old).digest('hex'), rawPersistedBytes: true }));
} finally {
  globalThis.Date = RealDate;
  Math.random = random;
  rmSync(root, { recursive: true, force: true });
}
