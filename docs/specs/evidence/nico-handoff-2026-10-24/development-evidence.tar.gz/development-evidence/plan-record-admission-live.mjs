import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const api = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
const corpus = '/Users/ra/dev/modular-agon-remediation/plan-headless-corpus-ca3b88d8';
let effects = 0;
const unexpected = () => { effects++; throw new Error('Unexpected effect'); };
const noop = () => {};
for (const name of ['awaiting-approval', 'cancelled', 'auto-approved-without-execution']) {
  const home = mkdtempSync(join(tmpdir(), 'agon-admission-live-'));
  process.env.AGON_HOME = home;
  const bytes = readFileSync(join(corpus, `${name}.json`));
  const payload = JSON.parse(bytes).payload;
  mkdirSync(join(home, 'plans'));
  const path = join(home, 'plans', `${payload.id}.json`);
  writeFileSync(path, bytes);
  const plan = api.loadCesarPlan(payload.id);
  assert.ok(plan);
  await assert.rejects(api.createPlanExecutor({ recordStepCompletion: unexpected })(plan,
    { self: { execute: unexpected }, review: { execute: unexpected } },
    { onCheckpoint: unexpected, onStepStart: unexpected, onStepDone: unexpected, onPlanUpdate: unexpected, onBudgetWarning: unexpected }), /execution record/i);
  const errors = [];
  const notify = (level, message) => { if (level === 'error') errors.push(message); };
  await api.runPlanResumeApproval(plan, { available: () => true, choose: unexpected, execute: unexpected, notify });
  const coordinator = api.createPlanCoordinator({ createExecutors: unexpected, executePlan: unexpected,
    callbacks: unexpected, setActivePlan: unexpected, setAbort: unexpected, releaseAbort: unexpected,
    save: unexpected, writeMarkdown: unexpected, hasWorkingTreeChanges: unexpected,
    estimateReview: unexpected, takeFallback: unexpected, notify, warn: noop });
  await coordinator.executeApprovedPlan(plan);
  await assert.rejects(coordinator.finalizePlanWithReviewGate(plan, {}, new AbortController().signal), /execution record/i);
  assert.equal(errors.length, 2);
  assert.ok(errors.every(message => /execution record/i.test(message)));
  assert.deepEqual(readFileSync(path), bytes);
  assert.equal(effects, 0);
  console.log(JSON.stringify({ name, readable: true, executionRefused: true, resumeRefused: true,
    coordinatorRefused: true, finalizerRefused: true, bytesPreserved: true, effects }));
}
