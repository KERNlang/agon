# Plan execution record admission

Status: record-shape admission committed; other execution boundaries remain open.
Base: f5ee4eff27c829e89c4ab893f4ec6b9ff8cc2dfd, clean before new regression tests.

Purpose: one execution-shape check before Plan effects or writes. Preserve
historical inspection. Do not infer missing outcomes, totals or context.

Verified defect: three negative controls fail against the accepted base. The
public executor dispatches incomplete historical records, the coordinator saves
them before checking, and resume offers execution without required fields.
Receipt: plan-record-admission-red.receipt.json. No providers launched.

Implementation reuses the candidate execution-record/dependency-graph work,
verified against current model and the historical corpus. The validator belongs
at execution admission, not loadCesarPlan. The graph owner also replaces the
headless factory's recursive duplicate. No new dependency or service.

Blast radius: execution record/graph helpers; executor, coordinator and resume
workflow admission; headless proposal graph check; focused regressions. Public
signatures stay unchanged. Valid typed plans preserve behavior. Invalid or
incomplete records fail before effects and remain readable and unchanged.

Verification: fail-before controls, valid execution controls, graph/type boundary
tests, preserved historical read tests, full suite/build/types/lint/structural
checks, compiled factory and historical execution refusal, one default review.

Open beyond this increment: explicit historical migration/restart UX that keeps
the original raw envelope, cross-process stale writer protection, remaining
ownership/adapters and full release qualification. A refusal is not claimed as
a completed historical migration or full release acceptance.

## Independent review, first subject

Tree db2fc52bb40c2f7b26e3f56607b6d897c362d4be. Packet SHA-256
5ab1d4d139c4dac557450db314be0adb8e78013333c6a56b61332b3c4ad01092.
Codex review completed; Kimi failed isolated authentication without any personal
state change. Codex log hash
383bc64ba359c154917207f6e16025b96d71df216534c753b44d3f57e8432ae0.

Findings requiring source/test adjudication:

1. Pending flags can contradict dependency readiness; getReadySteps currently
   trusts the flag without checking dependency outcomes.
2. Saved records bypass the proposal-only parallel workspace writer restriction.
3. Backend result accounting and review estimates are not runtime validated
   before subsequent persistence. Refusal of an unknown backend outcome must not
   synthesize a retryable failure and accidentally rerun a completed effect.
4. Admission errors are caught as initial-save errors and receive contradictory
   storage-recovery instructions. This is introduced and must be fixed here.

The first three are inherited but remain locally actionable for the overall
goal. They are not waived or release-green. Initial record shape admission is
only one execution boundary, not a claim that later result writes are safe.
Add optional-field and public-finalizer controls. Historical compiled admission
probe is prepared in plan-record-admission-live.mjs, to run after the build gate.

## Full-suite findings and repairs

`plan-record-admission-full` passed build/types/lint/structural gates but failed
21 tests in four files. No receipt is treated as passing. Cause trace:

- Four scheduler mutation baselines failed because their in-memory bundle did
  not include the newly imported validator. It now compiles the actual model,
  graph, validator, state and scheduler together. All four mutants are still
  killed; no assertion or mutation was removed.
- Approval and fallback fixtures omitted required creation time and estimates.
  They now use the actual constructor. Negative approval tests also use valid
  records, so refusal cannot pass merely because the fixture fails admission.
- The reporting-failure test injected null accounting before execution to force
  toFixed to throw. It now injects the same TypeError at Number.toFixed using a
  valid record. Existing final-state and reporting assertions remain unchanged.
- The new admission diagnostic had contradictory storage advice. A negative
  control reproduced it; admission now returns before the persistence try/catch.

`plan-record-admission-suite-repairs` passed all 128 affected tests, typecheck
and whitespace checks. Log hash
8116fe9bbdedf0a98a8349309cbce6ca10e609504ea1ca356adbb298e8e660fb.
Added a populated optional-field positive control and public finalizer refusal
before effects. Final qualification and commit follow below.

## Accepted record-shape increment

Commit `13b5345892f72f3aab68f21a1b85285db57d066b`, tree
`dc0681476bd5dd91bc8fc211901d42da120e387b`.
Message: `fix(modular): validate Plan records before execution`.
Qualification worktree clean; remediation branch/index advanced without
overwriting working bytes. Before/after preservation verified 281 paths with
unchanged allowlist and identical log hash
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.

`plan-record-admission-qualified` passed build, types, lint, structural checks,
all 8211 tests (6 existing opt-in skips), compiled Plan factory lifecycle,
historical inspection/refusal and the three SIGKILL checkpoint scenarios.
Receipt elapsed 279.45 seconds, no provider launches; log hash
`90ff8b309e861050860cea4df6cd96df6be1ec95f774ce3b2f552f91239ed7bc`.
All three real historical records stayed byte-exact while the compiled executor,
coordinator, finalizer and resume UI refused execution before effects.

Not a release claim: dependency scheduling, parallel-writer parity and runtime
result/estimate validation remain next locally actionable review findings.
Historical migration UX, cross-process writer fencing and full release gates
also remain open. No pushes or active/global installation changes occurred.
