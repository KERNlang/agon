import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = '2ece2047d634821387015719e8ae4c7f2e5aed49';
const root = mkdtempSync(join(tmpdir(), 'agon-rejection-live-'));
process.env.AGON_HOME = root;
const core = await import(join(repo, 'packages/core/dist/index.js'));
const physical = await import(join(repo, 'packages/mod-plan/dist/index.js'));
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js') && readFileSync(join(directory, name), 'utf8').includes('function cancelPendingCesarPlan('));
assert.equal(chunks.length, 1);
const cli = await import(pathToFileURL(join(directory, chunks[0])).href);
assert.equal(typeof cli.cancelPendingCesarPlan, 'function');
const old = execFileSync('git', ['show', `${base}:packages/cli/src/signals/dispatch/plan-execution.ts`], { cwd: repo, encoding: 'utf8' });
const start = old.indexOf('export function cancelPendingCesarPlan(');
const body = old.slice(start, old.indexOf('\n}\n', start) + 3);
const transpile = source => ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
const legacy = {};
const dependencies = {
  findPendingCesarPlan: ctx => physical.selectPendingPlan({ proposedPlan: ctx.cesar?.proposedPlan, activePlan: ctx.activePlan }, physical.listCesarPlans),
  cancelCesarPlan: core.cancelCesarPlan, saveCesarPlan: core.saveCesarPlan,
  writeFileSync, formatCesarPlanMarkdown: core.formatCesarPlanMarkdown,
  appendMessage: core.appendMessage, hostConsoleWarn: message => console.warn(message),
};
new Function('exports', ...Object.keys(dependencies), transpile(body))(legacy, ...Object.values(dependencies));
function files(path = root, prefix = '') {
  return Object.fromEntries(readdirSync(path, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).flatMap(entry => {
    const relative = join(prefix, entry.name);
    return entry.isDirectory() ? Object.entries(files(join(path, entry.name), relative)) : [[relative, readFileSync(join(path, entry.name), 'utf8')]];
  }));
}
const RealDate = Date;
const originalWarn = console.warn;
globalThis.Date = class extends RealDate {
  constructor(...args) { super(...(args.length ? args : ['2026-10-10T00:00:00.000Z'])); }
  static now() { return 1791590400000; }
};
let comparisons = 0;
try {
  for (const proposedState of [undefined, 'awaiting_approval', 'running', 'cancelled']) {
    for (const activeState of [undefined, 'awaiting_approval', 'paused']) {
      for (const chat of [false, true]) for (const markdown of [false, true]) {
        for (const failure of ['none', 'persist', 'markdown', 'chat']) {
          const outputs = [];
          for (const run of [legacy.cancelPendingCesarPlan, cli.cancelPendingCesarPlan]) {
            rmSync(root, { recursive: true, force: true });
            mkdirSync(root);
            mkdirSync(join(root, 'chats'));
            if (failure === 'persist') writeFileSync(join(root, 'plans'), 'not a directory');
            if (failure === 'markdown') mkdirSync(join(root, 'plan.md'));
            const record = (id, state) => state ? { ...physical.createCesarPlan(id, []), id, state,
              ...(markdown ? { planFilePath: join(root, 'plan.md') } : {}) } : undefined;
            const ctx = { cesar: { proposedPlan: record('proposal', proposedState) }, activePlan: record('active', activeState),
              ...(chat ? { chatSession: { id: 'rejection', startedAt: '2026-01-01T00:00:00.000Z', messages: failure === 'chat' ? Object.freeze([]) : [] } } : {}) };
            const events = [];
            const selected = [];
            const warnings = [];
            console.warn = (...args) => warnings.push(args);
            let result;
            let error;
            try { result = run({ ctx, dispatch: event => events.push(event), setActivePlan: value => selected.push(value) }); }
            catch (caught) { error = caught.message; }
            outputs.push({ result, error, events, selected, warnings, ctx, files: files() });
          }
          assert.deepEqual(outputs[1], outputs[0], JSON.stringify({ proposedState, activeState, chat, markdown, failure }));
          comparisons++;
        }
      }
    }
  }
  let reject = physical.rejectPlanProposal;
  if (process.argv.includes('--mutant')) {
    const source = readFileSync(join(repo, 'packages/mod-plan/src/proposal-workflow.ts'), 'utf8');
    const mutant = source.replace('  host.cancelled(cancelled);', '  // Deliberate missing prompt-release event.');
    assert.notEqual(source, mutant);
    const exports = {};
    new Function('exports', 'require', transpile(mutant))(exports, () => physical);
    reject = exports.rejectPlanProposal;
  }
  const events = [];
  const pending = { ...physical.createCesarPlan('negative control', []), state: 'awaiting_approval' };
  reject(pending, { clearProposal() {}, setActive() {}, persist() {}, writeMarkdown() {},
    cancelled: plan => events.push(plan.state), notify() {}, recordRejection() {}, warn() {} });
  assert.deepEqual(events, ['cancelled'], 'rejection must release the pinned prompt');
  console.log(JSON.stringify({ passed: true, comparisons, actualCompiledCli: chunks[0], base,
    oldSourceSha256: createHash('sha256').update(old).digest('hex'), rawPersistedBytes: true }));
} finally {
  globalThis.Date = RealDate;
  console.warn = originalWarn;
  rmSync(root, { recursive: true, force: true });
}
