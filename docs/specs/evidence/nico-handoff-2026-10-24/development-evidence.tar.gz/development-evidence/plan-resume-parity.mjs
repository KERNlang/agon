import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = 'f4b6bf342da26945b0c9b6441e213894956312c3';
const file = 'packages/cli/src/signals/dispatch/plan-execution.ts';
const owner = await import(repo + '/packages/mod-plan/dist/index.js');
const old = execFileSync('git', ['show', `${base}:${file}`], { cwd: repo, encoding: 'utf8' });
const current = readFileSync(`${repo}/${file}`, 'utf8');
assert.equal(readFileSync(`${repo}/packages/mod-plan/src/resume-policy.ts`, 'utf8'),
  execFileSync('git', ['show', `${base}:packages/mod-plan/src/resume-policy.ts`], { cwd: repo, encoding: 'utf8' }));
function compile(source, dependencies) {
  const parsed = ts.createSourceFile('entry.ts', source, ts.ScriptTarget.Latest, true);
  const declaration = parsed.statements.find(statement => ts.isFunctionDeclaration(statement) && statement.name?.text === 'resumeCesarPlan');
  assert.ok(declaration);
  const output = ts.transpileModule(declaration.getText(parsed), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  }).outputText;
  const exports = {};
  new Function('exports', ...Object.keys(dependencies), output)(exports, ...Object.values(dependencies));
  return exports.resumeCesarPlan;
}
let workflow = owner.runPlanResumeApproval;
if (process.argv.includes('--mutant')) {
  const source = readFileSync(`${repo}/packages/mod-plan/src/resume-workflow.ts`, 'utf8');
  const changed = source.replace("if (!['1', 'resume', '2', 'r', 'restart'].includes(trimmed))", "if (false)");
  assert.notEqual(source, changed);
  const output = ts.transpileModule(changed, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
  } }).outputText;
  const exports = {};
  new Function('exports', 'require', output)(exports, () => owner);
  workflow = exports.runPlanResumeApproval;
}
let comparisons = 0;
for (const answer of ['', ' ', '3', 'cancel', 'yes', '1', 'resume', '2', 'r', 'restart', ' RESTART ', 'resume please']) {
  for (const state of ['pending', 'running', 'done', 'skipped', 'failed', 'blocked']) {
    for (const cost of [0, 1.25]) for (const authority of ['enabled', 'disabled', 'capture-failure', 'changed']) {
      for (const failure of ['none', 'question', 'execute']) {
        const outputs = [];
        for (const source of [old, current]) {
          let answered = false;
          const events = [];
          const plan = { ...owner.createCesarPlan('resume parity', []), id: 'fixed',
            createdAt: '2026-10-10T00:00:00.000Z', updatedAt: '2026-10-10T00:00:00.000Z',
            state: 'paused', reviewCyclesUsed: 2,
            steps: [{ id: 'step', type: 'review', description: 'fixture', state,
              estimatedTokens: 1234, estimatedCostUsd: cost,
              result: { status: state === 'failed' ? 'failure' : 'success', output: 'saved',
                error: state === 'failed' ? 'original failure' : undefined,
                actualTokens: 12, actualCostUsd: 0.25, durationMs: 8 } }],
            totalActualTokens: 12, totalActualCostUsd: 0.25 };
          const snapshot = structuredClone(plan);
          const deps = {
            buildResumePromptContext: owner.buildResumePromptContext,
            prepareCesarPlanResume: owner.prepareCesarPlanResume,
            runPlanResumeApproval: workflow,
            planExecutionAvailable: (cb, check) => {
              try {
                check?.();
                if (authority === 'disabled') throw Error('disabled');
                return true;
              } catch (error) { cb.dispatch({ type: 'error', message: error.message }); return false; }
            },
            captureProcessSurfaceAuthority: () => {
              if (authority === 'capture-failure') throw Error('capture failed');
              return () => { if (authority === 'changed' && answered) throw Error('stale'); };
            },
            askChoiceQuestion: async (_cb, prompt, choices, defaultKey) => {
              events.push({ prompt, choices, defaultKey });
              if (failure === 'question') throw Error('question failed');
              answered = true;
              return answer;
            },
            executeApprovedPlan: async value => {
              events.push({ execute: value });
              if (failure === 'execute') throw Error('execute failed');
            },
          };
          let error;
          let result;
          try { result = await compile(source, deps)(plan, { dispatch: event => events.push(event) }); }
          catch (caught) { error = caught.message; }
          assert.deepEqual(plan, snapshot, 'input plan changed');
          outputs.push({ events, error, result });
        }
        assert.deepEqual(outputs[1], outputs[0], JSON.stringify({ answer, state, cost, authority, failure }));
        comparisons++;
      }
    }
  }
}
console.log(JSON.stringify({ passed: true, comparisons, base, policyUnchanged: true,
  compiledOwner: true, isolatedHostEffects: true }));
