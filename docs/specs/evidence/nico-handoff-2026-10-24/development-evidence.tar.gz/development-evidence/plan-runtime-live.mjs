import assert from 'node:assert/strict';
import './plan-presentation-live.mjs';
import { createPlanRuntime, PlanCostEstimator, createCesarPlan, approveCesarPlan } from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';

const estimator = new PlanCostEstimator(() => 1);
const runtime = createPlanRuntime(estimator);
const independent = createPlanRuntime(new PlanCostEstimator(() => 2));
assert.ok(Object.isFrozen(runtime));
assert.equal(runtime.estimator, estimator);
const draft = createCesarPlan('Native runtime isolation', runtime.sanitizePlanSteps([
  { id: 'a', type: 'self', description: 'a' },
  { id: 'b', type: 'self', description: 'b', dependsOn: ['a'] },
]).steps);
const result = await runtime.executePlan(approveCesarPlan(draft), {
  self: { execute: async step => ({ result: { status: 'success', output: step.id,
    actualTokens: step.id === 'a' ? 10 : 30, actualCostUsd: 0.5, durationMs: 1 } }) },
}, { onStepStart() {}, onStepDone() {}, onPlanUpdate() {}, onBudgetWarning() {} });
assert.equal(result.state, 'done');
assert.equal(runtime.sanitizePlanSteps([{ type: 'self' }]).steps[0].estimatedTokens, 20);
assert.equal(runtime.sanitizePlanSteps([{ type: 'self' }]).steps[0].estimatedCostUsd, 0.5);
assert.equal(independent.sanitizePlanSteps([{ type: 'self' }]).steps[0].estimatedTokens, 2000);
assert.equal(independent.sanitizePlanSteps([{ type: 'self' }]).steps[0].estimatedCostUsd, 2);
console.log('PASS public runtime factory, frozen composition, history feedback and independent runtime state');
