import { createPlanRuntime, PlanCostEstimator } from '../agon-audit-qualification/packages/mod-plan/dist/index.js';
import type { PlanExecutorCallbacks, StepExecutor } from '../agon-audit-qualification/packages/mod-plan/dist/index.js';
import { executePlan, sanitizePlanSteps } from '../agon-audit-qualification/packages/core/dist/index.js';
import type { PlanExecutorCallbacks as CoreCallbacks, StepExecutor as CoreStepExecutor } from '../agon-audit-qualification/packages/core/dist/index.js';

const runtime = createPlanRuntime(new PlanCostEstimator(() => 1), (_type, error) => { void error; });
const execute: typeof executePlan = runtime.executePlan;
const sanitize: typeof sanitizePlanSteps = runtime.sanitizePlanSteps;
declare const callbacks: PlanExecutorCallbacks;
declare const step: StepExecutor;
const compatibleCallbacks: CoreCallbacks = callbacks;
const compatibleStep: CoreStepExecutor = step;
void [execute, sanitize, compatibleCallbacks, compatibleStep];
