import { createPlanRuntime } from '../agon-audit-qualification/packages/mod-plan/dist/index.js';

const estimator = {
  estimate(_type: string, _engines: string[]) { return { tokens: 1, costUsd: 1 }; },
  recordStepCompletion(_type: string, _tokens: number, _cost: number) {},
  inspect() { return 'custom host estimator'; },
};
const runtime = createPlanRuntime(estimator);
const retained: typeof estimator = runtime.estimator;
void retained.inspect();
