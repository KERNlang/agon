import assert from 'node:assert/strict';
const api = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
const step = id => ({ id, type: 'self', description: id, estimatedTokens: 1, estimatedCostUsd: 0 });
const result = { status: 'success', output: 'synthetic', actualTokens: 1, actualCostUsd: 0, durationMs: 1 };
const noop = () => {};
const callbacks = { onStepStart: noop, onStepDone: noop, onPlanUpdate: noop, onBudgetWarning: noop };
for (const parallel of [false, true]) {
  const plan = api.approveCesarPlan(api.createCesarPlan('compiled order', [
    { ...step('dependent'), dependsOn: ['prior'], parallel }, { ...step('prior'), parallel },
  ]));
  plan.steps[0].state = 'pending';
  const events = [];
  const completed = await api.createPlanExecutor({ recordStepCompletion: noop })(plan, { self: { execute: async value => {
    events.push(`start:${value.id}`);
    await Promise.resolve();
    events.push(`done:${value.id}`);
    return { result };
  } } }, callbacks);
  assert.deepEqual(events, ['start:prior', 'done:prior', 'start:dependent', 'done:dependent']);
  assert.equal(completed.state, 'done');
  console.log(JSON.stringify({ compiled: true, parallel, dependencyOrder: true }));
}
let effects = 0;
const writers = api.approveCesarPlan(api.createCesarPlan('compiled writers', ['one', 'two'].map(id => ({ ...step(id), type: 'forge', parallel: true }))));
await assert.rejects(api.createPlanExecutor({ recordStepCompletion: noop })(writers,
  { forge: { execute: async () => { effects++; return { result }; } } },
  { ...callbacks, onCheckpoint: () => { effects++; } }), /execution record/);
assert.equal(effects, 0);
console.log(JSON.stringify({ compiled: true, parallelWritersRefused: true, effects }));
