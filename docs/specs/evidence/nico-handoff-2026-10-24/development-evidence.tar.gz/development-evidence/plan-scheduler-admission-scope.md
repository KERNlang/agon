# Plan dependency readiness and writer policy

Status: qualified locally; active remediation goal authorizes the repair.
Base: 13b5345892f72f3aab68f21a1b85285db57d066b.
Review origin: plan-record-admission-codex-review.log, findings 1 and 2.

Fix two verified source gaps with one scheduling contract: pending state does
not bypass unfinished dependencies; persisted execution uses the same existing
parallel workspace-writer restriction as proposals. Do not broaden the writer
type list in this increment or forbid supported parallel read/panel work.

Changes: scheduler readiness, shared writer-policy check, proposal/record
consumers, focused tests and scheduler mutation target. All valid legacy oracle
scenarios must retain exact raw events. Blocked dependents whose prerequisites
already succeeded must become runnable without rerunning those prerequisites.

Required controls: dependent before prerequisite, parallel dependency pair,
failed or missing prerequisite outcome, successful skipped prerequisite,
forbidden saved parallel writers before checkpoint/dispatch, valid parallel
work, exact frozen scheduler replay, mutation baseline and kill, full gates,
compiled runtime check and one default review.

Separate open requirements: malformed backend result/estimate handling,
historical migration UX, cross-process writer fencing and release qualification.

## Verification in progress

All four baseline controls failed in `plan-scheduler-admission-red`.
The repair derives readiness from dependency results and shares the unchanged
five-type writer restriction. `plan-scheduler-admission-controls` passed 75
focused tests, types and whitespace checks, including frozen scheduler replay
and four mutation controls. Log hash:
`c26f099e9b0acd8a232b2b789b01e1c863ca925527dec86b441d28eb4f464f72`.

Frozen review/full-gate tree: `0d8fe335dd252c78c35b79bb053047aec887a795`.
`plan-scheduler-admission-full` passed build, types, lint, re-export guard,
first-party ledger and roadmap checks, 8,224 tests (6 skipped), historical
record refusal, compiled headless lifecycle, and three real SIGKILL scenarios.
Log SHA-256: `10a3c84aebe7ca4b1a828e1122b33dcd6ed243d13f8483446f89bdbfe8c53873`.
`plan-scheduler-admission-live` passed one compiled process with sequential and
parallel dependency ordering plus parallel writer refusal before effects.
Log SHA-256: `73e884691eabc55e89da0159e99b7e33f2ce0f7f5b11835fbbf813bf7b3e204a`.
Both verification runs recorded zero provider launches.

Default Agon Codex review found no actionable issue in the frozen diff. It did
not independently run tests. Optional multiple-prerequisite and mixed-writer
coverage suggestions are not release findings. Kimi review was unavailable:
isolated authentication failed. No personal authentication was changed.
Review packet SHA-256:
`909bff2d19c163d29f1fe02d5e830cf10be139483c17c72348f47a2401c5ae0e`.
Codex review log SHA-256:
`26dd828470703f491208ac4449b353554a7b890f1542b31bb960c71521f23986`.
Kimi review log SHA-256:
`a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff`.

The six suite skips remain external/opt-in: four live provider cases, one pyte
TUI case, and one opt-in compiler case (separately exercised previously).
This is scheduler evidence, not whole-release acceptance. No source changed
during qualification. Candidate working-tree bytes remain untouched.

Committed subject: `caa97b71f0c65ce6d094bccca98efb3f68d8e98e`.
Committed tree matches the frozen review and gate tree above. Qualification
checkout is clean. Candidate branch advanced with an expected-old ref check
and index-only read-tree; its working files were not overwritten. Before/after
preservation checks both passed across 281 recorded paths with the unchanged
allowlist. Preservation log hash:
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
No push, install, or promotion occurred.
