import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';
import * as physical from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';

const repository = '/Users/ra/dev/agon-audit-qualification';
const subject = 'a57b5aa3e8406819fe0b35ccffa8127f2d2655ae';
const source = execFileSync('git', ['show', `${subject}:packages/cli/src/signals/dispatch/plan-queries.ts`], {
  cwd: repository, encoding: 'utf8',
});
let saved = [];
let oldReads = 0;
let newReads = 0;
const legacy = {};
const compiled = ts.transpileModule(source, { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText;
new Function('exports', 'require', compiled)(legacy, name => {
  if (name === '@kernlang/agon-core') return { listCesarPlans: () => { oldReads++; return saved; } };
  if (name === '@kernlang/agon-mod-plan') return physical;
  throw new Error(`Unexpected legacy dependency: ${name}`);
});
const states = [undefined, 'planning', 'awaiting_approval', 'running', 'paused', 'done', 'cancelled'];
const record = (id, state, date = '2026-01-01T00:00:00.000Z') => state === undefined ? undefined : {
  ...physical.createCesarPlan(id, []), id, state, createdAt: date,
};
const phrases = ['go', 'yes', 'ok go', 'sure', 'run it', 'do so', 'resume', 'continue',
  'go do the last part', 'done', 'what yu do', 'why stop', 'where are we', 'maybe',
  'change step 2', '/approve', '', 'keep going', 'tell me a joke', 'yes please'];
const texts = phrases.flatMap(phrase => [phrase, `  ${phrase.toUpperCase()}!  `, `${phrase}?`, `${phrase}\n`]);
let comparisons = 0;
for (const name of ['isCesarPlanApprovalInput', 'isStrongCesarPlanApprovalInput',
  'isCesarPlanResumeInput', 'isCesarPlanStatusInput']) {
  for (const text of texts) { assert.equal(physical[name](text), legacy[name](text), `${name}: ${text}`); comparisons++; }
}
for (const proposedState of states) for (const activeState of states) {
  const snapshot = { proposedPlan: record('proposal', proposedState), activePlan: record('active', activeState) };
  const ctx = { cesar: { proposedPlan: snapshot.proposedPlan }, activePlan: snapshot.activePlan };
  for (const records of [[], [record('finished', 'done')], [
    record('old', 'awaiting_approval'), record('new', 'awaiting_approval', '2026-02-01T00:00:00.000Z'),
    record('finished', 'done', '2026-03-01T00:00:00.000Z'),
  ]]) {
    saved = records;
    oldReads = newReads = 0;
    const before = structuredClone(records);
    assert.equal(physical.selectPendingPlan(snapshot, () => { newReads++; return saved; }), legacy.findPendingCesarPlan(ctx));
    assert.equal(newReads, oldReads);
    assert.deepEqual(records, before);
    assert.equal(physical.selectResumablePlan(snapshot), legacy.findResumableCesarPlan(ctx));
    comparisons += 4;
    for (const text of texts) {
      assert.equal(physical.shouldApprovePendingCesarPlanInput(text, snapshot), legacy.shouldApprovePendingCesarPlanInput(text, ctx));
      comparisons++;
    }
  }
}
for (const state of states.filter(Boolean)) {
  const plan = record('cplan-status-parity', state);
  for (const steps of [[], [
    { id: 'a', type: 'self', description: 'done', state: 'done' },
    { id: 'b', type: 'self', description: 'failed', state: 'failed', result: { error: 'fixture error' } },
    { id: 'c', type: 'self', description: 'blocked', state: 'blocked' },
    { id: 'd', type: 'self', description: 'pending', state: 'pending' },
    { id: 'e', type: 'self', description: 'running', state: 'running' },
  ]]) {
    plan.steps = steps;
    assert.equal(physical.formatCesarPlanRuntimeStatus(plan), legacy.formatCesarPlanRuntimeStatus(plan));
    comparisons++;
  }
}
console.log(JSON.stringify({ subject, sourceSha256: createHash('sha256').update(source).digest('hex'),
  comparisons, differences: 0, scope: 'compiled physical selection vs exact Git legacy policy, including read counts and input preservation' }));

const home = mkdtempSync(join(tmpdir(), 'agon-plan-selection-'));
const previous = process.env.AGON_HOME;
process.env.AGON_HOME = home;
try {
  const core = await import('/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js');
  assert.equal(core.listCesarPlans, physical.listCesarPlans, 'Core and physical Plan use one store function');
  const older = record('cplan-older', 'awaiting_approval');
  const newer = record('cplan-newer', 'awaiting_approval', '2026-02-01T00:00:00.000Z');
  const done = record('cplan-done', 'done', '2026-03-01T00:00:00.000Z');
  for (const plan of [older, newer, done]) physical.saveCesarPlan(plan);
  assert.deepEqual(core.listCesarPlans(), physical.listCesarPlans());
  assert.equal(physical.selectPendingPlan({}, physical.listCesarPlans).id, newer.id);
  assert.equal(physical.selectPendingPlan({ proposedPlan: older }, physical.listCesarPlans), older);
  assert.equal(physical.shouldApprovePendingCesarPlanInput('go', {}), false);
  assert.equal(physical.selectResumablePlan({}), null);
  assert.equal(physical.loadCesarPlan(newer.id).state, 'awaiting_approval');
  console.log('PASS real Plan storage selection: newest pending, live precedence, no hidden approval or implicit disk resume; zero providers');
} finally {
  if (previous === undefined) delete process.env.AGON_HOME;
  else process.env.AGON_HOME = previous;
  rmSync(home, { recursive: true, force: true });
}
