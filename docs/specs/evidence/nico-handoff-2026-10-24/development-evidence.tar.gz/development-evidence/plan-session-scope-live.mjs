import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

let plan;
if (process.argv.includes('--mutant')) {
  const { default: ts } = await import('/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js');
  const original = readFileSync('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/src/session-scope.ts', 'utf8');
  assert.ok(original.includes('session.active = false;'));
  const source = original.replace('session.active = false;', 'void session;');
  const code = ts.transpileModule(source, { compilerOptions: {
    target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext,
  } }).outputText;
  plan = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
} else {
  plan = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
}
const { withPlanSession, planSessionHost } = plan;
const context = invocationId => ({ invocationId, cwd: '/isolated-fixture',
  platform: 'darwin-arm64', signal: new AbortController().signal, config: {} });
assert.equal((await planSessionHost.run({ type: 'approve' }, context('none'))).exitCode, 2);
await Promise.all(Array.from({ length: 16 }, (_, index) => {
  const id = String(index);
  return withPlanSession(id, async () => ({ exitCode: 0, stdout: id }), async () => {
    await new Promise(resolve => setImmediate(resolve));
    assert.equal((await planSessionHost.run({ type: 'approve' }, context(id))).stdout, id);
    assert.equal((await planSessionHost.run({ type: 'approve' }, context('wrong'))).exitCode, 2);
  });
}));
for (const fail of [false, true]) {
  let release;
  const gate = new Promise(resolve => { release = resolve; });
  let late;
  let effects = 0;
  const invocation = withPlanSession('owner', async () => { effects++; return { exitCode: 0 }; }, async () => {
    late = gate.then(() => planSessionHost.run({ type: 'approve' }, context('owner')));
    if (fail) throw new Error('owner failed');
  });
  if (fail) await assert.rejects(invocation, /owner failed/);
  else await invocation;
  release();
  assert.equal((await late).exitCode, 2, 'expired invocation must reject late effects');
  assert.equal(effects, 0);
}
await withPlanSession('outer', async () => ({ exitCode: 0, stdout: 'outer' }), async () => {
  await assert.rejects(withPlanSession('inner', async () => ({ exitCode: 0 }), async () => {
    throw new Error('nested failure');
  }), /nested failure/);
  assert.equal((await planSessionHost.run({ type: 'approve' }, context('outer'))).stdout, 'outer');
  const aborted = context('outer');
  aborted.signal = AbortSignal.abort();
  await assert.rejects(planSessionHost.run({ type: 'approve' }, aborted));
});
if (!process.argv.includes('--mutant')) {
  const directory = '/Users/ra/dev/agon-audit-qualification/packages/cli/dist';
  const files = readdirSync(directory).filter(name => name.endsWith('.js'));
  function scopeImport(prefix, name) {
    const matches = files.filter(file => file.startsWith(prefix));
    assert.equal(matches.length, 1);
    const source = readFileSync(resolve(directory, matches[0]), 'utf8');
    const match = source.match(new RegExp(`import\\s*\\{[^}]*\\b${name}\\b[^}]*\\} from "([^"]+)"`));
    assert.ok(match, name);
    return resolve(directory, match[1]);
  }
  const hostPath = scopeImport('first-party-services-', 'planSessionHost');
  assert.equal(hostPath, scopeImport('app-', 'withPlanSession'));
  const compiled = await import(pathToFileURL(hostPath).href);
  const intents = [];
  const noEffect = () => () => {};
  const dispose = await plan.createMod({ planSession: compiled.planSessionHost }).activate({
    intent: contribution => { intents.push(contribution); return () => {}; },
    command: noEffect, tool: noEffect, planStep: noEffect,
  });
  try {
    const approve = intents.find(item => item.id === 'intentVariants:0003');
    assert.ok(approve);
    let calls = 0;
    await compiled.withPlanSession('compiled', async request => {
      assert.equal(request.type, 'approve');
      calls++;
      return { exitCode: 0, stdout: 'same compiled scope' };
    }, async () => {
      assert.equal((await approve.run({}, context('compiled'))).stdout, 'same compiled scope');
    });
    assert.equal(calls, 1);
    assert.equal((await approve.run({}, context('compiled'))).exitCode, 2);
  } finally { await dispose(); }
}
console.log('PASS compiled Plan scope: 16 concurrent invocations, identity refusal, success/failure expiry, nested restoration, abort and compiled CLI to physical-mod injection; zero provider calls');
