import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';
import * as plan from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';
import * as core from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js';

for (const name of ['createCesarPlan', 'exitCesarPlan', 'saveCesarPlan', 'loadCesarPlan']) {
  assert.equal(core[name], plan[name], name);
}

const repo = '/Users/ra/dev/agon-audit-qualification';
const base = 'f973bf6d392fcfd51ce717eacb8efeb9023a07cd';
const path = 'packages/cli/src/handlers/plan-mode.ts';
const oldSource = execFileSync('git', ['show', `${base}:${path}`], { cwd: repo, encoding: 'utf8' });
const newSource = readFileSync(join(repo, path), 'utf8');
let exitPlanSession = plan.exitPlanSession;
if (process.argv.includes('--mutant')) {
  const source = readFileSync(join(repo, 'packages/mod-plan/src/session-workflow.ts'), 'utf8');
  const mutated = source.replace('if (refusal) return refusal;', '');
  assert.notEqual(mutated, source);
  const compiled = ts.transpileModule(mutated, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
  const exports = {};
  new Function('exports', 'require', compiled)(exports, name => {
    assert.equal(name, './execution-state.js');
    return plan;
  });
  exitPlanSession = exports.exitPlanSession;
}
let trace;
let archiveFails;
const save = value => {
  trace.push(['persist', value]);
  if (archiveFails) throw new Error('disk full');
};
function compileHandler(source) {
  const body = source.slice(source.indexOf('export function handleExitPlanMode('), source.indexOf('export function buildStepExecutors('));
  assert.ok(body.length > 100);
  const compiled = ts.transpileModule(body, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText;
  const exports = {};
  new Function('exports', 'exitCesarPlan', 'saveCesarPlan', 'exitPlanSession', compiled)(exports, plan.exitCesarPlan, save, exitPlanSession);
  return exports.handleExitPlanMode;
}
const legacy = compileHandler(oldSource);
const current = compileHandler(newSource);
const RealDate = Date;
globalThis.Date = class extends RealDate {
  constructor(...args) { super(...(args.length ? args : ['2026-10-10T00:00:00.000Z'])); }
  static now() { return 1791590400000; }
};
let comparisons = 0;
try {
  for (const state of [undefined, 'planning', 'awaiting_approval', 'running', 'paused', 'done', 'cancelled']) {
    const value = state ? { ...plan.createCesarPlan('exit parity', []), state } : undefined;
    for (const reason of ['', '  ', 'changed mind', '  changed mind  ']) {
      for (const hasCesar of [false, true]) for (const hasSetter of [false, true]) {
        for (const hasDispatch of [false, true]) for (const fails of [false, true]) {
          function run(handler) {
            trace = [];
            archiveFails = fails;
            const ctx = { activePlan: structuredClone(value) };
            if (hasCesar) ctx.cesar = { proposedPlan: structuredClone(value) };
            if (hasSetter) ctx.setActivePlan = next => { trace.push(['active', next]); ctx.activePlan = next; };
            const result = handler(reason, hasDispatch ? event => trace.push(['dispatch', event]) : null, ctx);
            return { result, trace, activePlan: ctx.activePlan, cesar: ctx.cesar };
          }
          assert.deepEqual(run(current), run(legacy), JSON.stringify({ state, reason, hasCesar, hasSetter, hasDispatch, fails }));
          comparisons++;
        }
      }
    }
  }
} finally { globalThis.Date = RealDate; }

const root = mkdtempSync(join(tmpdir(), 'agon-plan-workflow-'));
const previousHome = process.env.AGON_HOME;
process.env.AGON_HOME = root;
try {
  const draft = { ...plan.createCesarPlan('native lifecycle', []), state: 'paused' };
  plan.saveCesarPlan(draft);
  let resumed;
  await plan.resumePlanSession(join(root, 'plans', draft.id + '.json'), {
    load: plan.loadCesarPlan,
    current: () => { throw new Error('unexpected current fallback'); },
    resume: async value => { resumed = value; },
    notify: () => { throw new Error('unexpected notification'); },
  });
  assert.equal(resumed.id, draft.id);
  let cleared = false;
  assert.match(plan.exitPlanSession('operator leaves', resumed, {
    persist: plan.saveCesarPlan, clearProposalAndMarkExited: () => { cleared = true; }, setInactive: () => {},
  }), /^\[PLAN_EXITED\]/);
  assert.equal(cleared, true);
  assert.equal(plan.loadCesarPlan(draft.id).state, 'cancelled');
  assert.equal(plan.loadCesarPlan(draft.id).exitReason, 'operator leaves');
  console.log(JSON.stringify({ passed: true, comparisons, base, legacySourceSha256: createHash('sha256').update(oldSource).digest('hex'), nativePersistResumeExitReload: true }));
} finally {
  if (previousHome === undefined) delete process.env.AGON_HOME;
  else process.env.AGON_HOME = previousHome;
  rmSync(root, { recursive: true, force: true });
}
