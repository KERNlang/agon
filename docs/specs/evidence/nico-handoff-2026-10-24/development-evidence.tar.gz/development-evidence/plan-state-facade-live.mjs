import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import './plan-runtime-live.mjs';

const root = mkdtempSync(join(tmpdir(), 'agon-plan-state-facade-'));
process.env.AGON_HOME = root;
try {
  const core = await import('/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js');
  const plan = await import('/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js');
  for (const name of ['createCesarPlan', 'approveCesarPlan', 'advanceCesarStep', 'cancelCesarPlan',
    'exitCesarPlan', 'getCesarPlansDir', 'cesarPlanJsonPath', 'cesarPlanMarkdownPath',
    'saveCesarPlan', 'loadCesarPlan', 'listCesarPlans', 'CESAR_STEP_TYPES']) {
    assert.equal(core[name], plan[name], name);
  }
  const tool = core.createListPlansTool();
  assert.equal((await tool.execute({}, {})).content, 'No plans found.');
  const draft = core.createCesarPlan('State facade native probe', []);
  core.saveCesarPlan(draft);
  assert.equal(plan.loadCesarPlan(draft.id).state, 'planning');
  const listed = await tool.execute({ state: 'planning', limit: 1 }, {});
  assert.equal(listed.ok, true);
  assert.ok(listed.content.includes(draft.id));
  core.saveCesarPlan(core.exitCesarPlan(draft, 'operator leaves'));
  assert.equal((await tool.execute({ state: 'planning' }, {})).content, 'No plans found.');
  assert.ok((await tool.execute({ state: 'cancelled', limit: 1 }, {})).content.includes(draft.id));
  writeFileSync(join(root, 'plans', 'cplan-malformed.json'), '{broken');
  assert.equal(core.listCesarPlans().length, 1);
  assert.equal(core.loadCesarPlan(draft.id).exitReason, 'operator leaves');
  console.log('PASS all public state/store identities, real ListPlans tool, exit/reload and malformed-file isolation');
} finally {
  rmSync(root, { recursive: true, force: true });
}
