import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const disabled = { forge: 'agon.forge', teamforge: 'agon.team-forge', brainstorm: 'agon.brainstorm',
  tribunal: 'agon.tribunal', campfire: 'agon.campfire', delegate: 'agon.agent',
  pipeline: 'agon.pipeline-delivery', review: 'agon.review', agent: 'agon.agent', 'team-agent': 'agon.agent' };
if (!process.argv[2] || process.argv[2] === '--conquer-only') {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  // Host disposal is source-tested; the shipped CLI does not export that test entry.
  const conquerScenarios = ['conquer-live', 'conquer-incomplete', 'conquer-disabled', 'conquer-revoked',
    'conquer-replaced', 'conquer-cancel-start', 'conquer-write-failure', 'conquer-finish-failure'];
  const scenarios = process.argv[2] === '--conquer-only' ? conquerScenarios
    : ['construction', 'generation', 'fallback', 'enabled', ...Object.keys(disabled),
      'tribunal-live', 'tribunal-ratings-disabled', 'tribunal-revoked', ...conquerScenarios];
  for (const scenario of scenarios) process.stdout.write(execFileSync(process.execPath,
    [process.argv[1], scenario], { encoding: 'utf8', timeout: 30000 }));
  console.log(JSON.stringify({ passed: true, nativeProcesses: scenarios.length }));
  process.exit(0);
}
const scenario = process.argv[2];
const root = mkdtempSync(join(tmpdir(), 'agon-step-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const fixture = {};
new Function('exports', 'require', ts.transpileModule(readFileSync(join(repo,
  'tests/helpers/modular-surface-lock.ts'), 'utf8'), { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
async function owner(symbol) {
  const files = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
  assert.equal(files.length, 1, symbol);
  const module = await import(pathToFileURL(join(directory, files[0])).href);
  assert.equal(typeof module[symbol], 'function', symbol);
  return module;
}
const authority = await owner('initializeProcessSurfaceAuthority');
const cli = await owner('buildStepExecutors');
const host = new kernel.DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0', processIdentity: 'native-step' });
async function install(disabledId) {
  const catalog = kernel.createFirstPartyModCatalog();
  const full = kernel.createFullCompatDesiredState(catalog, '2026-10-10T00:00:00.000Z');
  const desired = disabledId ? kernel.planDesiredStateChange(catalog, full,
    { kind: 'disable', id: disabledId }, '2026-10-10T00:00:00.000Z').nextState : full;
  await host.commitGeneration({ operation: disabledId ? 'disable' : 'install',
    lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
}
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isDirectory()) unlock(join(path, entry.name));
  }
}
try {
  await install(scenario === 'construction' ? 'agon.plan' : scenario === 'fallback' ? 'agon.agent'
    : scenario === 'tribunal-ratings-disabled' ? 'agon.ratings'
      : scenario === 'conquer-disabled' ? 'agon.conquer' : disabled[scenario]);
  if (!scenario.startsWith('conquer-')) await authority.initializeProcessSurfaceAuthority(join(root, 'host'));
  const ctx = { config: {} };
  const step = { id: 'native-step', type: 'self', description: 'fixture', state: 'pending', estimatedTokens: 0, estimatedCostUsd: 0 };
  if (scenario.startsWith('conquer-')) {
    process.env.AGON_NO_KERN_CONTEXT = '1';
    process.env.AGON_NO_SUMMARY = '1';
    const cwd = join(root, 'source'); mkdirSync(cwd);
    const git = (...args) => execFileSync('git', args, { cwd, encoding: 'utf8', stdio: 'pipe' });
    git('init', '-b', 'main'); git('config', 'user.name', 'Fixture'); git('config', 'user.email', 'fixture@example.invalid');
    writeFileSync(join(cwd, 'baseline.txt'), 'baseline\n'); git('add', 'baseline.txt'); git('commit', '-m', 'fixture');
    const { decorateCliFirstPartyServices } = await owner('decorateCliFirstPartyServices');
    const { runPhysicalCesarWorkflow } = await owner('runPhysicalCesarWorkflow');
    const { startChatSession } = await import(join(repo, 'packages/core/dist/index.js'));
    const calls = [], events = [], warnings = [];
    const controller = new AbortController();
    const originalWarn = console.warn;
    console.warn = (...args) => { warnings.push(args.map(String).join(' ')); };
    try {
      await authority.initializeProcessSurfaceAuthority(join(root, 'host'), async (manifest, base) => {
        const services = await decorateCliFirstPartyServices(manifest, base);
        if (manifest.id !== 'agon.conquer') return services;
        return { ...services, runs: { ...services.runs,
          writeArtifact: async (...args) => {
            if (scenario === 'conquer-write-failure' && args[1] === 'worktree.json') throw new Error('fixture worktree write failed');
            return services.runs.writeArtifact(...args);
          },
          finish: async (...args) => {
            if (scenario === 'conquer-finish-failure') throw new Error('fixture finalization failed');
            return services.runs.finish(...args);
          },
        }, engines: { ...services.engines,
          listActive: async () => ['fixture-builder'],
          resolveRequested: async ids => ids,
          dispatch: async (_id, _prompt, invocation) => {
            assert.equal(invocation.onWorkflowEvent, undefined);
            calls.push(invocation.cwd);
            const stdout = execFileSync(process.execPath, ['-e',
              `require('node:fs').writeFileSync('feature.txt', 'fixture feature'); console.log(${JSON.stringify(scenario === 'conquer-incomplete' ? 'still working' : 'CONQUER_DONE: fixture feature exists')});`],
            { cwd: invocation.cwd, encoding: 'utf8', timeout: 5000 });
            if (scenario === 'conquer-revoked') await install('agon.conquer');
            if (scenario === 'conquer-replaced') await install();
            return { exitCode: 0, stdout, stderr: '', timedOut: false, durationMs: 1 };
          },
        } };
      });
      const chatSession = startChatSession({ cwd });
      const cb = { ctx: { config: {}, chatSession }, dispatch: event => {
        events.push(event);
        if (scenario === 'conquer-cancel-start' && event.message?.startsWith('isolated branch:')) controller.abort(new Error('fixture cancelled'));
      } };
      const running = runPhysicalCesarWorkflow('conquer', { task: 'fixture feature', gate: 'test -f feature.txt',
        builder: 'fixture-builder', maxTurns: 1 }, cb, controller.signal, cwd);
      if (scenario === 'conquer-live') {
        const result = await running;
        assert.equal(result.workflow.done, true);
        assert.ok(chatSession.messages.some(message => message.content === '[conquer:done] fixture feature exists'));
        assert.ok(events.some(event => event.message?.startsWith('✓ Conquered')));
      } else {
        await assert.rejects(running);
        assert.ok(!chatSession.messages.some(message => message.content.startsWith('[conquer:done]')));
        assert.ok(!events.some(event => event.message?.startsWith('✓ Conquered')));
      }
      assert.equal(calls.length, ['conquer-disabled', 'conquer-cancel-start', 'conquer-write-failure'].includes(scenario) ? 0 : 1);
      for (const path of calls) assert.ok(existsSync(path), 'worktree retained');
      if (scenario === 'conquer-incomplete') assert.ok(chatSession.messages.some(message => message.content.startsWith('[conquer:stopped]')));
      if (scenario === 'conquer-write-failure') assert.ok(warnings.some(message => message.includes('Conquer work preserved on')));
      else if (scenario !== 'conquer-live' && scenario !== 'conquer-disabled') assert.ok(events.some(event => event.message?.startsWith('Work preserved on')));
      assert.equal(existsSync(join(cwd, 'feature.txt')), false);
      assert.equal(git('status', '--porcelain'), '');
    } finally { console.warn = originalWarn; }
  } else if (scenario.startsWith('tribunal-')) {
    process.env.AGON_DISABLE_FORGE_HEALTH_CHECK = '1';
    process.env.AGON_FORCE_HEALTH_PROBE = '';
    mkdirSync(process.env.AGON_HOME, { recursive: true });
    writeFileSync(join(process.env.AGON_HOME, 'config.json'), JSON.stringify({ cesarEngine: 'fixture-judge' }));
    const { EngineRegistry } = await import(join(repo, 'packages/support-engine-catalog/dist/index.js'));
    const { CliAdapter } = await import(join(repo, 'packages/adapter-cli/dist/index.js'));
    const registry = new EngineRegistry();
    for (const id of ['fixture-alpha', 'fixture-beta', 'fixture-judge']) {
      registry.register({ schemaVersion: 3, id, displayName: id, binary: process.execPath,
        isLocal: true, tier: 'user', timeout: 5, exec: { args: ['-e',
          `console.log(${JSON.stringify(id === 'fixture-judge' ? 'NATIVE_TRIBUNAL_VERDICT' : 'A substantive native fixture argument with evidence.')})`] } });
    }
    const adapter = new CliAdapter(registry);
    const dispatch = adapter.dispatch;
    const calls = [];
    adapter.dispatch = async options => {
      calls.push(options);
      const result = await dispatch(options);
      if (scenario === 'tribunal-revoked' && calls.length === 5) await install('agon.tribunal');
      return result;
    };
    const controller = new AbortController();
    const value = await cli.buildStepExecutors({ ...ctx, registry, adapter,
      activeEngines: () => ['fixture-alpha', 'fixture-beta'] }).tribunal.execute(
        { ...step, type: 'tribunal' }, {}, controller.signal);
    assert.equal(calls.length, 5);
    assert.equal(calls.at(-1).engine.id, 'fixture-judge');
    assert.match(calls[0].outputDir, /\/plan-exec-\d+\/native-step$/);
    for (const call of calls) assert.equal(call.outputDir, calls[0].outputDir);
    const files = readdirSync(calls[0].outputDir);
    const audit = files.filter(name => /^tribunal_.*\.jsonl$/.test(name));
    assert.equal(audit.length, 1);
    const events = readFileSync(join(calls[0].outputDir, audit[0]), 'utf8').trim().split('\n').map(line => JSON.parse(line).type);
    const revoked = scenario === 'tribunal-revoked';
    assert.equal(value.result.status, revoked ? 'failure' : 'success');
    assert.equal(events.includes('tribunal:done'), !revoked);
    assert.equal(existsSync(join(process.env.AGON_HOME, 'ratings.json')), scenario === 'tribunal-live');
    if (revoked) assert.equal(value.contextExport, undefined);
    else assert.match(value.result.output, /NATIVE_TRIBUNAL_VERDICT/);
  } else if (scenario === 'construction') {
    assert.throws(() => cli.buildStepExecutors(ctx), /unavailable/);
    assert.equal(existsSync(join(root, 'data', 'runs')), false);
  } else {
    const executors = cli.buildStepExecutors(ctx);
    if (scenario === 'enabled') {
      for (const key of Object.keys(executors)) authority.assertProcessPlanStepAvailable(key);
      assert.throws(() => authority.assertProcessPlanStepAvailable('unknown'), /unavailable/);
    } else if (scenario === 'fallback') {
      const value = await executors.self.execute(step, {});
      assert.equal(value.result.status, 'failure');
      assert.match(value.result.error, /Plan step 'delegate' is unavailable/);
    } else {
      if (scenario === 'generation') await install('agon.plan');
      const key = disabled[scenario] ? scenario : 'brainstorm';
      const pending = executors[key].execute(step, {});
      assert.ok(pending instanceof Promise, 'Execute must reject asynchronously');
      await assert.rejects(pending, disabled[scenario] ? /unavailable/ : /restart|disposed|replaced/);
    }
  }
  console.log(JSON.stringify({ passed: true, scenario, compiledCli: true, realDurableHost: true }));
} finally {
  process.chdir(repo);
  unlock(root);
  rmSync(root, { recursive: true, force: true });
}
