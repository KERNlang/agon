import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import * as api from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';

const root = mkdtempSync(join(tmpdir(), 'agon-store-precedence-live-'));
const source = `import { loadCesarPlan, listCesarPlans } from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';
console.log(JSON.stringify({ loaded: loadCesarPlan('cplan-fixture'), listed: listCesarPlans() }));`;
function readFresh() {
  const run = spawnSync(process.execPath, ['--input-type=module', '-e', source], {
    env: { ...process.env, AGON_HOME: root }, encoding: 'utf8', timeout: 10000,
  });
  assert.equal(run.status, 0, run.stderr);
  assert.equal(run.error, undefined);
  return JSON.parse(run.stdout);
}

console.log('helperSha256', createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex'));
try {
  mkdirSync(join(root, 'runs'));
  mkdirSync(join(root, 'plans'));
  const plan = { ...api.createCesarPlan('legacy fixture', []), id: 'cplan-fixture' };
  const legacy = JSON.stringify(plan);
  const oldPath = join(root, 'runs', 'cplan-fixture.json');
  const currentPath = join(root, 'plans', 'cplan-fixture.json');
  writeFileSync(oldPath, legacy);
  assert.deepEqual(readFresh(), { loaded: plan, listed: [plan] });
  for (const bytes of ['{broken', JSON.stringify({ ...plan, id: 'cplan-other' }), 'null']) {
    writeFileSync(currentPath, bytes);
    assert.deepEqual(readFresh(), { loaded: null, listed: [] });
    assert.equal(readFileSync(currentPath, 'utf8'), bytes);
    assert.equal(readFileSync(oldPath, 'utf8'), legacy);
  }
  console.log(JSON.stringify({ passed: true, compiledPublicApi: true, freshProcesses: 4, bytesPreserved: true }));
} finally {
  rmSync(root, { recursive: true, force: true });
}
