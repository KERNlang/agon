# Plan record selection and preservation

Status: accepted increment, not release acceptance. Base checkpoint increment: 54af546c.
Authority: active Modular Agon remediation goal. Same isolation and no-push rules.

## Confirmed next risks

`packages/mod-plan/src/execution-store.ts` removes invalid ID characters instead
of rejecting the ID. Different caller IDs can therefore select one record.
Its loader catches every canonical read/parse error and then reads a legacy
copy. Its list operation can likewise expose an older executable record when
the canonical record is corrupt. Neither path changes the corrupt file, but
selecting the stale record can make completed effects appear pending.

The candidate worktree contains fixes and a stricter execution-record validator.
Do not adopt them together without historical compatibility evidence.

## Bounded next change

- Reject invalid IDs instead of rewriting them.
- Bind a loaded record ID to the requested filename.
- Consult legacy storage only when the canonical record is absent, not corrupt
  or unreadable. The list operation must follow the same rule.
- Retain all saved bytes and provide a bounded diagnostic for invalid records.
- Use real-file fixtures and deterministic I/O-error controls. No personal plans.

No format migration or headless rewrite in this first storage increment.
Expected production blast radius: execution-store.ts only, plus focused tests.
Keep public function signatures and valid historical record behavior.

## Required follow-up, not silently dropped

Headless `implementation.ts` currently writes a smaller Plan shape through
support-persistence. It lacks total fields and stepContext. A strict CesarPlan
validator would reject these records unless compatibility is handled explicitly.
Core also exposes a separate worktree Plan through signals/plan-store.ts. Trace
its consumers before removing the generic support writer or adapters.

Freeze historical output from accepted source, including the envelope metadata,
before unifying writers. Do not invent successful results or unknown costs.
Historical records that cannot execute safely still need inspectable evidence.
Generated headless approval/exit semantics need their own surface checks.

## Evidence so far

Baseline: ten controls failed and the valid-legacy control passed.
Receipt plan-store-precedence-red, log SHA-256
b1d35c269f6f0378f3ad68e02b258c3c6a5be8fce7f471bdeeae63439741159a.
Exact IDs, filename identity and canonical precedence are implemented in the
single existing execution-store owner. A shared read helper removes duplicate
path/identity handling. Read operations do not migrate or rewrite records.

Focused repair run: 34 tests and types passed, including frozen save-byte parity
and the accepted checkpoint corpus. Receipt plan-store-precedence-fixed, log
3ed32c90c6abc4fb8464dbd0afafb1b2bab3b53a12a388214b3ac39dd834ac5e.
Reviewed staged tree: 1d77dcf49ec9393034245fff1d0ba9020cc43a19.
Review packet hash: a77f555ee83cd58b2e91c343a0a32a0577ab8392884da321cfa9e7f8643c4ac0.
Codex source review completed, log
1e301e6a5cae6b6f246f744b2e62f6e816ea03ed4f1e1e282931573cdaa4fa87.
Kimi authentication failed again; no personal-state repair was attempted.

Review hypotheses to reproduce before acceptance:

- One warning per corrupt file is unbounded per list operation. Aggregate it.
- ENOENT from a dangling canonical file or directory symlink is not proof of
  absence. Direct load must not expose a legacy record that listing suppresses.
- Add canonical per-file I/O listing coverage, legacy identity rejection, raw/
  envelope compatibility, wrong-kind envelope refusal and both-file byte checks.

Full gates passed on the reviewed tree (plan-store-precedence-full), but that did
not close the review. Log 21939b3d8c7db442fee1308eb406af4a99dce47888b3299d67ead59a511192e2.
Three new controls reproduced both findings: dangling canonical file/directory
symlinks revived the legacy copy, and 100 corrupt files produced 100 warnings.
Receipt plan-store-review-red, log
eec8bf510f35f29076f51a160e3402127d158e72809da81bff2288762395f6db.

Fixes: lstat distinguishes observed absence from a dangling entry; a dangling
plans directory also refuses fallback. Valid directory symlinks still work.
Listing aggregates failed reads into one warning per directory, at most two
for a complete canonical/legacy list operation. Healthy records remain visible.
These are observed filesystem checks, not cross-process writer fencing.

Expanded coverage also verifies canonical per-file I/O failure, legacy identity
rejection, raw canonical/enveloped legacy compatibility, wrong-kind envelopes,
invalid UTF-8 and unchanged bytes in both locations.
plan-store-review-fixed: 46 focused tests and types pass, log
a0b385f0fd325254960d4b44460cc70a6e147842502807415fcaaa3328b4c414.
No second model panel; review findings were checked and fixed locally.

Final full gate passed on tree baaf1a12d89190d963433738d2f6058632549a32,
receipt plan-store-precedence-qualified (299.011 seconds, exit 0), log
b60aeb7cd4692f3ea54dcd5944431d11d58902007564fae6bba5de82c8bf7e32.
8,173 tests passed; six existing skips. Build/types/lint/structural checks passed.
All six fresh-reader probes and three crash scenarios passed. Providers: zero.
The compiled helper now uses six fresh readers including both dangling links,
SHA-256 50c61fb4f77bbfbd7252a3a6a1a38cd3efee377c4b1f834c8d83cc8b4229c3bd.
Its original version is retained byte-for-byte as
plan-store-precedence-live.initial.mjs, SHA-256
d880be5fd3093a505bf3199bb8b6098333aea433b7eb42d462a3807439010ac0.

Committed as ca3b88d85e73fea8ab619e9c4cfcfad31d224e69,
`fix(modular): preserve canonical Plan record precedence`.
Committed tree equals the qualified tree. Qualification checkout is clean.
Candidate branch ref/index advanced without writing its working files; both
plan-store-preserved-before/after verified all 281 baseline paths with the same
allowlist and unchanged log hash bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.

Investigated all six existing suite skips. Four are opt-in live-provider probes;
one TUI probe requires pyte, unavailable in the current python3 interpreter.
No provider probes or installs were performed. The remaining real-TypeScript
diagnostic check was run explicitly, offline, and passed (one selected test;
the other 30 were intentionally filtered, not failures).
Receipt plan-store-real-tsc, log
0c99afbec21d93caf4a5989ed76a802e1ef3a706d2c29a6e0168218cf9eb7f86.
No push, install, global Agon or personal-state changes.
