import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import * as workflow from '/Users/ra/dev/agon-audit-qualification/packages/mod-plan/dist/index.js';
import * as owner from '/Users/ra/dev/agon-audit-qualification/packages/support-worktree/dist/index.js';
import * as store from '/Users/ra/dev/agon-audit-qualification/packages/support-persistence/dist/index.js';
import * as core from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js';

const home = mkdtempSync(join(tmpdir(), 'plan-workflow-built-'));
process.env.AGON_HOME = home;
const saves = [];
const dispatches = [];
const events = [];
let current = null;
let answer = '';
const host = {
  available: () => true,
  current: () => current,
  setCurrent: plan => { current = plan; },
  load: store.loadPersistedPlan,
  list: store.listPersistedPlans,
  save: plan => {
    store.savePersistedPlan(plan);
    const envelope = JSON.parse(readFileSync(join(home, 'plans', plan.id + '.json'), 'utf8'));
    assert.equal(envelope.status, plan.state);
    assert.deepEqual(envelope.payload, plan);
    assert.deepEqual(store.loadPersistedPlan(plan.id), plan);
    saves.push(plan.state);
  },
  emit: event => events.push(event),
  ask: async () => answer,
  forge: async plan => { dispatches.push(plan.state); },
};
function draft() {
  return owner.createPlan({ type: 'forge', task: 'isolated workflow probe' },
    { id: 'fixture', path: home, headSha: 'abc', branch: 'fixture', dirty: false },
    [{ id: 'dispatch', kind: 'dispatch', label: 'Dispatch', effects: ['exec'] }]);
}

for (const name of ['approvePlan', 'startPlan', 'cancelPlan', 'failPlan']) {
  assert.equal(core[name], owner[name]);
}
current = draft();
host.save(current);
const savedDraft = current.id;
current = draft();
await workflow.showWorktreePlan(host, savedDraft);
assert.equal(current.id, savedDraft);
assert.equal(current.state, 'draft');
assert.deepEqual(saves, ['draft']);
assert.deepEqual(dispatches, []);
await workflow.approveWorktreePlan(host);
assert.equal(current.state, 'approved');
assert.deepEqual(dispatches, ['approved']);
workflow.cancelWorktreePlan(host);
assert.equal(current.state, 'cancelled');

for (const state of ['paused', 'failed']) {
  current = draft();
  current.state = state;
  current.steps[0].result = { state: 'failed', attempts: [{ startedAt: '2026-10-19T00:00:00.000Z', error: 'fixture' }], artifacts: [{ type: 'output', path: 'fixture-output' }] };
  const previous = structuredClone(current.steps[0].result);
  await workflow.retryWorktreePlan(host);
  assert.equal(current.state, 'running');
  assert.equal(current.steps[0].result.state, 'pending');
  assert.deepEqual(current.steps[0].result.attempts, previous.attempts);
  assert.deepEqual(current.steps[0].result.artifacts, previous.artifacts);
  assert.deepEqual(saves.slice(-2), ['approved', 'running']);
}
current = draft();
answer = 'yes';
await workflow.showWorktreePlan(host);
assert.equal(current.state, 'approved');
assert.equal(dispatches.at(-1), 'approved');
const completed = { ...current, state: 'completed' };
for (const name of ['approvePlan', 'startPlan', 'cancelPlan', 'failPlan']) {
  assert.throws(() => owner[name](completed), error => error instanceof owner.PlanStateError);
  const expected = new Error('injected fixture');
  const runtime = { createStateError: () => expected };
  assert.throws(() => name === 'failPlan' ? owner[name](completed, undefined, runtime) : owner[name](completed, runtime), error => error === expected);
}
console.log(JSON.stringify({ home, saves, dispatches, eventCount: events.length, passed: true }));
