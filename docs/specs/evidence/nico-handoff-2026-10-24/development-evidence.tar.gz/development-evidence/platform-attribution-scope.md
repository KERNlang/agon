# Native platform receipt attribution

Status: building; authorized release qualification repair. Base 4726ab50.
No new dependencies, installs, global state changes, or pushes.

## Verified defect

The existing platform verifier hard-coded darwin/arm64 for every locally tested
runtime, regardless of actual host. It also always used the current executable
for Node 26 and always required local macOS archive hashes for explicit Node
overrides. This made the documented Linux/x64 runner command unreliable.

`platform-attribution-red` ran the actual script body in isolated VM contexts
with OS/process boundaries supplied by the test. Three supported targets failed;
only darwin/arm64 passed. Log hash:
`bc267e7f3fc824a04888388460b7a990581db24a5f919ea27411fe2f13d09e74`.
The test does not claim native platform execution: it verifies receipt labeling.

## Repair and scope

Two tracked files: platform verifier and focused test. Build each local cell from
the actual process host. Generate the other nine cells from the remaining target
triples. Use the current executable for its real Node major; allow explicit
caller-provided Node paths without imposing an unrelated cached archive. Retain
archive verification for built-in macOS cached candidates. Probe candidate
version/platform/architecture before tests; mismatched runtime is blocked, not
labelled native. Reject unsupported hosts.

Focused tests/typecheck/diff checks passed in `platform-attribution-identity`:
`f3f48278f2ee3a928c3a0b2f5f3470d348ded8657249a037e97309f96625747b`.
Real current-host run launched as `platform-attribution-native`, --no-write.
Seven expanded controls (including wrong architecture and alternate majors) pass
in `platform-attribution-controls`, log SHA-256
`7c61ee7003abbc0d8cf3a413bd20e7d2451583051f5951390fe8f0049e9b05bf`.
The real current-host check passed one Node26 cell with eleven blocked cells in
`platform-attribution-native`, log SHA-256
`b4cad657c03053429cb6034f3bba4761d00b97ba56456acc20c58509968dcfd8`.
Still needed: review adjudication, full repository gates, and verified local commit. Native Linux/x64 is
still unavailable here; simulated contexts must never replace those release cells.

## Other release evidence, kept separate

`release-set-current-check` failed because the CLI release channel is stale
relative to current built package tarballs. Hash:
`427c22df14e3ac418daa836932433ddbd6c418cbf14e1dc3ac20ecf8d32d8da4`.
Regenerate release-set/channel/SBOM on the final implementation subject, then
rerun their gates. Do not count this platform fix as release acceptance.
Original roadmap commands perf:modular-release and test:modular-load remain
absent from package.json. This is a separate local implementation requirement.

Ratings ownership consolidation awaits the already-presented internal workspace
dependency decision. This platform repair does not change that graph.

## Independent review, 2026-10-11

Frozen staged tree `cc91e3ade90a16bcdbc21957d01450e018202fa4` reviewed through
isolated Agon default reviewers. Packet SHA-256
`118232d4b43cf9d89e0e8b7ac9c56f972aeaa3bfed5717af6ab3a39500eb25a6`.
Codex returned findings; log SHA-256
`ec2d4b65b09beb3490d55f31319f0a4f2403c055f57e6c6f2393ede6c080d3ef`.
Kimi returned no answer (authentication failure), not an independent pass.

Source-confirmed findings, not yet resolved:

1. All-blocked matrix yields `passed:true` and exit zero. The S9 aggregator
   separately rejects zero passed cells, but this checker itself is false-green.
2. Matching Node process architectures does not prove native hardware. Rosetta
   and emulation need runner provenance; VM tests cannot supply it.
3. `/private/tmp/agon-s9-platform-nodeN` is Mac-specific, shared, and retained.
   Replace with a unique temporary path and guaranteed cleanup.
4. Throws before writing leave old receipt bytes in place. S9 reads a stored
   platform artifact without subject validation. Bind/reject stale evidence;
   do not claim a current passing matrix merely from those old bytes.
5. `includes('1.0.0')` accepts `11.0.0` and prereleases. Compare exact package
   version. Built CLI provenance is separately unverified by this checker.

Additional verified limitations: cached archive hashing does not bind extracted
executable bytes; a non-`node`-named override can leave spawned `node` commands
using a different runtime. Need explicit controls before final qualification.
The running full gate is a pre-adjudication baseline, not final acceptance.

## Review fixes and verified runs

Pre-adjudication full gate completed: build, typecheck, lint, re-export guard,
first-party ledger, roadmap, 8,246 passing tests (six skipped), and live matrix.
`platform-attribution-full`, 307.535 seconds, zero provider launches, SHA-256
`5c2661827d5dec43588d9a2cb552155efc9cf097c3146be6e2ea81995ac42875`.

The focused review controls failed six cases before the repairs, SHA-256
`41badd43e78da68f9e3fd9636e6597466655a8bd3c9d547e267fec8a973c827e`.
Now fixed: no all-blocked success; unique OS-temporary homes cleaned in finally;
exact CLI package version, accepting only the real optional `[log] ` prefix.
The first exact-version live check exposed this existing logger prefix. Kept
that failing receipt, added a regression, and did not restore substring matching.
Both incorrect bare and logger-prefixed versions fail. Failed cells now print
their child-process diagnostics even with --no-write.

`platform-review-controls-verified` passes fourteen cases, typecheck, whitespace
check, and one live current-host platform cell (eleven blocked). SHA-256
`c5568eefd22e59a3a619528b398d52fdb10fd01e1a30b724611871fb3d18e998`.
No provider launches. No commits or pushes in this increment yet.

Still open before calling this checker qualified: native-runner provenance,
current-run/subject binding and fatal-error receipts, archive-to-executable
identity, and child `node` resolution for nonstandard override basenames.
Do not claim the pre-adjudication full suite covers the subsequent fixes.
The index retains the original reviewed tree; working-tree changes hold the
locally verified review fixes. Freeze again only when these findings are closed.

Related S9 consumer: `qualify-modular-agon-slice9.mjs:98-108` reads the old stored
platform JSON and checks exact 3-passed/9-blocked counts, without subject binding.
Its clean run invokes the platform checker with --no-write. Thus a current
one-cell result cannot substantiate its historical three-cell coverage. Repair
the evidence contract and consumer together; do not merely relax the counts.

## Fatal receipts and fresh clean-checkout coverage

The repair now spans three files because the stale-data consumer is in the S9
qualifier. This is the same release-evidence requirement, not a change to the
three-runtime acceptance threshold.

The checker writes an incomplete, non-passing receipt before package validation
or any child can fail. Candidate probe/JSON/major/checksum errors produce failed
cells. Cleanup errors also produce exactly one failed cell, never a duplicate
passed/failed pair for the same runtime. --no-write deliberately leaves tracked
evidence untouched and now supports --json for complete fresh output.

The S9 clean-checkout step consumes that full JSON directly from the checker
process. Its coverage uses the fresh result; passing requires a successful,
completed platform step. A stored three-cell artifact cannot supply missing
coverage for a current zero- or one-cell run. Clean checkout/build and subject
hashing remain the existing owners; no parallel subject-hashing system was added.

Evidence:

- `platform-fatal-receipt-red`: four new cases failed on old behavior. SHA-256
  `d4aed269f61c68dde6f89fe2c02b44b11b3854b0eac00d3038fc526dea23e8e6`.
- `platform-fatal-receipt-green`: 18 controls, types, diff check, and live run
  passed. SHA-256 `a748cee911a29091e48594974fa8189488dd0e9200ec54f17804726908ae21e1`.
- `platform-cleanup-cell-red`: duplicate-cell negative control failed. SHA-256
  `cfdcd6cb7f4e1db394ea3de3010befd857bc34dbecae0e8919e9466f4725f676`.
- `platform-cleanup-cell-green`: 19 controls and live check passed. SHA-256
  `054562715d73d40bf1c6497c822799937bc18ff7e2781beb8ee756b85b8e8bff`.
- `platform-fresh-consumer`: 22 controls, types, whitespace and live JSON check
  passed. SHA-256 `85b223573bc1f2db8cf59b9f28168a23fc80f2668fd7e922fbad576e2fe908d5`.
- `platform-stale-consumer-mutant`: reverting selection to the historical
  artifact failed the fresh-coverage tests. Restored immediately. SHA-256
  `9e5956ae0f510e1f31c656c411eee7c70ca0106b0e64f5d113da838416137b73`.

All these runs used provider blockers and recorded zero launches. Still no new
full gate or commit after these review fixes. Native-runner attribution,
executable provenance, and child-node override selection remain open. Standalone
stored matrix output is not a source-bound release receipt; only the enclosing
clean-checkout qualification can bind the fresh matrix to its subject.

## Runtime provenance controls

The checker now compares the cached executable with the `bin/node` member of
the checksum-verified archive before executing it. `tar -xOf` reads to memory;
it does not extract or install anything. Archive reads have a 30-second timeout
and 256 MiB output limit. Explicit overrides keep caller-supplied provenance;
they are not mislabeled as checksum-verified downloads.

The sibling `node` selected by prepending the executable directory to PATH must
resolve to the same file as the chosen executable. A nonstandard basename can
work only if its directory's `node` resolves to that same runtime. This prevents
direct checks using Node22 while spawned `node` commands use Node26.

- `platform-node-binding-red`: two meaningful negative cases failed before the
  repair. SHA-256 `21b7d027ee242ebb7bcc38af5b66b014857fbdf72b01a8fb8713d8cfb4e126bc`.
- `platform-node-binding-green`: 26 controls, typecheck, whitespace check and
  actual Mac/Node26 JSON run passed. SHA-256
  `02dc986757a7871baa2108a4d8b7e90ba08ffea7b2d9bd1958bf3dfecc945c6c`.

No actual cached Node22/24 archive is available here. Archive-member binding is
covered by controlled process/filesystem-boundary tests, not a native Node22/24
claim. The live run covers the installed Node26 process only. Native hardware
provenance remains unresolved: matching process identities alone still cannot
exclude Rosetta, Linux emulation or containers. Do not certify native release
coverage until that attribution is corrected and runner evidence is supplied.

## Native attribution decision and final gate subject

Resolved the false automatic native claim without adding hardware-detection
heuristics: default runs are explicitly diagnostic. `--native-runner` records a
caller attestation, never an automatically verified hardware fact. The complete
matrix names that provenance. The S9 clean runner forwards the flag and requires
three fresh passed native-attested cells. Supporting runner inventory/job
evidence remains mandatory and external where runners are unavailable. This
does not weaken the Node22/24/26 threshold or treat simulation as native.

The operator-facing contract is documented beside the existing platform matrix
in the acceptance roadmap. No persistent configuration or new dependency was
introduced. `nativeHost` was renamed `runtimeHost` because Node reports its
runtime target, not the underlying physical hardware. Source tracing found no
consumer of the old field; S9 uses explicit fresh cells and provenance.

- `platform-native-attribution-red`: diagnostic/native distinction and flag
  forwarding controls failed before the repair. SHA-256
  `c87208e9d6887404e57e8080ae2d7b2f5a5e540d1d7eefbab807918955e87091`.
- `platform-native-attribution-green`: 28 controls, types, whitespace and live
  diagnostic Node26 check passed. SHA-256
  `b0d13bfc3bfdab2abd9e42322f4970da15b650b3d78719d49865e423a708a564`.
- `platform-qualification-preserved-before`: 281 operator paths verified with
  unchanged existing allowlist. SHA-256
  `bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.

Final gate launched as `platform-qualification-full` on frozen staged tree
`69c8cfc442be524bfe8f152bbe76ccd364c378dc` (four explicit paths). No unstaged diff.
The independent review remains the one default-roster review documented above;
its findings have local fixes/negative controls, not a second review panel.
No whole-release claim: live Node22/24 and other native platforms are absent.

## Accepted local increment

Commit `01c5dab05085c1e98aca3a720219f25d7df8f2c4`,
`fix(modular): qualify fresh platform evidence`.
Committed tree equals the frozen gate tree above. Qualification worktree clean.
`platform-qualification-full` passed in 286.62 seconds: full build, types, lint,
re-export/first-party/roadmap checks, 8,267 tests with six skips, and the compiled
current-host diagnostic checker. Zero provider launches. Log SHA-256
`bc1f90be2331fad6ff9c786344f6c52fcd938f97965f5a3fcc61e217755cd2ce`.

Candidate branch advanced with an expected-old-ref check and `read-tree` without
`-u`; working bytes were not replaced. Preservation after advancement is recorded
in `platform-qualification-preserved-after.receipt.json`. No global/personal
changes, installs, pushes or promotions. Temporary review credential copies
were checked absent. This qualifies the checker repair, not the modular release.

Remaining goal work: pending ratings dependency authorization; remaining host
ownership and adapter retirement; missing release performance/load gates;
release-set/SBOM regeneration; final clean-checkout receipts and independent
release review. Native runner inventory, absent Node22/24 binaries and other
platforms are still external evidence, not supplied by an attestation flag.
