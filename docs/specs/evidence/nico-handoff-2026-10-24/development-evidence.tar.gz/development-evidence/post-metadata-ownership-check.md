# Remaining ownership boundary after metadata simplification

Status: investigated; no new production edits in this check.
Subject: 754170e91ecabe68c3bc157b467e4aa4a697593c, clean qualification worktree.
Authority: existing remediation/completion goal. No scope expansion or new packages.

## Verified checks and their limits

`post-metadata-architecture.receipt.json` passed in 1.665s, zero providers.
Log SHA-256: 3a2223400d327496d4a5fb070c684e5f17071fb1e44ab9bb51707b88f821ead8.
Roadmap: 49 packages, 151 unique edges, 872 assignments, nine slices.
Kill-list ownership: all 15 IDs assigned. Source boundaries: eleven support
packages and twelve compatibility bindings. Asset parity: 27 pairs.
Support API probe compiles pre-release N-1/N-2 consumers and loads eleven
descriptors. These are not historical published-version release receipts.

The kill-list checker reports all 15 removed. Do NOT interpret that as complete
legacy-owner retirement. `verify-modular-kill-list.mjs` checks KL-011 only against
four old surface markers in lazy commands, intent, Cesar and MCP. It does not
inspect the remaining Brainstorm host assembly or public Core effect facade.
The passing counter is narrower than the completion requirement.

## Brainstorm consumer trace

Command: `rg -n '\b(runBrainstorm|runScout|collectRankedDrafts|calibrateConfidence|qualityScore|rankDrafts)\b' packages/forge/src packages/core/src packages/cli/src packages/mcp/src`.

`packages/forge/src/brainstorm.ts` still binds runtime services and retains the
public exports. Consumers include:

- CLI plan-mode.ts: two host adapters invoke runBrainstorm.
- CLI handlers/brainstorm.ts and commands/brainstorm.ts: legacy entrypoints.
- Forge conquer.ts: Brainstorm fallback/review workflow.
- Forge team-brainstorm.ts: qualityScore.
- Forge index.ts: public runBrainstorm and runScout exports.

`packages/core/src/blocks/brainstorm-host.ts` is now only injected effects, but
still imports configuration and protocol/rating/classifier effects. The actual
per-invocation assembly lives in mod-brainstorm/src/host.ts.

Do not mechanically replace the Forge binding with the invocation host: Forge
evaluates process.cwd() at dispatch, uses options.signal, and classifies before
mapping rating bids. Invocation host uses captured cwd/signal and maps bids before
classification. Existing raw-oracle tests exercise ten workflow cases against
both bindings, but six scout cases exercise only Forge. Preserve these observable
contracts during any consolidation; do not normalize away differences.

Next ownership work must migrate these actual consumers or move their assembly
behind the physical mod without introducing another authoritative workflow.
Keep public exports until their compatibility obligation is resolved. Prove
installed surface execution and persisted/event parity before marking A06 closed.

## Optional simplifications, not permission for blind deletion

F5 search: `rg -n 'LEGACY_SURFACE_CATALOG|createLegacyCompatibilityRegistry|generateLegacySurfaceProjections|LEGACY_COMPATIBILITY_GENERATION' --glob '!legacy-surface-catalog.ts' packages tests scripts`.
Direct consumers remain compatibility.ts, kernel index.ts, the projection-parity
test and Slice 1A measurement/generator. Root public exports still expose these
names; the current kernel package has only its root export. Moving the catalog
to a test fixture without a public-boundary decision breaks that API. Retain it
pending contract reconciliation, rather than delete the independent oracle.

F7 asset checker still compares canonical/compatibility copies byte-for-byte.
Removing a copy requires caller and pack-path migration, not simply deleting the
checker. No copied asset or evidence was deleted here.

One suspected input-normalization issue was not promoted to a confirmed runtime
defect: generated Brainstorm handler's direct array branch does not trim, but its
registered schema requires a string, and session-workflow normalizes array input
before invoking its executor. Establish an actual public path before changing it.

## Still required

Remaining Plan/Brainstorm ownership and adapter retirement; broader runtime
reachability evidence than KL-011 currently checks; current release-set/channel/
SBOM; clean committed checkout qualification and final independent review.
Native platform/publishing and unavailable review-provider cells remain separate.
No installation, personal state mutation or push occurred.
