# Pressure diagnostic guard root repair

Repository subject: `c8303654917870ca9d35e7c205bb4ebef8db9614`.
No repository source changed for this repair.

The clean pressure run stopped at test-ts: 10,769 tests passed, one failed,
six skipped. The CLI provider-stub test could not read calls.log. Fourteen
earlier gates passed. The terminal receipt reports zero provider launches.

Archive: `pressure-c83036549-seed2719/`. Seventeen original files were copied
and verified byte-for-byte. The original preload is also retained there.
Original receipt SHA-256:
`3e03e8c8d46c15f7250b9fb3c70dd2c9e1d8ea4fc67bffd8fbd12615db1e2733`.
Source archive SHA-256:
`1faa2f075f0ecf36972f4b113056f9f76f51d7a6ad0865ed24f4e97628b72d4e`.
Failed test log SHA-256:
`e3010289ba164df68c295cc0c0953feeccae5586874cd741f91cbcfcc3b51110`.

Cause: external no-login.cjs recognized recording stubs only below
/tmp/amr-runtime/tmp. The clean runner creates a different owned root,
/tmp/agon-pressure-<suffix>/runtime/tmp. The guard threw before the stub ran.
The production probe catches command failure; therefore calls.log never existed.
The standalone test reproduces this exact failure in the retained checkout.

The guard now recognizes both directory shapes. It still requires exact stub
bytes and realpath equality. This is a diagnostic guard, not a sandbox or an
ownership verifier. The harness creates and owns the fixture directories.

Evidence:
- modular-probe-pressure-guard-red: same standalone failure before repair.
- modular-probe-pressure-guard-fixed: all27probe tests pass, zero providers.
- modular-probe-guard-negative-controls:30VM controls over six subprocess
  methods. Valid stub accepted; edited script, symlink escape, wrong directory,
  and real provider path refused. These controls invoke no real subprocess.
- modular-pressure-stub-guard Codex review: no blocking finding. It correctly
  notes that directory shape is not proof of ownership. Its coverage suggestion
  distinguishes absolute invocation from bare-name PATH resolution.

The packed npx verifier has the same root mismatch in the preload's existing
candidate launcher exception. Source tracing confirms it executes the owned
Agon Home ü with spaces/bin/agon path. A VM reproduction fails before correction;
seven launcher path controls pass afterward, including refusal of global and
unrelated fixture paths. This second path correction was source-verified after
the Codex review; it was not part of that review packet.

Corrected preload SHA-256:
`3e2d82910c6461cd05bbe5d4c00783ac0480a92bd0a6a166a6016518b7db9ba4`.
The actual offline packed-candidate test passed85checks in95.274seconds:
modular-pressure-npx-guard-fixed.receipt.json. It installed15packages, survived
ephemeral cache deletion and verified idempotent setup. Zero providers launched.
Log SHA-256: `e513104670f5c720a6cdc069b847ea87267f4f2572f97ac7fe3d9016e4539492`.
Additional bare-name PATH resolution controls cover all six subprocess methods,
both temporary-root layouts and canonical macOS paths, with valid and edited
stub content: modular-probe-guard-path-controls.receipt.json.
A new complete pressure receipt is still required. The original failed receipt
must never be rewritten as passing.
