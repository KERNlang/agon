// Diagnose packed lock translation without installing or resolving new versions.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync, mkdtempSync } from 'node:fs';
import { join, posix } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';

const root = '/Users/ra/dev/agon-audit-qualification';
const evidence = '/Users/ra/dev/modular-agon-remediation';
const require = createRequire(join(root, 'package.json'));
const semver = require('semver');
const read = file => JSON.parse(readFileSync(join(root, file), 'utf8'));
const source = read('package-lock.json');
const map = read('docs/specs/evidence/modular-agon-package-map.json');
const directory = id => 'packages/' + (id === '@kernlang/agon-kernel' ? 'mod-kernel'
  : id === '@kernlang/agon-mod-api' ? 'mod-api' : id.replace('@kernlang/agon-', ''));
const roots = ['packages/cli', ...map.packages.map(entry => directory(entry.id))];
const profile = process.argv.find(arg => arg.startsWith('--profile='))?.slice('--profile='.length) ?? 'full-compat';
const { createReleaseSetupSelection } = await import(join(root, 'packages/mod-kernel/dist/index.js'));
const selection = createReleaseSetupSelection({ profile, with: [], without: [], now: '2026-10-12T00:00:00.000Z' });
const requestedRoots = ['packages/cli', ...selection.effectivePackageIds.map(directory)];
const visited = new Set();
const edges = [];
function lookup(from, name) {
  let parent = from;
  while (true) {
    const key = (parent ? parent + '/' : '') + 'node_modules/' + name;
    if (source.packages[key]) return key;
    if (!parent) return null;
    parent = posix.dirname(parent);
    if (parent === '.') parent = '';
  }
}
function visit(key) {
  if (visited.has(key)) return;
  visited.add(key);
  const entry = source.packages[key];
  assert.ok(entry, `missing lock record: ${key}`);
  if (entry.link) { visit(entry.resolved); return; }
  if (key.startsWith('packages/')) {
    const actual = read(key + '/package.json');
    for (const section of ['dependencies', 'peerDependencies', 'optionalDependencies']) {
      assert.deepEqual(entry[section] ?? {}, actual[section] ?? {}, `${key}: ${section} drift`);
    }
  } else {
    assert.match(entry.resolved, /^https:\/\//);
    assert.match(entry.integrity, /^sha512-/);
  }
  for (const [name, range] of Object.entries({ ...entry.dependencies, ...entry.peerDependencies })) {
    if (entry.peerDependenciesMeta?.[name]?.optional && !Object.hasOwn(entry.dependencies ?? {}, name)) continue;
    const target = lookup(key, name);
    if (!target && entry.peerDependenciesMeta?.[name]?.optional) continue;
    assert.ok(target, `missing dependency: ${key} -> ${name}`);
    let dependency = source.packages[target];
    if (dependency.link) dependency = source.packages[dependency.resolved];
    assert.ok(semver.satisfies(dependency.version, range, { includePrerelease: true }), `${key} -> ${name}: range mismatch`);
    edges.push({ from: key, to: target, name, version: dependency.version });
    visit(target);
  }
}
requestedRoots.forEach(visit);
const required = new Set(visited);
roots.forEach(visit);

const scratch = mkdtempSync(join(evidence, 'frozen-lock-probe-'));
const prefix = join(scratch, 'candidate');
const packs = join(scratch, 'packs');
mkdirSync(prefix);
mkdirSync(packs);
const npmEnv = { ...process.env, npm_config_cache: join(scratch, 'cache'),
  npm_config_ignore_scripts: 'true', npm_config_offline: 'true', npm_config_audit: 'false', npm_config_fund: 'false' };
function npm(args, cwd) {
  const result = spawnSync('npm', args, { cwd, env: npmEnv, encoding: 'utf8', timeout: 120_000 });
  assert.equal(result.status, 0, `${args.join(' ')}: ${result.stderr}`);
  return result;
}
const dependencies = {};
const packages = {};
for (const key of [...visited].sort()) {
  const original = source.packages[key];
  if (original.link) continue;
  const entry = structuredClone(original);
  delete entry.dev;
  delete entry.devOptional;
  if (required.has(key)) delete entry.optional;
  else entry.optional = true;
  if (key.startsWith('packages/')) {
    const metadata = read(key + '/package.json');
    const packed = JSON.parse(npm(['pack', '--json', '--ignore-scripts', '--pack-destination', packs], join(root, key)).stdout)[0];
    const locator = 'file:' + join(packs, packed.filename);
    if (required.has(key)) dependencies[metadata.name] = locator;
    delete entry.devDependencies;
    packages['node_modules/' + metadata.name] = { ...entry, resolved: locator, integrity: packed.integrity };
  } else {
    packages[key] = entry;
  }
}
const manifest = { name: 'agon-frozen-lock-probe', version: '1.0.0', private: true, dependencies };
const lock = { name: manifest.name, version: manifest.version, lockfileVersion: 3, requires: true,
  packages: { '': manifest, ...packages } };
writeFileSync(join(prefix, 'package.json'), JSON.stringify(manifest, null, 2) + '\n');
const lockBytes = JSON.stringify(lock, null, 2) + '\n';
writeFileSync(join(prefix, 'package-lock.json'), lockBytes);
const result = npm(['ci', '--dry-run', '--ignore-scripts', '--offline', '--omit=optional', '--bin-links=false', '--no-audit', '--no-fund'], prefix);
writeFileSync(join(scratch, 'npm-ci-dry-run.log'), result.stdout + result.stderr);
assert.equal(readFileSync(join(prefix, 'package-lock.json'), 'utf8'), lockBytes, 'npm changed frozen lock');
const installed = process.argv.includes('--install');
if (installed) {
  assert.equal(process.env.npm_config_cache, '/tmp/amr-runtime/npm-cache', 'use only the isolated qualification cache');
  const installation = npm(['ci', '--ignore-scripts', '--offline', '--omit=optional', '--bin-links=false', '--no-audit', '--no-fund',
    '--cache', process.env.npm_config_cache], prefix);
  writeFileSync(join(scratch, 'npm-ci-install.log'), installation.stdout + installation.stderr);
  assert.equal(readFileSync(join(prefix, 'package-lock.json'), 'utf8'), lockBytes, 'installation changed frozen lock');
  for (const [key, entry] of Object.entries(packages)) {
    if (entry.optional) {
      assert.equal(existsSync(join(prefix, key)), false, `${key}: unselected package installed`);
      continue;
    }
    const actual = JSON.parse(readFileSync(join(prefix, key, 'package.json'), 'utf8'));
    assert.equal(actual.version, entry.version, `${key}: installed version mismatch`);
  }
  const tree = npm(['ls', '--all', '--json', '--offline'], prefix);
  writeFileSync(join(scratch, 'npm-ls.json'), tree.stdout);
  for (const args of [['--version'], ['setup', '--profile', 'minimal', '--plan', '--json']]) {
    const smoke = spawnSync(process.execPath, [join(prefix, 'node_modules/@kernlang/agon/dist/index.js'), ...args], {
      cwd: prefix, env: { ...process.env, AGON_MOD_SAFE_MODE: '1' }, encoding: 'utf8', timeout: 30_000,
    });
    assert.equal(smoke.status, 0, smoke.stderr);
    writeFileSync(join(scratch, args[0] === '--version' ? 'version.log' : 'setup-preview.json'), smoke.stdout);
  }
}
const report = { diagnosticOnly: true, installed, profile, bootstrapSafeMode: true, scratch, sourceLockHash: createHash('sha256').update(readFileSync(join(root, 'package-lock.json'))).digest('hex'),
  selectedRoots: requestedRoots.length, requiredWorkspaces: Object.keys(dependencies).length,
  requiredRecords: Object.values(packages).filter(entry => !entry.optional).length, optionalRecords: Object.values(packages).filter(entry => entry.optional).length,
  requiredEdges: edges.length, dryRunExit: result.status, lockHash: createHash('sha256').update(lockBytes).digest('hex') };
writeFileSync(join(scratch, 'report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
