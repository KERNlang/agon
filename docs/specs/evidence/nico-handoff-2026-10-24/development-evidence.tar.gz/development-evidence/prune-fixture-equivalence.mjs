import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import * as asyncFs from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { execFileSync } from 'node:child_process';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const relative = 'tests/unit/runs-store.test.ts';
const oldSource = execFileSync('git', ['show', '22fbc4f3:' + relative], { cwd: repo, encoding: 'utf8' });
const newSource = fs.readFileSync(join(repo, relative), 'utf8');
const root = fs.mkdtempSync(join(tmpdir(), 'agon-prune-fixture-equivalence-'));
class Clock extends Date { static now() { return 1_800_000_000_000; } }
function fixture(source, overrides = {}) {
  const start = source.indexOf('/** Create a runs dir');
  const end = source.indexOf("describe('runs-store", start);
  assert(start >= 0 && end > start);
  const output = ts.transpileModule(source.slice(start, end), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None } }).outputText;
  return new Function('mkdirSync', 'writeFileSync', 'utimesSync', 'mkdir', 'writeFile', 'utimes', 'join', 'Date', output + '\nreturn seedRuns;')(
    fs.mkdirSync, fs.writeFileSync, fs.utimesSync, asyncFs.mkdir, overrides.writeFile ?? asyncFs.writeFile, overrides.utimes ?? asyncFs.utimes, join, Clock);
}
function records(dir) {
  return fs.readdirSync(dir).sort().map(name => ({ name, content: fs.readFileSync(join(dir, name), 'utf8'), mtime: fs.statSync(join(dir, name)).mtimeMs }));
}
try {
  const specs = Array.from({ length: 2005 }, (_, i) => ({ name: `run-${String(i).padStart(5, '0')}.json`, ageMs: (8 + i) * 86_400_000 }));
  const before = await fixture(oldSource)(join(root, 'old'), specs);
  const after = await fixture(newSource)(join(root, 'new'), specs);
  const original = records(before);
  assert.equal(original.length, 2005);
  assert.deepEqual(records(after), original);
  fs.unlinkSync(join(after, specs[0].name));
  assert.throws(() => assert.deepEqual(records(after), original), 'Missing-file mutant must fail equivalence');
  let pending = 0;
  const injected = fixture(newSource, {
    writeFile: async path => {
      if (path.endsWith('run-00000.json')) throw new Error('injected write failure');
      pending++;
      await new Promise(resolve => setTimeout(resolve, 25));
      pending--;
    },
    utimes: async () => {},
  });
  await assert.rejects(injected(join(root, 'failed'), specs.slice(0, 8)), /injected write failure/);
  assert.equal(pending, 0, 'Rejected setup must drain sibling writes before teardown');
  console.log('All 2,005 names, JSON bytes and mtimes match legacy fixture exactly; missing-file negative control rejected.');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
