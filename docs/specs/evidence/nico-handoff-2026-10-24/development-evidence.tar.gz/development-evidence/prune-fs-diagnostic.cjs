const fs = require('node:fs');
const { performance } = require('node:perf_hooks');
const rows = new Map();
function observed(path) { return typeof path === 'string' && path.includes('agon-test-runs-store-prune-'); }
function record(op, start) {
  const row = rows.get(op) || { calls: 0, totalMs: 0, maxMs: 0 };
  const ms = performance.now() - start;
  row.calls++; row.totalMs += ms; row.maxMs = Math.max(ms, row.maxMs);
  rows.set(op, row);
}
function report(phase) {
  process.stderr.write('PRUNE-FS-DIAG ' + JSON.stringify({ pid: process.pid, phase, elapsed: performance.now(), operations: Object.fromEntries(rows) }) + '\n');
}
for (const op of ['writeFileSync', 'utimesSync']) {
  const original = fs[op];
  fs[op] = function(path, ...args) {
    if (!observed(path)) return original.call(this, path, ...args);
    const start = performance.now();
    try { return original.call(this, path, ...args); }
    finally { record(op, start); }
  };
}
for (const op of ['readdir', 'stat', 'unlink', 'writeFile', 'utimes']) {
  const original = fs.promises[op];
  fs.promises[op] = async function(path, ...args) {
    if (!observed(path)) return original.call(this, path, ...args);
    const start = performance.now();
    if (op === 'readdir') report('scan-start');
    try { return await original.call(this, path, ...args); }
    finally {
      record(op, start);
      if (op === 'readdir' || op === 'unlink' || (op === 'stat' && rows.get(op).calls % 500 === 0)) report(op);
    }
  };
}
require('node:module').syncBuiltinESMExports();
