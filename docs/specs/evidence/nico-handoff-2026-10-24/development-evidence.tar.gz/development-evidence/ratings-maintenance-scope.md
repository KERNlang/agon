# Ratings maintenance ownership

Status: implemented, reviewed, qualified and committed locally.
Authorization, 2026-10-11: Raphael explicitly approved the internal Core to
existing mod-ratings workspace dependency. This includes matching workspace
lock metadata, not external packages or installation. Preserve Core's public API.
Date: 2026-10-11
Verified at: 4726ab50034384a82299191a423c1e2af9a06353, clean qualification checkout.
Allowed: isolated implementation, tests, default Agon review, verified local
commits. Not allowed: personal ratings/history access, installs, new external
dependencies, pushes or global Agon changes.

## Purpose and authority

Consolidate the ratings-maintenance state-store assignment under mod-ratings.
The original ownership map explicitly assigns
`packages/core/src/signals/ratings-maintenance.ts` to that physical mod. The
current modular implementation duplicates the legacy maintenance operations.
Do not expand this into a scoring-algorithm or whole-registry rewrite.

## Source evidence

`rg -l 'purgeUnknownEngineData|computeRunManifestPurge|computeUnknownEngineIds'
packages tests --glob '*.ts' --glob '!**/dist/**'` returns six files:
Core barrel, Core maintenance, mod-ratings barrel, mod-ratings implementation,
legacy CLI ratings command, and ratings-purge tests.
The generated-barrel generator is another required consumer.

The legacy CLI command is no longer imported by lazy command selection; the
existing lazy-commands test asserts that absence. Do not infer that Core's
exported API has no external consumers. Preserve it during extraction.

Core already consumes physical mod packages, but does not declare mod-ratings.
Retaining its public API through a direct mod-ratings re-export would require
an internal workspace dependency and matching lock metadata. No external package
or install is needed. Resolve authorization for that edge before adding it under
the goal's no-new-dependency constraint; do not hide it with a private path import.

## Differences that must not be accidentally lost

- Modular purge checks protected registered IDs, permissions, cancellation and
  storage-root stability before writes. Legacy synchronous API receives IDs.
- Modular purge rechecks run manifests after the asynchronous permission check.
- Modular purge reports actual successful run moves and propagates non-ENOENT
  failure; legacy purge catches all move failures. Retain the verified safety
  repair; never reintroduce swallowed failures during consolidation.
- Legacy reports include ratingsPath. Modular output does not. Keep each public
  result envelope compatible through narrow formatting, not duplicate mutation.
- Legacy no-op backupDir is null. Modular currently returns a computed backup
  path even when no directory was created. Measure existing consumers before
  selecting unified behavior or adding compatibility formatting.
- Both writers share ratings.json.lock and back up before mutation. Keep that
  cross-process coordination and preserve unknown JSON fields.

## Delivery

1. Extract domain operations into mod-ratings without changing behavior. Keep
   necessary host storage injection explicit; no Core private imports in a mod.
2. Route both entry points through one maintenance owner. Remove duplicated
   pruning/scanning/write logic. Keep permission and protected-ID checks at the
   modular invocation boundary and preserve the old synchronous API.
3. Generate public barrel/ledger changes using existing generators. Verify pack
   content, dependency graph, full gates and a compiled isolated filesystem run.

Estimated impact: 8–10 code/metadata/test files; no UI redesign. Risks: wrong
engine deletion, backup loss, output drift, circular dependencies, stale public
types. Scope limit: do not fold Glicko ranking, engine registry, or Brainstorm
host retirement into this change.

## Acceptance

- One physical implementation owns purge selection and mutations.
- Core API and generated ratings commands invoke it through declared boundaries.
- Dry run changes zero bytes. Protected engines and mixed real runs survive.
- Backups permit exact restoration. A second apply is a no-op.
- Missing/malformed manifests remain untouched. Non-ENOENT move errors fail
  honestly and report recoverable earlier changes.
- Existing ratings-purge, modular-ratings-protection, implementation and generated
  surface tests pass. New owner assertion discriminates duplicate ownership.
- Full build, types, lint, tests, generators and compiled stateful check pass.
- One bounded independent review, all findings source-verified and adjudicated.

Green baseline: plan-outcome-contract-qualified passed full gates, 8,239 tests
with 6 documented skips, on the exact committed tree above.

## Implementation and review, 2026-10-11

Current baseline a25ff39dc437123e50a302b9459131f4d4d274cb is fully green:
8,288 tests, six skips, all eight performance measurements. Backup branch
backup/ratings-owner-a25ff39d preserves it.

One physical maintenance.ts now owns selection, pruning, filesystem scans,
ratings lock, backup and run moves. Core is a narrow typed compatibility adapter;
storage codecs remain injected so host timestamps and JSON formatting do not drift.
The mod retains protected-ID lookup, permission/cancellation/root-stability gates,
preview unknown-ID reporting and its historical proposed-backup no-op output.

Codex reviewed tree f0c163b4d5a21449741b7e7fd618f19316e91323 through isolated Agon.
Packet SHA-256 8a2741788a5c4aa776badd9dc98d78e193309c5d237cc9b4349561a6002b767a.
Review SHA-256 b5bd782faae924224a3b5e4912d7c2124870f166913d14645234e30ef4cf979f.
Kimi unavailable again (engine exit 2, no answer). No authentication changes.

Confirmed findings and local adjudication:
- Core re-export narrowed inline-literal type compatibility. An actual TypeScript
  compile reproduced TS2353. A typed Core wrapper now preserves RatingRecord;
  the shared selector is generic over its smaller structural requirements.
- Inherited timestamp backup collision reproduced with two different purges at
  one frozen timestamp. A uniquely created directory now protects each snapshot.
- Inherited scan-to-move race reproduced by updating the run during ratings save.
  The shared owner rechecks under the per-run history lock. Source tracing found
  Forge writeManifest is the history writer; it now uses the same lock around
  history publication. This adds that one source file to the original impact map.
  This protects the cooperating Agon writer, not arbitrary external file writers.

Final scope: 12 files versus the initial 8–10 estimate; no external dependency.
Only the actual backup directory gains a uniqueness suffix. No-op conventions
stay unchanged. Non-ENOENT run move failures are now honestly fatal for Core too,
retaining the already-correct mod behavior. Tests cover a failure after one move,
copy failure, codec failure, vanished files, unknown JSON fields and malformed runs.

Evidence receipts outside Git:
- ratings-owner-red: duplicate-owner assertion fails before extraction.
- ratings-owner-focused: builds, types, 27 tests and generation check pass.
- ratings-inline-types-red-valid / ratings-inline-types-green: actual failing
  public consumer compile, then passing same compile after the wrapper repair.
  The earlier ratings-inline-types-red was a compiler-invocation error, not proof.
- ratings-recovery-races-red / ratings-recovery-races-green: both data-safety
  failures reproduced, then repaired.
- ratings-manifest-lock-controls: deferring the actual writer's lock callback
  leaves history unchanged; publication occurs only when that callback executes.
- ratings-owner-concurrent-live: compiled Core/mod dry-run, apply, byte-exact
  backup, no-op checks plus actual concurrent Forge/purge subprocesses pass.
  SHA-256 99ce832d529e22c5de38b04e12758c3ef0d86e98dc17d087f470590d6815277c.
- ratings-owner-pack: dry-run pack includes maintenance.d.ts and no source/test files.

OSV scan ratings-workspace-osv completed and returned findings (not a scan error):
563 packages, 56 local/unscannable entries filtered, 16 advisories across 9 entries:
2 critical, 7 high, 6 medium, 1 low. All external locked versions are unchanged.
Notable: two tinypool 1.1.1 dev advisories rated 9.5; undici 6.28.0 includes high
severity findings. This is a release issue, not waived or silently upgraded.
Raw log and immutable receipt retained. No repeated scan needed for the same lock.

Full gate, final live rerun, subject hash, local commit and preservation check
remain required. No release-complete claim is made by these component results.

Full-gate subject: tree 7dcdcb49dc8ec8cae6a8afc4a81c65d08b0136b2.
The staged tree contains all 12 intended paths, with no unstaged source changes.
ratings-owner-final-focused passed 37 tests, the explicit public-consumer type
compile, repository types and generated ownership checks. Final live probe now
includes two actual concurrent subprocesses (Forge history writer and Core purge)
behind a held history lock, then checks protected history remains and no protected
snapshot was moved. This tests cooperating writer behavior, not external editors.
ratings-owner-full is the named complete gate; read its receipt for final status.

## Qualified commit

7394158eefc4df5cc1790d5737aa43d78b6c17cd, tree
7dcdcb49dc8ec8cae6a8afc4a81c65d08b0136b2 (exact frozen gate tree).
ratings-owner-full passed in 312.392 seconds: full build/types/lint/re-export
guard, first-party and roadmap verifiers, 8,299 tests with six skips, all eight
performance measurements, and final compiled Core/mod/concurrent-writer probe.
Log SHA-256 a11d721265e655083ae90abf6d4520830064477509da3574d69e05cbd4776a7f.
Final pack dry run passed; receipt ratings-owner-final-pack, log SHA-256
5d6064eaeeecb551e0099a245ffff0a2c2045de2def947179a7f4ae526f86271.
All verification runs recorded zero provider launches.

Candidate branch advanced by compare-and-swap; index-only read-tree preserved
working bytes. Before/after preservation checks cover 281 paths with the same
approved allowlist; matching log SHA-256
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification checkout clean after commit. No push or installation. Personal and
global Agon state untouched. Security advisories remain a separate release issue;
this increment does not certify the whole release candidate.

## Remaining rating ownership, traced during load qualification

Verified against 67d7cca7; no production edits made during the load gate.
`packages/core/src/signals/glicko.ts` still owns the full rating algorithm,
load/save codec, lineage seeding and ranking. It is not a pure re-export.
`packages/mod-ratings/src/implementation.ts` has a second load/save codec.
The prior maintenance commit consolidated purge behavior, not these owners.

The dependency is reachable from Brainstorm's Core host adapter through
getRatings, seedNewEnginesFromRegistry and updateGlickoRanked. The Core registry
also injects getEngineGlickoRating into support-engine-catalog. Removing the
Brainstorm adapter before providing its effects would not finish extraction.
The audit clause at modular-agon-product-audit.md:1452 explicitly requires final
physical effect owners before adapter removal.

Existing dependencies are sufficient for a bounded next rating extraction:
mod-ratings already depends on support-engine-runtime (TaskClass and engine
types) and support-persistence (withFileLock); Core already has Raphael's
approved dependency on mod-ratings. Glicko's registry parameter only calls
list() and reads id/derivedFrom. It need not acquire a Core or catalog import.
The host-runtime functions it uses are direct Date, JSON and Math wrappers.

Keep public Core APIs stable. Before changing either codec, explicitly compare
their existing differences: warning behavior, HOME fallback, temporary filenames,
metadata types and byMode types. Do not silently alter these while moving owners.
Existing tests cover dispatch metrics, rating selection, lineage, role selection,
purge locking and raw Brainstorm effect parity. Extraction still needs direct
algorithm/persistence parity and a compiled consumer check. No claim that current
tests alone prove this future extraction.

Search evidence: `rg -l 'GlickoRating|RatingRecord|EngineMeta|signals/glicko'
packages tests scripts --glob '!**/dist/**' --glob '!**/*.tsbuildinfo'` lists 24
paths. This is a consumer inventory, not authorization to edit all 24 paths.
Keep changes bounded to owners, compatibility exports, generated public exports
and targeted evidence. Complete the running load increment first.

## Ratings runtime extraction contract

Status: building. Authorized by the continuing ownership-remediation goal.
Base: 37f2dec6d1e458018becc7ec540795a0f542acab. Its full build, types,
lint and 8,365-test receipt is green (modular-load-final).
Backup ref: backup/ratings-runtime-37f2dec6. No push or installation.

Move the existing Glicko implementation and its three persisted types into
mod-ratings. Expose a glicko namespace on the existing public package; Core's
legacy module becomes explicit bindings to that namespace. This avoids changing
the mod's existing loadRatings export, whose warning policy differs from Core.
Share the actual file reader, scope normalization and atomic publication between
both callers. Callers retain their path fallback, error-reporting policy and
temporary-file name. Reuse support-persistence's lock. No new dependency.

Estimated change: 10–12 paths, roughly 440 relocated production lines and
100–150 test lines. Medium risk: persisted ratings and competition selection.
Keep all math, ranking, tie behavior, seeding, lock paths and output shapes.
Use the existing EngineDefinition public type and a structural list() capability;
do not import Core or acquire a catalog dependency in the mod.

Binding rule: AGENTS.md says "Never break public entry points" through the
applicable refactor skill, and the repository requires build, typecheck, tests,
lint and guard:reexports before a commit. The user requires original behavior,
one owner and no private package imports. The existing namespace pattern is an
additive public boundary, not a new service or runtime registry.

Acceptance: Core runtime exports are the same function objects as the mod owner;
Core has no rating math or file implementation; malformed/missing/legacy files
preserve both callers' diagnostics and normalized output; pair/ranked/lineage
updates and raw persisted values match the pre-move implementation; simultaneous
updates preserve all matches under the existing lock; mod/core compile and pack;
full gates and a final compiled isolated write/read run pass. Preserve the source
oracle outside the shipping diff and verify exact Git provenance.

Out of scope: changing rating formulas, changing enablement policy, removing
stable public Core exports, changing task classification, changing dependency
versions, or claiming the remaining Brainstorm adapter retired by this move.

## Runtime extraction verification in progress

Final staged tree: 5b8aa4fb278d05fe28fd1c823924e9adcc1f6b38.
Ten paths, 580 additions / 445 deletions; 100 added lines are focused tests.
The new 380-line glicko file is the moved implementation, not a second algorithm.
Core retains explicit function bindings; canonical competition types live in
the mod. Its existing permissive leaderboard record type remains distinct from
the stricter competition record contract. The identical GlickoRating type is
shared. No dependency/lock changes.

The first focused run failed because mod-ratings/dist still lacked the new
namespace. Rebuilding the changed package fixed all consumer errors. Retained
failed receipt: ratings-runtime-focused. The rebuilt run passed its 134 tests,
types, lint and generated checks, then failed in the external comparison helper:
it used CJS resolution for an import-only support package. After fixing that,
the helper found a warning difference caused by creating separate VM realms for
storage and its caller. The helper now executes modules with distinct exports
but one shared JS realm, matching the actual ESM runtime. Warnings are compared
verbatim; none are filtered or normalized away. These were helper defects, not
excuses to modify production behavior.

Legacy source archive: ratings-runtime-legacy-37f2dec6.ts, verified byte-for-byte
against the committed base on every comparison run. SHA-256
b99b85bdc1224a2bdaacb2ac1d9e6e5c1e560895d3b8314d7d404c8fb1a9f9bb.
The comparison covers 2,008 checks: exact legacy/missing/corrupt/null/path-failure
records, warning text, pair/ranked/lineage disk bytes, and 2,000 numeric cases.
A changed Glicko scale is detected. The standalone snapshot stays outside the
shipping diff; committed tests contain small behavioral controls, not a second
full implementation.

Default Agon review subject: 6e56a8f1919bbee1a88743c50671592ff364bccb.
Packet SHA-256 27f5dd7e3489f9ac69c40af597506359e02245279ba19efa5c08a93563bb1865.
Codex log SHA-256 c4b85518362d3243ec349eb9176e43d64545e2fcaa4f6c102c2ce2c3ec8a86ba.
Kimi returned no answer; log SHA-256
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No second panel; unavailable Kimi is not approval.

Confirmed review finding: path resolution had moved outside the catch boundary.
Fixed by passing the existing path resolver into the shared reader. Negative
control ratings-runtime-path-negative failed, then ratings-runtime-path-positive
passed. Added serialization, write and rename failure controls. Kept Core's
timestamp-after-mkdir and maintenance's timestamp-before-mkdir ordering; the
latter is source-verified, not independently observed through a private object.
Home fallback expressions remain unchanged. The actual simulated home-lookup
failure is included in the legacy comparison, never sent to personal paths.

ratings-runtime-review-controls: PASS, 5.766 seconds, 138 tests, types and
2,008-case comparison. Log SHA-256
5aebb04a5f9ffb617d12781370767d3e019b97d4d55bb9b4cdc2de42832ec49c.
ratings-runtime-live: PASS, 9.344 seconds. Compiled Core/mod dry-run/apply,
byte-exact backups, protected history and concurrent Forge/purge checks passed.
Six actual Core/mod writer subprocesses preserved all 60 matches in all scopes,
with no remaining lock/temp file. Pack dry-run contains 12 entries, including
the new public declarations. Log SHA-256
38dc793172bc7980a8ffc3b85b714d72c3c455cd102c8383941173d606009d49.
All these verification runs recorded zero provider launches.

Full frozen-subject gate: ratings-runtime-final (read its terminal receipt).
It includes complete build/types/lint/tests, ownership checks, eight performance
gates, sustained load, the exact legacy comparison and compiled concurrency last.
Do not commit or count this as qualified until that receipt passes.

### Full-gate failure and focused reproduction

`ratings-runtime-final` failed after 277.972 seconds. Build, typecheck, lint,
re-export guard, first-party generation and roadmap checks passed. The suite
reported 8,377 passing tests, one failure and six skips. Performance, sustained
load and the final comparison/concurrency commands did not execute in this run.
Log SHA-256: 433efe992b16d4094d3da5cfeca39bbb3f5bf659ee0f394d63ede1e8ca064e4d.

The failure is `daemon-survival.test.ts`, real CLI job-shutdown case, line 159:
`accepted?.type` was undefined instead of `job-accepted`. The current assertion
does not print `lastRequestTrace`; the daemon also discards stderr in this case.
Therefore the failed run does not distinguish timeout, socket error, or close.
Do not label the failure as load-related or unrelated to this change without
additional evidence.

One unchanged focused run, `ratings-runtime-daemon-reproduce`, passed in
11.723 seconds. Log SHA-256:
7883a3231b0a3b4638c8573451539e89c156b36ee4764911a3c95a5eeee4f546.
Both runs recorded zero provider launches. A focused pass does not supersede the
full-suite failure. Ratings extraction remains staged and uncommitted.

Next diagnostic: retain the existing request trace and bounded child stderr in
failure output, then reproduce under full-suite conditions. Do not increase the
timeout or add retries to conceal the missing acknowledgement.

Separate release-gate finding: KL-013 still searches mod-jobs/implementation.ts
for the job envelope producer. The producer now resides in
mod-jobs/src/persisted-job-service.ts. Verify its runtime wiring and update the
gate with a meaningful missing/disconnected-producer negative control before
accepting its result. No gate change has been made yet.

### Diagnostic follow-up

Added bounded stderr capture (8,192 characters) and the existing request trace
to the failing assertion in daemon-survival.test.ts. No timeout, retry, or
acceptance criterion changed. This diagnostic change remains unstaged, separate
from the ten staged Ratings paths.

`ratings-runtime-daemon-diagnostics` passed the full suite in 71.209 seconds.
Log SHA-256: 00a6013a9e3aed2b647c43d1ed64288555ece19cddd59638107a2a2e75dad21c.
Zero provider launches. This does not identify the original failure's cause.
The bounded follow-up run is `ratings-runtime-diagnostic-pressure`: eight
existing daemon-suite runs, types/lint, performance/load gates and both Ratings
runtime comparisons. Inspect its terminal receipt; do not assume it passes.

Further KL-013 tracing changes the next action: ModularJobService is exported
but no production source constructs it. The real daemon constructs JobService
at packages/cli/src/commands/daemon.ts:198. Thus simply updating the verifier's
producer path would not prove daemon persistence. However,
docs/specs/unified-execution-job-control-plane.md explicitly excludes persistence
across process restarts for its minor release, while the modular security spec
requires envelopes for persisted jobs. Distinguish those contracts before adding
new persistence behavior. Verified fact: producer presence does not prove runtime
use. Open question: whether current agreed modular acceptance requires durable
daemon jobs or only versioned envelopes for already-persisted records. Do not
silently expand the product requirement or declare a runtime defect from this
source check alone.

The original failing daemon test took 619 ms total (ratings-runtime-final.log,
line 1333), less than sendRequest's 3,000 ms deadline. This rules out that
request timeout for this occurrence. The remaining null-response paths are
socket error, close before a parsed reply, and synchronous write failure.
Socket-file existence before readiness is a hypothesis, not a diagnosed cause.

Scope interpretation for the next KL-013 correction: the modular contract says
persisted records require versioned envelopes; it does not itself require every
daemon job to become persistent. The existing Jobs control-plane spec explicitly
excludes restart persistence. Preserve that behavior. Verify the exported
ModularJobService producer and its behavioral tests rather than wiring a new
durable daemon service solely to satisfy a static search. Any claim of durable
daemon jobs remains unsupported. The gate must keep job-envelope negative
controls and must not describe source presence as complete runtime proof.

### Qualification guard correction (separate uncommitted increment)

Updated scripts/spec/verify-modular-kill-list.mjs to read the current Jobs
producer path and check its public export chain plus storage call. Added missing
producer/export/storage-call controls. Self-test now rejects a red baseline,
preventing vacuous negative-control success. Direct command
`node scripts/spec/verify-modular-kill-list.mjs --self-test` exits 0 with all
15 structural rows passing. This is not whole-release acceptance or evidence of
daemon restart persistence. No runtime persistence behavior changed.

Review target hashes:
- verifier: 66e1a717dca95344be3f27405ab92c1fd4d966a2390f2e18c70e2534b57f4deb
- daemon diagnostics: 20ec3963b6183da79c05999f4214b5c672d2d66a979e4df2fbfe72e0ef92d6b2

Prepared existing isolated review.py packet `qualification-diagnostics` for the
default reviewers. It has not run yet; wait for load measurement to finish to
avoid CPU interference. This script change occurred after the pressure run's
lint phase; rerun lint and relevant existing tests for this increment. The staged
Ratings tree remains 5b8aa4fb278d05fe28fd1c823924e9adcc1f6b38; the two verification
changes remain unstaged. Do not fold them into a Ratings commit unnoticed.

`ratings-runtime-diagnostic-pressure` passed in 429.013 seconds, zero provider
launches. Log SHA-256:
132d2b13c5e275c8ff386cf626153de7eff6962c53594ef144f18251016bd92d.
Eight daemon suites passed (72 tests), types/lint and all performance gates passed.
The two measured phases completed 29,784 transport jobs and 760 local-fixture
workflow jobs. Request p95 was 1.970ms/8.189ms; peak daemon RSS was
177,192,960/178,601,984 bytes; workflow process-tree RSS was 963,657,728 bytes.
Workflow settled RSS growth was 4,685,824 bytes, peak concurrency four, no pending
fixtures. Failure/cancel/recovery/shutdown/cleanup controls all passed. Shutdown
completed in 19.892ms/20.233ms. Exact legacy comparison passed 2,008 cases and
killed the scale mutant. Six concurrent Core/mod writers preserved all 60 matches;
Core/mod purge and concurrent Forge/purge checks passed. Original 619ms daemon
failure is still unresolved; this receipt is not a diagnosis or full release signoff.

Started default isolated reviews `qualification-diagnostics` and existing-test
run `qualification-diagnostics-check`. Their terminal receipts, not this note,
determine success. Review helper syntax was checked with Python ast.parse.

Qualification review: Codex returned no blocking regression. Packet hash
d770a498969116a12d2b3337204d9a7250f524f89835797f2de7222729012338;
Codex log hash c03ab23327573d5c216bf5a781f125a033ebc25191d255c610bf23132b7ac998.
Kimi returned no answer (exit 1 from Agon); unchanged unavailable-auth log hash
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No personal authentication changes and no second review panel.

Verified review gap: whole-file deletion controls did not independently exercise
each new predicate. Added separate mutations of envelope construction, job kind,
inheritance, implementation import and implementation export. Self-test passes.
Added real connected-socket close and timeout controls to distinguish those
diagnostic paths from ENOENT. These do not change any daemon request deadline.
Stderr/status at socket completion remain snapshots, not proof the process stays
alive afterward. Comments/unreachable text can satisfy structural regexes;
behavioral tests remain necessary and no stronger claim is made.

`qualification-diagnostics-check` passed in 57.360 seconds before the review
controls, zero provider launches; log SHA-256
bbc6ef9985c0c1bf838524b988e2b83d3162c3b5de9f1e037c05e1c40e1c276b.
Post-review checks are running as `qualification-diagnostics-review-controls`.

Post-review checks passed in 68.686 seconds with zero provider launches.
Log SHA-256: 802a1400b3ba3076071b295d7c9de8e5b3aab413062c7d4a18b7c62518e67dbc.

Ratings extraction committed locally as 31ddb139becdc0d184b91cb676ed2f4dd22fe187,
exact frozen tree 5b8aa4fb278d05fe28fd1c823924e9adcc1f6b38. Only the ten Ratings
paths are included. Candidate branch advanced with compare-and-swap and an
index-only read-tree, no worktree overwrite. Before/after preservation receipts
ratings-runtime-preserved-before/after both pass with identical log hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
This is a verified ownership increment, not release acceptance. The original
daemon flake remains explicitly open; no push or global installation change.

The separate two-path verification increment is staged. Its full build, types,
suite, lint, re-export, kill-list and final live daemon check are running as
`qualification-diagnostics-final`. Check its terminal receipt before committing.

Final verification passed in 291.562 seconds, zero provider launches: build,
types, 8,380 tests (six skips), lint, re-export guard, kill-list negative controls
and eleven real daemon tests last. Log SHA-256
956184403d2923a979346567e29f520490519d3265d3ff84646162937fa2e0f8.
Committed exactly the two verification paths as
45749f249a8607dffe614de20456a88f4bf23637, tree
0a9a8de7dc330825ae8fd5bfc112b9bf967f7d1d. Qualification checkout was clean afterward.
Candidate ref/index advanced without writing working files; before/after
qualification-diagnostics-preserved receipts pass with the unchanged
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82 log hash.
No push or promotion. Daemon flake remains open; diagnostic controls do not fix it.
