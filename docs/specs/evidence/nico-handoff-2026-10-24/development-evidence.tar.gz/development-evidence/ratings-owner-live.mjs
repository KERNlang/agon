import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, rmSync, readdirSync } from 'node:fs';
import { tmpdir, hostname } from 'node:os';
import { join } from 'node:path';

const root = '/Users/ra/dev/agon-audit-qualification';
const sandbox = mkdtempSync(join(tmpdir(), 'agon-ratings-owner-'));
const previous = process.env.AGON_HOME;
try {
  process.env.AGON_HOME = sandbox;
  const core = await import(root + '/packages/core/dist/index.js');
  const mod = await import(root + '/packages/mod-ratings/dist/index.js');
  const checks = [];
  for (const lane of ['core', 'mod']) {
    const home = join(sandbox, lane);
    process.env.AGON_HOME = home;
    mkdirSync(join(home, 'runs'), { recursive: true });
    const rating = { mu: 1500, phi: 100, sigma: 0.06, wins: 1, losses: 0, lastActive: '' };
    const bytes = JSON.stringify({ global: { real: rating, fake: rating }, byMode: {}, byTaskClass: {}, engineMeta: {}, lastUpdated: '', custom: 'keep' });
    writeFileSync(join(home, 'ratings.json'), bytes);
    writeFileSync(join(home, 'runs', 'fake.json'), JSON.stringify({ engines: ['fake'] }));
    writeFileSync(join(home, 'runs', 'mixed.json'), JSON.stringify({ engines: ['fake', 'real'] }));
    const invoke = async dryRun => lane === 'core'
      ? core.purgeUnknownEngineData({ registryIds: ['real'], dryRun })
      : (await mod.runRatings({ action: 'purge-unknown', apply: !dryRun }, {
        invocationId: 'fixture', cwd: home, platform: `${process.platform}-${process.arch}`,
        signal: new AbortController().signal, config: {},
      }, { permissions: { check: async () => 'allow' }, ratings: { protectedEngineIds: async () => ['real'] },
        receipts: { record: async () => 'fixture-receipt' } })).result;
    assert.deepEqual((await invoke(true)).ratingsUnknown, ['fake']);
    assert.equal(readFileSync(join(home, 'ratings.json'), 'utf8'), bytes);
    const result = await invoke(false);
    assert.deepEqual(result.ratingsRemoved, ['fake']);
    assert.equal(readFileSync(join(result.backupDir, 'ratings.json'), 'utf8'), bytes);
    assert.equal(existsSync(join(home, 'runs', 'fake.json')), false);
    assert.equal(existsSync(join(home, 'runs', 'mixed.json')), true);
    assert.equal(JSON.parse(readFileSync(join(home, 'ratings.json'), 'utf8')).custom, 'keep');
    assert.deepEqual((await invoke(false)).ratingsRemoved, []);
    checks.push({ lane, dryRun: true, applied: true, backupByteExact: true, mixedPreserved: true, idempotent: true });
  }
  const home = join(sandbox, 'concurrent');
  const forgeDir = join(home, 'forge');
  mkdirSync(join(home, 'runs'), { recursive: true });
  mkdirSync(forgeDir);
  const history = join(home, 'runs', 'fixture.json');
  const oldRun = JSON.stringify({ engines: ['fake'] });
  writeFileSync(history, oldRun);
  writeFileSync(join(home, 'ratings.json'), JSON.stringify({ global: { fake: {} }, byMode: {}, byTaskClass: {}, engineMeta: {}, lastUpdated: '' }));
  const lock = history + '.lock';
  writeFileSync(lock, JSON.stringify({ pid: process.pid, uuid: 'live-fixture', hostname: hostname(), acquiredAt: new Date().toISOString() }), { flag: 'wx' });
  const { spawnWithTimeout } = await import(root + '/packages/support-engine-runtime/dist/index.js');
  const launch = code => spawnWithTimeout({ command: process.execPath, args: ['--input-type=module', '-e', code],
    cwd: root, env: { ...process.env, AGON_HOME: home }, timeout: 8000 });
  const writer = launch(`import {writeManifest} from '@kernlang/agon-forge'; writeManifest(${JSON.stringify({ forgeId: 'fixture', forgeDir, engines: ['real'] })});`);
  const purge = launch("import {purgeUnknownEngineData} from '@kernlang/agon-core'; purgeUnknownEngineData({registryIds:['real'],dryRun:false});");
  try {
    const deadline = Date.now() + 4000;
    while (!existsSync(join(forgeDir, 'manifest.json')) || JSON.parse(readFileSync(join(home, 'ratings.json'), 'utf8')).global.fake) {
      assert.ok(Date.now() < deadline, 'both workers must reach the held history lock');
      await new Promise(resolve => setTimeout(resolve, 10));
    }
    assert.equal(readFileSync(history, 'utf8'), oldRun, 'writer must not bypass the live history lock');
    rmSync(lock);
    for (const child of await Promise.all([writer, purge])) {
      assert.equal(child.exitCode, 0, child.stderr);
      assert.equal(child.timedOut, false);
    }
    assert.deepEqual(JSON.parse(readFileSync(history, 'utf8')).engines, ['real']);
    for (const directory of readdirSync(home).filter(name => name.startsWith('purge-backup-'))) {
      const moved = join(home, directory, 'runs', 'fixture.json');
      if (existsSync(moved)) assert.deepEqual(JSON.parse(readFileSync(moved, 'utf8')).engines, ['fake']);
    }
    checks.push({ lane: 'concurrent-forge-purge', sharedLock: true, protectedHistoryRetained: true });
  } finally {
    if (existsSync(lock)) rmSync(lock);
    await Promise.all([writer, purge]);
  }
  const ratingHome = join(sandbox, 'concurrent-ratings');
  mkdirSync(ratingHome);
  const writers = Array.from({ length: 6 }, (_, index) => {
    const module = index % 2 ? "import {updateGlicko} from '@kernlang/agon-core';"
      : "import {glicko} from '@kernlang/agon-mod-ratings'; const {updateGlicko}=glicko;";
    return spawnWithTimeout({ command: process.execPath, args: ['--input-type=module', '-e',
      module + "for(let i=0;i<10;i++) updateGlicko('a','b','test','brainstorm');"],
      cwd: root, env: { ...process.env, AGON_HOME: ratingHome }, timeout: 8000 });
  });
  for (const writer of await Promise.all(writers)) {
    assert.equal(writer.exitCode, 0, writer.stderr);
    assert.equal(writer.timedOut, false);
  }
  const ratings = JSON.parse(readFileSync(join(ratingHome, 'ratings.json'), 'utf8'));
  for (const scope of [ratings.global, ratings.byMode.brainstorm, ratings.byTaskClass.test]) {
    assert.equal(scope.a.wins, 60);
    assert.equal(scope.b.losses, 60);
  }
  assert.equal(ratings.engineMeta.a.matchCount, 60);
  assert.equal(ratings.engineMeta.b.matchCount, 60);
  assert.equal(existsSync(join(ratingHome, 'ratings.json.lock')), false);
  assert.equal(existsSync(join(ratingHome, 'ratings.json.tmp')), false);
  checks.push({ lane: 'concurrent-core-mod-ratings', workers: 6, preservedMatches: 60 });
  console.log(JSON.stringify({ passed: true, checks }, null, 2));
} finally {
  if (previous === undefined) delete process.env.AGON_HOME;
  else process.env.AGON_HOME = previous;
  rmSync(sandbox, { recursive: true, force: true });
}
