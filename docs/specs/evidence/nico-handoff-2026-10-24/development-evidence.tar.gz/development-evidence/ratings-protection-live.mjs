import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = mkdtempSync(join(tmpdir(), 'agon-ratings-cli-'));
const home = join(root, 'home');
const cwd = join(root, 'project');
mkdirSync(join(home, 'engines'), { recursive: true });
mkdirSync(join(home, 'runs'));
mkdirSync(cwd);
try {
  writeFileSync(join(home, 'engines', 'unavailable-fixture.json'), JSON.stringify({
    schemaVersion: 3, id: 'unavailable-fixture', displayName: 'Unavailable fixture',
    binary: 'agon-fixture-never-installed', searchPaths: [], versionCmd: ['--version'],
    isLocal: false, timeout: 1, exec: { args: ['{prompt}'] },
  }));
  const filtered = JSON.parse(readFileSync(join(home, 'engines', 'unavailable-fixture.json'), 'utf8'));
  filtered.id = 'kimi';
  writeFileSync(join(home, 'engines', 'kimi.json'), JSON.stringify(filtered));
  writeFileSync(join(home, 'config.json'), JSON.stringify({ ratingsPurgeKeepEngines: ['renamed-fixture'] }));
  const ids = ['unavailable-fixture', 'kimi', 'renamed-fixture', 'cli-kept', 'fake'];
  const global = Object.fromEntries(ids.map(id => [id, { mu: 1500, phi: 350, sigma: 0.06, wins: 1, losses: 0, lastActive: '' }]));
  writeFileSync(join(home, 'ratings.json'), JSON.stringify({ global, byMode: {}, byTaskClass: {}, engineMeta: {}, lastUpdated: '' }));
  for (const id of ids) writeFileSync(join(home, 'runs', `${id}.json`), JSON.stringify({ engines: [id] }));
  function invoke(apply) {
    const args = ['/Users/ra/dev/agon-audit-qualification/packages/cli/dist/index.js', 'ratings', 'purge-unknown', '--keep', 'cli-kept', apply ? '--apply' : '--dry-run'];
    const result = spawnSync(process.execPath, args, { cwd, env: { ...process.env, AGON_HOME: home }, encoding: 'utf8', timeout: 30000 });
    assert.equal(result.status, 0, result.stderr + result.stdout);
    const match = result.stdout.indexOf('{');
    assert(match >= 0, result.stdout);
    const documents = result.stdout.slice(match).trim().split(/\n(?=\{)/).map(text => JSON.parse(text));
    assert.equal(documents.length, 1, 'A selected child must not emit a parent-command result');
    const reports = documents.filter(document => typeof document.dryRun === 'boolean');
    assert.equal(reports.length, 1, result.stdout);
    assert(documents.every(document => typeof document.dryRun === 'boolean' || Array.isArray(document.ratings)), result.stdout);
    console.log(JSON.stringify({ apply, outputKinds: documents.map(document => document.dryRun === undefined ? 'leaderboard' : 'purge') }));
    return reports[0];
  }
  const preview = invoke(false);
  assert.deepEqual(preview.ratingsUnknown, ['fake']);
  assert(existsSync(join(home, 'runs', 'fake.json')));
  const applied = invoke(true);
  assert.deepEqual(applied.ratingsRemoved, ['fake']);
  const stored = JSON.parse(readFileSync(join(home, 'ratings.json'), 'utf8'));
  for (const id of ids.filter(id => id !== 'fake')) {
    assert(stored.global[id], `Protected ratings lost: ${id}`);
    assert(existsSync(join(home, 'runs', `${id}.json`)), `Protected run lost: ${id}`);
  }
  assert(!existsSync(join(home, 'runs', 'fake.json')));
  assert(existsSync(join(applied.backupDir, 'runs', 'fake.json')));
  assert(JSON.parse(readFileSync(join(applied.backupDir, 'ratings.json'), 'utf8')).global.fake);
  console.log('Two compiled generated-CLI invocations passed: dry-run and apply. Unavailable registered engine, filtered registered ID, configured historical ID and --keep preserved; unknown data backed up.');
} finally { rmSync(root, { recursive: true, force: true }); }
