import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import { createContext, runInContext } from 'node:vm';
import { pathToFileURL } from 'node:url';

const root = '/Users/ra/dev/agon-audit-qualification';
const require = createRequire(join(root, 'package.json'));
const ts = require('typescript');
const persistenceRoot = join(root, 'node_modules/@kernlang/agon-support-persistence');
const persistenceManifest = JSON.parse(readFileSync(join(persistenceRoot, 'package.json'), 'utf8'));
const persistence = await import(pathToFileURL(join(persistenceRoot, persistenceManifest.exports['.'].import)));
const base = '37f2dec6d1e458018becc7ec540795a0f542acab';
const oldSource = readFileSync('/Users/ra/dev/modular-agon-remediation/ratings-runtime-legacy-37f2dec6.ts', 'utf8');
assert.equal(oldSource, execFileSync('git', ['show', `${base}:packages/core/src/signals/glicko.ts`], { cwd: root, encoding: 'utf8' }));
const currentSource = readFileSync(join(root, 'packages/mod-ratings/src/glicko.ts'), 'utf8');
const storageSource = readFileSync(join(root, 'packages/mod-ratings/src/storage.ts'), 'utf8');
const instant = '2026-10-11T00:00:00.000Z';
class FixedDate extends Date {
  constructor(value = instant) { super(value); }
  static now() { return new Date(instant).getTime(); }
}
const warnings = [];
let failHomeLookup = false;
const context = createContext({ process, Date: FixedDate, console: { warn: text => warnings.push(text) } });
const host = { hostNowIso: () => instant, hostNowMs: FixedDate.now,
  hostEpochFrom: value => new Date(value).getTime(), hostSqrt: Math.sqrt,
  hostPrettyJson: value => JSON.stringify(value, null, 2) };
function evaluate(source, storage) {
  const exports = {};
  const compiled = ts.transpileModule(source, { compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022,
  } }).outputText;
  runInContext(`(function(exports, require) {\n${compiled}\n})`, context, { timeout: 5000 })(exports,
    name => {
      if (name === 'node:os') return { ...require(name), homedir: () => {
        if (failHomeLookup) throw new Error('home lookup failed');
        return require(name).homedir();
      } };
      if (name.startsWith('node:')) return require(name);
      if (name === '../blocks/host-runtime.js') return host;
      if (name === '../blocks/file-lock.js' || name === '@kernlang/agon-support-persistence') return persistence;
      if (name === './storage.js') return storage;
      throw new Error(`Unexpected dependency: ${name}`);
    });
  return exports;
}
const storage = evaluate(storageSource);
const previous = evaluate(oldSource);
const current = evaluate(currentSource, storage);
const temporary = mkdtempSync(join(process.env.AGON_HOME, 'ratings-parity-'));
const savedHome = process.env.AGON_HOME;
const stable = value => JSON.parse(JSON.stringify(value));
let compared = 0;
function scenario(api, name, initial, action) {
  const home = join(temporary, name);
  require('node:fs').mkdirSync(home);
  process.env.AGON_HOME = home;
  if (initial !== undefined) writeFileSync(join(home, 'ratings.json'), initial);
  warnings.length = 0;
  const output = action(api);
  process.env.AGON_HOME = home;
  const record = api.loadRatings();
  const path = join(home, 'ratings.json');
  return stable({ output, record, warnings: [...warnings],
    raw: require('node:fs').existsSync(path) ? readFileSync(path, 'utf8') : null });
}
try {
  const cases = [
    ['missing', undefined, api => api.getRatings()],
    ['legacy', '{}', api => api.getRatings()],
    ['corrupt', '{bad', api => api.getRatings()],
    ['null', 'null', api => api.getRatings()],
    ['home-failure', undefined, api => {
      failHomeLookup = true;
      delete process.env.AGON_HOME;
      try { return api.loadRatings(); } finally { failHomeLookup = false; }
    }],
    ['pair', undefined, api => api.updateGlicko('a', 'b', 'test', 'brainstorm')],
    ['ranked', undefined, api => api.updateGlickoRanked([{ engineId: 'a', score: 90 }, { engineId: 'b', score: 90 }, { engineId: 'c', score: 10 }], 'test', 'forge')],
    ['lineage', undefined, api => { for (let i = 0; i < 8; i++) api.updateGlicko('a', 'b', 'test', 'forge');
      return api.seedNewEnginesFromRegistry({ list: () => [{ id: 'c', derivedFrom: 'a' }] }); }],
  ];
  for (const [name, initial, action] of cases) {
    assert.deepEqual(scenario(current, `${name}-new`, initial, action), scenario(previous, `${name}-old`, initial, action));
    compared++;
  }
  for (let i = 1; i <= 1000; i++) {
    const args = [0.06, 0.1 + i / 1000, 0.3 + i / 100, i / 1000];
    assert.equal(current.computeNewSigma(...args), previous.computeNewSigma(...args));
    assert.equal(current.glickoE(i / 100, -i / 200, i / 300), previous.glickoE(i / 100, -i / 200, i / 300));
    compared += 2;
  }
  const mutant = evaluate(currentSource.replace('173.7178', '100'), storage);
  assert.notDeepEqual(scenario(mutant, 'mutant', undefined, api => api.updateGlicko('a', 'b', 'test', 'forge')),
    scenario(previous, 'control', undefined, api => api.updateGlicko('a', 'b', 'test', 'forge')));
  console.log(JSON.stringify({ passed: true, compared, mutationKilled: true, base,
    legacySha256: createHash('sha256').update(oldSource).digest('hex'),
    ownerSha256: createHash('sha256').update(currentSource).digest('hex'),
    storageSha256: createHash('sha256').update(storageSource).digest('hex') }, null, 2));
} finally { process.env.AGON_HOME = savedHome; rmSync(temporary, { recursive: true, force: true }); }
