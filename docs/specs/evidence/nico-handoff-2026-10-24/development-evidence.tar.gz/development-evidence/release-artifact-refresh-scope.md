# Release artifact refresh after ownership repairs

Status: building under the existing goal. Base e15c05728b5645849ccdffca4423ada86218efd4.
Allowed: existing local pack/generation/check commands, isolated review and local
commit. No installation, dependency changes, push or promotion.

Three generated tracked files: packages/cli/release-channel.json,
docs/specs/evidence/modular-agon-release-set.json and modular-agon-sbom.cdx.json.
The existing generator also refreshes the ignored built release-channel copy.
Do not change schemas, package inventory, dependency graph or acceptance budgets.

Baseline: full code gate and live CLI/PTY tests passed on e15c0572. The release
artifact check failed specifically with CLI release channel drift. Receipt
release-artifact-drift-e15c0572, SHA-256
427c22df14e3ac418daa836932433ddbd6c418cbf14e1dc3ac20ecf8d32d8da4.

Both old BOM and SBOM match the existing durable archive byte-for-byte, including
manifest hashes and original commit provenance. Archive:
/Users/ra/dev/modular-agon-evidence-archive/2026-10-10-2b59937b.
Keep it indefinitely unless Raphael explicitly approves deletion. No evidence
file is untracked or removed; current acceptance metadata remains in Git.

Acceptance: regenerate from the already built packages using lifecycle-scripts-
disabled npm pack; regenerate SBOM; repeat check/self-test commands; inspect every
package identity/version/dependency and artifact count for unexpected changes.
Keep provenance externally blocked. Rebuild and recheck to prove the source
channel survives the build and the hashes are reproducible. Reuse existing
representative/live probes after repository gates. Qualify the exact committed
tree; this increment alone does not certify the whole release.

## Review findings verified, 2026-10-11

Reviewed staged tree a33c9e795ec7bca7df39231705daf5710561d32d.
Codex packet ae5fd4cc68a8a98ff74b0f35c41bff6f3a0534d6a10addd0c3c428cec1a8f2dd;
review log ac57daf9fa528c515d6c1d156319464a0c238ce0825468e2b509aa33227efe44.
Kimi returned no answer (exit 1); no authentication changes attempted.

Confirmed pre-existing acceptance defects, not runtime regressions:
- Launcher BOM omits its 36 optional mod dependencies.
- Supply-chain validator accepts replacing an internal dependency with a self-edge
  while preserving count. Verified by invoking the current validate function.
- Release version self-test never calls the production validator.
- SBOM serial and version are constant across different artifact content.

Physical adjacency needs care: package-map edges describe architectural dependencies.
All 47 support/mod packages also declare the kernel peer contract; the map already
includes this edge for seven support packages and omits it for the other 40.
This is not permission to change the resolver graph or add installed dependencies.
The SBOM must distinguish the selected graph from actual package relationships.
An initial comparison that omitted peer dependencies reported seven mismatches;
including peers exposed this separate, intentional shared-kernel contract.

Scope extension: repair the two existing verifier scripts and their existing
self-tests, then regenerate the same three metadata files. No additional shipping
helpers or packages. Preserve 151 architectural edges; record actual npm dependency
and peer relationships separately. Validate membership rather than only counts.
Use content-derived SBOM identity and retain explicit unpublished provenance.
The running pre-fix full gate is baseline evidence only, not final acceptance.

## Repairs and controls

The release verifier now calls one production package validator from inspection
and self-tests. It checks exact physical dependency membership against the map,
accounting for map dependencies supplied as peers. Existing lockstep checks in
both dependency sections remain intact. The BOM retains the 151-edge architecture
graph and separately records package peer declarations. The launcher inventory
includes its optional packages. Both channel copies are read from the actual
launcher tarball and compared byte-for-byte with the qualified channel.

The supply-chain verifier compares BOM adjacency, map package adjacency and map
edges. Its duplicate-edge negative control preserves the edge count and requires
the specific duplicate-edge error. Other controls reject substituted membership
and omitted optional launcher dependencies. UUID v5 identifies release content;
the same content produces the same ID, changed artifact evidence a different ID.
The SBOM includes 234 unique release-package relationships: 151 architecture edges,
40 additional kernel peers, and 43 launcher links. It explicitly excludes external
npm transitive closure; it is not represented as a complete ecosystem SBOM.

Evidence so far:
- release-artifact-qualified: baseline full build/types/lint/tests/performance and
  live CLI/PTY/session checks passed, 8,417 tests and six skips, 355.884 seconds.
  Log SHA-256 029db7feb36cfaac704fad403387be3e557802cd7b57fd0159b2bc8e52ac83bc.
- release-adjacency-red: new self-test failed on the original membership defect,
  log SHA-256 8072b34b6e739913f751870ff6c2c346c8b7163fecc4ab8cadab21e0683a330a.
- release-verifier-fixed: regenerate and repeat check/self-tests passed, 23.816s,
  log SHA-256 78f0c6788bc6dfcb6fb8a77ade813b932e463a92b7a0f2b1d3a2fbcfd1072b8e.
- release-verifier-final-focused: tarball channel check, SBOM/self-tests and lint
  passed, 68.242s, log SHA-256
  1216a872235a672d4a692d4f22fd6ca8d2f402e3b8f42a374a46ae5cdaad70f6.
- release-verifier-mutations: three in-memory production-source mutants were
  discriminated: version guard removal, BOM adjacency guard removal and launcher
  dependency guard removal. Healthy validators reject the bad input; each removed
  guard accepts it. No source mutation was written to the worktree. Log SHA-256
  2179e584f6731abee24d2ba1b31b9296bfbae9e3139520e0e03917ec2ec1d9b5.

Final staged subject: 9bb691eb6068f8d74fbb648753cbcd173c675041. Full verification
release-verifier-qualified is running. No commit or acceptance yet. One default
review panel was used; its source-confirmed findings were fixed locally, without
a second panel. Five tracked paths; no dependencies, installs or graph changes.

## Completed increment

Commit 33510c6e0af34a4393e993e6d91b41ee87326292, tree
9bb691eb6068f8d74fbb648753cbcd173c675041. Qualification worktree is clean.
Final release-verifier-qualified passed in 356.336s with zero provider launches:
build, types, lint, re-export guard, release/SBOM self-tests and reproducibility,
8,417 tests (six skipped), all performance measurements, three live workspace
CLI/PTY phases and four session lifecycle invocations. Log SHA-256
96a15430740348bca221bf35cf6ad1d452a2537aada2ef65058b102d5579ad02.

Independent direct comparison of all 50 physical package manifests against SBOM
adjacency passed: 234 relationships, including normal, optional and peer fields.
This check did not derive its expected edges from the architecture map.

Predecessor archive reverified against HEAD before commit:
- BOM 410fa60b2ac30250fc8269695082da4b384d115ce58b913cb120727e22b1a92e.
- SBOM a124b9d78713736418ef25ece291c5b7831a4a9f5bcd54839202c78f880ac634.

Candidate branch/index advanced without updating working files. Before/after
preservation checks passed for the original 281 paths, unchanged allowlist and
log SHA-256 bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Nothing pushed, installed, promoted or changed in active/global Agon.

Still not whole-release acceptance: exact clean-install and all packed consumers,
remaining runtime ownership/adapter retirement, final receipt reconciliation,
platform/provider/provenance cells and advisory remediation remain separate.
Current live CLI checks use the built workspace, not an installed tarball.

Post-commit architecture checks passed in 1.878s on 33510c6e:
roadmap, kill-list ownership, support boundaries and negative controls, 27 asset
pairs, kill-list checks, N-1/N-2 public consumers and S5 ledger reproducibility.
Receipt post-release-architecture; log SHA-256
86e64d5ef5cb70ce066521630e84d74908e7c9e48e606590c6a48e5acc3d11fc.
Their passing counts do not close remaining runtime adapters: S5 still labels
authority from file existence and KL-011 checks catalog markers, not every
execution import. Those limitations are unchanged, not silently accepted.

Next ownership trace on this subject: Core brainstorm-host.ts remains effects
composition used by both CLI/MCP decorators; Forge brainstorm.ts now has only
public compatibility bindings. CLI brainstorm-session.ts injects session/UI
effects into the physical mod. Plan execution is 180 lines and step-host is 193;
the migration ledger still treats their presence as legacy authority. Distinguish
real remaining policy from necessary host injection before deleting anything.
A suspected approve-before-authority state mutation was refuted: approveCesarPlan
returns a new object and does not save or mutate the pending draft; existing
modular-plan-entry-authority tests already cover the refused route. No fix made.
