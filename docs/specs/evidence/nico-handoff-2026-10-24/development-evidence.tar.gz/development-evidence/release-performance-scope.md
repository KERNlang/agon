# Release performance and load qualification

Status: performance increment committed and verified; sustained load remains.
Implementation authorized by the active Modular Agon completion goal.
Date: 2026-10-11
Verified at: agon@01c5dab05085c1e98aca3a720219f25d7df8f2c4.
Authority: original S9 roadmap and frozen measurement budgets.
Allowed: isolated local implementation, tests, default Agon review, local commits.
Not allowed: installs, dependencies, personal/global state changes, pushes, Pipeline.
AI data mode: Agon allowed for this task. Evidence remains outside shipping diff.

## Purpose and accepted scope

Implement the missing `perf:modular-release` and `test:modular-load` acceptance
commands without replacing meaningful measurements with unit-test totals.
First increment: compose the eight existing performance measurements and make
S9 consume their fresh results from the qualified checkout. Keep each existing
budget unchanged. Second increment: sustained-host/concurrent workflow load,
after tracing the existing host/job APIs and recording a measured baseline.
This plan does not authorize lower acceptance thresholds.

## Verified baseline and reuse

`package.json:94-153` exposes eight per-slice performance commands, but no release
aggregate or sustained load command. The S9 roadmap names both missing commands
at `docs/specs/evidence/modular-agon-implementation-roadmap.json:2805-2806`.
`qualify-modular-agon-slice9.mjs` runs eight fresh measurement subprocesses, but
its aggregate performance flags and coverage still come from historical JSON.
As with the repaired platform gate, fresh output should own qualification.

Existing scripts own cold startup/RSS, resolver, package size, TUI latency,
durable host boot, desired-state/grouped-view latency, support/mod imports,
registry activation, lifecycle apply, discovery and trusted bootstrap.
Do not duplicate these measurements or create a second percentile implementation.

On 01c5dab0, S1A first failed --version p95 (187.466 ms > 185 ms), then passed
unchanged (173.440 ms). Both receipts retained. No performance fix is claimed.
S2 through S8 each passed one isolated run. Receipt filenames:
`release-performance-existing-s{2,3,4,5,6,7,8}.receipt.json`.
Each receipt binds command, duration, exit code, log hash and zero provider
launches. Read receipts, not this prose, for their exact evidence hashes.

## Contract gate

| Binding text | Source | Application |
| --- | --- | --- |
| "Do not weaken an oracle" | accepted implementation goal | Keep all frozen numeric budgets; propagate failures. |
| "startup, memory, resolver, TUI, package-size, sustained-host and concurrent-workflow load budgets remain green" | S9 roadmap exit criteria | Compose existing owners; add missing load evidence separately. |
| "Run the gate ... green before committing" | repository AGENTS.md | Full build/types/lint/tests/re-export gate before local commit. |
| "No ... installs or new dependencies" | active remediation goal | Use installed executables only; isolate state; no providers. |

## Approach and blast radius

Reuse existing scripts through bounded sequential subprocesses, collect complete
JSON results, retain failed outputs and aggregate all eight verdicts. A failed,
missing, malformed or timed-out measurement must make the command red. A false
verdict must not be overridden by successful process exit. No retry-until-green.
The aggregate prints JSON for the clean-checkout qualifier to retain directly.
The CLI itself and its runtime behavior are not changed in this increment.

Expected first-increment paths (about 150–200 lines, adjust with evidence):

- `package.json`: wire the required command; no dependency change.
- `scripts/spec/measure-modular-release.mjs`: bounded orchestration only.
- `scripts/spec/qualify-modular-agon-slice9.mjs`: consume fresh aggregate evidence.
- Focused unit tests for missing/malformed/failing child evidence and stale
  stored-green rejection. Reuse actual script-body VM controls already present.

Direct callers are the package command, S9 clean checkout and focused tests.
No UI, package public API, registry owner, persistence format or installer changes.
Risk: false-green aggregation, discarded child errors, indefinite subprocesses,
personal state leakage, or contamination between samples. Each needs a control.

## Acceptance and completion conditions

1. Command exists and runs all eight existing measurement owners sequentially.
2. Complete child evidence and failures retained; one failure makes result red.
3. Malformed JSON, nonzero exits, timeouts and absent verdicts cannot pass.
4. S9 bases coverage/verdict on this clean run, never historical performance files.
5. Existing per-slice commands and numeric budgets stay unchanged.
6. Isolated real run and focused negative controls pass; full repository gate
   follows one bounded independent review before local commit.
7. No claim that eight component measurements alone prove sustained load.

## Remaining load work

Verified reuse candidates: `modular-lifecycle-concurrency.test.ts` checks sixteen
competing lifecycle writers and stale-plan exclusion; daemon survival tests drive
the built CLI over real sockets; daemon Jobs authority tests cover cancellation
and generation changes. They are useful behavior oracles but do not measure
sustained memory/throughput. Trace those real host paths before designing the
load driver. Load duration, concurrency and budgets must be evidence-based and
documented, not guessed just to make a gate green. Native cross-platform evidence
remains external where runners are unavailable.

## Corrections

2026-10-11: S1A performance is mixed, not universally green. A passing repeat
does not erase the failed initial run or demonstrate a fixed root cause.

2026-10-11: The first real aggregate failed S1A again (version p95 199.357 ms,
help 207.861 ms), while S2–S8 passed. Receipt `release-performance-consumer-focused`,
SHA-256 `4217b58372217ad0e2faad721368fefbd10fd00891c2e3e61a902116700e109b`.
An isolated import probe measured the eager CLI Core chunk at 98.9–109.5 ms,
kernel at 44.6–56.4 ms, and citty at 16.3–19.2 ms (five samples each).
Probe receipt SHA-256 `e9fc58f2d13403477ff29d26f41b2b8390eb55050425666dceecbc3f366b9851`.

Source trace: `index.ts` needed Core's config only inside the interactive branch.
Auth is already owned/exported by declared dependency support-engine-runtime;
Core's auth-store is a deprecated re-export. Importing auth from its real public
owner and loading Core config only inside the same interactive branch preserves
early auth injection and all generation/disabled-mod checks. No new dependency.
Added two CLI files to this increment (index and existing lazy-command guard).
This is a measured budget repair, not a new metadata fast-path or skipped check.

`release-startup-lazy-red` failed the new source boundary control; SHA-256
`0fc81fcbe336172d1af138d7a33eb768e826c51eef79160e437f475769aa764e`.
`release-startup-lazy-green` passed focused tests, types, CLI rebuild, real
metadata commands and all eight aggregate performance measurements. SHA-256
`1c3ffbd1928d4396bfd456ad3ed7ab8b1ba4c3fa27e02d317b8b02d79e5722f3`.
Version p95 143.603 ms, help p95 136.350 ms; peak RSS below 90 MiB.
Before/after help+version output is byte-identical, hash
`358a5414427c1f3ae6400efbc36cc53342075f838563da4cde9c45d1c52b1a6b`.
All runs recorded zero provider launches. Full repository gate and independent
review remain required before committing. Sustained-load implementation remains
separate and unfinished, not covered by the aggregate success.

## Independent review and adjudication

Codex reviewed frozen tree a305dbe73b54a55b167eb1a5526e0dfe1edf93bb.
Packet hash: 54dfec8f0a1f08c5c041b55bb814676062c658f1253118af314b962fd0559d54.
Review log hash: bf956483b101a9a1256072e77273a8175382be3a8ee0fd5eca9b1ea873d6ad6e.
Kimi exited 1, with engine exit 2 and no answer. It is unavailable evidence,
not approval. No personal authentication changes were attempted.

All three findings confirmed and repaired:

1. S9 discarded aggregate JSON on nonzero exit. A fixture with an early failure
   and more than 4,000 characters reproduced the loss. Parse JSON regardless of
   exit status; retain complete evidence while keeping failure fatal. Malformed
   JSON produces a failing receipt instead of aborting receipt construction.
2. Synchronous timeout left descendants alive. A real child/grandchild fixture
   reproduced it. Reuse the public support-engine-runtime spawnWithTimeout owner
   for bounded escalation; terminate remaining owned group after every result.
   Real fixtures cover successful parent exit and a parent that ignores SIGTERM.
   Cleanup errors fail and stop the aggregate rather than contaminate later samples.
3. Explicit 0/null/string verdicts overrode valid budget flags. Negative controls
   reproduce all three. A present verdict must be exactly true.

Additional consumer controls independently vary aggregate/step/child verdicts,
missing/reordered slices, malformed JSON, and contradictory red budgets. The
contradictory case found inherited S9 validation accepted passed:true plus a red
budget; corrected without weakening thresholds. Other cases rejected correctly.

Receipts (external, immutable):
- release-review-verdict-evidence-red: four expected failures.
- release-review-verdict-evidence-green: corresponding controls green.
- release-review-descendant-red: real surviving descendant detected and cleaned.
- release-review-process-green: 41 controls, types and lint green; 66.979 seconds.
- release-review-consumer-boundaries-red: contradictory budget accepted (one failure).
- release-review-consumer-boundaries-green: 48 controls green, 2.631 seconds.
Every run recorded zero provider launches. Receipt JSON records full SHA-256 values.
No second paid review panel: source-verified fixes and local controls adjudicate
the original review. New source diff is still seven files, no added dependencies.

## Qualified increment

Commit a25ff39dc437123e50a302b9459131f4d4d274cb.
Tree aac38adc84c3439c3e36d6534a85c0c625b11c13, identical to the frozen gate subject.
Receipt release-performance-full passed in 315.335 seconds:
build, types, lint, re-export guard, first-party generator, roadmap verifier,
8,288 tests (6 skips), and all eight real performance measurements.
Log SHA-256 44b7a566a1f8bea0109d2701d03522469028728f3578a60200b28a12cea14eaa.
Zero provider launches. The qualification worktree is clean after commit.
Candidate branch advanced by compare-and-swap and index-only read-tree; no
candidate working bytes were overwritten. Before/after preservation receipts
check 281 paths with the same approved allowlist and matching evidence hash.
No push, installation, promotion or personal/global Agon change occurred.
This proves this increment, not full release or sustained-load acceptance.
