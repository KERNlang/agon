# Remaining first-party settings ownership

Status: building; implementation authorized by the standing goal.
Date: 2026-10-11. Base ac4b6dd0e7ce07423ec4e4dcdc13be53ff22d161.
No push, installation, dependency or personal-state changes.

Apply the verified Forge pattern to seven ledger-assigned settings in Review,
Agent, Mutate and Synthesis. Their existing schemas become authoritative input;
Core keeps generated static compatibility data, not runtime imports of mods.
Keep exact optional types, defaults, ordering and registration IDs. Register
the schema at every existing config registration owned by each affected mod.

Blast radius: four schema inputs, four generated manifests, four implementation
registration sites, Core types and generated settings, existing focused test,
and three generated release artifacts (18 files). No new architecture or API.
Green base: 8,534 tests plus full build/types/lint/package and runtime probes.

Acceptance: all nine mod-owned fields match the ownership ledger, generated
keys/defaults match all five source schemas, registrations apply owner defaults
and reject wrong types before effects, disabled handles remain unreachable,
the historical 121-field compatibility check remains exact, and generator
negative controls stay meaningful when Review contributes goalReviewEngines.
Default Agon review, full gates and built-artifact probes required before commit.

Not complete here: namespace-to-flat precedence, durable versioned migration,
remaining host adapters and whole-release clean-checkout qualification.

## Work in progress

Test-first remaining-settings-owner-red failed on missing owner properties and
defaults; log hash 500198255a4420189112841bd67593b64a3c1de6b0135ea58bf1736678e9768c.
All seven definitions now reside in their four owner schemas. Core's interface
composes owner types only; all default entries preserve their original positions.
No generator changes were needed. Focused tests (16) and typecheck pass; lint and
generator check are part of remaining-settings-owner-focused, still in progress
when this note was written. Fifteen authored/generated source paths staged.

Agon review subject is staged tree 9cbbf0de8ad62d0582655207662d31c247e0bc47.
Review ID remaining-settings-owner, default Codex/Kimi isolated harness.
Full qualification, built-artifact checks, review adjudication and commit remain
required. Do not treat the working-tree implementation as qualified acceptance.

Focused run completed: remaining-settings-owner-focused passed in 71.075s,
log SHA-256 33ed7be43d29ce269d58af26161ca3298ffc81a7a2c8de294c66def701af0a45.
Codex review exited 0; packet hash
bc48b4bb668d18181391049749fbdc4052690ade225880bbc9f3730801110241,
log hash 75f72bda8ab28a45a796e51e0fd270c828f92cbfab9ebabcd263cb962d9a8723.
Kimi exited 1 without review; no authentication repair.

Review adjudication:
- Claimed stale manifests: refuted. They are staged in the frozen subject, but
  omitted from the bounded review packet. Actual repository generator --check
  passed. No source fix needed; include metadata in future review packets.
- Shared mutable goalReviewEngines default: confirmed by failing
  remaining-settings-alias-red, hash
  96d9c318fa41227cd2bb39898c7c9627b0bc846f763d0e8f07003ca759bdf966.
  Core now copies the generated array at its compatibility boundary. Mutation
  isolation test passes; no public default or type change.
- Added exact per-registration schema checks, every-field invalid values,
  explicit false/zero/string arrays, retained unknown data, array snapshot
  isolation/freeze and cross-package duplicate ownership rejection.

remaining-settings-controls passed (hash
ab7b208d7c52e5bd8115b6d0777fbea12de3a9bf10726e68886b789b23ca9c51).
Full run remaining-settings-owner-qualified is now active. It includes the full
repository and package gates, historical config parity, seven CLI subprocesses,
the built Forge probe, and four built registration/settings-boundary probes.
The latter intentionally replace command effects with a recorder; they do not
claim to run provider workflows. Do not change this source while the gate runs.
No commit yet; review corrections are unstaged after the frozen review tree.

## Full-suite finding

remaining-settings-owner-qualified failed at one existing Cesar route expectation:
8,539 tests passed, one failed, six skipped. Build, types, lint, API and package
checks completed successfully first. The test expected exactly {selected:true},
but Agent now supplies its owned default cesarAgenticContinuationLimit:12.
Trace: Agent schema -> registry resolveRegisteredModSettings -> injected engine.
Updated the exact expected config object to include 12, not a loose matcher;
foreign-owner settings must still be absent. No production source changed.
Failed run log hash 9a7766d8ddf61b8fcdb4c422732adef5b1880a7a6523d4087f51932748e2c77e.

remaining-settings-route-fixed passed focused surfaces/settings tests, all 121
historical type/default/order checks, and four built registration probes; hash
3ddabee08b247662dfc6d4b8663e75f36b4a245bfb2c2c673d7b8ebdfa7cf921.
The v2 full verification reruns types, lint, all other gates, the complete suite
and runtime probes. It reuses the successful production build because the only
subsequent change is this test expectation. No failure is waived or hidden.
The additional existing surface-test file makes the final scope 19 files.

## Qualified increment

Commit 257fb2dfd774526764e98378401f8bb7c7d861e8, tree
06736b7fd0b016e172d7fefb9b84d50db208bf18. Nineteen explicit files committed.
remaining-settings-owner-qualified-v2 passed in 171.730 seconds; log hash
60fda858bc4a30d7c4ed10077ecd9cde7bb59e6110925b360c4ac9b3057d33ef.
Repository suite: 8,540 passed, six skipped. Types, lint, reexports, public API,
generator drift, release/supply-chain gates and self-tests passed. Production
build passed in the preserved preceding run; only the test expectation changed
between it and this rerun. All runtime probes passed; zero provider launches.

All 121 public fields derive from assigned owner definitions. Historical optional
types, defaults and property order compare exactly with fb77dc97. This does not
claim that legacy flat values already bridge to canonical mod namespaces or that
versioned config migration is connected to lifecycle and rollback.

Generated package changes were exactly Review, Agent, Mutate and Synthesis plus
the CLI launcher. Candidate ref/index advanced without touching its working files.
Before/after 281-path preservation checks passed; qualification checkout is clean.
No push, install, active/global Agon change or personal-state mutation.
