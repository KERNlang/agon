# Remaining ownership source checks

## Current-state correction at 9b523a34

The caa97b71 observations below remain historical evidence, not current status.
Source rechecked during the TUI asset-resolution increment:

- Ratings maintenance is consolidated at the physical mod (7394158e). Core's
  ratings-maintenance file is now a synchronous public compatibility binding.
  Core glicko exports the mod's algorithms rather than implementing another copy.
- perf:modular-release and test:modular-load now exist in package.json:95-96.
  Earlier missing-gate findings below are superseded; existence is not acceptance
  of the latest subject or every platform. Retain failed historical measurements.
- Plan's CLI coordinator effect adapter remains explicitly temporary at
  cli/src/signals/dispatch/plan-execution.ts:130. Its domain coordinator is imported
  from mod-plan; closure requires consumer/host retirement, not a comment edit.
- Brainstorm's Core host capability adapter is still live in CLI and MCP. Its
  configuration dependency still resolves to Core's implementation. Ratings and
  classifier bodies have physical owners; do not repeat their original findings.
- Model-probe asset resolution moved to its runtime owner in 7cb51822, with actual
  isolated tarball-load and missing-file controls. Doctor history resolution now
  uses the persistence execution owner in 9b523a34, with false-success and
  false-failure controls. Neither change deletes the legacy asset copies.
- The last committed full repository receipt is doctor-sidecar-owner-qualified:
  8,455 tests pass, six skipped. Full ownership, rendering and clean-release
  acceptance remain unproven. TUI script consumer migration is currently under
  verification; see tui-probe-owner-scope.md, not a whole-release claim.

### Follow-up at f11c6602

TUI path migration is committed; latest full suite is 8,458 passing with six
skips. Rendering remains unverified, and no copied asset was removed.

Current roadmap contradiction is confirmed, not inferred: its Markdown still
labels durable host/state/profiles "specified only", while the JSON C04 already
says implemented and names actual sources. JSON C05 still says only API/kernel
target directories exist; actual release packing includes all 49. JSON C03 still
describes 148 edges/four duplicates/144 corrected edges, while current package map
contains 49 packages and 151 declared edges. These historical claims cannot remain
labelled current truth. Update claim status/evidence without changing exit criteria.

post-tui-owner-architecture passed on f11c6602 in 0.844 seconds, SHA-256:
6759805968b40037d147b337325a232c77398cbce19278d65e09d2213970a29e.
It verifies roadmap/source coverage, kill-list source ownership, support-boundary
negative controls, asset parity, kill-list patterns and migration-ledger drift.
It DOES NOT prove those claim sentences: verify-modular-agon-roadmap.mjs:57 only
checks state vocabulary and nonempty evidence arrays. Passing that gate alongside
the contradicted claims is a coverage limitation, not whole-project acceptance.

Read-only check on caa97b71 with frozen outcome-contract staged tree
8bd89abe5769be371d8adcba6e2e9726e9a18237 (2026-10-11).
This supplements the original roadmap; it does not add product requirements.

## Confirmed unfinished owners

- `packages/core/src/signals/ratings-maintenance.ts` still implements collection,
  pruning, run selection, backups and ratings writes. The frozen ownership map
  assigns this exact state-store module and ratings.json to mod-ratings.
- `packages/mod-ratings/src/implementation.ts` independently implements those
  operations. The implementations already differ: current modular purge reports
  only successfully moved runs and propagates non-ENOENT move failures, while
  legacy purge swallows every move failure. Preserve the safer verified behavior.
- Live source consumers of the legacy API: Core's public barrel and
  `packages/cli/src/commands/ratings.ts`. Tests in `tests/unit/ratings-purge.test.ts`
  exercise legacy semantics. Trace CLI generated dispatch before deleting the old
  command; a source import alone is not proof of production reachability.
- `packages/core/src/blocks/brainstorm-host.ts` remains the documented
  A06-HOST-CAPABILITIES/KL-011 adapter. CLI and MCP first-party-services both
  construct it. Its rating operations still import Core glicko. Registry itself
  is a support-engine-catalog class wrapped in Core to inject Glicko lookup.
- `packages/cli/src/signals/dispatch/plan-execution.ts` still contains an explicit
  temporary coordinator effect adapter. Most domain policy is now in mod-plan,
  but removal needs final host composition and preserved entrypoint consumers.

## Existing coverage and migration constraints

Ratings already has protected-engine and provider-isolation tests from earlier
remediation. Consolidate behind one physical owner; do not reintroduce a second
purge implementation or broaden what can be removed. Never exercise real ratings
or histories. Keep exact old public API compatibility until callers migrate.

Do not move Glicko into a user mod by assumption: the present inventory names
ratings-maintenance, not all Glicko consumers. Its ranking/lineage consumers in
Core teams, role specialization, registry and workflow hosts need explicit
support-versus-toggleable ownership before extraction. User-facing disabling
ratings must not silently break unrelated model selection.

## Documentation truth

`docs/specs/modular-agon-acceptance-roadmap.md` still calls durable host, physical
extraction and generated runtime specified-only. This is historical prose, not
current verified status. The S5 ledger's generic adapter text is historical too.
Reconcile these at final qualification against the actual accepted subject.
No whole-release success can be inferred from their current counts or passing
structural verifiers. Do not alter scope or claim the remaining owner is retired
just by changing its comment.

## Release performance follow-up at 01c5dab0

After the platform-checker repair, executed the existing S1A performance gate
unchanged, with isolated state, provider blockers and --no-write. No installs.
First run (`release-performance-existing-s1a`) failed cold-start: --version
p95 187.466 ms versus the frozen 185 ms budget; --help p95 172.481 ms. RSS,
resolver, package and TUI budgets passed. TUI p95 8.02 ms versus 12 ms.
Log SHA-256 `bc2950ac6a741ded60057e2b77f95795054ce0bfdfe77065030fb706dc6409c1`.

One unchanged repeat (`release-performance-existing-s1a-repeat`) passed in
15.821 seconds. SHA-256
`e88809e32d3118ff0ab97adf694266fc4f617d6cb1612a6dacfc36b0be17ff5d`.
Both receipts remain evidence; do not erase the first failure or claim a fixed
regression from the repeat. Need measurement margin/source attribution before
changing startup code or deciding final release performance is qualified.

The existing gate measures 15 cold starts per command and five RSS samples;
the reported p95 at n=15 is the maximum observation. Source inspection shows
CLI statically imports Core loadConfig/loadAllAuthKeys and surface authority,
and calls loadAllAuthKeys before command parsing. These are investigation
locations, not yet proven causes. Never optimize by bypassing disabled-mod or
selected-generation enforcement. perf:modular-release and test:modular-load
remain missing; compose existing measured gates where applicable, but do not
substitute unit-test totals for sustained-host/concurrent-workflow measurements.

## Current correction at 77d6b300

The preceding historical missing-gate and ratings-owner statements are no longer
current. Source recheck: package.json defines `perf:modular-release` and
`test:modular-load` (lines 95-96), backed by their measurement scripts. Core
ratings-maintenance now delegates to mod-ratings, retaining public API and codec
injection only. Do not reimplement or re-extract these completed owners.

Configuration storage is Kernel-owned; 112 of 121 field declarations/defaults
are in their assigned Kernel/support packages. Nine user-mod fields remain in
Core. CLI/MCP/Cesar invocation constructors currently give mods empty settings;
TUI constructors give the entire host config. A bounded TUI owner-namespace fix
is in progress, with review findings still to repair. Full runtime configuration
transport, per-owner schema/defaults/migrations and host-adapter retirement
remain incomplete. See mod-settings-host-gap.md and tui-settings-boundary-scope.md.
