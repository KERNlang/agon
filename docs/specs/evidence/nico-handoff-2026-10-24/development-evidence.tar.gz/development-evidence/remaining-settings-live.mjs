import assert from 'node:assert/strict';
import { ModRegistry } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const expectedOwners = {
  review: { autoReviewAfterImpl: true, goalReviewEngines: [] },
  agent: { cesarAgenticContinuationLimit: 12 },
  mutate: { cesarMutateReflex: true },
  synthesis: { forgeEnableSynthesis: false, forgeSynthesisTimeout: 300, skillSynthesisThreshold: 3 },
};
for (const [name, expected] of Object.entries(expectedOwners)) {
  const { MANIFEST, createMod } = await import(`/Users/ra/dev/agon-audit-qualification/packages/mod-${name}/dist/index.js`);
  const owner = { id: MANIFEST.id, version: MANIFEST.version, contentHash: `sha256:${'a'.repeat(64)}` };
  const registry = new ModRegistry({ generation: 'built-owner-settings', activeOwners: [owner] });
  const session = registry.beginRegistration(MANIFEST);
  const observed = [];
  // Probe the real registration/config boundary, not provider workflow behavior.
  const registrar = { ...session.registrar, command(surface, contribution) {
    return session.registrar.command(surface, { ...contribution, run(_input, context) {
      observed.push(context.config);
      return { exitCode: 0, result: context.config };
    } });
  } };
  const mod = await createMod(new Proxy({}, { get() { throw new Error('unexpected host effect'); } }));
  await mod.activate(registrar);
  session.commit();
  const record = [...registry.project('cli').entries, ...registry.project('tui').entries].find(entry => entry.kind === 'cli-command' || entry.kind === 'tui-action');
  assert.ok(record, name);
  const context = { invocationId: name, cwd: process.cwd(), platform: 'darwin-arm64', signal: new AbortController().signal, config: {} };
  record.payload.run({}, context);
  assert.deepEqual(observed[0], expected);
  const explicit = Object.fromEntries(Object.entries(expected).map(([key, value]) => [key, Array.isArray(value) ? ['fixture-engine'] : typeof value === 'boolean' ? false : 0]));
  record.payload.run({}, { ...context, config: explicit });
  assert.deepEqual(observed[1], explicit);
  for (const key of Object.keys(expected)) {
    assert.throws(() => record.payload.run({}, { ...context, config: { [key]: null } }), /mod settings/);
  }
  assert.equal(observed.length, 2);
  await registry.disposeOwner(owner.id);
  assert.throws(() => record.payload.run({}, context), /unavailable/);
}
console.log(JSON.stringify({ passed: true, builtRegistrationOwners: Object.keys(expectedOwners), defaults: true, explicitValues: true, invalidRejected: true, disposedRejected: true, hostEffects: 0, providerWorkflowsExercised: false }));
