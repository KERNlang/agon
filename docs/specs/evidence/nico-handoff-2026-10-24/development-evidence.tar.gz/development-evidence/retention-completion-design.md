# Complete retention without a second lifecycle manager

Status: building within the authorized six-stage implementation goal. Inventory
and rollback-window inspection committed; collection and retirement remain open.
Date: 2026-10-16. Source: agon-audit-qualification@6c60fab2.
No destructive behavior has been implemented from this document.

## Binding need

The original readiness spec, lines 189-195, requires protection for running jobs,
rollback windows and explicitly reproducible artifacts. Under quota pressure,
unleased caches precede unleased generations outside the window. Required bytes
are reported, never silently removed. Migration spec lines 405-407 preserves the
previous selectable generation and failure/rollback receipts.

No numeric retention duration or quota was frozen. Supply explicit policy inputs;
absence of policy retains everything. This preserves defaults without claiming
that conservative retention alone implements quota handling.

## Verified current owners

- lifecycle-recovery.ts: ManagedRetentionInspector performs one validated scan
  under lifecycle then generation writer fences. Report includes generation,
  installation, storage and process/artifact reference bytes.
- generation-leases.ts: process and artifact mutations use the generation fence.
  Process age alone does not prove death. Existing explicit artifact marking is
  sufficient; automatic attachment of every workflow output is not required.
- managed-lifecycle.ts: owns installation staging, qualified immutable prefixes
  and installation transaction history. host-rollback.ts owns generation rollback.
- durable-host.ts: recovery may need generation files to repair a missing receipt.
  Generation ID allocation scans both directories and historical journals.
- candidate-process.ts:121-147: default npm cache is below a temporary candidate
  home and removed in finally. Caller-supplied cacheDirectory is not owned by that
  function. setup.ts:132 passes --cache verbatim after resolving its path.
  Therefore external npm caches must not become implicit collection targets.
- applyManagedPurge already binds exact paths and selected generation to a plan
  hash, revalidates references under both fences and journals quarantine phases.
  Its rejection of kernel-managed paths must remain intact.

## Proposed contract

Extend the existing lifecycle owner, not a generic GC service. Begin with an
explicit preview and apply API plus matching mod CLI entrypoints. Neither boot
nor startup may silently trigger deletion.

Policy contains an explicit rollback protection duration and logical-byte quota.
Validate finite nonnegative safe integers; no fallback duration or byte count.
Report the accounting scope: managed regular-file logical bytes, not disk blocks.
Never promise a specific number of freed filesystem blocks.

Rollback protection derives from committed selection transactions: each successful
selection protects its base generation for the requested duration from selection.
Repeated selection extends protection; a rollback must also protect the generation
it leaves. Historical journals retain this evidence. Malformed or unfinished
selection history blocks collection. Clock rollback conservatively keeps protection.
Whether duration shortening needs a separate explicit approval is a design question
for the critic, not an assumed permission.

Preview includes policy, observation time, selected pointer identity, lease/reference
identities, protected generations and reasons, ordered eligible targets, measured
bytes and any unsatisfied quota. Selected generation is always protected.
Shared installation bytes count once and become eligible only after their last
retained generation reference disappears. No released lease file is itself proof
that other references are absent.

Before apply, clone and validate the plan and require its exact hash approval.
Under lifecycle then generation fences, re-read selection, journal terminal state,
leases and target identities. An added lease or changed selected generation makes
the preview stale. Never broaden the approved target set during revalidation.
Persist quarantine progress and terminal evidence before final removal. Retry
uses the original plan; it does not reinterpret reused original paths as old bytes.

## Cache scope and ordering

Default candidate npm caches are transient and already removed. Supplied external
caches, local package tarball sources and offline stores are not automatically
owned or disposable. Do not scan or delete them by convention or path spelling.
Trace remaining mod cache owners before freezing the cache target inventory.
Staging directories and transaction evidence are not caches merely because they
look temporary. If no managed eligible caches exist, the first tier is empty;
state that explicitly rather than claiming external caches were collected.

## Recovery prerequisite

Do not remove a generation while host recovery can still require it. Candidate
eligibility requires all transactions referencing it to be terminal and bound to
valid receipts, and no pending snapshot restoration or cleanup.

Proposed durable retirement record binds generation ID, manifest/lock identity,
original transaction identities, approved collection plan and quarantine state.
Preserve enough terminal evidence for recovery to distinguish deliberate removal
from corruption. Keep historical allocation journals and original receipts.
Recovery must not skip arbitrary missing generations simply because a filename
resembles a retirement record. A corrupt retirement record fails closed.

Critical design question: reuse the existing host transaction journal's
garbage-collect operation or extend lifecycle purge journal with typed generation
targets? Compare recovery coupling and migration cost before implementing either.
Do not create a third journal protocol. Ordinary data purge stays unchanged.

## Blast radius and tests

Expected owners: lifecycle-recovery, durable-host recovery, host contracts,
host-rollback selection evidence, public kernel exports and mod CLI. Existing
retention, recovery and CLI tests provide fixtures. Cache owner trace may change
this list; freeze exact paths before code. No new package or dependency.

Required discriminating cases from current flows:
- two committed generations: prior protected during the window, eligible after;
- rollback then forward selection: both selection timestamps respected;
- process/artifact lease added after preview prevents retirement;
- two generations share one installation: first retirement preserves payload;
- unresolved cleanup/missing receipt blocks retirement without touching bytes;
- killed collector before and after quarantine: recovery/retry is deterministic;
- corrupt retirement evidence does not hide missing generation corruption;
- boot after collection, create next generation, rollback to protected generation;
- insufficient quota reports required bytes and does not remove protected data;
- eligible cache targets precede generations; external --cache remains untouched;
- existing exact-purge rejection of generation paths remains a negative control.

## Alternatives and restraint

Keeping everything forever is safe but does not meet the original quota requirement.
Deleting directories from inspector output is small but breaks recovery and races
leases. A separate daemon/GC registry adds ownership and scheduling not requested.
Prefer explicit collection through the existing lifecycle protocol, with retirement
understood by its existing recovery owner. The critic must challenge this choice.

Completion means actual collection, crash recovery, rollback and installed CLI
checks pass. A preview-only change or a green inventory test is not completion.

## Independent challenge adjudication, 2026-10-16

Agon Codex review completed exit0. Packet SHA256
f604d2b47f1f42691e77def2a14b6634bf0e6c9fd90b3201790391b28385d18e;
review log SHA256
28c01213d3979e88e76938c86fcfd977dc5f9158def9b45526d09cc01cf3f9f7.
Review is design evidence, not implementation acceptance.

1. REJECT requirement expansion: keep previous generation forever. The original
   migration clause says exactly: "Keep the prior generation immediately
   selectable until the rollback window closes." No indefinite predecessor pin
   is required. The two-generation expiry test remains valid.
2. ACCEPT timestamp distinction. host-rollback.ts publishes pointer.selectedAt
   before the later terminal journal.updatedAt. Host recovery may synthesize a
   pointer from updatedAt. Terminal time is not exact selection time. Preserve
   exact selection evidence where available; uncertain legacy timing retains the
   affected target. An elapsed time below zero cannot authorize collection.
   Do not claim arbitrary wall-clock jumps can be detected without more evidence.
3. ACCEPT receipt-loss-after-retirement case. durable-host.ts:590-611 repairs a
   missing terminal receipt by validating generation bytes. Store sufficient
   original terminal journal/pointer data in retirement evidence before removing
   bytes. A hash alone cannot reconstruct these data. Recovery must validate the
   binding, not skip missing retired generations.
4. SELECT typed lifecycle purge journal extension. Source search for garbage-collect
   found only the operation union and schema set, not a collector. Existing host
   replay infers historical commits from all baseGeneration values; GC selection
   journals would need unrelated replay special cases. Reuse purge quarantine,
   approval and fence semantics, with a versioned typed retention variant. Keep
   version-2 ordinary purge intact. Generation targets derive paths from IDs,
   never by allowing kernel paths in dataPaths.
5. ACCEPT self-contained replay evidence and crash point. Existing purge journal
   has only planHash and positional phases; retention needs the approved typed
   plan and repair evidence persisted. Per target: durable intent, quarantine
   rename, sync both parents, durable staged marker, physical removal, removed
   marker. Staged means logically retired; deletion is retryable cleanup. Missing
   both source and quarantine before that marker is corruption, not an absent
   success. An original-path replacement is not covered by old approval.
6. ACCEPT recovery ordering gap. lifecycle-recovery.ts:145 calls host recovery
   before installation inspection. Pending retirement reconciliation must occur
   before missing-generation receipt reconstruction. Direct host.boot/recovery
   must also recognize unresolved retirement; CLI-only recovery is insufficient.
   Startup may recognize previously approved retirement but cannot initiate a
   new collection plan. Do not introduce implicit deletion during startup.
7. ACCEPT accounting clarification. Inspector storage includes generations;
   per-generation bytes are its breakdown, not another total. Use disjoint quota
   terms and name exclusions. Quarantined bytes count until physically removed.
   Shared installations count once. Remove only enough eligible targets to meet
   the approved quota; report any protected shortfall.

Additional verified cache trace: model metadata in AGON_HOME/cache has a stale
offline fallback; session tool caches under AGON_HOME/sessions contain context
referenced by persisted history. Neither owner currently uses kernel generation
fences for cache mutations. Do not call them unleased solely because the kernel
lease list is empty. Explicit cache owner integration remains necessary where
those caches enter quota scope. External npm cache stays outside that scope.

Pre-change baseline: retention-collection-baseline, four existing suites,211
tests passed,36.637s,zero provider launches. Log SHA256
3010dfbf7be2929387b2afc220c448f460c805513ce4bf1a03aeee2ff5dbd2de.
No production source changed while collecting this design evidence.

## Recovery contract refinement, 2026-10-16

Verified against 1ea5fdf2ee8df7121ee514bf8073efeec9db11fd. This section
refines the approved retention work; it does not authorize new product scope.

### Two validation paths, not a permissive replacement

`DurableModHost.validateGeneration` must continue to mean that executable
generation bytes exist and validate. Do not make it return a retired manifest.
The function also authorizes rollback (`host-rollback.ts:35`), process leases
(`generation-leases.ts:190`), artifact leases (`generation-leases.ts:266`), and
boot fallback (`durable-host.ts:686`). A metadata-only success there could revive
a deleted generation or permit a lease on absent bytes.

Historical receipt repair and rollback-window history need a separate internal
read path for preserved identity. That path accepts only a validated retention
journal whose target reached `staged` or `removed`. It returns historical data,
never a bootable generation or an execution capability. Reuse host-contracts
parsers and canonical hashes; do not create a second set of manifest rules.

### Typed journal and identity binding

Extend the purge journal format, not the host selection journal. Leave ordinary
purge's current version and target validation unchanged. The retention variant
contains its complete approved plan, plan hash, and per-target phase/evidence.
The plan names generation IDs and installation IDs, not caller-selected paths.
Paths derive from these IDs and the existing host root.

For each generation target preserve the validated manifest and each original
terminal selection receipt for that generation, including its complete parsed
journal, pointer, and optional predecessor pointer. Bind these records into the
approved plan hash. This must cover rollbacks selecting that generation, not
only the creation transaction named in its manifest. At apply, compare every
captured journal with the current journal bytes after parsing. A new transaction
or changed journal invalidates the preview before any target is renamed.

Receipts are recovery evidence, not substitutes for pre-removal file validation.
Validate actual contents before first retirement. After retirement, require the
preserved manifest content hash, pointer graph/lock identity, candidate generation,
transaction ID, complete terminal journal, and successful cleanup step to agree.
Missing/corrupt preserved evidence produces a typed recovery failure. Do not
silently skip the historical transaction.

### Crash-state matrix

| Recorded phase | Original path | Quarantine | Required behavior |
| --- | --- | --- | --- |
| pending | present | absent | Revalidate approval, current selection, leases and identity before rename. |
| pending | absent | present | Validate captured identity, sync both parents, persist staged; no new target selection. |
| pending | absent | absent | Fail as corruption. Unlike ordinary purge, absence is not success. |
| pending | present | present | Refuse ambiguity; never delete either path by guessing. |
| staged | absent | present | Historical retirement is effective; explicit retry may remove quarantine. |
| staged | absent | absent | Retry sync and removed marker after an interrupted physical removal. |
| staged | present | either | Never touch the replacement original; report conflict for that namespace. |
| removed | absent | absent | Idempotent success; preserved historical evidence remains readable. |
| removed | either | present | Refuse unexpected quarantine bytes; old approval cannot cover a replacement. |

An interrupted rename must be reconciled before historical receipt repair.
Native macOS baseline confirmed EACCES when renaming the immutable generation
root (0555), despite writable source/destination parents. Existing fixtures also
chmod the root before rename. Collector intent must be durable before making the
root writable for quarantine; keep payload files immutable until staged. On a
pre-rename failure, restore the original root mode, retaining any cleanup failure
in the reported error. Retry must handle interruption after chmod but before rename.
Direct host recovery takes only the generation fence. It must not acquire the
lifecycle fence afterward: that reverses lifecycle apply's lock order. Reading
or reconciling the approved generation retirement under the generation fence is
safe only if every collector mutation also holds that fence. No new collection
or physical deletion occurs in boot recovery.

### Installation replay dependency

`recoverManagedLifecycle` currently recovers host journals before scanning
installation journals, then uses retained-generation references to infer whether
a nonterminal installation was committed (`lifecycle-recovery.ts:145-184`).
Therefore collection must reject a target installation or its last generation
while a referencing installation journal is nonterminal. Otherwise deleting the
last generation can turn an interrupted successful install into apparent failure.
Preserve terminal installation receipts and journals after payload removal.

### Next implementation boundary and verification

Implement the typed retirement protocol and historical recovery together with
actual explicit collection, not a public unused schema. Keep CLI projection in
the same completed concern, or test the callable kernel operation before adding
CLI in the next verified increment. Primary owners: lifecycle-recovery.ts,
durable-host.ts, host-contracts.ts, index.ts and commands/mod.ts. Existing test
owners: modular-purge-retention.test.ts, modular-lifecycle-recovery.test.ts and
modular-first-party-cli-recovery.test.ts. Add no package or dependency.

Required negative controls in addition to the earlier list:
- A retired historical identity cannot pass validateGeneration, acquire a new
  process/artifact lease, become a rollback target, or enter boot fallback.
- Loss of a terminal receipt after collection repairs from preserved evidence;
  changing the captured journal operation, steps, lock or pointer makes it fail.
- A rollback receipt and creation receipt for the same retired generation both
  remain repairable. Preserve predecessor links for subsequent window reports.
- A pending installation journal prevents collection of its last reference.
- At each phase boundary, simulate interruption and run direct host boot plus
  managed lifecycle recovery; original replacement bytes remain untouched.
- Repeated recovery does not create a new generation, change selected state,
  start physical collection, or remove the historical allocation journals.

Open implementation evidence: all cases above. This document is not a passing
acceptance receipt. Managed cache ownership and disjoint quota accounting remain
part of the same retention requirement, not optional future work.

## Implementation and review checkpoint, 2026-10-16

Worktree remains uncommitted on 1ea5fdf2. Implemented a generation-only explicit
preview/apply operation with version-3 plans and version-2 typed purge journals.
No new package. The internal generation-retirement.ts file shares retirement
parsing/history between host recovery and lifecycle collection; executable
generation validation remains the existing owner. Quota selection, installation
payload collection, cache ordering and CLI projection remain unfinished.

Agon Codex protocol review: packet
7508b798ab8a90420d268d0b6b5fa7ae9a7ccf1350adcc689b2248af11e43940;
log 7e6b052f02cdda44802bc39058405840439bcb781f98d6ad6d45d7d121379861.

Adjudication:
1. Rejected scope expansion: prohibit all boot rollback cleanup. The restriction
   is no newly initiated retention collection on boot. Existing transaction
   rollback removes uncommitted staging as part of its already-authorized
   operation. Changing that behavior would change the original recovery contract.
2. Confirmed/reproduced overlapping pending plans. New plans must not claim a
   generation reserved by another persisted plan. Added the check under the
   existing generation writer fence in preview and apply.
3. Confirmed/reproduced stranded staged bytes when a later pending target gains
   a lease. Finish already-authorized staged cleanup before checking pending
   targets. Never let that authorize a new pending target.
4. Confirmed/reproduced a normal earlier restart-required receipt blocking a
   later recovered committed transaction. Preserve earlier receipts but capture
   only terminal-bound ones. An older restart-required snapshot may be skipped
   only after checking stable transaction identity and timestamp ordering.
5. Confirmed with a four-generation chain: an alternate valid terminal receipt
   can suppress receipt repair while missing the only predecessor link. Window
   inspection now falls back to validated preserved original receipt evidence.
   A first three-generation test did not reach the affected older generation;
   it was expanded, not counted as proof of the failure.
6. Confirmed/reproduced writable original root after failed permission restore.
   Rejected suggested removal of chmod: native macOS run already disproved it.
   Host recovery validates pending original contents and restores0555 under the
   generation fence. Inspection stays read-only. No payload deletion on boot.

Remaining local protocol checks before calling the operation complete:
- A selection change can leave untouched pending entries permanently stale.
  Provide explicit cancellation of those entries, bound to the same saved plan
  approval. It may finish staged cleanup but must not delete pending originals.
  Cancelled targets release reservations and require a new preview for removal.
- Reject executable use of a retired ID even if valid old bytes are copied back.
  This must be enforced at the shared execution validation boundary, not CLI only.
- Run broad crash/concurrency/permission cases, installed CLI and full gates.

These are implementation obligations, not user product decisions or blockers.

## Cache and quota consumer trace, 2026-10-17

Verified read-only while retention-collection-full-gate builds the frozen WIP.
Search: `rg -n 'cacheDirectory|cacheDir|cachePath|cacheRoot|/cache|.cache'
packages/mod-*/src packages/support-*/src --glob '*.ts'` followed by source reads.
This search is a locator, not proof that all persistent state was classified.

- support-engine-catalog/src/engine-registry.ts: binaryCacheFile names
  AGON_HOME/cache/binaries.json. loadBinaryDiskCache treats absence as an empty
  optimization; scanPathForBinary reconstructs from PATH without a provider.
  saveBinaryDiskCache uses PID temporary file plus rename, without the kernel
  writer fence. This is a plausible disposable cache, not yet a safe collector
  target. An owner-scoped collection action must account for concurrent writes.
- support-engine-catalog/src/cli-models-registry.ts: probedModelsCacheFile names
  individual cli-models-<engine>.json files. Removing one can trigger a new
  live CLI/TUI probe when models are next opened. Never classify deletion as
  zero-effect just because static fallback exists. Tests must block providers.
- support-persistence/src/paste-store.ts: paste-cache holds original pasted
  text, retrieved by content hash. Existing age cleanup is not evidence that
  arbitrary quota deletion preserves referenced prompts. Keep it protected
  unless reference ownership is established; do not sweep by directory name.
- support-persistence/src/session-store.ts: session toolCacheManifest points
  to full results. core/src/sessions/session-resume.ts:931 passes activeIds to
  pruneToolCache. That reference-aware owner, not absence of a kernel lease,
  determines whether tool-result bytes are unused.

The existing generation/installation report measures payload and staging, not
all journals, receipts, leases, saved approval plans or cache bytes. A quota
result must explicitly name its measured scope and separately account retained
evidence. Generation retirement duplicates original recovery evidence in the
saved plan and journal; removed-generation size alone is not net byte savings.
Do not print quota-achieved from that subtraction.

Existing installation deletion owner: applyManagedPurge. It rechecks retained
references under lifecycle then generation fences, quarantines, syncs and
replays typed phases. Generation retirement leaves an installation unreferenced
only when its last retained generation disappears. Reuse this deletion owner;
do not create an alternate installation remover. Composition must preserve exact
approved target identity and handle interruption between generation retirement
and installation cleanup. A new reference at that boundary must block payload
removal, even if the earlier quota preview counted it as reclaimable.

Still to resolve by source-backed design and review: complete cache/accounting
scope, owner-coordinated collection, disjoint net-byte accounting including new
evidence, and preview/apply composition. These are not marked implemented.

### Accounting implementation boundary

Continue on20899237. Preserve existing storage/installation fields and add an
explicit host-root accounting block. Enumerate root entries under the existing
lifecycle and generation fences. Reuse measured installation and staging totals;
measure every remaining root entry separately, including journals, receipts,
leases, pending-authority plans, pointer files and unknown retained data. Exclude
only the locks directory, explicitly named as coordination state. Unknown entries
remain protected, never collection candidates. External AGON_HOME caches and
caller-selected npm caches remain outside this named host-root scope; later
cache-owner integration must expose its own accounting rather than imply zero.

Use logical regular-file bytes, not allocated disk blocks. Reject symlinks,
special entries, unreadable/disappearing enumerated paths and unsafe totals.
Do not sum per-generation metadata again: storage already includes generations.
Do not sum shared installation bytes more than once. Add no collector or new
dependency in this boundary; existing CLI JSON projection exposes the report.

Source/consumer trace: rg for ManagedRetentionReport/totalStorageLogicalBytes
found lifecycle-recovery.ts, public index type reexport, and two existing tests;
CLI forwards inspector output. Changed code: existing lifecycle-recovery.ts;
tests: existing purge-retention and CLI recovery files. Runtime contract update
must state that truthful accounting is not quota selection or cache collection.
Baseline: full repository gate on20899237 passed9493 tests+types+lint+release gates.
Discriminating tests: known retained evidence bytes contribute exactly once,
unknown root data remains byte-identical, unsafe evidence scan fails closed,
and collection reports its new retirement evidence rather than promising that
generation directory removal alone lowers total usage.

### Accounting review writer trace

Agon Codex review packet247d5119, log33f6f57b, found static-tree arithmetic
sound but questioned concurrency. Source reconciliation:
- managed-lifecycle.ts:548 takes lifecycle-writer before transaction payload
  creation/promotion. lifecycle-recovery.ts collection/purge also takes both
  fences before quarantine mutations. Recovery creates empty top-level roots
  before its fence but writes/removes contents after admission. No verified
  legitimate writer adds purge-staging payload while inspector holds both fences.
  The proposed absent-prefix injected race does not yet prove a product defect.
- CLI commands/mod.ts:100 writePlan does not take either fence. It can add a
  pending-authority approval during scanning. Unknown retained root data also has
  no defined writer coordination. Therefore the expanded accounting is an
  observation across a scan, not a globally atomic snapshot of all host bytes.
  Do not expand the lock architecture merely to hide this distinction. Quota
  collection still needs its own exact target revalidation and final observation;
  concurrent auxiliary writes can leave the quota unmet and must be reported.
- Reviewer wording issue confirmed: counting regular files uses stat, not reads.
  Metadata/enumeration errors reject; unreadable contents alone need not reject.

Before commit: correct documentation to distinguish fenced lifecycle groups
from observed auxiliary data, prove metadata-only counting with denied content
reads, add aggregate-overflow controls. Do not silently drop quota requirements
or call the observation an atomic filesystem snapshot.

## Quota-to-cleanup transition proposal, f70c8d0d

Status: design under the already-authorized retention requirement, not a new
product scope. No numeric quota/window defaults. No automatic startup collector.

### Operator contract

Explicit quota preview takes logical-byte limit and rollback-window duration.
It names accounting roots, protected references, ordered exact targets, estimated
net savings (including evidence overhead), and any protected shortfall. Approval
binds the whole target set and policy. Apply never adds a target. A final fresh
observation reports actual remaining usage and unmet quota; no success based only
on projected bytes. Auxiliary concurrent writes can cause a remaining shortfall.
Below-quota preview is a non-destructive report, not an empty deletion plan.

Target order: proven disposable owned caches first, then expired/unleased
generation groups and their now-unreferenced installation payloads. An already
unreferenced installation is eligible only through existing purge checks. Unknown
host data, histories, receipts, sessions, pasted source, live jobs, selected or
window-protected generations and declared reproducible artifacts remain retained.
Shared installation bytes count once; deleting only one of its references does
not reclaim that payload. Selection order is deterministic, not a global packing
optimization. Stop once the observed quota is met; never broaden the approved set.

### Avoid a second deletion owner

Existing generation retirement owns receipt preservation and immutable-generation
quarantine. Existing applyManagedPurge owns installation payload deletion. Its
public preview currently rejects referenced payloads, correctly. The transition
must preserve this public behavior while allowing an approved conditional target
whose references are all scheduled for retirement.

Option A: extend the existing typed retention plan/journal with conditional
installation targets and persisted child purge plans. Reuse private under-fence
purge execution extracted from applyManagedPurge; its current public wrapper
still acquires the same fences and applies the same checks. Parent plan approval
binds the child target IDs/identity and hash before any generation is removed.
Only invoke payload removal after rechecking that no retained generation or
unfinished installation transaction needs it. Preserve child transaction IDs on
retry. This adds one typed plan variant but no independent deletion algorithm.

Option B: CLI sequences separately approved cache/generation/payload plans. This
needs less kernel integration, but cannot offer one quota approval with crash-
safe continuation across the reference transition unless it grows its own
coordinator. That would move lifecycle policy into CLI and duplicate state.
Prefer A provisionally; independent review must challenge the coupling and
whether existing saved plans can be composed without a new journal owner.

Do not weaken ordinary purge path guards. Do not synthesize a new target after
approval. If plan format changes, preserve parsing/replay of existing generation
collection plans; do not reinterpret old hashes or cancel terminal work.

### Cache boundary, not arbitrary path deletion

The only cache currently proven fully reconstructible without provider access is
support-engine-catalog's binaries.json. Its owner performs PATH scanning when
missing. Model probe caches can cause live subprocesses on refill; session/paste
caches contain source/context and are not generically disposable. The default
npm cache is transient and already removed; caller-selected caches are not owned.
No public Mod API cache contract exists in current source. Avoid inventing a
generic plugin cache framework just to collect this one known file.

An owner operation for binary-cache inspection/eviction can remain in the existing
engine-catalog package, composed by CLI with kernel retention. It must disclose
its own root and bytes separately from managed-host accounting. Cache writes are
atomic replacements and derived bytes are never required execution artifacts;
recreated files are not chased by retries. Need to settle durable approval/retry
composition with the critic before implementing. No live/personal cache touched
while developing: fixtures and isolated homes only.

### Required transition evidence

One approval, shared-payload groups, insufficient quota, evidence larger than
removed metadata, selected/window/process/artifact protection, new reference
between phases, interruption before/after child plan persistence and quarantine,
retry with replacement bytes, cancellation, no new targets on retry, recovery
without provider launches, and unchanged historical readers. No new dependencies
or test harness. Existing lifecycle fixtures, built CLI and fault injection apply.

### Independent challenge adjudication, f70c8d0d

Review: retention-quota-transition-codex-review.log, SHA-256
84cd74394749e6c2ff518e1df5d41676a1f51f21c09c1722ec04f9bbf45d4391.
This is design evidence, not implementation acceptance.

Source-verified requirements for the proposed composition:
- Existing generation plans require a selected pointer and nonempty targets
  (generation-retirement.ts parser). Keep their hashes and replay unchanged;
  quota needs a separate discriminant for cache-only and orphan-only attempts.
- Ordinary purge journals retain only hash/phases, not the plan. A parent must
  preserve complete child plans and IDs before effects. CLI writePlan is only
  approval transport; it has no durable execution phases or sync operation.
- captureRetirementEvidence checks unfinished installation journals. Ordinary
  purge does not. Conditional payload admission must reuse that protection,
  including orphan-only quota attempts, rather than assume purge supplies it.
- Binary-cache replacement has no serialization with deletion. A check followed
  by unlink can remove a replacement. Any approved cache operation must have
  an owner-scoped claim/serialization protocol; do not call the current rename
  writer sufficient. Kernel must not import engine-catalog internals.
- Historical retirement readers parse exact variants. Extending the journal
  requires corresponding readers and legacy fixtures in the same boundary.
- Pending-plan reads enforce 256 KiB while writes do not. The quota preview
  must reject an oversized approval document before saving unusable authority.

Selected design constraints (not extra product requirements): preserve child
owners, persist terminal stop/cancel/exhaustion, and never reactivate unused
targets when later usage grows. Account for retained evidence overhead and
report final measured usage; an estimate cannot prove quota success. A missing
or replaced cache is not permission to chase a new file. Review's suggested
one-attempt cache policy is conservative but still requires an owner protocol;
implementation must prove it rather than add generic cache management.

Prerequisite found while tracing payload cleanup: real installed prefixes are
0555 (managed-lifecycle.ts freezePrefix); macOS rejects their quarantine rename.
Existing public purge failed EACCES after the last reference retired. Correct
that existing owner before composing it. Apply rejects an already-existing
installation destination, so interruption cannot silently reuse a writable old
prefix as a new qualified install. Preserve the selected payload throughout.

### Existing cache serialization seam located

No new lock implementation or support-package dependency is necessary for the
binary cache. The catalog already declares the kernel as a peer dependency.
Kernel publicly exports withSynchronousWriterFence (index.ts:140), which uses
the same WriterFence record and exclusion protocol as asynchronous writers.
The catalog's existing saveBinaryDiskCache is synchronous; its best-effort
fallback can retain that behavior while fencing only the replace operation.
The cache eviction owner can use the same cache-specific lock, not the global
generation/config writer lock. A busy cache writer means skip cache persistence,
not fail PATH resolution. Explicit eviction must report contention, not claim
zero bytes or removal. Stale-lock recovery must use the existing WriterFence
owner protocol; do not add a TTL-based second lock.

This seam preserves package direction: engine-catalog consumes kernel's public
machinery; kernel quota execution receives a bounded cache-owner capability,
never imports engine-catalog. Existing synchronous lock safety tests supply
negative controls for lost ownership and asynchronous callback misuse. Add
cache-specific behavior to the existing registry tests, including live writer
contention, dead-writer recovery, replacement identity, denied metadata and PATH
fallback. Measure lookup cost because durable fencing adds filesystem syncs.
This is an implementation route, not yet completed behavior or a new public
third-party cache framework.

### CLI composition readiness, source rechecked after quota API implementation

No CLI changes yet. `packages/cli/src/commands/mod.ts` already owns retention
subcommands and saved approval transport. Extend it, not a new command owner.
Add `quota-collection` to PendingPlan and call parseManagedQuotaPlan while
reading it. The kernel already budgets this exact schemaVersion2 envelope
against the CLI's256KiB pretty-JSON limit.

Preview requires explicit quota bytes and rollback-window milliseconds. Apply
and cancel require the saved path plus exact hash; reject replacement policy
flags. Reuse previewManagedQuotaCollection/applyManagedQuotaCollection. Print
observed logical bytes, quotaMet and shortfall separately from historical journal
state and estimates. A null plan must distinguish already-below-quota from no
net-beneficial eligible collection. Never claim physical disk savings.

Cache owner composition requires the pending CLI to existing engine-catalog
dependency approval. Do not import undeclared transitive packages or re-export
through Core to evade this boundary. Canonicalize the configured Agon home once
using catalog semantics (trimmed AGON_HOME, resolved absolute path, otherwise
homedir/.agon). Bind that explicit home to all three cache owner methods. A
separate AGON_MODULAR_HOST_ROOT does not relocate the catalog's cache. Missing
home/cache must not trigger creation during preview. Existing cache APIs require
a real home; retain no-cache behavior without swallowing permission/type errors.

Reuse built safe-mode CLI tests in modular-first-party-cli-recovery.test.ts:
cache-first collection, exact approval refusal, cancellation and terminal replay,
unmet protected quota, separate host/home, absent cache, changed cache identity,
malformed numeric inputs and replacement flags. Existing kernel process-death
tests remain authoritative for child transaction recovery; do not duplicate all
faults in CLI. Generate docs/release metadata only after the CLI source changes.
No new quota default, automatic startup collector or third-party cache API.
