# Review remediation evidence

Candidate: `/Users/ra/dev/agon-audit-remediation`, branch
`fix/modular-audit-remediation`, base commit
`2b59937ba55d21fbd9649cc6f2d64d423e58f59c` plus inherited and remediation WIP.
This is not a clean committed release receipt.

Latest verified local increment: `8a4f5c544ed9de4baf0387b403a9a2d21ca2e5be`.
Plan entry authority, resume workflow and execution callbacks are now in place;
the inherited callback error-reporting defect is fixed. Latest full suite:
7,596 passed, six skipped. Native receipts and peer adjudications are below.
Cached step admission and nested phase boundaries are now enforced.
Guarded backend entries and cooperative monitoring are now wired for panel,
Forge and delegation paths. The whole modular release is NOT accepted:
live-self/Review/Agent injection, other post-await effects and physical ownership,
historical-state compatibility, remaining retirements and final release gates
remain open. Active/global Agon unchanged; nothing pushed or installed.

## Verified changes

### In progress: API and tool execution authority foundation

Base `8a4f5c54`. Five source/test paths plus the generated migration ledger;
staged tree `21706d896f87660ab7a85f35dbd81e1d4913092e`.
Existing candidate draft reused: executionRefusal in ToolContext and API-agent
options, synchronous tool checks across asynchronous approvals/hooks, provider
entry/retry/return and final-result checks. Only undefined permits execution;
empty reasons and thrown checks refuse with generic non-secret diagnostics.
This is the shared foundation; session/team/Plan/live-Cesar wiring is not yet
qualified or claimed active. Candidate WIP was not overwritten.

`api-tool-authority-red`: 14 failing and four healthy tests before the guards,
log SHA-256 `bdde8b8a71032e55cbc4390bb6751577eb424a89792ff326b1104d134eb17668`.
Draft implementation passes the original 18 cases. Four further tests then
reproduced empty-reason bypass (`api-tool-authority-empty-red`), SHA-256
`44fbdb6397c8250ba6ed0a0f3424d845039f05c95659cf666e8bdc087d985f44`.
Corrected `api-tool-authority-focused` passes typecheck, independent support
package build and 23 cases, including actual temporary-file tool writes and
approval/hook pending-state tests. Log SHA-256:
`8f6498017858ddd3342307af6f30fa06d8d406c51304cc20f379ded2ac8e2152`.
No provider launches; API stream is stubbed.

Currently running: full `api-tool-authority-qualified` handle 8444; review
packet `api-tool-authority`, Codex handle 12767 and Kimi handle 56780. Poll
these exact handles; do not mutate the frozen subject or start duplicate runs.
No commit yet. Reconcile review, consider the existing candidate mutation
harness (it assumes six tests and needs explicit adaptation for eight), then
final verification and local commit. Do not install or push.

### Step result boundaries (verified local increment)

Base `52d32a43`, staged tree `7e385e6c63a01736d7597f1ffd3ab3f0481eb933`.
Five existing authority checks added: after self fallback delegation, after
its verification command, and after Review, Agent and team Agent results.
The self fallback checks the Delegate owner, not merely Plan, before effects.
Live Cesar brain behavior and guarded adapter injection for Review/Agent are
still unfinished; this is not a claim that all step effects are closed.

`plan-remaining-return-red`: 12 new stale-success cases failed, four healthy
controls and 95 existing cases passed. Log SHA-256:
`e4241bfd5b2c7c13ce98366c25eadd524a1bd5d5e091d77b1ec358257fc6e0db`.
After the checks, `plan-remaining-return-focused` passes types and 116 tests.
Log SHA-256 `6b4ba11afe69451681a0880dd893bee4338adb08a9a03f5a6867480e96b5ee1b`.
The self matrix now also runs an actual verification subprocess creating a
temporary marker. Only the healthy case may create it; revoked, replaced and
cancelled cases do not. `plan-remaining-return-effects` passes 111 tests,
log SHA-256 `ba97fd991c0728c3bf74ed42c9c249527e235b41c18ebff05d3c1bf60386db2c`.
Model backends are stubs; no provider launches.

Running now: full `plan-remaining-return-qualified` handle 22784; isolated
default review packet `plan-remaining-return`, Codex handle 97542 and Kimi
handle 85708. Poll these; do not restart or edit their frozen subject.
No commit for this slice yet. Three staged files: CLI handler, admission tests,
generated migration ledger. Candidate working files remain untouched.

Qualification on the original staged tree passed in 329.194 seconds, including
full build, types, lint, drift, roadmap, full suite, native CLI checks and the
111-case admission replay. Log SHA-256:
`d767ec0253ecb6e8a9f2ee0925fd29d1eee23e77ea07597d4c4b4f020994f29a`.
Both reviews completed on packet SHA-256
`1fb52b07afce1ce41c370b56b78ab1953278586ba7979692b01f35b48c13ae4d`.
Codex log: `0a3bf96cd23c641e1cfa5780a3c33365f0dc01e29b6018ef431ec805e62e7c02`.
Kimi log: `a2d754e10947d3b8c4a8718909abf1102d6991f536ebb3741c6a8f4bd432745d`.

Codex correctly identified that the post-verification check needs its own
negative control. Three tests now pause the verification adapter, wait for
confirmed entry, change authority/cancel, then release a successful result.
The shared monitor is frozen. Normal verification calls still run the actual
process implementation; only these three pending calls are replaced.
`plan-remaining-return-postverify` is running under handle 1966. After it
passes, remove only the post-verification check temporarily and prove the
three cases fail, then restore it exactly. Final full test qualification and
commit remain pending. Earlier run/review handles are all terminal.

Other review claims: live Cesar and raw Review/Agent adapter gaps remain
explicitly unfinished, not claimed fixed. Kimi's self-owner bypass is not
supported by the generated catalog: `self` belongs to `agon.kernel`, cannot
be disabled as a mod, and generation/lifetime changes already fail the shared
check. The marker-isolation concern is refuted by per-test mkdtemp in beforeEach.
The old admission tests only exercised Review admission failure, not empty-diff
or engine selection; the new target/engine mocks did not displace those tests.
These tests prove returned-result boundaries, not provider interruption; do
not broaden that claim from their passing counts.

Review-required post-verification coverage now passes. The first added harness
run exposed a test-fixture bug: mock restoration cleared the default real
spawn implementation, so the healthy marker was absent. beforeEach now restores
the real implementation explicitly. No production change was needed.
`plan-remaining-return-postverify-isolated` passes all 114 admission cases;
log SHA-256 `0f3ed91052b22700f3b47d9e750d00b8fd87f5243aa2c3f6712cc7ec3b7019af`.
Removing only the assertion after `await runVerifyGate()` makes all three new
cases fail with stale success (`plan-remaining-return-postverify-mutant`).
Mutation log SHA-256:
`31e04bd7d61f6d2c257357da4b48c5dfa159fede43cc3f003a62836853b01f84`.
The production file is restored byte-identically to its reviewed index object
(empty unstaged production diff). No mutant remains.

Final staged tree `59c2e33820761d250e6a2ac446c6f96ae505aa75` adds only the
review-required test coverage to the already-built source. Final run
`plan-remaining-return-final` handle 29387 is active: types, lint, re-export,
drift, full tests, compiled CLI checks and 114 admission cases. All other
handles for this slice are terminal. After this run passes, verify WIP
preservation and commit the three explicit paths; no new review panel needed.

Final run completed in 169.785 seconds: 7,596 tests pass, six skipped, native
CLI checks pass, and all 114 admission cases pass again. Zero providers.
Log SHA-256 `99aeb540f66f48197391f90188b83b112e750c07db48ccecc430ece7318934d9`.
Commit `8a4f5c544ed9de4baf0387b403a9a2d21ca2e5be` matches the tested tree
`59c2e33820761d250e6a2ac446c6f96ae505aa75`; qualification checkout clean.
Candidate advanced by expected-old ref and index-only update; no working files
overwritten. Preservation check `plan-remaining-return-preserved` passes the
281-path baseline. All listed slice handles are terminal. Nothing pushed.

Important next-slice source correction: Agent does NOT dispatch through
`ctx.adapter`. `handlers/agent.ts` constructs core's compatibility AgentSession,
which injects `runApiAgentLoop` into the support-agent-runtime owner. The real
effect boundary is AgentSession/AgentTeam and the API/tool loop, not a context
adapter wrapper. Existing candidate WIP already threads `executionRefusal`
through these paths; inspect and qualify that code rather than invent a second
mechanism. Review DOES use `ctx.adapter`. Candidate Cesar brain WIP already
adds parentSignal and assertOwnerAvailable to the real brain loop. It includes
other cleanup changes, so isolate and verify each dependency before copying.
Both WIP areas remain unqualified; their presence is not acceptance evidence.

### Forge post-return boundary (verified local increment)

Based on `c954b188`, 12 new tests fail before the fix: Forge and team Forge,
each after generation change, host replacement or cancellation, with either a
winner or an already-satisfied result. Winner cases reach patch lookup after
authority is lost; no-op cases publish success. The monitor is held pending
so it cannot mask the missing post-return check. No real patch or provider is
executed by this reproduction. Existing 77 admission tests still pass.
Red log SHA-256:
`838d7a63e77b259632857e25bbdca5c1e71bbc7966d9e9c0329ea7f53014a280`.
Two existing `assertStepAvailable` calls now follow the backend awaits, before
patch lookup, usage publication or no-op success. Focused run
`plan-forge-return-focused` passed; log SHA-256
`2c4555966122bcf12a071bc55f4074d56c95761535093e2746bc987bbe182a18`.
Six further cases use actual `git apply` in fresh temporary Git workspaces:
Forge/teamforge healthy paths change `before` to `after`; revoked-generation
and cancellation paths leave bytes unchanged. Source tests use the actual
patch backend, with only the model-producing backend stubbed. The session root
is reset in teardown. `plan-forge-return-real-patch` passes types and focused
tests; log SHA-256
`3186130f6f615f4b125e9c3ea2c71a4ae852faf73887fe810b924d8b8d0141d6`.

Staged subject `a91cf1e3a66089217590ddeaaebdd458d4d14e64` has three paths:
CLI handler (two lines), admission tests, regenerated migration ledger.
Backup ref: `backup/modular-before-forge-return-c954b188`.
Currently running: `plan-forge-return-qualified` handle 9971 (build, types,
lint, re-export guard, drift, roadmap, full tests, compiled CLI checks and
real-host/patch tests again); reviews `plan-forge-return` Codex handle 34048,
Kimi handle 69209. Poll these exact handles; do not start duplicate runs.
This fix is uncommitted. Source-verify review findings, finish qualification,
preserve candidate WIP, then commit. Production Forge must not be invoked in
these tests; model backend calls remain stubbed.

Both default reviews completed for packet SHA-256
`e16f8c0d00d3a1a3d2e2540b29c663db9747d96aa558d738bc824cd075eb214b`.
Codex log SHA-256 `5349f425f7102e922db645208f484f89145cc7135be4a99d0dfdd107228af42d`;
Kimi log SHA-256 `29d02a7d8996c56f05835317c70db0701ec2e9add2240957f5b4dc4bdd3858b8`.
Neither found a blocking defect in the two-line fix. Source verification:

- Existing catches retain metered usage; finally blocks clear progress timers.
  The outer authority monitor retains its own cleanup. Additional cleanup
  assertions are optional here; shared monitor cleanup already has tests.
- No stale patch access and no stale no-op success are tested. The stronger
  phrase "no manifest inspection" follows source placement, not the getter
  oracle alone. Do not overstate the getter test.
- Kimi's "no residual gap" claim is rejected: another process can change the
  pointer during synchronous patch handling. This fix checks authority after
  the asynchronous backend boundary; it is not a cross-process transaction
  or a sandbox. Existing admitted-operation semantics remain unchanged.
- Suggested retry classification is not a demonstrated token-spending defect:
  cached executor admission rejects stale hosts before any backend. Generic
  failed-step behavior and measured accounting are deliberately preserved.
  Typed terminal-plan propagation remains part of broader scheduler work,
  not a reason to invent a new status in this bounded fix.

Review handles 34048 and 69209 are terminal; qualification handle 9971 is
still running. Continue polling it without rebuilding or editing its subject.

Final update: handle 9971 completed successfully in 306.698 seconds.
7,577 tests passed, six skipped, seven compiled CLI provider/monitor checks,
14 compiled CLI admission checks, then 95 real-host admission/patch cases.
Zero provider launches. Full build, types, lint, re-export, drift and roadmap
gates pass. Receipt `plan-forge-return-qualified`, log SHA-256:
`1d22dd2d835a915bee103fbf505bd1a6d38c794ba23482aaba5e7c99df4433dc`.
Commit `52d32a4397b260d03d1964e8f478f3cc86eaed74` has exact tested tree
`a91cf1e3a66089217590ddeaaebdd458d4d14e64`; qualification checkout is clean.
Candidate advanced through expected-old ref/index updates only; working files
remain untouched. `plan-forge-return-preserved` confirms the 281-path baseline.
No push or install. All Forge slice run/review handles are now terminal.
Remaining next work: self/Review/Agent invocation and output authority, then
physical execution ownership extraction, historical-state compatibility and
the remaining roadmap acceptance dimensions. This is not release acceptance.

### Plan panel execution owner (verified local increment)

Commit `c954b188930c4c5de57b8eeecdf5bcf23e479872`, tree
`4df9aa3bc2f6df8e4662479be8dc2fd65e36eec4`, physically moves Brainstorm,
Tribunal, Campfire and Delegate step policy into mod-plan. CLI supplies guarded
backends, authority monitoring and metered usage. Both default reviews were
source-checked. Seven new regressions proved and fixed receiver binding and
pre-aborted direct-owner execution defects. Generator drift was corrected.
The exact pack allowlist passes. Review details and retained failed receipts:
[panel owner qualification](plan-panel-owner-progress.md).

Full build and gate pass (`plan-panel-owner-qualified`), followed by the final
test-only signal-identity/spy-isolation improvements and another full types,
lint, repository tests and native check run (`plan-panel-owner-final-tests`).
Final log SHA-256:
`afdb546aa2dfca493b0483c01303388bed8398c306fc18fe7a48eaee21a29474`.
7,559 tests passed, six skipped; seven compiled CLI provider/monitor cases,
14 compiled CLI admission cases and 36 compiled-owner parity cases passed.
Provider backends are stubs; zero live provider launches. This does not prove
live-provider interoperability or the unfinished release dimensions.

Qualification checkout is clean at the tested tree. Candidate branch advanced
without writing its working files; all future WIP remains. Candidate still
contains its older draft panel files as uncommitted differences; these are not
the qualified release subject and must be reconciled before final acceptance.
No push, installation or global-state change occurred.

### Panel post-return authority (verified local increment)

Base `ab58c538443dedf8a72c14d8dc17c71a30e730b1`. Four production lines add
the existing authority check after Brainstorm, Tribunal, Campfire and Delegate
return, inside their existing catches and before success/context publication.
No new API or wrapper. This is the behavior fix required before pure panel
ownership extraction, not a claim that all remaining step effects are guarded.

`plan-panel-return-red`: all 12 stale-output cases failed (four types × pointer
change, host replacement, caller cancellation), zero providers. Log SHA-256:
`5f91fc8dc8bb7c80a1e2a106fbaf3df89807ef62a04b3e990265657857375d81`.
`plan-panel-return-focused`: types and 78 tests pass, SHA-256
`2b82189e7530f51cdc0aecf3bf06586835847e9eb7853b8b0b286eaf21b58c95`.
Build passes in 151.612 seconds; log SHA-256
`a320ac0bed25005d73224295e3a2995a8c00404b01d9742db99146c889f44409`.

Default reviewers found no blocking defect in subject
`9a9919e319260c2ac46fc23b818e13fa40906846`; packet SHA-256
`c2a1bc4b2390d90f1dade80dfe747927e3a9ada4df33f7a573614c8b5397ab32`.
Test improvements verify exact nonzero token/cost deltas on rejection, stop
monitor intervals from firing so the post-return checks are independently
required, and pin healthy output/context formatting for all four types.
Production remained unchanged after review. Final indexed tree:
`f966e052f04052ffb5b4ce7acb222f1d66b0fca5`.
Full gate `plan-panel-return-final` passed in 147.528 seconds: types, lint,
re-export guard, generated ledger/roadmap, 7,506 tests (six skipped), seven
compiled-CLI provider/monitor scenarios, 14 compiled-CLI admission scenarios,
then 77 real-host admission/return tests again. Zero provider launches.
Log SHA-256 `c3c9447b6dde631c08b1fc7f75448f6c038ac7b54adb8a4f872eb877c5c15e58`.
Commit `841e27299dbf5c3eba8962d50ed111ab16a2fd4b` has the exact tested tree
above; qualification checkout clean. Candidate fast-forwarded without changing
future source files. `plan-panel-return-preserved` passes the 281-path baseline.

Confirmed remaining risks: Forge must recheck before patch application, not
merely before returning success; Review/Agent/self output boundaries remain
unfinished. Backend effects already performed cannot be undone by refusing
their returned text. Caller-side state consumption also needs its own authority
check at asynchronous boundaries. These are original acceptance work, not new
product requirements. The next parity oracle is frozen outside Git as
`plan-panel-baseline.ts`, copied from the indexed Git object above; it contains
the exact constructor/helpers and four panel branches, not rewritten policies.

### Plan provider guards (verified local increment)

Base `98c2b3d2c26c76a8ac183618f1bc7a4c8b112a02`. Four paths: process authority,
CLI executor bindings, existing admission tests, generated migration ledger.
One nonmutating adapter wrapper checks the captured host and selected owner
before six documented EngineAdapter methods. Optional methods remain absent
when the original lacks them. Generator delegation preserves yielded chunks,
return values and consumer cleanup. Legacy bootstrap keeps its adapter identity.
Plan execution reuses the existing cooperative monitor; it does not create a
second cancellation mechanism or modify the shared session adapter.

Seven direct backend-entry regressions failed in `plan-provider-guard-red`:
Brainstorm, Tribunal, Campfire, Delegate, self fallback, Forge and team Forge
all invoked a provider after revocation. Mock dispatches only, zero providers.
SHA-256 `ce8f373a89b253f2259323b121536b87557d38a559d1aad23b0274ec645c4f3e`.
The first focused runs then caught three classification regressions introduced
by cooperative cancellation: revoked authority was reported as user cancellation.
The tests stayed unchanged. Pipeline now recognizes the existing kernel
SurfaceGenerationError abort reason and reports failed authority separately.
`plan-provider-guard-status` passed types and 56 tests; SHA-256
`54afa15adbccbcee7cb80a2676d9462f749e971d60fc85ac634d89085d125e80`.

Default reviews: indexed subject `c5fb76cb0f7b75576a4e4047fc84b7e402c6aa7c`,
packet SHA-256 `ec957040a7cff167d6974c83535bde125322db5272a7443d3396552cee2d43ea`.
No confirmed new blocking defect. Review additions cover host disposal/restart,
stream return/throw cleanup, monitor interval/listener cleanup on all exits and
late provider dispatch in each nested phase. Production unchanged after review.

Adjudication:
- Streams are guarded at entry; subsequent chunks remain cooperative under the
  passed child signal. A noncooperative backend is not forcibly sandboxed or
  stopped by this wrapper. Do not claim per-chunk revocation enforcement.
- Kernel errors originate in the existing process-authority module, are passed
  unchanged as the AbortSignal reason, and use the same kernel import as the
  classification. No wrapping layer is in this path. Accepting arbitrary `MOD_`
  strings would broaden classification without evidence. Duplicate kernel
  release qualification remains a required gate, not something this unit proves.
- Consumer tracing finds only declared adapter dispatch/agent methods in the
  relevant Forge/Brainstorm/Tribunal/Campfire/Delegate backends. No duck-typed
  extended-property consumer was found. A Proxy would expose unguarded unknown
  effects, so the six-method public contract is intentionally retained.
- Each active step has one existing monitor, disposed in finally. Fan-out cost
  remains for load/performance qualification; no new shared monitor is invented.
- Disposal does not restore the bootstrap catalog. It leaves the selected
  generation whose physical registrations are removed by each mod disposer
  (`activated-surface-generation.ts` and `mod-plan/src/implementation.ts`).
  Captured calls reject replacement; fresh Plan construction checks the now
  unavailable Plan contribution. The alleged implicit bootstrap reset is not
  in source. Raw helper bootstrap passthrough is not a Plan execution bypass.

Build `plan-provider-guard-build` passed in 151.136 seconds, zero providers.
SHA-256 `bab91e8a19c7fb6d86c61bde32ab49520259c2b7382bc537dc6211ed4534685f`.
`plan-provider-guard-final` passed in 148.293 seconds: types, lint, re-export
guard, generated ledger and roadmap checks, 7,490 tests (six skips), two native
runs of seven compiled-CLI provider/monitor cases, 14 compiled-CLI admission
cases, then all 61 real-host admission/provider regressions again. Zero
provider launches. Log SHA-256:
`96d7bb345f02c6a2aaf5ba695ee09a813a3bcbcab98fe1d8bb1008e82d84475f`.
Native provider-probe SHA-256:
`d350523ec6e01f462cfc83b27f713747e60a1c4296511a2e43bd5c2103b39e13`.
Reused admission-probe SHA-256:
`73114fad807c64069fcf200ccc0bc72faa9444830781cd072f04f0dc47ef14d6`.
Commit `ab58c538443dedf8a72c14d8dc17c71a30e730b1`, tested tree
`b2c3aa1870831ef41cca8c6faa48f892aff58b82`. Qualification checkout clean.
Candidate fast-forwarded with expected-old-value check, no working-file reset.
Preservation receipt `plan-provider-guard-preserved` passes the 281-path baseline.

Live self brain, Review/Agent injection, post-await workspace effects and physical
extraction still need implementation. Pending candidate extraction must preserve
the committed `createPlanProposal` public export: candidate `index.ts` currently
drops it despite the function and its consumers remaining present. Do not copy
that whole index over the committed one. Physical Pipeline classification must
also retain the now-tested authority-failure versus user-cancellation distinction
without importing kernel internals into Plan. No release acceptance or push.

Next extraction inspection: candidate has five physical step owners (942 lines)
and corresponding owner/parity tests, but they are not all qualified. Panel
owner also adds post-return authority checks not yet present in the committed
CLI. Separate that behavioral fix from a pure ownership move; do not claim
whole-file mechanical parity. Existing candidate panel fixture targets an
older pre-admission base and includes an aborted case, so refresh its frozen
subject from the current Git object rather than normalizing away new refusals.
Keep `createPlanProposal` exported, retain the latest provider wrappers and
monitor, and preserve candidate historical-record WIP independently.

### Nested Plan workflow phase authority (verified local increment)

Base: `8b81287ac9b0fe267121623e3e379a5e6f8192aa`. Three affected paths:
the existing CLI step factory, its admission test, regenerated migration ledger.
No new package, dependency, public API or parallel executor. Shared local
`assertStepAvailable` checks cancellation, captured lifetime, Plan and the
selected step owner. Pipeline calls it plus the child owner before and after
each Brainstorm/Forge/Tribunal backend call. Backends are mocked in these tests;
no live Pipeline or external model workflow is activated.

`plan-nested-phase-red`: six failures, 22 passes. All three disabled-child cases
and all three mid-phase generation changes wrongly succeeded. Enabled workflow
control passed. Log SHA-256:
`04167e87b68a3d27d8b0fda3e43a48364645a8394369cb7d63d1aab9d7699a5a`.
`plan-nested-phase-focused`: types and 28 tests pass after the repair, zero
provider launches. Log SHA-256:
`b0e9333dbdf920e35048cd4500568f46340d3c980ae4100ec98a1e999cc15692`.

Default reviews inspected indexed tree `00c4167120fdc8d76857f0847e026ac13c8d5654`.
Packet SHA-256 `93cef032d5f7d55a8eb98684c15ba7d4040bb33437787e014c7e709fcda890a3`.
Neither found a blocking new defect. Production source unchanged after review.
Additional tests assert no completed event for rejected returned work, no next
phase start, one terminal event, no conformance failure, host replacement,
cancellation from phase-start callbacks and progress interval cleanup.

Adjudication:
- Codex's post-call mutation weakness is valid: a next-phase check could mask
  removal of the prior post-call check. Event assertions now distinguish these.
- Kimi's suggestion to put admission before phase-start is not adopted blindly.
  Existing workflow tracking requires a started phase before its failure event.
  The current trace records an attempted phase followed by refusal, with the
  specific unavailable error. UI notification is not unauthorized provider work.
  The checks deliberately sit after user callbacks, immediately before calls;
  moving only that check earlier could miss cancellation inside the callback.
- A post-call denial discards output as accepted Plan context. It does not
  undo effects that a backend already performed. This limitation is explicit.
- Rejecting already-cancelled invocation uses the same Promise error contract
  as admission. Both scheduler branches catch it; direct library callers must
  handle rejection. Cancellation during a phase retains the existing failed
  result plus cancelled workflow event channel.
- Timer cleanup remains in `finally`; real interval handles are now checked.
- Backend-internal retries/dispatch while a call is pending are NOT covered.
  Guarded adapters, cooperative cancellation, other step types and physical
  step extraction remain required next work. This is not whole-release proof.

Build `plan-nested-phase-build` passes in 151.264 seconds, zero providers.
Log SHA-256 `d8cfb5e146483ae59e5a3c11a088f3b83065ae92e55ec8abf617d19713cb5ce9`.

`plan-nested-phase-focused-reviewed` passes types and all 36 admission/phase
tests (real durable hosts, mocked backends). Log SHA-256
`31e448f5c9209814077908b2d6908ab79e5427e7d5354f3ef9da182431f8517d`.
Targeted negative control `plan-nested-phase-postcheck-mutant` temporarily
removed only Brainstorm's post-call assertion. Both selected event assertions
failed even though the next-phase guard still rejected continuation. Two
failures and 34 intentionally filtered tests, zero providers. Log SHA-256:
`8a8e72e9b1b36be0b81126f19d2b5cb22e13db9eb8028404d28c60d57e5ae176`.
The mutation was restored byte-for-byte to the reviewed production index.
Final indexed tree after test additions:
`14f79523e5d4478fa9fdf2b34ce397ee07e83394`.
`plan-nested-phase-final` passed in 136.458 seconds: types, lint, re-export guard,
generated drift, roadmap, 7,465 tests (six skips), 14 compiled-CLI admission
scenarios, eight compiled-CLI entry scenarios, then all 36 real-host admission
and nested-phase tests again. Zero provider launches. Native checks validate
shipping admission entries, while nested backend boundaries use mocks; no live
Pipeline/model execution is claimed. Log SHA-256:
`8f90151c8c659ee52af351605284f57512a400cd1c86d145c6b62b0ba91b7170`.
Commit `98c2b3d2c26c76a8ac183618f1bc7a4c8b112a02` has the exact tested tree
above. Qualification checkout is clean. Candidate advanced without changing
its future implementation files; the new tests were mirrored after verifying
the prior candidate test exactly matched the preceding committed version.
Preservation receipt `plan-nested-phase-preserved` passes the 281-path baseline.
Nothing pushed, installed or promoted. Next required work is guarded backend
dispatch/cooperative cancellation and the five physical step-owner extractions.

### Plan step admission (verified local increment)

Base: `6e6a9dd6c1ab62e044c1e52e957ce1721b9188ad`. Four-path change:
CLI factory, shared process authority, admission tests, regenerated migration
ledger. The factory checks Plan before storage and captures its host lifetime.
Every executor checks its fixed dictionary key, not caller-supplied `step.type`.
Self's no-dispatch fallback additionally checks the Agent/delegate owner.
This is admission only. Nested workflows, later async effects and physical
step-owner extraction remain unfinished; no release acceptance is claimed.

Evidence:
- `plan-step-admission-red`: 14 failures, one enabled control passed.
- Initial wrapper repair exposed synchronous throws instead of the existing
  Promise contract. Changing the wrapper to `async` fixed it without weakening
  the rejection tests.
- `plan-step-admission-focused-complete`: 33 tests passed (17 admission,
  16 entry). The command also named a nonexistent self-step filename; Vitest
  selected only the two actual files. Do not claim a third test file ran.
- Review subject: `7cad346409fa3c902bde39795613ad9929e9bd0c`.
  Both default reviewers completed. Packet SHA-256:
  `9d9abd26611963b8558afe1d1292b816a5e3c807e6f68980d1650f6c9b83d7be`.
  Production source is unchanged after review. Four test cases were added:
  still-enabled generation change, disposal without restart, same-owner alias
  duplicates and cross-owner alias collision. Enabled execution now also uses
  a forged caller type to prove only the selected executor controls admission.
- Final indexed tree after those test additions:
  `dfe2055749189b002c49b57ff8ef198192d78234`.
- `plan-step-admission-build`: passed in 151.356 seconds, zero providers.
  Full-suite receipt `plan-step-admission-final` passed types, lint, re-export
  guard, generated ledger drift, roadmap verification and 7,450 tests (six
  skipped). The compound command then failed in the external native helper:
  it tried to call `disposeProcessSurfaceAuthority`, which is not exported by
  the shipping CLI bundle. This is a probe mistake, not a production defect.
  No shipping export was added. Host disposal remains covered by real-host
  source tests; native child processes instead test shipping entry points.
  Failed compound receipt log SHA-256:
  `dbebc7037918145a45c197cc129b0e584a34da1d5102d75c0a96d7078fca9b1e`.
- Corrected `plan-step-admission-native` passed in 23.024 seconds: two runs of
  14 compiled-CLI admission scenarios and eight existing compiled-CLI Plan
  entry scenarios. All used real isolated durable hosts and zero provider
  launches. Native enabled control proves admission, not live model execution.
  Log SHA-256: `205096fc7d3dde8afdc39802313b8af341caea718b84999c7e12eb5dfbfa9d51`.
- Local commit `8b81287ac9b0fe267121623e3e379a5e6f8192aa` has the exact tested
  tree `dfe2055749189b002c49b57ff8ef198192d78234`; qualification checkout is
  clean. Candidate branch was advanced by an expected-old-value fast-forward;
  its index was reset to that tree without changing working files. No unrelated
  work was staged or committed. Nothing pushed, installed or promoted.

Peer adjudication against source:
- Codex: no confirmed new defect. Its additional controls are implemented as
  listed above. Concurrent initialization is a source-supported follow-up:
  `initializeProcessSurfaceAuthority` checks `boot` before awaits and publishes
  later without a shared pending promise. Reproduction and repair remain open.
- Kimi's unhandled-rejection concern is refuted by the real scheduler:
  `packages/mod-plan/src/executor.ts` catches executor rejection in both parallel
  and sequential branches (lines 100 and 151 on this subject). Existing scheduler
  tests cover thrown parallel execution. The self fallback uses its inherited
  failure-result channel; both paths ultimately become failed steps. Typed
  restart presentation is a separate broader concern, not a new bypass.
- Kimi correctly identifies the ambiguity branch as defense in depth:
  the real generation constructor already rejects conflicting owner names.
  Mocked corrupt-catalog tests do not prove real activation can create that state.
- Same-owner lookup is not generic dispatch. The actual catalog contains four
  Brainstorm, two Pipeline and three self Plan-step declarations. Admission
  establishes their one owner; it does not select one registry record to execute.
  Generic `assertAvailable` requires one record and cannot substitute here.
- Nested Pipeline admission is genuinely unfinished and was present before
  this patch: Pipeline can call Brainstorm, Forge and Tribunal without checking
  those child owners. Include checks before the first child as well as after
  awaits in the next enforcement slice. Live self dispatch also needs its own
  authority/effect tests. No Pipeline workflow was executed during this review.
- Repeated canonical reads are a possible optimization, not a correctness fix.
  Date-based output-directory collisions are inherited and still need a focused
  reproduction. Creating Plan's own run directory while a different mod is
  disabled is not itself a child execution or disabled-Plan write bypass.
- New step-type drift checks are useful only against the actual flexible Plan
  contract; do not replace it with a made-up closed union.

Preservation receipt `plan-step-admission-preserved` rechecks the 281-path
baseline. Unrelated files are unchanged. Candidate's future executor extraction
remains untouched; only the new admission test is mirrored into it.

- F8: one shared resolver now serves CLI and the physical Review mod. Tests
  distinguish the requested branch from ambient HEAD and distinguish two-dot
  from three-dot ranges. Untracked text, binary markers, safe refs and output
  bounds remain covered.
- Source-verified peer findings: reject extra range endpoints; preserve unusual
  untracked filenames; refuse implicit default-branch self-review; resolve
  commit objects before diff/show; verify stale origin/HEAD before comparing it
  to the reviewed branch. Each defect had a failing regression before its fix.
- F9: CLI/MCP explicit selection uses the existing registry's alias, removal and
  availability logic without default exclusions. The CLI's prior selection
  owner delegates to this helper. Hidden but explicitly named engines work.
- Source-verified peer findings: map parsed intent fields before execution;
  reject conflicting selectors; validate explicit selection on empty diffs;
  reject invalid timeout values before run creation; create no run on rejected
  selection. Callers now omit absent selectors instead of sending empty strings.

## Independent review and adjudication

Default Codex and Kimi reviews ran through isolated candidate Agon. Temporary
authentication copies were removed after each run. Packet and output hashes
are in `review-target-*-review.receipt.json` and
`review-engines-*-review.receipt.json`. Reviewers inspected supplied source,
not the complete release, and did not execute tests.

- Both reviewers' intent and run-lifecycle findings: reproduced, fixed and tested.
- Cesar array-shape claim: not a confirmed direct mismatch. The actual Cesar
  router converts arrays to comma-separated command selectors before dispatch.
  Its absent-selector encoding needed the correction recorded above.
- Missing optional explicit-resolution capability: fallback remains fail-closed;
  real CLI and MCP hosts now provide the capability. It does not claim an
  excluded engine is usable on an unspecified third-party host.
- Registry silently drops unknown IDs: refuted against `partitionRoster` and
  executable mixed-panel tests. Unknown IDs survive partitioning and fail lookup.
- Whitespace-only Review base: existing CLI normalization, not a new extraction
  regression. Preserved rather than silently changing accepted CLI semantics.
- Synthetic diff placeholders: informational review input, not an apply-patch
  artifact. No verified consumer requires patch applicability.
- Oversized Git output: 10 MiB subprocess bound can fail before review truncation.
  This is a bounded existing limitation, not proof that arbitrary diffs succeed.
- Default exclusion duplication: confirmed separately maintained CLI/MCP policy;
  keep on simplification backlog and trace all consumers before consolidation.

## Verification

Receipts store command, exit status, duration, log SHA-256 and provider-launch
observations. Negative receipts are retained alongside passing receipts.

- `review-target-stale-red` -> `review-target-stale-green`: 32 target cases green.
- `review-engine-peer-red`: 14 failures / 16 passes before peer corrections.
- `review-engine-peer-green`: corrected intent/selection paths passed.
- `review-timeout-red` -> `review-timeout-green`: invalid timeout controls.
- `review-final-full`: 7,675 passed, 6 skipped, 627 files passed / 1 skipped.
- `review-final-lint`, `review-final-types`: pass.
- `review-fixes-build`: pass, but predates the final peer corrections. Rebuild
  and clean-checkout qualification remain necessary before acceptance.

No real provider was launched by these test gates. The four separately recorded
independent reviews did use the authorized Codex/Kimi providers.

## Archive

Durable root: `/Users/ra/dev/modular-agon-evidence-archive/2026-10-10-2b59937b`.
392 files, 8,772,250 source bytes. Every working copy was byte-compared and
retrieved into a temporary directory with SHA-256 verification. Original paths,
base commit and latest path commit are recorded. Differing committed versions
are retained separately.

Manifest SHA-256:
`60e2f3f3a5bfc5ff1d32ea2e95fea02ff50f55b0fdeb86732145d4ec3f886a65`.
Nothing untracked or deleted yet. Never delete this archive without Raphael's
explicit approval. A tracked index and consumer updates are prerequisites for
any later archival removal.

## Not finished

## Jobs review corrections (2026-10-10)

The Codex/Kimi `jobs-contract` packets reviewed an explicitly incomplete
migration. Both source packets and reviewer logs remain beside this report.

- Empty event replay was reproduced against the real daemon: the client exits
  zero with no new events. The MCP bridge now preserves that successful empty
  response. Receipt: `jobs-empty-replay-red` ->
  `jobs-options-and-replay-green`.
- Option-like positional workflow names and job IDs reached the CLI parser.
  Seven failing cases now reject them in the canonical Jobs argument builder.
  Receipt: `jobs-option-red` -> `jobs-options-and-replay-green`.
- Cancellation and invocation-directory forwarding were missing from the MCP
  client. Both failed focused tests before repair (`jobs-context-abort-red`).
  The host now forwards its invocation context. The bridge uses the existing
  shared process supervisor instead of its own spawn/kill handler.
- The supervisor now accepts an optional combined byte limit for buffered
  output. Overflow uses its existing group termination and escalation path.
  `jobs-process-bound-red` proved the missing bound. A split-UTF-8 control
  (`jobs-output-utf8-red`) also failed: decoding now retains character state
  across chunks, preserving the previous Jobs bridge's decoding behavior.
- Spaces in a single argv string do not become additional argv entries. That
  reviewer claim is rejected. Leading option tokens are the confirmed issue.
- Idempotency keys are not an agreed contract. No new idempotency mechanism
  was introduced in response to the review.

Additional boundary checks found and reproduced two defects:

- The CLI parser treats `--reason`, `--help` as a help flag, not a reason.
  Three real-parser tests failed (`jobs-reason-option-red`). Encoding the
  option as `--reason=<text>` preserves the text (`jobs-reason-green`).
- A daemon already running in another directory ignored the caller's local
  removed-engine policy when the submission omitted `cwd`. The real daemon
  accepted that job (`jobs-daemon-cwd-red`). The CLI payload builder now
  resolves omitted and relative directories before IPC. Unit negative controls
  are green (`jobs-submit-cwd-red` -> `jobs-submit-cwd-green`). The full fresh
  build `jobs-client-final-build` passed. `jobs-daemon-cwd-green` then passed
  all 32 focused tests, including the actual cross-workspace daemon boundary.
  Provider launch count: zero. Final typecheck passed.

Full suite `jobs-client-full` found two failures: the new PID readiness fixture
published its file before its contents, and the scheduler move lacked ledger
evidence. The fixture now publishes with atomic rename. The migration ledger
records the three relocated result declarations and their actual source path.
The Core export identity and absence of the old source are tested.
`jobs-client-full-corrected`: 7,697 passed, 6 skipped. This predates the final
reason and directory corrections. Types and lint passed before those corrections.

This does not finish Jobs ownership. The non-MCP factory scheduler still needs
retirement. Persistence errors, disabled-owner reachability and host disposal
also remain open.

Final local checkpoint for these client fixes:

- `jobs-client-final-build`: pass, 150.359 seconds.
- `jobs-client-final-types`: pass.
- `jobs-daemon-cwd-green`: 32 focused checks pass after the fresh build.
- `jobs-client-qualified-full`: 7,703 passed, 6 skipped, 57.804 seconds.
- `jobs-client-qualified-lint`: pass, 67.848 seconds.
- All test receipts record zero provider launches.

These are dirty-candidate receipts, not clean committed release qualification.
No commit, push, install or promotion was performed at this checkpoint.

Next ownership work must preserve the distinct legacy lifetimes: TUI JobManager
uses local numeric IDs backed by JobService, while CLI/MCP share daemon UUIDs.
Do not merge these namespaces or cancel autonomous daemon jobs on MCP disposal.
Trace `signals/job-manager.ts`, `signals/dispatch/intent-meta.ts`,
`commands/job.ts`, `jobs/daemon-job-router.ts`, and `jobs/workflow-job.ts` before
removing the factory-local ModularJobService. The removed source's three ledger
rows are result declarations, not proof of complete CLI/TUI execution cutover.

## Dependency metadata scan

## Daemon router ownership move

The existing CLI Jobs router now lives in `packages/mod-jobs/src/daemon-job-router.ts`.
Jobs wire types live in the same package. Core composes the public types into its
transport union. CLI imports the public router. The old router file is removed
from the candidate, remains recoverable from Git, and its one emitted-event
ownership row points to the new implementation with test evidence.

`jobs-router-source-parity` compares both function bodies and all thirteen Jobs
request/response variants to HEAD using the TypeScript parser: identical.
`jobs-router-daemon` runs the rebuilt CLI, actual daemon socket and MCP client:
pass. `jobs-router-full` and `jobs-router-lint` passed before review corrections.

Default Codex and Kimi reviews used packet hash
`b0585d58b7e2b877401d0211df50156a5586d474077eebe4af101e5498969742`.
Source-verified dispositions:

- Confirmed new type guard defect: a tag-only input gained validated payload
  fields. The guard now narrows the caller's existing union using Extract.
  `jobs-router-type-guard-red` failed compilation as expected; the corrected
  `jobs-router-peer-green` includes a passing external public-contract compile.
- Confirmed test weakness: an early return could skip cancellation assertions.
  Unexpected submission replies now throw.
- Added public-entrypoint execution and Core/mod-jobs type composition checks.
- Added parsed-frame -> guard -> router -> encoded-response tests, invalid
  requests, exact resolver forwarding, client attribution, bounded event replay,
  failure results, terminal cancellation, and resolution-error behavior.
- Missing CLI integration in the reviewer packet was a packet limitation:
  real daemon evidence already existed and is retained. No claim that a
  deleted-file assertion alone proves execution ownership.
- Shared JobService identity is verified by `job-service.test.ts`; Core exports
  the physical Jobs class. No mod-jobs import of Core was added.
- The claimed check-then-act race has no supplied reproducer. These calls are
  synchronous; do not label it a confirmed defect solely from peer speculation.
- Core still owns wire normalization. This move does not claim complete Jobs
  extraction, disabled-host enforcement, or factory-local scheduler retirement.

After corrections: `jobs-router-final-full` reports 7,712 passed / 6 skipped;
`jobs-router-final-lint` and `jobs-router-peer-types` pass. Temporary review
authentication copies were verified absent. Both review commands exited
successfully. These remain dirty-candidate receipts, not release approval.

## Approved scanner result

Raphael explicitly approved sending package names and versions to OSV.
`workspace-edge-osv-online` completed with exit 1 because it reported findings,
not because of a scanner or network failure: 16 findings across 9 packages,
including two critical findings in dev dependency tinypool. The raw log and
hashed receipt are retained. No dependency version was changed or installed.

## Remaining acceptance work

## Evidence handling correction

The local driver reused `jobs-scheduler-package-build` during consolidation and
overwrote the earlier log and receipt under that name. The current file belongs
to the 2.709-second consolidation build (log hash
`2a261cca7b64f60b01a278b4b0dc78a3cd41d029890b42e27a55a01798cf1b48`).
The earlier 2.633-second build had log hash
`6d5b6db8e8405f738515d8676a07368ec1bbd1acbb47eb8886cece2f04ac1545`
as recorded in the conversation; that earlier raw log is no longer available
at this path and must not be cited as retrievable evidence. The earlier hash
is transcript metadata, not a reconstructed or reverified artifact.
The durable archive was not altered. The driver now refuses existing receipts
and atomically reserves each new log name before running a command. Fresh
uniquely named receipts are required for acceptance.

## Remaining implementation

### Historical raw-output archival increment

Committed locally as `85ba7ebf` (six explicit paths only). Removed 77,304 raw
lines from tracking and added 66 lines of ignore rules, index and retrieval
guidance. Neither raw artifact was destroyed: both local copies are restored
and ignored, both remain in the immutable durable archive and Git history.
Nothing was pushed. The rest of the dirty implementation is not in this commit.

Both artifact files match their current bytes, archive bytes, recorded SHA-256,
byte counts, Git blobs and the frozen pre-removal commit. Retrieval from Git
and archive passed, including a corrupted-byte hash negative control:
`archive-two-file-retrieval`. Full archive integrity was separately checked for
all 392 entries. `archive-post-commit-retention` checks the ignored restored
copies and retrieval using the old commit after the new commit exists.

Both raw files were moved outside the worktree for verification. The full suite
passed with them absent: `archive-raw-absent-full`, 7,724 passed / 6 skipped,
58.199 seconds, log SHA-256
`cf66e8cd7dc537ef00d7648f5bfb7fc76fd63f95a1321eb0d0d39514466f7b7a`.
They remained absent after the suite; it did not silently recreate them. Types
passed. This proves no dependency in those tests, not whole clean-release
qualification of the unrelated dirty implementation.

Default Codex/Kimi review packet SHA-256
`32ca041a0a10117e6371a930f22bee6f03fdbef5f1ecb68a1ccfc9403c25e420`.
Both reviews exited 0. Applied wording clarifications: untracked versus deleted,
link label for the retrieval guide, and frozen subjectCommit versus current HEAD.
Kimi's suggested retrieval failure after a later commit is refuted by explicit
post-commit retrieval: the fixed historical SHA still names the recorded bytes.
No historical receipt bytes were changed.

The consistency gate was already red before either raw file was removed from
disk and emitted the identical error while both were absent (same log hash
`2fe8e627c302ff2ba3bbe0732e02828965dee3e0d261f206a6bbd0e7feb74e37`).
It rejects the product-audit link to completion-progress heading
`Apply workflow extraction — development qualification`: the checker collapses
hyphens while the authored link uses a double hyphen. This is an unresolved
anchor-semantics issue, not an archival failure and not waived for final release.
No source, fixture, schema, generator input or active acceptance oracle was removed.

### Daemon authority admission increment

Verified defect: a real daemon accepted `job-submit` after a real durable
generation commit disabled agon.jobs. Receipt `jobs-daemon-stale-red` records
the wrong `job-accepted` response. The daemon now captures its original host
lifetime and checks the selected Jobs contribution before all six Jobs routes.
No new resolver or registry was introduced.

The initial green attempt passed authority assertions but failed fixture cleanup:
DurableModHost makes generation directories mode 0555. The integration fixture
now permits removal of its own generated directories after the test. Production
generation permissions are unchanged. `jobs-daemon-stale-clean-green` passes.

Default Codex/Kimi reviews both completed with exit 0, packet SHA-256
`40d6d08a7e4b9b052f69fde2b88e7ef2b1e8c31a3fb3e3f8811e83654e54c2c7`.
Adjudication:

- Confirmed plain-prompt bypass: `jobs-daemon-prompt-red` returned ack after
  disable. Prompt admission now checks the captured host and daemon contribution
  before writing the prompt ledger or dispatching. `jobs-daemon-prompt-green`
  passes. The ledger also proves the rejected prompt was not recorded.
- Confirmed test isolation weakness: the test now sets an explicit modular root
  and clears safe-mode for its fixtures, then restores previous environment values.
- Confirmed independent guard coverage gap: focused tests inject each denial
  separately and assert the Jobs router was never called. Existing real bootstrap
  tests separately verify the disabled-owner behavior of the shared authority.
- Confirmed recovery evidence gap: the stale case now waits for actual process
  exit and verifies socket/pidfile removal. It no longer treats bye alone as exit.
- Confirmed test organization issue: the stale-generation case has its own named
  test and daemon, separate from cold-start/MCP interoperability.
- Router caller audit: rg finds only one production caller, the guarded daemon
  transport. An additional unguarded MCP caller was a hypothesis, not a fact.
- `jobs-v1` advertises wire-protocol support, not current authorization. Keeping
  it allows clients to receive the truthful generation mismatch instead of the
  existing misleading "older daemon" capability error. No dynamic downgrade.
- Existing queued/in-flight work is not proven cancelled by this admission fix.
  The accepted specification pins long-lived hosts and drains/restarts them
  (overview lines 153 onward; Slice 3 restart semantics). Provider-boundary and
  drain/re-entry qualification remain open; do not claim this proves all execution
  ownership. Post-disable per-job cancel is denied; raw shutdown still drains.
- No claim of live-provider execution: tests use the documented echo seam and
  launch blockers. They prove admission, no router invocation on guard denial,
  prompt ledger exclusion, transport behavior and actual daemon exit.

The pre-peer suite `jobs-authority-full` passed in 57.878 seconds. Fresh final
checks after the peer corrections are required before accepting this increment.

Final corrected suite `jobs-authority-final-full`: 7,724 passed / 6 skipped,
58.118 seconds, log SHA-256
`b98df3a3d47f187a31f1d67bd15733f4cfda9782abf07dfc6454b5a00e9fe2e5`.
`jobs-authority-final-types` and `jobs-authority-final-lint` pass. The separate
last real-daemon check is `jobs-authority-final-daemon`. Reviewer temporary
auth/config copies are absent. The archive integrity check also passes all 392
files (`archive-current-integrity`). No files were untracked or pushed.

### Jobs scheduler consolidation: default peer review and corrections

Review packet SHA-256:
`3a42315bb22a4306835c96ea0da9585b6e4274a9705e577ff667aa4b14acbd5a`.
Both `jobs-scheduler-codex-review` and `jobs-scheduler-kimi-review` exited 0.
Codex identified shutdown, admission, persistence backlog, cleanup and JSON
type defects. These were verified against source and reproduced:

- `jobs-cleanup-all-red` / `jobs-cleanup-all-green`: one failed unregister
  previously skipped the remaining registrations and masked the storage error.
  Every cleanup is now attempted in reverse order. Multiple failures use
  AggregateError; one failure retains its original error.
- `jobs-storage-timeout-red` / `jobs-storage-timeout-green`: a never-settling
  host state write previously blocked disposal forever. Persistence flush now
  has a 10-second deadline, after the existing task-idle wait of up to 10 seconds.
  The error explicitly states that host storage I/O may still be pending: the
  storage API provides no cancellation capability. Cleanup callbacks themselves
  are awaited; this is not a universal deadline for arbitrary host cleanup code.
- `jobs-late-submit-red` / `jobs-late-submit-green`: engine discovery could
  resume after disposal and submit new work. Disposal synchronously closes
  scheduler admission before cancellation. Manual-job admission also closes.
- `jobs-persistence-backlog-red` / `jobs-persistence-backlog-green`: coalescing
  bounded observations per job, not across jobs. New admissions now stop when
  outstanding jobs reach the existing retention limit. A slot remains reserved
  until its terminal envelope reaches storage. Blocked writes do not silently
  discard accepted jobs; admissions recover after successful draining. This
  bounds outstanding record count, not arbitrary JSON payload byte size.
- `jobs-json-types-red` / `jobs-json-types-green`: the persisted service had
  widened JSON output/event types to unknown. Canonical JobService now has a
  default-unknown type parameter, preserving Core callers; the persisted service
  specializes it to Json. An external compile-only fixture checks JSON outputs
  and rejects non-JSON event values. No second scheduler was introduced.

Kimi H1 (two canonical schedulers) is refuted: the Core source was deleted and
Core re-exports the physical mod class. `tests/unit/job-service.test.ts` verifies
public class identity and behavior against current config defaults. The OLD
file in the review packet was historical comparison evidence, not a live copy.
Kimi's claim that pending writes were already bounded by live records was
incorrect: pruning could remove records while writes remained queued. The new
backlog negative control demonstrates the actual risk.

Kimi M2 concerns pre-existing invalid waitForIdle timeout handling; disposal
passes a fixed positive value. No clamp was added to conceal invalid input.
M3 does not demonstrate a lost-wakeup bug: flush drains observed writes, not
future task events. That boundary is now documented. M5 cannot occur for a live
record under the current positive event limit and initial queued event invariant.
L8 is refuted: the persisted wrapper's default replay limit is 100, whereas the
canonical service defaults to its event limit. Removing the override changes
behavior. MCP validation and transport checks remain covered by existing tests.

Current focused tests and typecheck pass. Full build/lint/suite and final daemon
qualification are being refreshed. These are dirty-candidate checks, not a
clean committed release receipt. Factory CLI/TUI parity and disabled stale
surface enforcement remain separate unfinished requirements.

Packaging follow-up: `jobs-pack-declarations-red-local` proved the manifest
omitted five generated declarations needed by the extracted public types.
The explicit Jobs file list and its existing generator now include those files,
the public exports, and the storage adapter's state.write permission. No broad
glob or allowlist exclusion was added. `jobs-pack-declarations-green` and
`jobs-generated-check` pass. The latter checks all 36 generated first-party
packages without writing them. Only Jobs metadata was edited.
The earlier `jobs-pack-declarations-red` used a bare npm path, which npm parsed
as a GitHub shorthand. It failed at name resolution and is not a negative
control for packing. The corrected command uses an absolute local path.

`jobs-reviewed-full-build` passed in 154.589 seconds; the Jobs package and CLI
were rebuilt again after the manifest-only follow-up. Full lint, generator lint,
final typecheck and re-export guard pass. Temporary reviewer credential/config
copies are absent. All local verification receipts report zero provider launches.

Fresh full-suite result: `jobs-reviewed-full` passed, 7,721 tests / 6 skipped,
58.727 seconds, log SHA-256
`725aeda768f763e1cc236c4c44bfa8fc6d9266f9b0e6907e65a218d0f084412b`.
The final separate real CLI/MCP daemon run is recorded under
`jobs-reviewed-final-daemon`; consult that immutable receipt for its exit.

MCP Jobs consolidation, archival consumer migration, ownership retirement,
safe simplifications, direct package-import declarations and clean committed
release qualification remain. No release, install, promotion or push occurred.

## Heading-anchor validator follow-up

The existing heading `Apply workflow extraction — development qualification`
has two hyphens at its punctuation separator. The consistency checker collapsed
them and incorrectly rejected the existing document link. The document was not
changed. The checker now preserves separate spaces and literal hyphens.

`spec-anchor-red` failed with the previous implementation. `spec-anchor-green`
passes the four regression examples, collapsed-anchor negative assertion and
the full existing consistency scan. Green log SHA-256:
`84dc9fcf3ddf67e5fc8f56aeb8692761ff606837543f7efe28db3ccdb3febab6`.
This is a narrow anchor correction, not a complete Markdown parser. Independent
review and normal-gate self-test integration remain pending. It is uncommitted.

The operator explicitly approved sending dependency metadata to OSV. The saved
`workspace-edge-osv-online` receipt confirms a completed scan, exit 1 for findings:
16 findings across 9 packages, including two critical dev tinypool findings.
No dependency upgrade or installation followed from this approval.

### Anchor review adjudication

Codex and Kimi completed the bounded `spec-anchor` packet, SHA-256
`70914a1edb7bf07243fb9655b3e7ea7dbda128993c89cde1be1a5ff214dcb466`.
Codex found no concrete defect. Kimi agreed on the separator correction and
identified inherited Markdown limitations: duplicate heading suffixes, encoded
fragments, fenced code, indented headings and combining marks. Those paths are
unchanged; no claim of a complete Markdown implementation is made.

Kimi's proposed retention of tabs/non-breaking spaces conflicts with the
GitHub section-link documentation, which removes non-space whitespace:
https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax#section-links
Retained the documented behavior and added explicit tab/NBSP cases. The oracle
now runs unconditionally in the normal consistency command, without a new gate
or package dependency. Full lint passed (`spec-anchor-lint`). Build and remaining
verification are in progress; not yet committed.

### Next reachable boundary: HTTP Jobs

Source trace: `buildServeRuntime` constructs a per-runtime JobService and passes
it to `AgonServe`; `/v1/jobs` routes call it without process surface checks.
The repaired daemon socket does not cover this separate HTTP entry point.
Added an integration test against a real ephemeral HTTP server, real modular
desired-state generations, and a fixture executor (no providers). It tests Jobs
disabled at boot, disabled after boot, and host replacement. Expected refusals
are typed, and attach/auth behavior remains available. Production code is not
yet changed; the red run is pending completion of the current build.

### HTTP Jobs verification and review

`http-jobs-authority-red` reproduced all three admission defects: HTTP 202
instead of refusal. The repair uses the existing captured host lifetime,
`assertProcessSurfaceAvailable('cli', 'job')`, and cooperative execution monitor.
It adds no scheduler or dependency. The wrapper checks queued work before it
starts and waits for executor cleanup after cancellation. HTTP status is 403 for
an unavailable owner and 409 for a stale lifetime; responses retain typed codes.

Default review packet `http-jobs-authority`, SHA-256
`1ff17bcd18a23401a232438df0b08ac670d0edf30f3917845d7ec5ff65da15bb`,
completed with both Codex and Kimi. Codex found two introduced scope regressions:
construction on an already-stale host threw before non-Jobs routes could serve;
the shared error handler changed non-Jobs typed-error responses. Both reproduced
in `http-jobs-review-controls-red-valid`, then passed after fixes. Construction
now retains its capture error for Jobs access only; typed translation is scoped
to the Jobs route. The first `http-jobs-review-controls-red` had an invalid cancel
body and is NOT evidence for the error-translation finding. Its constructor
failure was valid. The corrected run supplies `turnId` and observes HTTP 409
instead of the original non-Jobs 500.

Kimi's claim that non-Jobs semantics were unchanged was refuted by those tests.
Its claim that synchronous admission fully closes races is too strong: another
process can still change durable state between checks. Enforcement is admission,
execution-start, and cooperative monitoring, not atomic revocation of external
effects. Running executors must honor their signal. No claim of sandboxing or
forced termination is made. Jobs-disabled reads/cancel remain unavailable by the
agreed disabled-surface contract; bridge `close()` remains the cleanup path.
Production call tracing finds `createAgonServe` called from `buildServeRuntime`,
after normal CLI initialization. Tests also cover capture before a replacement
and bridge creation after invalidation. Uninitialized rollback compatibility is
not advertised as a monitored durable host.

Meaningful temporary mutation controls (all restored):
- `http-jobs-execution-negative`: removing the execution wrapper fails both
  queued/running checks (two failures, no provider launches).
- `http-jobs-body-negative`: removing only post-read checks fails both submit and
  cancel race cases (202/200 instead of 409, no provider launches).

Added enabled-success, same-generation replacement, non-Jobs error preservation,
and delayed executor-cleanup controls. The private body-reader spy keeps the real
HTTP/JSON reader and changes durable state at its asynchronous return boundary;
it does not replace the request or resolver result. The running-job fixture holds
cleanup until explicitly released, proving drain does not report idle early.
Broad tests, final lint, and a final separate HTTP/daemon run are pending.

### Verified checkpoint (2026-10-10)

The pending checks above completed:
- Full build: `spec-anchor-build`, pass, 150.866s; CLI rebuilt after HTTP changes
  in `http-jobs-final-cli-build`, pass.
- Types: `http-jobs-final-types`, pass. Full lint: `http-jobs-final-lint`, pass.
- Re-export guard: `spec-anchor-reexports`, pass. Normal specification consistency:
  `spec-anchor-final-normal`, pass (six anchor examples, no opt-in flag).
- Full repository: `http-jobs-final-full`, 7,736 passed / 6 skipped, 58.934s;
  SHA-256 `dd5453ff0daa4a8c00d85a265231c9c2d3b3de06b8cf8ed1a0622a73a3158b27`.
- Final real local HTTP/SSE/daemon transport run: `http-jobs-final-live`, 21 passed,
  6.748s; SHA-256 `ee4fbc27c547627286ba88c9aa3014105c3c0d83676c6d02a7ec981179c9a83c`.
All verification receipts record zero provider launches. External reviewers are
separate, authorized Agon calls. No global installation or personal state changed.

Local commit `d1383daec196858270facd41606d59aa67b61547` contains only the
independently reviewed anchor-validator correction. Index is empty. No push.
The HTTP repair remains uncommitted with its integration test: its captured-host
and monitored-execution helpers depend on inherited, still-uncommitted authority
work, and its fixture uses the extracted JobService. Do not create a knowingly
non-compiling standalone HTTP commit. Integrate those verified dependencies in
order; preserve all other inherited work.

Remaining scope has not changed: Jobs workflow/factory ownership and protocol
parsers, Plan/Brainstorm/Apply runtime ownership, temporary adapters, other
disabled execution boundaries, archive consumers and safe simplifications,
performance/load gates and clean committed release qualification. HTTP delayed
cleanup and same-generation replacement now have executable coverage. Ordinary
HTTP cancellation is covered in the legacy bridge suite; add an initialized-host
control before calling the monitored parent-signal matrix exhaustive. No claim
of complete modular release acceptance follows from this checkpoint.

## API dependency and Jobs process ownership (2026-10-10)

`http-jobs-parent-cancel` passes all 13 HTTP authority cases, including ordinary
operator cancellation under an initialized host. The executor's delayed cleanup
must finish before drain reports idle. This closes the specific follow-up test
gap recorded above; it does not qualify every execution path in the product.

Local commit `cd41cf1adb5353f464de0478c915e7f1b39b673c` contains only the additive
Mod API contracts for explicit reviewer resolution and the bounded Jobs daemon
transport. Existing default hosts remain valid because both capabilities are
optional. These contracts were in the earlier reviewed Review/Jobs packets.
Independent API build, pack/schema validation, external compile-only fixture and
focused contract checks pass (`review-jobs-api-independent-build`,
`review-jobs-api-pack`, `review-jobs-api-contracts`). No dependency installation,
global link, promotion or push occurred.

The subprocess runner and event chunk emitter now physically live in
`packages/mod-jobs/src/workflow-process.ts`. CLI imports and re-exports the same
public functions; the planner, config defaults and command sequence are still
CLI-owned. No second runner was introduced. The exact two definitions match
Git subject `cd41cf1adb5353f464de0478c915e7f1b39b673c`, old path
`packages/cli/src/jobs/workflow-job.ts`; definition SHA-256:
`ae56568dd95d7daac7770a8c794f376b21cd14a2b18403b6617d893abc5f9929`.
`jobs-runner-parity` records the byte comparison and a changed-body control.

`jobs-runner-baseline` passed before the move: real isolated child output,
stdout/stderr chunking, nonzero exit and final event, pre-abort and live SIGTERM.
After the move, `jobs-runner-moved` and `jobs-runner-public-consumer` pass.
Both forwarders have identity assertions. The existing compiler-host fixture
checks public built declarations against Core's old JobTaskContext and rejects a
string in place of AbortSignal. This is a public-package boundary check, not a
fresh npm installation claim. Exact pack allowlist and all generated package
metadata pass (`jobs-runner-pack`, `jobs-runner-generated`). Only the frozen
command-finished event assignment's implementationPath moves in the ledger;
legacy runtime authority remains recorded until planner/dispatch cutover.

Default reviews: packet `jobs-runner-owner`, SHA-256
`dde92937b346a3bd98914d07c4485e216875518dbc1348520af42002a2c9570b`.
Both found no extraction regression. Kimi's possible lint error is refuted by
full `jobs-runner-lint`; its suggested Core type import is rejected because
Core already re-exports the Jobs-owned type and would create a reverse boundary.
The compile-only fixture verifies compatibility rather than trusting that claim.
Codex's emitter-identity and public declaration gaps are now covered. The ledger
and pack claims were verified locally, not inferred from peer acceptance.

Inherited follow-up risks (not charged to the mechanical extraction):
- Buffer-by-buffer String decoding can corrupt split UTF-8 sequences.
- Direct `emitChunks` calls with a non-positive bound can fail to advance.
- Forced SIGKILL and spawn-failure evidence should accompany the runner repair.
Reproduce in bounded subprocesses before fixing; never run a zero-bound infinite
loop in the test process. Keep these changes separate from byte-parity evidence.

Runner package build, CLI rebuild, types, full lint, re-export guard, generated
ledger and focused tests pass. Full suite and last live transport run are pending.
The implementation remains dirty because mixed inherited Plan/Apply/Core exports
must be committed in dependency order, not swept into the Jobs extraction.

Runner checkpoint complete (not release acceptance):
`jobs-runner-final-full` passed, 7,741 tests / 6 skipped, 59.194s;
log SHA-256 `52c49a21ebbadd2eef4bae55ff9b775b158a4667922b42f30971cfa2fe728449`.
`jobs-runner-final-live` passed in 6.722s after the suite; real fixture processes,
daemon socket and HTTP authority paths, no providers;
log SHA-256 `e0e8b66d22fa6b594c94b424f1ab58abb2eff045d332e3c8cfd5b0c231325a05`.
Index remains empty; only the additive API contract commit was created this turn.
The two inherited runner risks above remain locally actionable next work, followed
by remaining workflow ownership and clean committed qualification. Nothing pushed.

## Jobs output repair after the byte-preserving extraction

The prior byte-parity receipt describes the extraction checkpoint, not this later
behavior repair. The public runner now keeps one UTF-8 StringDecoder per pipe and
flushes trailing bytes before command-finished. Both exported entry points reject
chunk limits that are not positive safe integers. The runner validates before spawn.
No dependency, process supervisor, or new configuration was added.

`jobs-runner-output-red` reproduced all three original assertions: split bytes became
replacement characters, NaN did not reject, and Infinity did not reject. Its log hash
is `0006fffe5b450e90bf5aa2e4e5ea7a99e806b2ddf6ce9b7ba6f45ab662efde83`.
`jobs-runner-output-green` passes; expanded checks include zero, negative, fractional,
and unsafe limits, side-effect refusal, accepted boundaries, and empty text.

Default Agon reviewers both completed packet `jobs-runner-output`, SHA-256
`b731f7a5188b468c0ef6bc3430575eff27ce3a810bb71ed6d2794ae45d59427c`.
No introduced defect was identified. Codex's missing stdout-tail and valid-boundary
checks were added. Kimi's missing SIGKILL and spawn-error checks were added with real
children. The latter also checks abort-listener removal. Kimi's claim that error means
command-finished can never occur is not accepted: the close listener remains installed
after error and can emit it. Existing error/close semantics were not changed here.
UTF-16 code-unit event splitting remains the existing chunk contract; rejoining events
preserves text. Windows is outside the agreed platform scope, not labelled tested.

Verification: package build, full typecheck and full lint pass. One full suite passed
7,755 tests / 6 skipped (`jobs-runner-output-full`, 59.843s, SHA-256
`19bfa5896db4ae0138188f5c3722462ce4e15448e534334c7470dc11584cc97a`).
Five additional assertions/tests were added after that full run; the final focused
suite including real subprocesses and daemon transport passes in 6.819s
(`jobs-runner-output-reviewed-live`, SHA-256
`ca08b5650c029e901dd3b3173ebdea7e16d495eabe7ea6d3490592bbcabb819b`).
Final changed-file lint and diff whitespace checks pass. All verification receipts
record zero provider launches; isolated external reviews are separate receipts.

Final source hashes:
- workflow-process.ts: `8a863d7f1a00cfce174e2d91783320382ea888034da3f31940918e4078f607ac`
- modular-workflow-process.test.ts: `8b808553223c3feaa1b34f4286dd7a724651d5be03c23d7bca1d50c5eedb02f1`
- daemon-workflow-job.test.ts: `1bfead95531f7275c70f4139f0d9482df86a6dfb85354a6a373b43656a897135`

Still open: daemon queued/running Jobs authority (admission is guarded but its
resolver still returns the unguarded executor), planner/command sequencing ownership,
factory CLI/TUI routing, and the larger roadmap. Commit assembly remains dependency-
ordered because inherited Core and host exports are mixed with these changes. No
release claim, push, install, promotion, or personal-state change.

## Daemon Jobs execution authority

Admission checks alone did not protect delayed execution. Two focused tests
(`daemon-jobs-execution-red`) proved an admitted executor still ran after either
host or owner authority failed. The daemon now wraps its existing resolver's
executor with the same withProcessSurfaceAuthority monitor used for HTTP Jobs.
The wrapper rechecks the captured host and Jobs owner at execution, passes the
monitor child signal, and awaits the original execution/cleanup. Ping/shutdown
remain outside the Jobs authority boundary. Monitoring is cooperative, every
100ms plus event-loop delay; this is not instantaneous revocation or sandboxing.

Real Unix-socket tests use the real host generation store, router and scheduler;
only workflow execution is controlled. Disable and host replacement both abort
running work, hold scheduler capacity until cleanup finishes, then reject queued
work without invoking it. The scheduler drains before shutdown, so shutdown
cancellation cannot make the negative reachability assertion falsely pass.
Temporarily removing only the running monitor caused both real socket cases to
fail (`daemon-jobs-monitor-negative`); the monitor was restored.

Codex review completed with no new defect, packet SHA-256
`10b2431bc40cb258594d753017e2028d0be0ed10f1733b2ee276d6c26969c77d`.
Its parent-cancellation coverage request is addressed: a real job-cancel request
reaches the wrapped child signal, cleanup is awaited, and outcome stays cancelled.
Kimi review is still running at this checkpoint; no approval is inferred.

CLI rebuild, full typecheck and full lint pass. `daemon-jobs-execution-full`
passed 7,764 tests / 6 skipped in 58.561s, log SHA-256
`b3bb993981ae8d105aeec1d0959995a9249700154598f6ed04afb2e485a02c0a`.
The final focused run adds the parent-cancel case: 30 daemon/HTTP/unit cases pass
(`daemon-jobs-reviewed-live`, 6.85s, log SHA-256
`315644169597422823e3d8297b6516398dac1e22d6eaba998add144fcb350733`).
Changed-file lint passes after that addition. All verification receipts report
zero provider launches.

Final source hashes:
- commands/daemon.ts: `c26b2bc6164a97c7ca9bc9a880f894416c06e0dbfe8025805d12805d85c0e1b6`
- daemon-jobs-execution-authority.test.ts: `2f22983db06481c2504a6ef386675d61167f0ca5d89b4653a1ff320ab083a226`
- daemon-start-readiness.test.ts: `cde3372393edc3eeceb442cf25e69049e7c848d874b410146ec70fc3cf77066e`

Newly grounded follow-up from the previous runner review: emitChunks can split a
UTF-16 surrogate pair. This is not only theoretical: commands/job.ts printEvent
writes each event separately to a Node stream, so separately encoded halves become
replacement characters. A local Buffer reproduction confirms this. Fix with a
failing real-consumer assertion; do not claim the prior byte-decoder fix covers it.
Jobs factory CLI/TUI still uses the simplified local operate() path; preserving
actual daemon and session-local behavior remains required before ownership is done.

### Kimi daemon review adjudication and output follow-up

Kimi completed the same daemon packet (log SHA-256
`950f69feab90b8f0547f386a3d761bfa9dd66921cd4cdbafd365df2acd9c07a8`).
Source-verified resolutions, in review order:

1. Static jobs-v1 is protocol support, not an activation grant. Existing
   ensureJobDaemon() distinguishes older daemons by this bit; removing it for a
   disabled mod would incorrectly report an old daemon. Every Jobs request still
   checks authority. Reject the claim that this repair introduced a callable bypass.
2. index.ts awaits initializeProcessSurfaceAuthority() before any daemon dispatch;
   the pristine fast path applies only to top-level help/version. No production
   uninitialized daemon entry was found. Keep intentional legacy test compatibility.
3. Init-after-capture invalidation is intentional: a stale host must restart rather
   than silently acquire a different registry. No automatic rebind is authorized.
4. Rejection already carries the explicit restart message from captured authority.
   Ping/shutdown deliberately remain available for recovery. A richer status view
   may improve usability later; not a reason to remove recovery operations.
5. submitted records the original accepted request/client, not provider execution.
   Its placement is inherited and does not grant authority. Terminal failure follows
   a refused execution. No semantic change to this receipt is needed.
6. CONFIRMED: an executor that ignores child abort could return success. Added a
   real socket/scheduler regression that failed with succeeded instead of failed
   (`daemon-jobs-result-revocation-red`). The existing shared monitor now checks its
   child signal and current authority after awaiting execution, before returning a
   value. It still awaits cleanup; it does not pretend to undo prior external effects.
   Three consumers traced: daemon Jobs, HTTP Jobs, Plan step execution. All supply
   a captured-authority check. Their focused suites pass after the repair.
7. Unit tests intentionally prove delayed entry refusal; real integration tests
   prove monitoring. The recorded monitor-removal negative control explicitly
   distinguishes these. No claim that unit tests alone prove running revocation.
8. CONFIRMED adjacent work: runHeadlessTurn dispatch lacks the authority-wrapped
   signal. Record as remaining daemon prompt work, not as solved by Jobs checks.

Emoji follow-up: tests now pass events through the real CLI printEvent() and encode
each write separately. Two limits failed before repair (`jobs-unicode-printer-red-valid`).
emitChunks now moves a boundary off a surrogate pair. Existing UTF-16 unit bounds
remain unchanged for limits >=2; limit 1 permits exactly two units for a pair.
This avoids changing every limit to code-point counts or adding a consumer buffer.
Five direct bound tests and four printer cases pass; malformed original strings
are not claimed repaired. Configured default remains 16,000 units versus the
1,048,576-byte daemon frame bound. ASCII event splitting is unchanged.

No second review panel was started for fixes to these reviewed findings. Full
qualification for this checkpoint is running; no release or clean-commit claim.

Correction after full-suite evidence: the initial shared-monitor result check was
too broad. `jobs-reviewed-boundaries-full` failed 34 existing Plan authority tests
because Plan returns typed refusal results rather than throwing at this boundary.
The helper change was reverted. The two Jobs executor wrappers now await, reject an
aborted signal, and recheck their own captured authority before returning a value.
Plan tests were not edited or weakened. `jobs-result-scoped-green` passes the full
Plan authority file plus both transport files. The failure is preserved with log
SHA-256 `61387d3ec0ebcc2bc400cb62920a39d492497223d397c6ea997078a980238fc2`.
HTTP now also tests an executor returning after it ignores abort. Final full-suite
requalification follows the scoped repair. Process correction: result policy stays
with the domain wrapper; the shared lifecycle helper only owns signal/monitor cleanup.

Final repair checkpoint: `jobs-result-final-full` passed 7,776 tests / 6 skipped in
58.852s, log SHA-256
`d4a8ee912c62f0d2129e0de91e530e8ce3f3c3640c7e59d622d518c36a266147`.
Then `jobs-result-final-live` passed 62 transport/subprocess/printer tests in 6.84s,
log SHA-256 `383abacfd703587250e91437148a53b2012f24805859ee0b0e39fd5b1582d916`.
Types, rebuilt Jobs package and CLI, full lint before the scoped correction, and
changed-file lint after it passed. No provider launches in test receipts. Shared
authority helper is restored to its pre-turn behavior; production repair hashes:
- daemon.ts: `84688c19e3b2014dead5cd9559562bba4484e888100167bfac6b6c89b65d1f10`
- agon-serve.ts: `3f645aa682cc4e92dad41d0b1e79f4aa62587a2a888f4d2f4f91d43cf5aaea95`
- workflow-process.ts: `4b8e7739b0306baf277cc582a566d8f2e77ac75b345a0aed7a6cc63c094107d2`

Index remains empty. No new commit combines these repairs with unrelated inherited
changes. Next locally actionable work: daemon prompt authority, remaining Jobs
workflow/factory ownership, then coherent dependency-ordered commits and full
roadmap qualification. This checkpoint is not a release or completion claim.

## Daemon prompt authority (following the confirmed adjacent review finding)

runHeadlessTurn had no provider cancellation signal or result-time authority check.
Two real-socket tests failed after disable/host replacement because providerSignal
was undefined (`daemon-prompt-authority-red`, log SHA-256
`a6f6958895988f5ae1a8cb2510501845bae196bab90f2108272376907305e419`).
The turn now captures its host lifetime, checks the daemon contribution before
recording the prompt and dispatching, forwards the existing monitor's signal, and
checks signal/authority before returning the provider result. Existing error ledger
and ack-sequence behavior remains; no new protocol or engine policy was introduced.
Real host, socket and ledger tests use only a controlled provider adapter. Enabled
success, disable and replacement pass without any live provider launch.

Default Codex review completed, packet SHA-256
`741a0f47a24a70ea47c19a866d50b281c9a5ccf09bd2d70430d34eb123278d8e`.
It identified an additional await boundary before publication. A controlled wrapper
changes the real host after the original monitor returns; the stale engine-block
was published before the fix (`daemon-prompt-publication-red`, log SHA-256
`3e8d785542aff684543c50916729b37e0b64f26199e89482e82cf3f978bdbbd0`).
An assertAvailable() after the outer await now keeps the final check and ledger
publication in one synchronous continuation. Same test passes, along with typed
terminal-event and ack.seq equality assertions. No monitor tick is needed for that
case. The wrapper spy is a test boundary control, not a new production hook.

First full suite, prior to the publication-check refinement, passed
(`daemon-prompt-full`, 59.214s). CLI rebuild, types, full lint and post-refinement
changed-file lint pass. Final full-suite requalification and Kimi review are pending
at this checkpoint. Prompt shutdown cancellation/draining remains an inherited
separate lifecycle gap; do not claim it solved by generation monitoring.

Kimi review completed (same packet; log SHA-256
`3283d56fc11a7ea5290a3b8d72fed4dc82093c2ced1a17b0d1ce9349d415fa8d`).
Its claim that no microtask can intervene before publication is rejected: the
Codex-requested boundary control reproduced stale publication, so the outer check
stays. Ack means durable processing, not successful answer generation; the new
typed ledger/sequence assertions pin that inherited contract. Stale-at-entry prompts
are refused without a new user-message by the existing admission guard. Added a
provider rejection case and assertions that subsequent stale-host prompts return an
error without dispatch or ledger growth. Tick latency remains explicitly cooperative.

Final production hash: commands/daemon.ts
`aa5fbdc9cc7e5c49eb3eefd1248fae656aea219b02c7fb74f32fc69c45f64540`.
Final test hash: daemon-jobs-execution-authority.test.ts
`62fbb16d3588f9a2eb3af0772a96c09ee8475083e13700689f2db960ff65bbba`.
`daemon-prompt-reviewed-full` passed 7,780 tests / 6 skipped in 58.869s,
log SHA-256 `f665499d71b5d98c2c40f6865503800f4826681331c8b0e0662dc4fc3b4f4aeb`.
After the final test-only review additions, `daemon-prompt-peer-final-live` passed
14 real-socket/lifecycle cases in 6.717s, log SHA-256
`9fe12aecb4323c70af92dd178062a89193e90893d1acfc4737a039107bbaaf56`.
Types, full lint, rebuilt CLI, final changed-file lint and diff checks pass. Test
receipts contain zero provider launches. All review processes are finished.

Remaining: shutdown must cancel/drain an active prompt, Jobs workflow/factory
ownership and other roadmap ownership, coherent local commits and clean-checkout
qualification. Index empty; no push, install, promotion or global-state change.

## Daemon prompt shutdown and ownership

Confirmed shutdown omission via a real socket/provider boundary. The first test
fixture failed to reject a socket closed before reply and timed out; that fixture
defect was corrected, not accepted as product evidence. The bounded valid red run
`daemon-prompt-shutdown-red-valid` proves the provider signal stayed un-aborted.
Its log SHA-256 is `2b02440d2d9ff788408e9366b4dc511421d34758b647706f32e09df55eda346e`.

The daemon now owns one lifetime AbortController and one activeTurn promise.
Shutdown closes admission before yielding; cleanup aborts the lifetime and drains
Jobs and prompt concurrently within the existing jobShutdownTimeoutMs. The optional
runHeadlessTurn signal preserves prior call compatibility. Late results cannot pass
the cancellation/publication check. No new scheduler, dependency, timeout setting,
or shared-monitor result policy was added.

Default review packet: `daemon-prompt-shutdown`, SHA-256
`f337f0a21cf411f49898c75d5b296a78eb40eb422f3e2546af5655e7f51dc4f1`.
Codex identified two concrete defects in the first repair; both reproduced in
`daemon-shutdown-review-red` (three failing assertions, log SHA-256
`1dcee43e61a48b7b03e6b33ab58e6b224827b5eee6217601f108525b51ec4928`):
- Acceptance-to-cleanup gap: now lifetime abort happens synchronously before bye.
  The test freezes deferred cleanup timers and asserts abort immediately after bye.
- Ownership loss: stopDaemon now returns a pending warning without sweeping live
  ownership files. It also refuses to sweep changed ownership. Drain timeout keeps
  the daemon PID file so startup cannot replace a live provider-owning process.

Tests verify held cleanup, admission refusal, normal re-entry, and an actual ten-
second deadline with both prompt and Job held. Both drain warnings are required;
elapsed time must remain below a serial two-budget drain. A late provider result
after the deadline is refused; PID ownership remains while the socket is closed.
This is honest bounded cleanup, not a claim to forcibly kill an uncooperative engine.

Kimi corroborated the ownership concern (now fixed), but its claim that
runHeadlessTurn never rejects is false: entry authority checks precede its catch.
Both fulfillment and rejection are handled by the drain promise. Ack-on-error stays
the inherited durable-ledger sequence contract, not a new success claim. The fixed
10ms reply-flush delay is inherited; cancellation no longer waits for it. Its
possible rare flush loss has a SIGTERM fallback and was not misreported as new.
Signal-path and same-chunk coverage remain useful follow-up controls; existing
readiness/survival tests and the explicit shutdown/late-result controls pass.

Reviewed production hash: daemon.ts
`1bdf0508676f77f6fe685cb23badd838cd41abe7ddbab98de0d576cab5499af4`.
Current test hash:
`6ffa249f7aa7a53ebacf587ce9c0d66b7ecc2d12434eec8be7ed0a24c7cbf4c5`.
CLI rebuild, types, full lint before review corrections and changed-file lint after
corrections pass. No release claim or new commit yet.

The reviewed full suite passed 7,784 tests / 6 skipped in 59.368 seconds:
`daemon-shutdown-reviewed-full`, log SHA-256
`c8511ea4591d4771a1e314c3d2ae3d1ac87721b4503cdfcc275f75a481d5a2fc`.
Final real-socket/readiness/survival run passed in 15.464 seconds:
`daemon-shutdown-final-live`, log SHA-256
`596b52c6360711174f1f0180b498d3bb3fec707fadac6666dd55adbf43993e98`.

Review follow-up controls now cover a single socket write containing shutdown,
prompt, job submission, ping and repeated shutdown. Both work requests are refused;
control replies remain available. SIGTERM and SIGINT handler tests hold a provider,
assert synchronous cancellation and retained ownership, release it, and verify no
late answer and final PID removal. These signal tests invoke process event handlers;
they do not claim separate OS-delivered-signal evidence. The existing subprocess
survival tests remain separate evidence. `daemon-shutdown-control-paths` passes in
15.822 seconds, log SHA-256
`9ad4c7b75efa05d3277bd2073a7893cd4f5152754bd2f20fdeb96aeaee7d8d4c`.
Test source SHA-256:
`5e14dfbbf74c0815f9830e31030ca99d7f9cf3d745e03c04581670b7012dadd6`.
Changed-test lint passes; all receipts report zero provider launches.
Full suite after these three controls: `daemon-shutdown-controls-full` passed
7,787 tests / 6 skipped in 58.913 seconds, log SHA-256
`9d320153545c443f5abc5a1afc9ecddea1697513417e51c311bc44c8c577f786`.
Final typecheck passes. The daemon comment now describes deadline/PID semantics
accurately; no executable change followed the reviewed repair. Final production
SHA-256: `f4cbdd3f3403beaaa741907e7d39c5a00619a0361415e70e97543034d66e1a91`.
Post-suite live checks: `daemon-shutdown-controls-last-live` passed in 15.631
seconds, log SHA-256
`c8e7d6f25152f5cf47234d8e4926c73f2bea331867b1f1ebee234ea83384a231`.
Zero provider launches. No verification subprocess remains running. The index
remains empty; no install, push, or active/global Agon change occurred.

Next ownership boundary, source-verified: mod-jobs implementation.ts still uses
its own ModularJobService for generated CLI/TUI commands. The actual CLI job.ts
uses daemon UUIDs, workflow payloads and polling; intent-meta.ts /jobs and /focus
use the interactive session jobManager. decorateCliFirstPartyServices provides no
Jobs host service. Do not conflate these stores or replace CLI behavior with the
simplified local engine dispatch. Required migration: mod-owned semantic handlers,
injected daemon transport/session effects, preservation of both existing contracts,
and removal of the duplicate factory operation only after consumer parity passes.

## Jobs daemon workflow ownership

Physical owner: `packages/mod-jobs/src/daemon-workflow.ts`. The CLI now injects
the existing command compiler, roster validator and config defaults. Planning,
payload allowlists, working-directory validation, engine-flag validation and
sequential command execution have one implementation in the Jobs package. The
daemon and HTTP resolver still use the same CLI configuration/entry-script/echo
boundary. This does not finish generated CLI/TUI Jobs ownership.

Pre-extraction file retained outside Git: `jobs-workflow-before.ts.txt`, SHA-256
`b38d373b48ed3d17f3bdf37ea355c6f27bb5d3ec78542d6892675f96137f6d08`.
New implementation SHA-256:
`1b21e8edfc9b011f6d833682e948d1f503e2fe67c43c873613ddae198ee5cc5d`.
CLI boundary SHA-256:
`cf88e2ec34e9f3844c1b0d02b23100f3aebcd674cd42d210e2dcf015e10eacb6`.

`jobs-workflow-body-parity` compares all six function bodies after TypeScript
transpilation, whitespace removal and exactly three host-injection substitutions:
DEFAULT_AGON_CONFIG -> host.defaults; buildCallCommands -> host.buildCommands;
validateCallEngineRoster -> host.validateEngineRoster. All six match. This is
bounded mechanical evidence, supplemented by execution tests, not runtime parity
inferred from directories. Log SHA-256:
`0c11f9ad0aeae294a7a31217b6a651ddbe3e367f562dc7bf315bd4a55c3f6c3d`.

Meaningful negative controls removed auto-approval rejection, nonzero-exit failure,
and pre-phase cancellation checks. Four assertions failed (including the existing
approval regression). All three guards were restored before rebuild/full tests.
`jobs-workflow-negative-controls`, SHA-256
`9d4a809a6e5975e7f9e86a49b8701d82f2eac67d45697ecaa63dd7feb5dfcbdd`.
The new real-child tests prove sequential execution, stop-on-failure and no second
phase after cancellation. Public compile-only evidence checks the host contract
and assignability to the existing Core executor; a missing compiler must fail.

Default Agon review packet SHA-256:
`1cb8f8497d6683944e929150a6cf3a254193131bb17894c380dd953c203b7f55`.
Codex and Kimi both completed and found no extraction-induced behavioral defect.
Adjudications against source:
- Package/type uncertainty: package build, public compiler test and re-export
  guard pass. Core exports the same Jobs types, not a second divergent definition.
- Kimi export-spy concern: no matching spies exist. Same-module lexical calls did
  not route through mutable module namespace properties before this extraction.
  Existing module mocks replace the resolver, not internal exported planning calls.
- Resolver-before-echo coverage added: removed roster and auto-approval refusal,
  configured label limit, and exact echo event/result. No provider launch involved.
- Unicode chunk-boundary controls already exist in modular-workflow-process.test.ts,
  including limits 1 through 5 and UTF-8 round-trip per emitted chunk.
- Null payload cannot reach the resolver through current daemon/HTTP transport:
  daemon-protocol.ts validates it before routing; agon-serve.ts rejects it with 400.
- Final-phase cancellation remains terminal-cancelled in JobService; both live
  daemon and HTTP execution wrappers also check cancellation after executor return.
- POSIX tests match current macOS/Linux scope. Windows is not a release target.
- A claimed doubled abort timer has no demonstrated native event interleaving:
  listener registration and final aborted check run synchronously, with no await
  or external callback invocation between them. Do not add machinery for that claim.
- Raw argv flag scanning, permissive fractional config flooring and label UTF-16
  truncation are inherited limitations, not claimed fixed by extraction.

Full suite `jobs-workflow-owner-full`: 7,791 passed / 6 skipped, 59.425s, log
SHA-256 `173ab63d2f0fe71d7d88ad8a2afef0848451b9a3cd5486c3b07d9e0b852ba739`.
Package build, CLI build, types, full lint, focused tests, generated drift,
re-export guard and Jobs dry-run pack pass. Review follow-up tests still need their
final run; they were added after that full suite.

The all-first-party pack gate exposed missing Brainstorm public declarations in
its declared pack list. Red receipt `jobs-workflow-owner-pack-check`, log SHA-256
`bad579f070aa47e4ff5ecb75f18bf26645198dbd1a529af0d6c0236bf9053e61`.
Every added declaration is reachable from Brainstorm's public index or its type
imports: collector, host, policy, presentation, result, runtime, scout,
session-record, session-workflow, workflow. The generator now lists these exact
ten files. The strict exact-content oracle is unchanged; no broad exclusion added.
Requalification `jobs-workflow-pack-brainstorm-declarations` passed Brainstorm,
then exposed the same mismatch for Forge's `dist/apply.d.ts`. Receipt log SHA-256:
`7dea22669c23f6ceb36a726503d69d76aa254f0f62bf0cd8555f3eaf92bc6ee9`.
Forge's implementation imports apply.ts; TypeScript emits its internal declaration
as part of the existing build. The exact pack inventory now declares that file.
This does not export a new package subpath or make private imports supported.
A read-only census of all current first-party declaration outputs found no other
undeclared output. Requalification `jobs-workflow-pack-declarations` passed:
36 packages, 344 ownership occurrences and 259 contributions, plus the existing
duplicate-dependency negative control. Duration 108.719 seconds; log SHA-256
`95d8c80c9369d824b20894eda36387fa68ee0703eb97e6c59f1f97aaa297d577`.
This pack/registration check does not prove the full migration ledger complete.

Kimi R2 (partial facade identity checks) is a nonblocking test suggestion: unchanged
direct re-exports plus body parity and compiler checks cover the boundary without
requiring an assertion for every constant. R3 payload shape/nonboolean checks were
added to the existing invalid-input table; fractional flooring and invalid zero
label limits are pinned explicitly. The old engine-denial fixture now removes its
own temporary directory in finally. No production behavior changed for these tests.

Final full suite with review-follow-up tests and both declaration corrections:
`jobs-workflow-reviewed-full`, 7,792 passed / 6 skipped, 59.481 seconds, log SHA-256
`5b776ca3e5fdebb2f536a2b5e5a84b40ee5b0deb1c0fca34a675046c95e7d257`.
Final types, changed-file lint, generated drift and rebuilt CLI pass. The last live
run `jobs-workflow-reviewed-live` passed (daemon, HTTP, child processes, public
types), 15.917 seconds; log SHA-256
`739350b97350783a21bb7d1173664a6ced22a2f37ac7fd09862e310162faa466`.
All verification receipts contain zero provider launches. Both review subprocesses
are terminal. No install, push or global/personal-state change occurred.
Index remains empty. This change is not independently committed yet: Core exports,
generated package metadata and previously extracted Plan/Brainstorm owners share
dirty integration files. Commit boundaries must include their verified dependency
closure, not claim a clean checkout by committing dangling imports.

## Generated session Jobs ownership

Confirmed defect: generated `/jobs` displayed two JSON `[]` outputs from its own
empty scheduler, instead of the existing session's table. `jobs-session-red` is
the failing real factory/host test; SHA-256
`2f2585fcc2f9d04be0ed778a89d8e9f9929d56ad464fcd80a3c3b80081f3f18f`.

`packages/mod-jobs/src/session-jobs.ts` now owns list/focus/cancel presentation and
state decisions. The TUI host supplies its existing manager and dispatch in a
public SessionJobsInvocationContext. The old intent-meta fallback calls the same
action implementation. Generated Jobs controls run directly rather than spawning
another session job to list or cancel jobs. No new scheduler/store is used by TUI.
The remaining CLI factory operate() path is still explicitly unfinished.

Factory disposal closes cached executable handlers before draining/removing
registrations. Session jobs themselves are not cancelled by disposal of the
factory-local CLI scheduler. Host manager and invocation context now have public
types instead of the DispatchCallbacks.jobManager any hole.

Legacy call-trace comparison: `jobs-session-legacy-parity` compares the exact saved
old switch against the new action over 72 combinations of state, command, action
and ID, including absent manager and long labels. All emitted events and manager
calls match. Log SHA-256:
`687468bcb988eee7b2c29380312cdcb6b99edde48e2c4d7cf968e131279cbae0`.
Old switch retained outside Git in `jobs-session-before.txt`.

Default Agon review packet SHA-256:
`5305980536bbe8acf0cf1b9f8e980300adabb644f7eceba892c3ea3132ecdced`.
Both Codex and Kimi completed. Verified adjudications:
- Host type-contract weakness: fixed with explicit public invocation annotation
  and DispatchCallbacks.manager type. Existing JobManager passes typecheck.
- Missing route oracles: real detectIntent/registry/dispatch now covers successful
  list/focus/cancel, no extra runAsJob, and cached cancellation after disabling Jobs.
- Cross-session isolation: same factory, two managers with identical local IDs;
  cancelling one session leaves the other's job running.
- Missing manager, usage, missing IDs, terminal cancellation, failed details and
  pre-aborted invocation controls added. No-host invocation refuses instead of
  falling back to the factory store. An intentionally absent manager within an
  existing host retains legacy empty-list behavior; no silent contract change.
- Fallback duplication concern refuted: intent-meta.ts imports and invokes the
  public runSessionJobAction; its old algorithm was removed.
- Cleanup speculation: close() only sets an admission flag. cancelAll() retains
  normal cancellation after close; persistence observation captures its own
  failures. No concrete synchronous close/cancelAll throw path was established.
  Existing unregister/persistence failure tests remain green. No speculative
  lifecycle rewrite was added to this repair.
- A fresh abort signal for synchronous Jobs controls is intentional. Cancelling
  another running job must not depend on that job's abort scope.

The initial full suite `jobs-session-full` passed 7,796 / 6 skipped (59.113s), log
SHA-256 `5026b80b6651fafabed32abff8ea3e3414333c176b6358c2b4e24d8ffcc17a50`.
Review follow-up controls and host types pass. `jobs-session-reviewed-full` is
running. Initial negative controls proved cached handler disposal rejection but
the router negative was masked by test teardown reading a generations directory
not yet created. The fixture now skips only that absent cleanup directory. The
repeated router negative fails on the intended ranAsJob true/false assertion:
`jobs-session-router-negative`, SHA-256
`193c7a3a2096a18724db06fffbc3b5445c8dc3562137db008cb1785459c6bd20`.
The direct-execution branch was restored. The earlier cached-handler control fails
on unexpected successful cancellation after disposal, not on teardown.

`jobs-session-reviewed-full` passed 7,796 tests / 6 skipped in 59.288 seconds;
SHA-256 `b339d037ec6539f255e988333ece5eeb2c6c507cb0a910485b8c9c85cef324a8`.
Exact Jobs package-content check passes, including session-jobs.d.ts; generated
drift, final CLI build, re-export guard, types and lint pass. The post-suite live
registry/session/daemon/HTTP run `jobs-session-final-live` passed in 15.753 seconds,
SHA-256 `d23f2e4d02aaa45204767c99e9bc6b5b7edabf17f5a264f40be2e9f548d0bd2a`.

The additional legacy-entry sweep reproduced a disabled-owner bypass: direct
dispatchMetaIntent({type:'jobs',action:'cancel',...}) still cancelled a session job
after the Jobs owner was disabled. `jobs-session-fallback-red`, SHA-256
`3c91b5df2c236bef3a86a3fdd74c327a543ea58104f97bd0a124a87d2f4690a2`.
The two compatibility entries now check the active `/jobs` or `/focus` surface
before reading or changing session state, then call the physical action owner.
Both negative reachability assertions pass, with the protected job still running.
Focused green receipt `jobs-session-fallback-green`, SHA-256
`c0387a9350da85f32aad7a62300205d123961d4be7d62107b2c4fa59108a0148`.
Types and CLI build pass. Full follow-up `jobs-session-fallback-full` passed
7,796 tests / 6 skipped in 59.123 seconds. Log SHA-256:
`7a3dd96aef38365a892c320258c7bd0a325fb27044f2dd285710e728bdf47311`.
The final local session/socket/HTTP run `jobs-session-fallback-final-live` passed
in 15.774 seconds. Log SHA-256:
`e77f0c4468a359d87544e4e7bba4c4ae21e333b427e0f11423edfa8c87fdfbd1`.
Both receipts record zero provider launches. This verifies the current dirty
candidate, not a clean committed release subject.

Next ownership trace: CLI Jobs still uses the daemon-backed Citty command in
packages/cli/src/commands/job.ts, loaded through lazy-commands.ts. The physical
Jobs factory's CLI contributions instead use operate() and a factory-local
ModularJobService. That is not execution parity: submit takes prompt/engine
instead of kind/input/payload, and the daemon action lists jobs. The actual CLI
still selects the legacy implementation, so this is an unfinished cutover rather
than proof that ordinary CLI invocations now run that divergent factory path.
The extraction must preserve daemon probing, startup, structured payloads,
client cwd, event replay/follow, JSON/JSONL, polling and exit codes. No production
change to that path has been made in this verification checkpoint.

Current source hashes:
- session-jobs.ts: d41401c5f4d33fcbbe24f835861c53a8cadff79c45bd0e799145648fc54a65f9
- Jobs implementation.ts: 72c53fb3896b00f3cbe1eeea07808a72034e5bc4595c6f7e2948f3c7c9761b19
- intent-router.ts: df575e8cb36d97d03aef418cd144c37330b06d4c35c47e6fc05bcfd69a304971
- intent-meta.ts: bfda1b2aa8c427cd8e3ef3f315a804e9878699cf5441fab014f3733e1aca9d51
- intent-session.ts: 59f37b1f17f3794942c47d2782ce36a20eaf899f35aae97197b5a540b3e9c7e9
- dispatch.ts: 2b811fdc17ea4d6b5a10fbb65fc2b60c5dad6a0ef358f94c1bae6cc68649fa31
- modular-jobs-session.test.ts: c6d085a3331c34998ac9676055b90ed8e9cdd983b8549269e3908bac6ddaa121

### CLI Jobs contract ownership extraction

Moved eight existing CLI validation, payload, capability and exit-code functions
and two client interfaces into mod-jobs/src/cli-contract.ts. CLI keeps public
compatibility exports and calls the same imported functions. Added the public
export and exact declaration to the existing generator and pack allowlist.
No dependency was added. The legacy transport, polling and generated-CLI cutover
remain unfinished. This extraction is not a release completion claim.

Default Agon reviewers codex and kimi completed, exit 0, packet SHA-256
`f95e639766efbf3b2d5a255460b3fd76309ea3fa7c25c52b14efce1a47ce367d`.
Codex log: `b17532fa876ad8abff7bc397ec6511d8f3b8e81ac0e2012dd3c91eeb091935c0`.
Kimi log: `e7de5a676576b08b56032611c6282605b65ba92368bf901d0441b950cdba439b`.

Adjudication:
- Confirmed: structural capability parameter rejected direct pong literals with
  sessionId/uptime through excess-property checking. Made the structural bound
  generic, preserving these callers without importing Core. The compile-only
  public-package test accepts the complete Core response union, pong literals
  and null, and rejects a non-string discriminator.
- Both reviewers noticed the client cwd binding differs from committed HEAD.
  Correct, but not introduced by this extraction: the earlier verified
  jobs-submit-cwd-red/green and jobs-daemon-cwd-red/green repair is documented
  above. Do not revert that security/policy correction for artificial parity.
  The attempted eight-body comparison against HEAD correctly failed on this
  pre-existing repair. Seven bodies match; do not claim eight match HEAD.
- Core JobOutcome/JobSnapshot compatibility: the CLI typecheck passes. Core
  re-exports the physical Jobs types rather than defining a competing shape.
- Added identity checks for all eight compatibility exports, not only six.
  The Unicode event test now uses the public package export as well.

Verification: Jobs build, CLI build, public compile tests, focused tests,
generated drift, re-export guard, full typecheck and targeted lint pass.
Exact offline package contents pass (`jobs-cli-contract-local-pack`); includes
dist/cli-contract.d.ts and no undeclared file. An earlier diagnostic pack command
used `packages/mod-jobs` without a leading dot or absolute path. npm interpreted
it as a GitHub shorthand; name resolution failed and no package was fetched.
The corrected command uses an absolute path and --offline. Preserve the failed
receipt as a harness invocation defect, not a product failure or passing gate.
Full suite `jobs-cli-contract-full` passed 7,797 tests / 6 skipped in 59.752s,
log SHA-256 `5b522f9b723123e4903d049f384af3710067b262bda9207617b86e3c9513e1fd`.
Final daemon-backed CLI/MCP and public-type run `jobs-cli-contract-final-live`
passed in 6.961s, log SHA-256
`d9e1ff3bc16f8c56475d73e60a97d2354c540df2b5b01fa94ace038587f8baf0`.
Both record zero provider launches. No commit or push at this point; the
generated files still include the earlier uncommitted extraction closure.
Current source SHA-256 values:
- cli-contract.ts: c53f01d28071e418cce6fa5ba79a18e4d921680c4515bedf27489500912146de
- commands/job.ts: 7401ef84ae1f0d0c099a059ff9a173b03b4e8b083f948698ac91d187a3ee3b25
- job-command.test.ts: 6abf51e972f8a9d55815b09ae7fbbc9c8ef611f3e59a0683918616200d33d919
- modular-jobs-type-boundary.test.ts: b6a1b051da74b9a780fdb1336a4d3b46c695495a28422585abafe4cec25384f8

### CLI Jobs client execution ownership

Extracted the remaining eleven client helpers and all six CLI action bodies
from commands/job.ts into mod-jobs/src/cli-client.ts. CLI now supplies only
daemon IPC/startup, terminal output and exit-code effects, plus the existing
Citty argument definitions. No dependency added. Exact pre-extraction source:
jobs-cli-client-before.ts.txt, SHA-256
`7401ef84ae1f0d0c099a059ff9a173b03b4e8b083f948698ac91d187a3ee3b25`.
The generated factory's local-store CLI path and legacy lazy catalog entries
still need cutover; do not treat this extraction as their completion.

Default review packet SHA-256:
`022362fb328263f204b0ecb1d738d46d7c66c32858047ccf0c4209031998a651`.
Both reviewers exit 0. Codex log SHA-256:
`c8a5a99afc8d21d4936cd7e3abc44174a38378d0fe936074b210e4139ca5dcbb`.
Kimi log SHA-256:
`74451dd20264a041314caf847db5060bafa736c7411b4786c68f1c02bf1220b4`.
Neither found a concrete runtime regression against the exact before source.

Review adjudications:
- Added repeated result/event polling, cursor advancement, wait/follow timeout,
  timer cleanup, stdout/stderr chunks, human-readable list/snapshot/cancel/result
  output, quiet true/false startup timeout, and console restoration on failure.
- Existing tests already cover compatible, incompatible and absent daemons.
  The live cold-start test exercises CLI submit and MCP-to-CLI status, result,
  events, cancel and submit. Added JobList to exercise the sixth CLI action.
- Both package and CLI compile. The public compile-only test proves Jobs request
  assignability to Core and Core reply assignability to the Jobs client boundary.
  DaemonJobRequest's cancel variant explicitly owns optional reason.
- requestOrFail's helper signature is narrower: Jobs requests and ping only.
  Consumer tracing finds no non-Jobs caller or imported consumer outside this
  client. It is a private CLI helper, not a Mod API contract. No runtime coercion
  or protocol change was added to manufacture type compatibility.
- JobEvent has seq/ts/type/data, not a required jobId; the supplied fixture is
  valid. Kimi's suggested missing jobId was not a verified defect.
- Initial non-pong probe fails immediately. Only the post-start readiness loop
  retries non-pong replies, exactly as before; no speculative change made.

The cursor negative control replaced its advancement with a no-op, rebuilt the
actual package, and failed the third IPC request's expected afterSeq assertion:
jobs-cli-client-negative-cursor, SHA-256
`f6dbdff1b8e0a667cca94948d06c28a5eaf46923aa39b04ef58f2259f43ad0e9`.
Restored source and rebuilt Jobs and CLI before final verification.
Public tests, typecheck, lint, generator drift, re-export guard and exact offline
package contents pass. Full suite jobs-cli-client-full passed 7,813 tests /
6 skipped in 58.495s, log SHA-256
`b2b6de81d30b9a84af58311002b5ba1a179b62a026354656c9eb66a5d2dba789`.
Final daemon-backed CLI/MCP run jobs-cli-client-final-live passed in 7.219s,
log SHA-256 `7562fb59d1926121eb58f32afab8179089856ec0e1a7cc8fed4774e6358337e2`.
Both receipts record zero provider launches. No active/global install changed.

Next required transition: retire the generated factory's divergent operate()
CLI path by injecting this same physical client's narrow host at invocation.
Generate all six CLI argument projections from one Jobs-owned contract, preserve
the parent command's no-op semantics after Citty child dispatch, and remove job
from the legacy lazy catalog. Daemon lifecycle itself still needs its own owner
transition. Test real parsing/help/defaults/aliases, all six commands, disabled
and cached invocations, and cleanup before claiming cutover. Then qualify and
commit the complete dependency closure; do not commit a package factory that
expects a host missing from that committed checkout.

Current production hashes:
- cli-client.ts: 0a33bd460fd3b42c9ecc7b9422f1e774321f51abaf71d9d558a3bc64bd21df81
- commands/job.ts: 0ec14b5a60b5e37b4743b8cb0353b989f84957dd98d6b11f7810a10068330b3c

### Generated Jobs CLI cutover

The `job` command and its six children now come from the physical registry.
Removed the legacy lazy loader and the factory-local operate() implementation.
The factory no longer constructs a scheduler or dispatches an engine for CLI
submission. The existing persisted scheduler class remains available and tested;
daemon Jobs and TUI JobManager retain their separate, explicit process/session
ownership. Daemon lifecycle itself remains a legacy loader, not a completed mod
cutover. Direct invocation of its unused generated placeholder now refuses with
exit 2 instead of falsely listing jobs.

One Jobs-owned cli-projection.ts holds original argument metadata and derives
schemas/projections. The compatibility command imports the same definitions.
Frozen original definitions were evaluated from the archived pre-extraction
module without invoking any command, then saved as
tests/fixtures/modular-jobs-legacy-cli.json, SHA-256
`295a5bbd2f9f209e4dbc7081acd12d93e893642d7fd9aaf513e5062be714f7be`.
The metadata, aliases, defaults, required fields and positionals compare exactly.
The initial Citty union-inference compile error was fixed with a discriminated
argument type and explicit ArgsDef generic, not an unchecked runtime workaround.

Default reviewers completed, exit 0. Packet SHA-256:
`5938c89f4897349e31e779803e9d9b44bed8bcfb8754ec351d13ddb01d9fcafa`.
Codex log: `cfe9134762350068857e238ad206f54cce2be6ee69be6a42b0a77b2df2fceaeb`.
Kimi log: `9de36531715ee8ff740849ae934c3408c3ba117c5baf7346f01397e9f1c50f43`.

Confirmed findings and fixes:
- MCP could accept a successful transport reply after disposal or abort. Both
  cases reproduced in jobs-cli-cutover-mcp-red. Recheck active and signal after
  transport. The first green assertion wrongly expected an error object; the
  established Mod API commandResultToToolResult throws CommandExecutionError.
  Corrected the test to require that existing rejection contract. No production
  error contract was changed to satisfy the test.
- Final CLI rendering/exit codes lacked an authority recheck. Generated command
  closures now capture their original host generation at construction and check
  before execution, after completion, before streamed effects and final output.
  This also fixes cached non-Jobs commands. A cached History command executed
  after host replacement with the guard disabled: negative-control log SHA-256
  `4991966b806fd5a7c5888e71718884b1cffa411d7a54b74f9965f007b211ea04`.
  Restored guard passes. An earlier green run failed only because its old error
  regex did not include the precise disposed/replaced host message; the updated
  test requires that exact rejection. Do not count that regex failure as a
  product defect or as the negative-control failure.
- Quiet startup temporarily replaced global console.log across an await.
  Replaced this with a quiet option on existing startDaemon; only its local
  info/warn/success reporting is suppressed. Errors remain errors. Overlapping
  startup tests prove the process logger is never changed.
- Partial factory registration now invokes the same reverse-order cleanup on
  failure and invalidates cached handlers. Kernel also rolls back the registration
  transaction (activated-surface-generation.ts); local cleanup is separately
  tested for a fourth-registration failure and for aggregated cleanup errors.

Adjudicated non-findings and boundaries:
- `cliCommands:0015` is top-level `daemon`, not `job daemon`. Actual daemon
  start/status/stop still resolve through the legacy loader. The real daemon
  integration exercises this, and direct generated refusal now has a test.
- Parent no-op follows Citty's actual runCommand implementation: child is awaited
  before parent run. The live submit result is parsed as one JSON document and
  all six actions run through the MCP-to-CLI bridge, detecting extra parent output.
- Worktree/wt reconciliation is not dead merely because those commands moved
  out of the kernel map: generated entries populate that same commands object.
- The minified trailing persisted-scheduler tests predate this cutover. Their
  semantics are not new production responsibility and were not deleted.
- Four old factory-storage tests were adapted, not silently skipped: retained
  public scheduler still tests persistence failure/bounded flush; new factory
  tests cover pending IPC disposal, no local state/provider effects, absent host,
  reverse cleanup and partial activation. No scheduler is owned by this factory
  now, so it must not invent storage writes simply to retain obsolete assertions.

Verified so far: focused lifecycle/projection tests, cached disabled Jobs and
cached replaced History tests, actual CLI/MCP cold-start and all six actions,
types, lint, builds, drift, re-export guard, and exact offline pack contents.
Full suite jobs-cli-cutover-full passed 7,819 tests / 6 skipped in 58.676s,
log SHA-256 `c86c0a4769625ec23898fc447719ad549d6a208721cc65a9fe4c50276a7fdca2`.
Final daemon/HTTP/generated CLI/session run jobs-cli-cutover-final-live passed
in 15.862s, log SHA-256
`b1a2f45990c1c9904c26dfe2d67700a971ccd4ee268f2e7dd5dcfc3084ce4aa6`.
Both receipts record zero provider launches. No installation, push or personal
state change. No commit yet: release qualification still needs one coherent
committed dependency closure, not a dangling package-only commit.

Current production SHA-256:
- implementation.ts: 2d4c8856de123039561ec36578dcf71f86a0f3b8fc94bd7e68ab8a7afff313c4
- cli-invocation.ts: 7b5f74d0023253119d52e39853633f8bf1a73d838e2061a225d5ff1d07f9e089
- cli-projection.ts: d4c7d01e91959d41f241b8b741d3ac66ba4069065291a178db8f9c6f92a585c4
- lazy-commands.ts: bdd7d69374a19bfdcba0b6f1cbb0d7c27f5660df88b41b4baa0355f2cec02abe
- cli-host.ts: d3ee324780f9d4c6d0755982450cbadadfaedcd78599d11c589b3f950ae2c946
- daemon.ts: fb25139d3a92ceaa19422b19261926d296987b3ce94250205ea00a0d2b1cc11d

## Daemon process controller ownership (2026-10-10)

Moved 14 existing functions from CLI commands/daemon.ts into the physical Jobs
package daemon-controller.ts. CLI retains socket serving, headless execution,
and explicit host bindings. The ownership map assigns daemon state and the
daemon command to Jobs. This is one ownership boundary, not completed daemon
extraction or release qualification.

An AST-printer comparison of all 14 function bodies against the durable exact
before copy daemon-controller-before.ts.txt matched after only the six explicit
host substitutions (directory, home creation, server, spawn, ping, shutdown).
An earlier scanner-only comparison mishandled template literals and reported a
false mismatch; the parser/printer comparison resolves that diagnostic.

Default Agon reviews, no reviewer tools, packet SHA-256:
`d98071bdc13f78d53e4764fa813916471f0056d0e8ddfe54d0cb8909454b966a`.
Codex log: `5bf49e83f86a508f189838f3d3f678c5c7afc87d6ff82d0abeca4b42012866ac`.
Kimi log: `bac4fac9ad14e841aa6fc33a5314effdfb3a1d35f79fb00806d7c6ef28a70ef3`.
Both found no extraction regression. Their prose is not executable evidence.

Adjudication:
- Direct factory coverage was missing. Added independent directory/callback
  tests, foreground await/failure propagation, and live/hung start refusal.
- Removing the hung refusal fails the exact test with Unexpected daemon spawn.
  Restored the guard and rebuilt before final checks. Negative log SHA-256:
  `60a103069e9ab0da2bd1f08daf059365cd7ae31f11cf1727a8e67ddf68a8a577`.
- Kimi's claim of zero stop coverage is false outside its bounded packet.
  daemon-survival tests actual CLI stop; daemon-jobs-execution-authority tests
  pending provider drain, retained files, shutdown cancellation and re-entry.
- Host bindings are intentionally for this Node CLI process, not a generic
  portable/sandboxed controller. Filesystem, signals, argv, environment, timers
  and diagnostic streams remain process-owned. Documented this scope rather
  than adding speculative injection APIs. Quiet errors remain visible by design.
- Ping/shutdown response narrowing preserves the old explicit discriminant
  checks; no unexpected frame becomes successful readiness or shutdown.
- Both reviewers raised inherited ownership hazards. Source confirms server
  publishes PID and starts heartbeat before listen succeeds, and error cleanup
  removes socket/PID without comparing ownership. Concurrent foreground starts
  can therefore damage the existing server's files. This needs a reproducing
  isolated test and an ownership-safe fix, not dismissal as inherited.
- Additional inherited hypotheses to verify: PID reuse before fallback SIGTERM,
  non-atomic PID publication, no-PID/socket-only cleanup and stale PID socket
  takeover. Do not mark these fixed from this extraction's passing tests.
- Heartbeat comment and status behavior differ: stale heartbeat is shown
  separately but does not override live process plus answering socket. Preserve
  behavior during the move; clarify in the later lifecycle repair.

Verification:
- Initial focused run used a bare vitest outside npm's PATH and never ran tests.
  Corrected command to npm test; 44 tests passed. Failure receipt retained.
- Full lint caught the now-unused CLI existsSync import. Removed it; full lint
  and the final changed-file lint passed with zero warnings.
- Public package build, CLI build, typecheck, generator drift and re-export
  guard pass. Offline pack matches all 21 declared files, 117282 unpacked bytes.
  The first pack command used a relative name without ./ and npm treated it as
  a GitHub shorthand; DNS failed. Corrected to the absolute local directory.
  No package was installed. Both pack receipts remain available.
- Final full suite daemon-controller-final-full: 7823 passed, 6 skipped,
  58.922s; log SHA-256
  `7ae80209b76516a6c6ff23498b7ee3e2d68fb32166addf520d5b21f822402956`.
- Final actual daemon/HTTP run daemon-controller-final-live: pass, 16.087s;
  log SHA-256
  `17e3102684fd504d81b6a60f919b93f115ad8ddf1426ac51a7d21bddbacd4761`.
- Test receipts report zero provider launches. Review calls are separately
  authorized live model runs. No active/global Agon or personal state changed.

Current source hashes:
- daemon-controller.ts: 75804d926a83dbe6cebd5d9ffcde4db1c5739a565ef75af643bf7f2ca6b2f790
- CLI daemon.ts: 9f685d6ca07cf24d9f730c2e4aa6507c97e193ecd1b077fe895f40149d727bf4
- daemon-command.test.ts: 7f2b29ecf09875fbe5f38dec4e0b245b1f74f320bc315bb6fde516dc4bc124fd

Next: qualify the accumulated dependency closure for local commits, reproduce
and repair the confirmed competing-server ownership hazard, finish the daemon
generated dispatch/host ownership, then continue the original roadmap. The
index is empty; 151 tracked paths and 259 untracked paths comprise inherited
and remediation work. Do not sweep-stage or claim a clean committed subject.

## Review resolver checkpoint (2026-10-10)

Committed `dfd08272a5b17bcc00852f88cb4af2a5d783e6f1` locally:
`fix(modular): consolidate review target resolution`.
Seven explicit paths, 427 additions / 266 deletions. Tree object:
`3d8b97577a7e73e7ae241e0df5592ebd93a03871`.

Includes the canonical shared target resolver, CLI forwarding, shared explicit
reviewer resolver used by CLI, target contract tests, and the CLI's workspace
dependency in package.json and the lockfile. The optional Plan adapter-injection
hunks in CLI review.ts were excluded from the index. Only the CLI dependency
edge was staged from the lockfile; Core/MCP Jobs and MCP Review edges remain WIP.
Index path list and tree hash were asserted immediately before committing.
No unrelated working bytes were replaced. Index is empty afterward. No push.

Pre-commit evidence against the integration working tree:
- review-checkpoint-build: full build including forced types, pass, 151.834s;
  log SHA-256 3a17d3cb90ac217a73d46b335c86c89c2e6010b41360b59a3d1c14bdef94d903.
- review-checkpoint-full: 7823 passed / 6 skipped, 60.036s;
  log SHA-256 b85130e9d1b31fef60be2f7fb045e7e2a4ea07a31cea5165c36ad53b4eb3ff0f.
- review-checkpoint-lint and review-checkpoint-reexports: pass.
- Both earlier default Review target and selection review packet/log hashes
  rechecked against their receipts. Follow-up corrections remain adjudicated
  above; no extra panel was run simply to reconfirm the same fix.

This is a code checkpoint, NOT a clean-checkout acceptance receipt: the full
suite ran on the integration working tree. Independent clean committed-subject
qualification remains a release requirement. F9's physical mod and CLI/MCP host
selection changes are still unstaged and require their own coherent checkpoint.

## Competing daemon ownership regression (2026-10-10, verification running)

Two actual foreground CLI processes reproduced the inherited bug. The second
failed bind deleted the first process's PID file. The fixture records and kills
only its own spawned processes even when the PID file is lost. Red receipt:
daemon-owner-collision-red, log SHA-256
152d763b1d5042f5475717034fc824cc8a05c6aa35303f68f9c1f52070f1080a.

Repair uses the existing exclusive Unix socket bind, not a new locking system.
Reject an existing live PID before server effects. Do not publish PID or start
heartbeat until listen and permission setup succeed. A failed bind owns no
socket to unlink. PID cleanup compares the published process/session/start
identity. This intentionally supersedes the earlier pre-listen ready:false PID
publication: that publication let competing boot overwrite the current owner.
Readiness tests now prove absence of both PID and heartbeat before listen and
successful publication afterward; chmod failure still cannot publish readiness.

The real collision/start/shutdown suite passes (daemon-owner-collision-green,
15.81s, log 651a982e45290d911e3772db4fcd73c6666cbb2b952aad5e7a8ebd302a4b0365).
A separate test simulates the other server publishing its three files after
preflight but before EADDRINUSE. All three remain byte-exact. Types pass.
Full suite, lint and default Codex/Kimi reviews are running; not yet qualified.

Follow-up evidence and review adjudication:
- Both default reviews completed, packet hash
  d25795636d1bb07d5633d85cb916e5fec87d9fdadd186582b3bec4bc8965f776.
  Codex log e9d591be4e3b96c8accbc2cc352d5277003eb05f3c14074d5de17ca01cd9cfa1;
  Kimi log af364178c91ab8276be9578ec5f8d94e2bcab91da70a6f91d14d4ec9c52b2a35.
- No extraction regression found by either reviewer. Their claims about
  lifetime safety are not accepted as proof. In particular, Kimi's claim that
  SIGTERM-before-listen is fully safe was incomplete: a later listen callback
  could publish readiness and start heartbeat after cleanup had resolved.
  Reproduced in daemon-late-listen-red (ec94042034474a6fb4d100c5d380660fd254730570b68248b3d28cc643205084).
  The callback now closes and returns when shuttingDown is set. Same test passes
  in daemon-late-listen-green (f8dff1b0b4aa838c9c1bf3ca577da92b16a18d8bcee329f0348418d0fdd83e1c).
- Full suite daemon-owner-full exposed a real partial-PID publication:
  daemon-survival read an existing but empty PID file and JSON.parse failed.
  This is not dismissed as a flake and no retries were added.
- Deterministic failure control injects an error after opening the write target.
  Before repair, the previous record becomes unreadable. After repair, it is
  byte-complete and no temporary file remains. daemon-pid-publication-red log:
  cdb1560a5759471b405988f20baa5a6a4ab5e359ea878c55a480e9e8e025c2e5.
  writePidFile now exclusively opens a unique 0600 sibling, writes/closes it,
  and renames it over the target. Cleanup only removes a temporary file whose
  exclusive open succeeded. This promises atomic visibility, not fsync or
  power-loss durability. Existing best-effort error reporting remains.
  daemon-pid-publication-green passed unit/readiness/live tests, 8.051s,
  log 63ab4b903588406f3a4f76bea7a4b0b512569144371f43a7bfb334dd07f7deed.
- The packet predates these locally verified follow-ups. Per the one-review
  rule, do not pretend they received a fresh panel. Preserve red/green evidence.
- Still open: probe stale-observation unlink, stop identity/signal correlation,
  current socket identity after external pathname replacement, and release
  qualification. Kimi's claim that close prevents every rebind race is not a
  verified fact. Do not cite it to close those dimensions.

Source hashes after follow-ups:
- CLI daemon.ts: 068880418ba4bea226491ea56da00911a5d15a93d272c7cf7716d429f0951d49
- daemon-controller.ts: d88a67df6a32b8363eb11fe584098d8fc0f896eb1d67548cf0e362dbefd9f181
- daemon-start-readiness.test.ts: 78936b12f57d1eadb38c29a2b2b2585d2d6cf3bf8e7197d08c00610d1275d5b7
- daemon-command.test.ts: 4e53f1dd2e0e896c49cc64fdcc255cac5fe39c326e6293f010d7edc2d7055e87
- daemon-survival.test.ts: 8cdb385b572aa17d4eafbdbd9f80212d923b41921939f2bb6d07b9afa9c83355

Final local verification for this boundary:
- daemon-owner-final-full: 7827 passed / 6 skipped, 59.022s,
  log fdb44e559cbc0079b51011e96bc8343e9761f9a4c62f5fad225796cd8988c8b3.
- daemon-owner-final-lint, daemon-owner-final-types,
  daemon-owner-final-cli and daemon-owner-final-guard all pass.
- daemon-owner-final-live: actual CLI process/socket/HTTP tests pass, 15.995s,
  log f8fa7e61b2e1a753fb6fc8d4a0e2ffeedf071a172ec5235c03f5c39e53ce69b0.
- All test receipts record zero provider launches. Review calls completed and
  their temporary authentication copies were removed by the wrapper.

The daemon changes remain WIP within the Jobs extraction closure; the Review
resolver checkpoint is committed. Index empty, no push or installation. Next
checkpoint should isolate F9's remaining host/mod changes using the same
selective-index method; then retire remaining Jobs daemon ownership and address
the source-confirmed probe/stop races. Clean checkout/release gates remain open.

## F9 explicit Review selection checkpoint (2026-10-10)

Committed `3e453df751151e95f4fb86713b6f31bf888329b6`, tree
`48503cb2fb7d02d3f40db48bdc34fbc0c33e768f`.
Eight paths; 208 additions, 26 deletions. Selective staging excluded the pending
Plan host import, MCP Jobs host/dependency changes, and unrelated Cesar guards.
The complete index path set and tree were checked immediately before commit.
Nothing pushed, installed, promoted, or changed in the active Agon.

Qualification checkout: `/Users/ra/dev/agon-audit-qualification`.
Its sources came from that exact staged Git tree, not working-tree bytes.
Existing node_modules were copied with APFS copy-on-write; all @kernlang
workspace symlinks resolve within the qualification checkout. Package outputs
were built there from source. This is independent source qualification, NOT
a clean dependency-install or complete release receipt.

Receipts in this directory:
- `review-selection-index-build`: full build passed, 151.754s;
  log SHA-256 4df17efc62ba9cb8ba6be1181430b489b0a228da50423c5cccadd884bd845af0.
- `review-selection-index-full`: 6,700 passed / 6 skipped; 555 files passed,
  one skipped, 47.84s; log SHA-256
  b2f2f38277e3c56098345577e2501159ca979dd5c92b1d7d0681dec54dc23977.
- `review-selection-index-lint`: lint, typecheck and re-export guard passed,
  68.1s; log SHA-256
  d854fbf8eba08b4a271e8209c3182bf6001b34d0ba3a1872262f3560b0a6000d.
- `review-selection-index-cli-reject`: actual built CLI exited 1 and printed
  `Unknown Review engine: audit-unknown-engine`; log SHA-256
  71959854f4b5f538b5c815a586db32e450dc3649a29184e18cd979ed464da596.

All four receipts record zero provider launches. Earlier Codex/Kimi review
log hashes were revalidated; their source-verified corrections and negative
controls remain documented above. This is not a new review of all pending WIP.
The lower test count than the integration working tree is expected: uncommitted
ownership extractions and their tests were deliberately excluded.

Remaining work is unchanged: finish Jobs and other ownership closures, retire
adapters, resolve confirmed daemon races, then qualify the whole committed
candidate. No component pass closes the full goal.

## Daemon stale-observation fixes (2026-10-10)

Confirmed four cases in `daemon-stale-owner-red` (4 failed / 22 passed),
log SHA-256 c2ee16be5d4946d308b2b7dab19d856bab8af1ac6db5642102c9c3f0a54f7678:
- PID/socket publication during awaited ping was unlinked by the old probe.
- A stale dead PID caused removal of a responding socket without a ping.
- Both PID replacement and PID removal during awaited shutdown still caused
  SIGTERM from the old observation.

Jobs' existing controller now snapshots PID/socket inode, timestamps and size;
checks changes across awaits; checks a socket even when the recorded PID is
dead; and leaves changed ownership alone. Failed stale-file removal propagates
instead of reporting successful cleanup. No dependency or locking subsystem added.
`daemon-stale-owner-green` passes; log SHA-256
a015254a3373199e358dafe4e6cde148f543ef528400b096bf2c5914739ae680.

Default isolated Codex/Kimi review packet:
ceaa81d6af7c294a334b928bcc1bdb920333e31da2a46a25281fbe294a4423d9.
Codex completed, log SHA-256
3c5bd377af648f2201217d533e9351fe8101db038b9bc8d69f238365fda4fd8a.
Kimi was still running at this note; its opinion is not assumed successful.

Both Codex findings reproduced in `daemon-stale-owner-peer-red`:
2 failed / 32 passed, log SHA-256
8456dd85450871b1e4099421313c86769d6c89909a1c59ac4fa36a61b5ab1968.
- Acknowledgement is not completed shutdown. With no PID, stop unlinked a
  socket whose server still drained. The regression runs the built CLI against
  an actual Unix socket whose server acknowledges but keeps listening.
- Completed concurrent cleanup was incorrectly reported as a hung daemon.

Corrections: acknowledged shutdown waits within the existing bounded polling
window for server-owned file removal; never sweeps those files itself. Pending
drain is reported as pending. A changed probe observation with both files absent
reports no daemon. Other changed observations still refuse startup, with a
retry message rather than claiming a known live PID.
`daemon-stale-owner-peer-green`: 45 passed in three files, including actual
process/socket tests. The socket-only case also proves a replacement bind gets
EADDRINUSE. Log SHA-256
c015bf170f65fc6d5254e8557e2145d5e6b0ccac668031ff4d963b62fb93233e.

Latest broad gates:
- `daemon-stale-final-full`: 7,833 passed / 6 skipped; 635 files passed / one
  skipped, 59.129s; log SHA-256
  14d91b2d20e349f679a9f326c4bf6c9b465934846913fde3eff8ea50beb825c8.
- `daemon-stale-final-lint`: lint, types and re-export guard pass, 70.421s.
- `daemon-stale-peer-build`: Jobs and CLI build pass.
- Test receipts show zero provider launches; model reviews are separate.

Source hashes after corrections:
- daemon-controller.ts: 63151d2f527bfa2bc048e9fa8c3bbb93ecd407053be3b316f13fd80f5211251b
- daemon-command.test.ts: 9b1c0d253e1a13f9429cd6d9b9352203f15f3093d4adfb94c6890cce91e4ad12
- daemon-survival.test.ts: 8b09b80a6d56c2e64b80065943c32ec819609cf6e0c62a1787637d48ea76a70e

Limits remain explicit: snapshots do not establish an interprocess lock, prevent
arbitrary path replacement between synchronous filesystem calls, or prove OS
PID identity after PID reuse. The server's own close/unlink lifecycle still
needs its ownership review. These fixes stay in the pending Jobs extraction
closure; the committed Review checkpoint is separate. No release claim.

Kimi finished with log SHA-256
c605e49cc4c2d964b9fd2065329fd662e63f612cf33f5624acdf6d6d047ffa84.
Temporary Codex/Kimi authentication copies were checked absent after both runs.
Source-verified adjudication:
- R1: same completed-cleanup/incorrect-message issue as Codex; corrected above.
- R2: chmod changes ctime, but the new diagnostic does not assert a hung PID.
  A concurrent daemon publishing readiness must prevent another start anyway.
  Dropping timestamps globally is rejected: PID content can change in place
  under legacy writers, and inode-only comparison would miss that. Conservative
  retry during observed ownership changes remains intentional, not a claim
  that every concurrent start succeeds on its first attempt.
- R3: non-ENOENT inspection errors fail closed. Citty runMain catches command
  errors, prints their message and exits 1; they are not unhandled rejections.
  Its generic diagnostic also includes stack context. Better operator wording
  is a UI opportunity, not evidence that cleanup should continue on EACCES.
- R4: the claimed permanent swallowed-SIGTERM loop is refuted: server cleanup
  removes its SIGTERM/SIGINT handlers before resolving. Do not recommend killing
  a PID from a stale file. File disappearance after unacknowledged shutdown
  conservatively aborts further effects; another status/stop can inspect anew.
- R5: partial self-clean may leave a dead PID file for the next fresh probe.
  This is safer than deleting from an invalid observation; no perpetual refusal.
- T1/T3: tests now prove acknowledged replacement files remain untouched and
  unchanged dead PID/socket files still clear on stop. This does NOT prove a
  shutdown request cannot reach a replacement before the post-request check.
  Kimi's claim that the latter race is already closed is rejected.
- T2: both probe and stop now have failed-removal controls. Stop incorrectly
  swallowed the failure and printed success. `daemon-cleanup-failure-red`
  reproduced it (1 failed / 30 passed), SHA-256
  c1adb49b1740351c64dce9bb3e77436a08063733640926d89a41b18b116d4970.
  Removing the two silent sweep catches fixes the same test; green receipt
  SHA-256 6440c97bbc88a817637954e41054258abcb2573badebc747d4bac466f67af02d.

Superseding gates after that final correction:
- `daemon-cleanup-failure-build`: Jobs and CLI builds pass.
- `daemon-owner-qualified-full`: 7,837 passed / 6 skipped, 58.63s;
  SHA-256 396f256e6ab372fd99709fddc335cd6c4631caf2e172486dcf0ab4fb3e4d4a43.
- `daemon-owner-qualified-lint`: lint, types, re-export guard pass, 70.505s.
- daemon-controller.ts SHA-256:
  4a813b7d313805a4434ef656d18c55087340d82c3b6ca81ed055f121661eb039.
- daemon-command.test.ts SHA-256:
  3c04a2ca14911be77bb2ca9880b56f8a094c03509b3140a359c995615f2c8e1e.

Evidence correction: `daemon-stale-final-live` included a nonexistent second
test filter. Vitest silently ignored it. Retain that receipt, but do not use it
to claim the requested two-file scope ran. `daemon-stale-final-live-exact`
reran the actual existing integration path and passed. Future calls resolve
test paths before execution. Latest final run is `daemon-owner-qualified-live`.

Next ownership closure: daemon remains a legacy loader in
`packages/cli/src/lazy-commands.ts`; physical Jobs contribution `cliCommands:0015`
still returns a dedicated-host refusal in `cli-invocation.ts`. Move its command
projection/dispatch to Jobs, inject the host, and remove the legacy loader only
after live parity and disabled/cached-generation tests. The server loop itself
still resides in CLI. These are open implementation requirements, not waived
by the controller tests. Whole-release clean qualification remains open.

`daemon-owner-qualified-live` completed: seven real process/socket integration
tests passed in 10.424s, zero provider launches. Log SHA-256
a0f2ba0fda20c69b326b3cc49c284d8176cae44f6d95830412940c846f4d6d3b.
Index is empty, `git diff --check` passes, and no review/test subprocess from
this boundary remains running. The Review qualification checkout is now detached
at its committed subject `3e453df7`, with an empty porcelain status and the same
tree as the tested index. No new dependency installation was performed.

## Daemon command ownership and review fixes (2026-10-10)

Subject: candidate worktree on committed HEAD `3e453df7`, still with inherited
Plan/Brainstorm/Apply changes. This is working-tree evidence, not a clean release
receipt. No push, installation, personal-state mutation or dependency addition.

Physical Jobs now owns daemon metadata, argument projection and action dispatch.
The generated CLI injects daemon host bindings and executes its registered Jobs
contribution. The old `daemonCommand` is a thin compatibility adapter, no longer
the generated loader. Server/socket loop and headless dispatch remain in CLI;
their extraction is NOT complete. Job auto-start forwards the host authority
into the controller rather than checking only around startup.

Evidence before review corrections:
- `daemon-projection-red`: ten failures before implementation.
- `daemon-projection-green`: one metadata failure retained. The old generic
  pre-boot catalog says `daemon`, unlike the actual legacy command description.
  Corrected the test location to the activated registry, retaining the exact
  legacy literal metadata and argument oracle. Did not rewrite the catalog or
  weaken production parity. HEAD's old daemon command confirms those literals.
- `daemon-projection-green-r2`: 59 passing tests.
- `daemon-projection-focused`: projection, session, job command, lazy command,
  and daemon controller tests pass.
- `daemon-projection-full`: 7,848 passed / 6 skipped, 58.91 seconds;
  log SHA-256 a75cf162271e58d669f1ae0baac6729551548a090851b3e7815bc61c6dc0adc6.
- `daemon-projection-lint`: lint/types/re-export guard pass, 69.854 seconds;
  log SHA-256 f1e3c7fcda1a2b4ac3f876eea4f9022a70650fb94c61c4a3b2d2294e43a9e755.
- `daemon-projection-live`: seven built-CLI/process/socket integration tests pass.
- First-party package generator check passes (36 packages / 290 files).

Default isolated Agon reviewers used bounded packet `daemon-command-owner`:
SHA-256 a387ba5ddd64594a4e2bd380bf4965c628b69a7d564db248b70a7021ad4110af.
Codex log e4bb8a601f749354ec23e34fa84f58a4a1bd94e3f0125c2fbeabbaa463aace12.
Kimi log 9b648d4d0405b20aa5bca7c150afac895890dec2a096ce20d707afc3caff9137.

Finding adjudication:
1. Codex P1, confirmed: job startup forwarded generation authority but omitted
   the combined mod-active/cancellation guard inside the awaited probe. Two
   negative controls reproduce an unexpected spawn, for both abort and disposal.
   `daemon-start-invocation-red` failed twice; SHA-256
   597deb38ed7be86216eb6f8d2ffa690bf00e74812491e6ba48f5721c84b1ea05.
   Fixed the existing JobCliHost startup contract to pass the combined guard;
   CLI host composes it with captured generation authority. No parallel owner.
   `daemon-start-invocation-green` passes, SHA-256
   3eceb20252f21e285837c7d1931ebab75f5f61c965ba335fa653c57d41cfe7be.
   Kimi's claim that all startup guards were already combined is refuted by
   these negative controls.
2. Codex P2, confirmed: foreground server lifetime ignored invocation abort and
   Jobs disposal. `daemon-lifetime-red` reproduces both failures; SHA-256
   896996e6d7e4fcf289deeeda77be8ee9c9c5b719f67779008eb52e75dd19736c.
   Added one activation-lifetime signal, combined with invocation cancellation.
   Existing host forwards it to the existing server cleanup path. Cleanup drains
   active work, removes the abort listener and signal handlers, and retains the
   existing drain-deadline ownership rules. No new shutdown implementation.
   `daemon-lifetime-green` passes unit boundaries and real socket/provider-shim
   cancellation/drain tests; log SHA-256
   ea36498086aae265cf3e5f1ad5aa74530f5c9103b49068cba3d85b10cd8a21e5.
3. Kimi quiet-mode warning: not a cutover regression. HEAD prints spawn errors
   directly to stderr; preserving diagnostics is deliberate. Quiet suppresses
   normal startup chatter, not spawn failure. No evidence of a promised silent
   stderr contract. Keep existing behavior.
4. Kimi hard-coded child argv: verified inherited coupling, not a new defect.
   Record for server/launcher extraction. Jobs currently owns the public daemon
   action names; do not add a second launch abstraction just for this review.
5. Kimi wrapped exit code: not a defect. The contribution returns CommandResult;
   generated CLI applies it. Calling process.exitCode inside the contribution
   would duplicate outer-surface ownership. Direct compatibility client retains
   the host setter. No verified non-CLI consumer requires that side effect.
6. Kimi invalidation after detached spawn: a spawned daemon has its own lifetime.
   Losing caller authority must not kill an independently running daemon. An
   invocation failure does not certify that no earlier effect occurred. Keep
   this limit explicit; no claim of transactional daemon startup.
7. Review test coverage was packet-limited. Existing generated-session tests
   check disabled and cached daemon commands; real built-CLI integration tests
   exercise startup/shutdown. Review prose is not a replacement for those runs.
8. Kimi's assertion that synchronous check/remove has no race is too strong:
   other processes can mutate files. Existing PID-reuse/TOCTOU limits remain.

Final full suite and lint/type/generator gates are running under
`daemon-projection-reviewed-full` and `daemon-projection-reviewed-lint`.
Run the exact real CLI integration path last. Then record hashes/counts and
continue coherent Jobs checkpoint qualification; do not mark the release done.

Final results for this boundary:
- `daemon-projection-reviewed-full`: 7,854 passed / 6 skipped, 59.714 seconds;
  SHA-256 e4e3f77fcf83c837be907ead5aa318de9766b65c527dc5fad2791715cd3d07a4.
- `daemon-projection-reviewed-lint`: lint/types/re-export/package-generator
  checks pass, 69.829 seconds; SHA-256
  90f9ba96085c5a11d58cebcf5adb48ba66c33eca58fe2ed6f0be6c4e8c28daa1.
- `daemon-projection-reviewed-live`: seven real built-CLI process/socket tests
  pass last, 10.359 seconds; SHA-256
  c436411276cafd2803b14e4777c909628ce6816330020c05fee6a18de1ac08f3.
- All verification receipts report zero provider launches. Temporary review
  auth copies are absent. Index remains empty; no commits or pushes this boundary.
- Key source hashes:
  cli-invocation.ts 108da88a2b9ee9bcf2f375a319884fbd991f0f406161d5b635ad169bd22328d0;
  daemon-controller.ts 879f9be85efb0b17602a7c0575e04ef625f5ab91fe6602343272f0f80e58ee85;
  CLI daemon.ts 75f1109a00d75cf19b28cd504762bc98c11eeb96d003ee8c90589808c9f866b0;
  Jobs implementation.ts be989188ca8504a039b8427b2a4937303b2517b1bf6f3589f963f405cd2267fd.

Next: isolate the coherent Jobs extraction dependency closure for a staged and
committed clean-source checkpoint. Mixed Core index, generator, surface routing
and dispatcher files also hold inherited Plan/Brainstorm/Apply changes; do not
sweep them into the Jobs commit. Then continue server/transport ownership and
remaining original roadmap acceptance. This boundary is green; the project is
not yet a qualified modular release candidate.

## Jobs checkpoint source qualification (2026-10-10, in progress)

Previous goal turn made progress: two review hypotheses reproduced and fixed;
7,854 tests plus live daemon interoperability checks passed afterward.

Selected Git index tree: `0b78b401a5b0ef530ba7f2b005de9dda204b8723`.
Parent remains `3e453df751151e95f4fb86713b6f31bf888329b6`.
61 explicit paths (59 with rename detection). Includes physical Jobs scheduler,
daemon controller and workflow runtime, CLI/TUI/MCP host adapters, the shared
bounded process fix, and their tests/fixtures. Seven mixed files were staged
selectively: Core index, CLI surface authority, intent-session, intent-meta,
first-party package generator, migration-ledger generator, and its generated
ledger. Unrelated Plan/Brainstorm/Apply changes remain unstaged and unchanged.

Qualification checkout was confirmed clean at the parent, then populated with
`git read-tree --reset -u 0b78b401a5b0ef530ba7f2b005de9dda204b8723`.
Its index matches that tree and it has no unstaged source changes. This is an
exact staged Git-object subject, not yet a committed subject. Existing isolated
dependencies are reused; do not call this a fresh dependency installation.

`jobs-index-generators` passes both package and migration-ledger generators in
check mode. Log SHA-256
05711f43bba5b1d9a5ac96ca4035e5743c4556fb50e717601f705f69378d0f6f.
Full build is running as `jobs-index-build`; tests and real CLI run follow it.

Size accounting (`git diff --cached --numstat --no-renames`):
- Production TypeScript: +2,309 / -1,537 = +772 lines.
- Tests and frozen fixtures: +2,650 / -23 = +2,627 lines.
- Generators: +37 / -1 = +36 lines.
- Package metadata/lock: +19 / -6 = +13 lines.
- Migration evidence: +24 / -20 = +4 lines.
Total net +3,452 lines. Relocations contribute to physical additions/deletions;
net growth and behavioral complexity are not interchangeable. Existing duplicate
mod scheduler and CLI/Core implementations are consolidated, not left alongside
the new implementations. Remaining server/transport host ownership stays open.

F10 interoperability evidence is not just schema comparison:
`daemon-survival.test.ts` submits with the actual CLI, exits that client, then
uses the active generated MCP owner to list/status/result/events/cancel the same
daemon ID; it also submits the legacy structured workflow payload through MCP
and observes it through the daemon socket. Invalid kind and removed-engine
workspace cases fail. Provider work uses explicit echo/shim fixtures, not live
providers. These exact assertions must also pass on the staged source checkout.

Checkpoint accepted locally and committed:
`6c645b5da725f7954db0595994b281fefb411f96`
(`fix(modular): restore one Jobs execution owner`). Its tree is exactly the
tested index tree above. Qualification checkout now points at that commit and
has clean porcelain status. Candidate index is empty; inherited work remains.
No push. Active/global Agon and personal state are untouched.

Qualification receipts:
- `jobs-index-build`: full source build, 151.322s; log SHA-256
  dceb8ba3da361143e17c854766d70245454b0e9c65bc136f61161b441b07e7ba.
- `jobs-index-full`: 6,870 pass / 6 skipped, 47.466s; log SHA-256
  3d598e06c5b2819a2198f064f13bbfcd3f1b5a6b2a4d5439073b6308a8a29150.
- `jobs-index-lint`: lint/types/re-exports pass, 67.596s; log SHA-256
  c51a86f52d75225ca9974355102e5d0db81472ee6c128c24e35a43ffb652838c.
- `jobs-index-pack`: exact 21-file allowlist and public exports pass; missing
  daemon declaration and unexpected credential filename negative controls fail
  as required. Compressed size 26,113 bytes, unpacked 121,995 bytes. Log SHA-256
  635b590ebf227d23aca89770c42cf1173fea23b5ec2050178c7ebbeca817e215.
- `jobs-index-live`: built CLI/MCP interoperability and real socket authority
  tests pass, 15.784s; log SHA-256
  2c22605b39cc84db3ca4a8f5b6356b84ff0f6696292bb4d5cf449f0cd72b03e9.
- Every receipt is exit 0 with zero provider launches; hashes were rechecked
  from raw logs immediately before commit.
- No untracked or unstaged source in qualification checkout. Ignored-source
  scan found only declared build outputs (`dist`, CLI's tsconfig `dist-tsc`)
  and node_modules; no ignored source outside those paths.

The smaller test count versus 7,854 in the combined worktree is expected:
unfinished Plan/Brainstorm/Apply test additions were deliberately NOT included.
No tests were deleted to lower the count. This checkpoint closes F10's duplicate
scheduler and legacy workflow/payload regression, not all Jobs ownership or the
whole release. HTTP bridge enforcement remains a separate tested pending slice.

## HTTP Jobs checkpoint qualification (2026-10-10, in progress)

With the Jobs scheduler and authority helpers committed, the prior HTTP repair
now has a self-contained two-file dependency closure:
`packages/cli/src/bridge/agon-serve.ts` and
`tests/integration/serve-jobs-authority.test.ts`.
Staged tree `810a085e02cb5b3e9cab6b9919be154a0372527a`, parent `6c645b5d`.
Qualification checkout was clean at that parent before applying the tree.

Source checks confirm the previous independent-review corrections remain:
constructor capture errors affect Jobs only, typed 403/409 translation stays
inside Jobs routing, async request-body reads recheck authority, and queued or
running work uses the existing cooperative monitor. Non-Jobs routes keep their
old behavior. Real HTTP tests cover disable at boot, disable after boot, stale
and replaced hosts, submit/cancel body races, execution and delayed cleanup,
enabled success and non-Jobs error preservation. Original negative controls and
review adjudications are recorded above, not rerun as a new paid panel.

Reviewed logs remain available and were rehashed:
- Codex: 1b187edbc4a6beb131ed93fe8baf7fab5d8c05502a8704672ff42798c7aadf4f.
- Kimi: c0a28d470f6463667e9409ee263f6dd957de618f38cc0ac3b6c8304de4fcba56.

`http-jobs-index-build` runs the full build against this staged source subject.
Full tests, lint/types/re-export guard and a final real HTTP run follow.

Next dependency-ordered pending slice: explicit approval fixes. The shared
helper, Build/Forge/Plan/Commit/Run and suggested-workflow checks are already in
the working tree with red/green historical evidence, but their source note says
independent review remains outstanding. Keep Forge undo/Apply changes out of
that approval checkpoint. Review its bounded actual diff before committing.

HTTP checkpoint completed and committed locally as
`007afcc9e5e51025b9e2021f09908c8a4196c79a`
(`fix(modular): enforce Jobs authority on HTTP routes`). The tree matches the
staged subject above exactly. Qualification checkout is now detached at this
commit with clean porcelain status. Two paths, +239/-2; of those 208 added lines
are real HTTP integration tests. Candidate index is empty. Nothing pushed.

Receipts, all exit 0 and zero provider launches:
- `http-jobs-index-build`: 151.806s; SHA-256
  d46add61baf17340c623c5d1aa74dd2d7ba1f05e02498f3195f2914dab48e0aa.
- `http-jobs-index-full`: 6,884 passed / 6 skipped, 48.186s; SHA-256
  bf89491bb9f33de08fd859e33244c2447245dc331cd878140e0eabbf146ffa73.
- `http-jobs-index-lint`: lint/types/re-export guard, 67.901s; SHA-256
  b4896732032b43e5995322457fc25011ecc8377faf9d547ed996135273165422.
- `http-jobs-index-live`: real HTTP plus built CLI/MCP daemon tests, 10.351s;
  SHA-256 ce390f5ba84a1fe2b8ece16df09e5cde170e38eabdc7fa8972432d53d441f193.
Raw log hashes and the complete staged path set were verified before committing.
No test process from these gates remains running. Existing isolated dependencies
were reused; this is not a fresh-install release qualification.

Progress this goal turn: two independently source-qualified local checkpoints
landed; the previously uncommitted Jobs and HTTP dependency closure is now
reproducible from Git. Remaining approval/Plan/Brainstorm/Apply work remains
untouched in the candidate. Original completion requirements stay unchanged.

## Explicit approval checkpoint — review and local corrections

Parent: `007afcc9e5e51025b9e2021f09908c8a4196c79a`.
Reviewed staged tree: `509e0de316d61c3425cc25050afecacdd881c745`.
Corrected qualification tree: `e26ddbf3ae35ec6d2af181f7939076ac9633601d`.
This selects approval hunks only. Forge undo/artifact changes and Plan executor
extraction remain outside the index. The app file contributes only its current
worktree-plan reference setter, not pending session or undo wiring.

Both default reviewers ran through the existing isolated Agon source-packet
harness. No second panel followed local corrections. Packet SHA-256:
`114369fa5d2fa77e35f95fd6ae3079c6ce82f1c4ceb3cf01f66023d274c32965`.
Codex log: `d4a50f00abd7db2ee5c495c813816ed0d9499ede2dff2ccfa83cfd24007c3863`.
Kimi log: `5ab6bf29e8a20496a2fa9a3e452fb7ed498c54654a1a3d819dd6be1b7acf982c`.
Both exited 0. Raw inputs, outputs and receipts remain beside this document.

Source-verified adjudication:

- Codex/Kimi stale dismissal: confirmed. Six deferred-question tests reproduced
  overwrite of replacement/cancelled plans on blank, affirmative and negative
  replies. Bind the displayed disk draft before awaiting; reject a response if
  the current object or draft state changed. `approval-stale-draft-red` failed;
  `approval-stale-draft-green` passed all 29 tests in that file. No cancelled or
  replacement plan is restored by a stale question.
- Local host tracing found a separate prerequisite: app `currentPlanRef` was
  initialized but never assigned. The getter used by `/approve` stayed null.
  The setter now updates the reference synchronously and queues its existing
  render update. `approval-app-ref-red` fails with null, green passes. This test
  executes the actual source declarations/getter with a queued-render host; it
  is not a full mounted-React or terminal end-to-end claim.
- Kimi missing draft persistence: confirmed. `createPlan` only returns an
  object. Build/Forge dismissal now saves the draft before returning. Two red
  cases became green; explicit refusals also assert cancelled-state persistence.
- Kimi Build `/approve` continuation: verified inherited behavior. Both old
  `/approve` and inline Plan approval approve a Build draft but instruct the
  user to run Build again; the Build dispatcher creates another plan. This
  checkpoint does not silently change approval into automatic execution.
  The new Build-dismissal message no longer advertises `/approve` as recovery:
  it says to run Build again when ready to approve and execute. Exact-draft
  Build continuation remains an explicit follow-up in Plan execution ownership,
  not a claim of completed resumability or a release waiver.
- Codex/Kimi auto/upstream/existing-plan coverage: added all three for Build
  and Forge, with question callbacks throwing on unexpected use and assertions
  of execution. Existing exact-answer controls cover y/yes, case/space handling,
  blank, refusal, and misleading y-prefix words at consumers.
- Commit retains custom text as a message (including yikes/yes please), explicit
  supplied-message bypass, and existing attribution behavior. Added custom-text
  and supplied-message tests. No attribution code changed. Direct helper tests
  would duplicate consumer truth tables and are not required for this checkpoint.
- Inherited concerns retained for later: Build abort-handle cleanup ownership,
  Build/Forge approval freshness after awaits, Commit auto-staging before its
  question, and suggested-workflow callback execution integration. They are not
  silently classified as fixed by exact string validation.

Negative control `approval-negative-old-behavior` restores the unsafe approval
predicates and old disk-draft selection in the isolated qualification checkout.
It exits 1 across all four test files. The exact staged tree was restored before
qualification; no mutation touched the candidate or any active installation.
Raw log SHA-256: `ff62f78efe996eaf12edda1472083471f9617d0f16e2b13f49fe9ac6ed31f6dd`.

Qualification runs rebuild from the staged Git tree, not mixed working bytes.
Existing isolated dependencies are reused; no fresh install is claimed.

Approval checkpoint committed locally: `7b7a549efcd052d031f81bf67092fceb1d05fd14`.
Its tree is exactly the corrected qualification tree above. Thirteen paths,
+312/-20. No unrelated pending extraction was committed and nothing was pushed.

Final receipts (all passed, exit 0, zero provider launches):
- `approval-index-build`: full build, types, re-export guard; 150.238s;
  SHA-256 `f7848ef472fc62f3db2ab6accb25cfa09ffeb8cb230bf016d7a0c570a7874c14`.
- `approval-index-lint`: 65.630s;
  SHA-256 `2e9e48c35693b25f511f6e03cc467fdff41466688f182e44e585efcf6efecf48`.
- `approval-index-full-native`: 6,932 passed, six skipped; 46.295s;
  SHA-256 `130f32f17f03eb621f31d9f478df01827d6f876fa024ff915acb4543eb6d3592`.
- `approval-index-pack-v2`: CLI dry-run pack, actual dynamic TUI chunk present,
  missing-chunk and auth-file negative controls rejected; 0.722s;
  SHA-256 `26e9378f98607166477d235a04189aaf91671129a6f0f52d15c9908d1c04f7e4`.
- `approval-tui-live`: actual built Ink TUI in an isolated PTY/home. `/plan`
  displayed the seeded disk draft. Empty Enter printed "Plan remains draft".
  `/approve` printed "Plan approved" rather than "No active plan". `/exit`
  exited 0. No provider ran. 43.491s;
  SHA-256 `ff4507ceeb5efeae01dc844dcf3f66bc9c4cec11d2acc00bfee9c0d122792c6a`.
- `approval-tui-state`: verified persisted ID, task, approved state, and the
  ordered draft-then-approval transcript; 0.184s;
  SHA-256 `1b78fc176730522491ad35a3893d6673ecd117a04b8b592a6fa901a2ab16e8a4`.

Failed attempts are retained, not overwritten: `approval-index-full` ran inside
the restrictive sandbox and failed with socket EPERM/file-watcher failures.
The unchanged suite passed with native local-I/O permission. The initial pack
probe incorrectly expected `dist/surfaces/app.js`; tsup produces a hashed dynamic
chunk. The corrected probe resolves the actual import from built `index.js`
and has negative controls. No production or repository test was weakened.

Next: retire proven parser/normalization forwarding paths, then the remaining
Apply backend, Plan/Brainstorm ownership and release qualification. The original
goal remains active and its acceptance criteria are unchanged.

## Patch parser/normalization facade retirement checkpoint

Parent: `7b7a549efcd052d031f81bf67092fceb1d05fd14`.
Staged qualification tree: `fc13858f14bfeed1c8548b17f6d54111773fbb24`.
Seven files, +63/-12. Two private forwarding files disappear; public Core
functions/types remain direct reexports. CLI Review parser/summary and Core Git
normalization use their already-declared physical support package. Apply/undo
bindings and parser algorithms are unchanged. This does not close A13/KL-011.

Consumer trace: `git grep -n -E '(blocks/patch-parser|utils/patch)' HEAD -- packages tests scripts`
found Core git/index and three integration imports. All six occurrences are
updated. History identifies `34e094d3` as the earlier physical extraction.
Core's export map exposes only `.`. Neither removed path is a public subpath.
The current working-tree backend fixes are deliberately not in this checkpoint.

Default Agon reviewers found no blocking issue in the frozen diff:
- Packet: `0d67c4534511ae6c2bfdc9d5b7916df093c331823474c96870707bad0813693e`.
- Codex log: `bc47c89794d055e02ed85eebcae6bab700051183ae8564770d95870ca56c8231`.
- Kimi log: `725707857d6a17f38e72e4480a1639d408255c9badbae3c3c84a2f271fc7b35f`.

Review reconciliation:
- The relative-import guard covers the repository's explicit .js/.ts spelling,
  not every possible alias or extensionless string. Its claim is scoped. The
  broad Git search also checked committed tests/scripts. No extra resolver is
  added for hypothetical syntax.
- Runtime identity assertions use package exports: Vitest has no Core aliases.
  Qualification rebuilds first; Core tsup has `clean: true`, and then tsc emits
  declarations. Verify obsolete compiled paths are absent before packing.
- Kimi's statement that a manifest proves global cycle-freeness is too broad.
  Accepted claim only: the removed facades already used the same support barrel,
  so this change adds no dependency edge or new initialization path.
- The test scanner has no production cost. Its four cases enforce file removal,
  absence of old import edges, detector sensitivity, and public function identity.

`patch-facades-index-focused`: 54 tests passed. Negative control
`patch-facades-negative-restored` recreated the old forwarding paths and one old
consumer in qualification only: two expected failures, two controls passed.
SHA-256 `86a845eaa714b7d2e7835e604af65a4b46899dbb36b4775770df82fa8d2f0039`.
Those temporary copies were removed and the exact staged source restored before
the full source build. Historical source remains recoverable from Git; no audit
evidence was untracked or deleted in this checkpoint.

Committed locally as `1a40ea75aa35b309864525f6592dd14e8b04badf`,
`refactor(modular): retire private patch facades`. The committed tree matches
the qualified staged tree exactly. Qualification checkout has clean committed
source; candidate index is empty and all other pending work remains untouched.

Receipts (exit 0, zero provider launches):
- `patch-facades-index-build`, 151.543s:
  `bb16197026e909cce4097609a7ba47bc7263b104a67b07eb8852dd307a77fa42`.
- `patch-facades-index-full`, 6,936 passed / six skipped, 49.208s:
  `0c31dd5489fd59b6b895ba0ffc992c53662003dce90d2063d9c0c516e41c6c25`.
- `patch-facades-index-lint`, lint plus N-1/N-2 pre-release compile/load
  compatibility, 69.338s:
  `b9964709e9f176baf321fddbf2eb7dacffaa6d10c0dc14a2d280cbac0c1df563`.
- `patch-facades-index-pack`, 1.126s:
  `8aba823bbb5ecb8c89930400659201d211401cc936d94ab4bb9a49d9f7f72dee`.
  Eight obsolete compiled artifacts absent; Core public parser declarations
  remain; reinserting a retired compiled path fails the pack check.
- `patch-facades-index-live`, 33 real-Git/backend/core integration checks,
  2.079s: `8818a99c33cf841a9bd1e186bf951874a8f6af63020d45d02d96b8d4b2294b2c`.

Next verification concern before further Apply extraction: Build/Forge approval
answers also cross an await. Their new blank-draft persistence could overwrite a
concurrently cancelled draft. This is a hypothesis requiring a failing deferred
question test, not a confirmed defect yet. The Plan-show path is already guarded.

## Approval freshness follow-up — confirmed and repaired

The preceding hypothesis is now confirmed. `build-forge-stale-approval-red`
failed six delayed-answer cases. Blank answers rewrote cancelled plans as drafts;
affirmative/refusal answers also replaced the current cancellation. The blank
persistence overwrite was introduced by the preceding approval checkpoint; the
other stale-answer branches were inherited. Keep that attribution explicit.

This continues the existing approval review's freshness concern. Per the review
discipline, local corrections and negative controls follow; no second paid panel
is run for these fixes. It is not a fresh independent-review claim for new code.

Staged tree `1662ac93f44a6a5ce0931a9216b64f97b302aca3`, parent
`1a40ea75aa35b309864525f6592dd14e8b04badf`: three files, +44/-0. Both handlers
snapshot the published current plan before the question and reject a response
if that identity changes, their own draft state changes, or their controller is
aborted. No save, cancel, approval, or execution follows a stale response.
The live TUI's synchronous reference update was qualified in `7b7a549e`.

Eighteen cases cover Build/Forge × blank/y/n × cancellation/replacement/in-place
cancellation. Existing auto/upstream/existing-plan and exact-approval tests stay
green. `approval-freshness-index-focused` passed. Disabling the two new guards
in qualification makes exactly these eighteen cases fail while 21 controls pass:
`approval-freshness-negative-guards`, SHA-256
`8f679db6015ee65ebd5e2b4c24e94ab4a2fa1f2d0ae40961dcc6ee8d6b0efc85`.
Mutations were restored to the exact staged tree before building.

One failed local repair attempt is retained: Forge's controller was initially
mistyped as `abort` instead of `forgeAbort`. Positive-path tests caught it;
the corrected run passed. This demonstrates why the negative cases alone were
not treated as sufficient proof.

Committed locally as `59eb525fa5e8b290413420806f87f8d11fbbe3d2`,
`fix(modular): reject stale build and forge approvals`. Its tree is the exact
staged subject above. Qualification checkout is detached at that commit, clean;
the candidate index is empty. No push or install. All preceding approval and
facade fixes are included in this subject.

Final receipts, all exit 0 and zero provider launches:
- `approval-freshness-index-build`: 150.904s;
  `5df5937408fff18bd5d9ec14bc7bd0901ace50fa2c80743b5e4f0245608511f1`.
- `approval-freshness-index-full`: 6,954 passed / six skipped, 48.517s;
  `42020ebc7586a059d6987f2f75b2fe9f4c7577baf5e15dbb47dce88dfa5b92d7`.
- `approval-freshness-index-lint`: 67.664s;
  `db150a008c61a7d45fd7910bab6b2db795d2e55cc2c6ec5170e78b34e182182b`.
- `approval-freshness-index-pack`: dry-run CLI pack plus missing-chunk and
  credential-path negative controls, 1.282s;
  `f12f5cd0af84df4764022b3ef658c979f6cd0ce332d09d688a6fd8ea42d5af9e`.
- `approval-freshness-index-workflows`: 104 fixture-backed orchestration/Forge
  workflow and approval cases, 20.415s;
  `ec60d9ba10f026a51d60692a849eba842a35859a4a1cfdf85539ed2899001275`.

Progress in this goal turn: three verified local commits. Original modular
acceptance is not complete. Continue with the remaining Apply backend/undo
work and ownership retirement, then Brainstorm and Plan, then same-subject
release qualification. Read the existing pending backend tests/notes, verify
against current source, and keep legacy compatibility requirements explicit.
Do not repeat another approval review panel solely because the prior findings
were fixed; do run the next substantive backend review through isolated Agon.

OSV approval remains recorded. The completed online scan found 16 known
vulnerabilities across nine affected package entries: two critical, seven high,
six medium, one low. Both critical findings are in development tinypool 1.1.1.
`workspace-edge-osv-online` exit 1 denotes findings, not a transport failure.
No dependency update or installation was performed. Treat this as a release
limit, not as a passed security gate.

## Apply continuation: copy-patch inverse gap (uncommitted)

Subject: candidate HEAD `59eb525fa5e8b290413420806f87f8d11fbbe3d2`,
plus the existing uncommitted Apply changes. This is not clean-subject release evidence.

The existing inversion/path/publication/lifecycle tests passed in
`apply-inversion-existing-check` (exit 0, 2.768s, zero providers; log SHA-256
`2873ce37976e68a32f595578092727c7e8cb8dd4817b1c7ab8f0f1e0b40df773`).
A new real-Git copy case then reproduced a missing inverse operation:
`invertPatch` retains `copy from`/`copy to` metadata, so applying the inverse
tries to create the destination again instead of deleting the copied file.
`apply-copy-inversion-negative`: one failed, 17 passed; log SHA-256
`a11d6bedbfca2602419ec7405592e2656dc833f53204ca3a2f0717cccbcebb76`.

An independently selected alternative, `git apply --reverse`, also fails on
that real copy patch: it tries to create the already-existing source. Thus
switching to Git reverse is not a verified repair. `apply-copy-reverse-control`:
two failed, 17 passed; zero providers; log SHA-256
`3fa1e2050bc0f15b45843a09fc84171f7dca2186cb23600211cfd83ebbf30ae6`.
The two red cases remain in the uncommitted inversion test for investigation.
No production code changed, no commit, no changes to qualification checkout.

Next: resolve copy support at the Apply boundary using actual preimage evidence,
or establish an explicit fail-before-mutation unsupported-format contract. Do
not silently convert the restoration oracle into a passing rejection test.
Copy metadata alone does not contain the complete destination bytes needed to
emit a standalone deletion patch; trace actual producers and public consumers
before choosing the smallest compatible repair. Broader Apply qualification
and its isolated default-review pass are still pending.

One discarded diagnostic launch (`apply-copy-git-characterization`) exited 9
because the stdin-less harness invocation supplied `--input-type=module` without
a script. It supplies no product evidence and is retained as a failed attempt.

## Copy undo: real lifecycle reproduction and contextual repair in progress

The previous goal turn was progress: it supplied a reproducible failure and
eliminated Git reverse as a repair. This continuation implemented a contextual
repair but does not qualify or commit the complete Apply slice yet.

Default isolated Agon reviewers completed `copy-undo-design` on one immutable
packet, SHA-256 `9c6c3e07f6318694e4aa5b8c0e240499f4893b098ca20eadcef98c25f39a049b`.
Both exit 0. Codex log SHA-256
`06e5fed64f53d174ffb16360b79b598e180f498be6b60870be9c995e4c1cc4f3`;
Kimi log SHA-256
`17652bf960f52e71a9bc5ead8c67cbcf32d3f6ac4a38a84165dc0124d6b3436b`.
These reviewed repair choices, not the subsequently written implementation.

Adjudication:
- Codex's claim that metadata-only copies lack the bytes for a self-contained,
  content-checked deletion agrees with source and the actual Git experiment.
- Kimi proposed no-hunk deletion metadata, claimed capability loss was absent,
  and suggested defaulting file mode. Rejected: real Git reports `removal patch
  leaves file contents`. Receipt `apply-copy-metadata-hypothesis`, exit 1,
  17 passed/three failed, log SHA-256
  `0083fc5f9b9a0f1dc67830f4d05ffb08b685fc274e072d4ce2bb30481a7aee3e`.
- Kimi's `diff.copies` configuration claim and statement about Git multi-file
  atomicity are not accepted facts; neither was source-verified.
- Both recognize that blanket rejection removes valid forward Apply behavior.
  The repair therefore retains successful Apply for copies.

Real lifecycle reproduction: new `modular-copy-undo.test.ts` exercises Apply,
  record storage, Undo, exact bytes, source preservation and real-index bytes.
  Before the repair all four initial cases failed at Undo, after Apply succeeded:
  unchanged, edited, binary and C-quoted Unicode/tab paths. Receipt
  `apply-copy-lifecycle-negative`, log SHA-256
  `0a241b09fd0e9bbe461bf7837a39f7977802ba629c9800155456ef07140fde56`.

Implementation, still unstaged:
- `git-path.ts`: moved the existing C-quote decoder unchanged; internal direct
  imports, not a new package-root export. Its 25 path tests pass.
- `patch-copy.ts`: validates original applicability with Git, reads bounded
  repository paths without following parent links, copies each source to private
  temporary storage, lets Git materialize copy edits, and generates a binary
  destination-addition patch with no external diff/text conversion. Temporary
  Git repository uses no inherited Git variables/config/templates and is removed
  in finally. The target index and object store are not used for preparation.
- `applyPatchWithUndo`: prepares copies before writing the existing inverse
  record; applies the prepared patch, not a fresh copy against changed source.
  Preparation failures return the existing typed failed result before mutation.
- Content-only `invertPatch` now explicitly requires context for copies instead
  of returning an invalid patch. This is an intentional API error correction,
  not proof that pure inversion supports copies. The real contextual lifecycle
  retains positive restoration assertions. The earlier shortcut probes now
  assert their observed Git failures and verify files remain unchanged.

Local receipts (all exit 0, zero providers):
- `apply-backend-pending-sweep`: 83 tests across 11 existing Apply-related files;
  log SHA-256 `5e12e14a70a2f8e9a2a086a3e2b988d257cd631356283661a7d521259aa48ffc`.
- `copy-path-decoder-move`: 25 path tests; log SHA-256
  `f3567303dca360235b4fb4f83c49f42be2ce85c73d5bf361d16276da255a3c61`.
- `apply-copy-materialization-first`: 36 tests including all four formerly red
  copy lifecycles; log SHA-256
  `fa0df78f0676cafcefb827b965eb22a923804d8976bd7b3b9e0631124538f879`.
- `apply-copy-supported-contract`: copy lifecycle, inversion and paths; log
  SHA-256 `4a1e1f09508470dcc239c802c83beab83ea10e95b19bb369c611d95bfb6d35fd`.
- `apply-copy-mixed-controls`: eight copy lifecycle cases. Added source edits
  in the same patch, multiple copies, source removal before Undo, and refusal
  to delete a destination edited after Apply. Log SHA-256
  `e4c615c43c380ec13f0993299857c93d322a55a8524e87e0400d53dc464af65f`.
- `apply-copy-local-types`: support-worktree tsc --noEmit, exit 0.
- `apply-copy-local-lint`: six changed/new source and test files, exit 0.

Remaining before staging/commit:
1. Source snapshot revalidation immediately before actual mutation. Applying
   the prepared patch binds inverse bytes, but a concurrent source change could
   still cause a stale copy result. Do not describe this as race-safe yet.
2. Empty/executable/symlink copies, malformed/traversal paths, storage and
   preparation faults, nested cwd semantics, copy with source deletion/rename,
   absent source and existing destination, large source limits. Preserve the
   current pure-inversion non-copy corpus and historical record reading.
3. Review final implementation (the completed design review is not that review),
   verify/refute findings, then qualify the dependency-closed Apply slice from
   exact staged Git objects with full gates before a local commit.
4. Continue Brainstorm/Plan ownership and final release qualification; do not
   substitute this component for the overall goal.

Candidate HEAD remains `59eb525f`; index remains empty. Qualification checkout
is untouched. No active/global Agon, personal state, dependencies, installs,
pushes or release claims changed. No review processes remain running.

## Apply continuation: source binding and final-review corrections

This goal turn made implementation and verification progress. HEAD remains
`59eb525f`. Fourteen explicitly selected Apply source/test paths are now staged
as tree `4cc760724d175fbf39fde3983325fa3fc6172ba2`. That tree predates the review
corrections below. Those corrections remain unstaged atop the same files.
Preserve both layers and all unrelated Plan/Brainstorm work.

Qualification checkout was clean before loading that exact Git tree. Its build,
typecheck and re-export guard passed in `apply-backend-index-build` (148.430s,
log SHA-256 `062858307dbae28f81619c5d4ff11415aeff8d6abe55ad392d954e9646dcdc5e`).
This is NOT acceptance for later working-tree fixes. No full-suite run or new
commit has occurred for this slice yet.

Source binding: materialization now returns prepared content and an internal
source verifier. The existing backend checks copy source bytes, file mode and
regular-file/symlink type after undo-record durability and immediately before
Git mutation. A record-write fault changes the source in a real fixture. Before
the guard Apply incorrectly succeeded; after it refuses, preserves the concurrent
edit, creates no destination and removes the unused record. This bounds the
preparation window; it is not atomic exclusion of hostile external writers.
- `copy-source-race-negative`: exit 1, log SHA-256
  `2e907f28189b406afbb68cb359333ef9b87343dac73c842c89e70d7f6a66ec56`.
- `copy-source-race-fixed`: exit 0, log SHA-256
  `30604fd89632910172f669b3ca34873db17e8010d29e934c36a379312adbec16`.
- `copy-filetype-controls`: 13 passing cases, including empty/executable/symlink
  copies and a nested invocation; log SHA-256
  `66245091057452b8d26e191a657113521bfd7b54b3c5b619ce103021d358d328`.
- `copy-refusal-controls`: 17 passing cases, including missing source, existing
  destination, traversal and malformed metadata; log SHA-256
  `965bb1bc467e8f9185b7d7801bd2e0556215509c91eaa283142ee375b3b06b94`.

Final implementation review `apply-backend-final` was launched for default Codex
and Kimi through the existing isolated Agon harness, from the frozen staged tree.
Packet SHA-256 `377acf47b3088c860a76e6ac6552eb29b667d9b8b8f1e95e88ed54951556cdc9`.
Codex finished exit 0; log SHA-256
`cb17035a599aa228bfa13df97ecf8cf619d95506fe5d21396532c9bd47d561f2`.
At the latest poll, Kimi remained RUNNING on tool session **47812**. Poll that
same handle; do not restart based on silence. Its wrapper timeout is 660 seconds.
No other processes from this turn remain running.

Codex findings, verified locally:
1. Non-UTF-8 bytes without NUL: confirmed corruption in generated text diff.
   Fixed by forcing binary diff representation in the private scratch repository's
   `info/attributes`. This never changes target attributes/configuration.
2. Subdirectory Undo: confirmed Git can skip the entire patch but report success,
   then the backend consumes its record. Fixed by resolving root consistently in
   dry-run, direct Apply, Apply-with-Undo and Undo. Added all-outside copy and
   mixed inside/outside text-patch restoration cases. Preflight uses the same
   root resolver. This intentionally corrects inherited folder filtering.
3. macOS alias durability: confirmed ENOTDIR when fsync tries O_NOFOLLOW on
   `/tmp` itself. Fixed by one shared exact-system-alias resolver for validation
   and fsync. Arbitrary links remain rejected. A new live fixture creates its
   undo directory directly beneath `/tmp` and verifies parent fsync before Apply.
4. Forward-only binary payload: CONFIRMED, STILL OPEN. A real Git patch with only
   the forward payload applies successfully in a fresh recipient; the existing
   inversion produces the wrong bytes/hash and fails on Undo. The producer's
   object database is absent. New positive restoration test remains red. Do not
   accept the slice while this is unresolved, nor quietly change that assertion
   into successful blanket rejection. Content-only inversion cannot recover
   omitted old bytes; contextual preparation is available at the backend.

Correction evidence (zero providers in every local test receipt):
- `apply-review-bytes-root-negative`: both defects red, log SHA-256
  `4b71565366680b952ac22f067869a76dc66029956d45448c52c3f592a7c87db5`.
- `apply-review-bytes-root-fixed`: green, log SHA-256
  `0925e798c9ed7539dad3c45b0b3121caf578a2cf3f46c251f0337744d28a94e3`.
- `undo-alias-durability-negative`: real alias defect plus mock call-count
  fallout from the new read-only root probe; log SHA-256
  `8e81846cf13e369e41f081fbda0f8bfdb2e140f0bd72693d3b0ce376ec8a72b2`.
- `undo-alias-durability-fixed`: green, log SHA-256
  `a463fd8fad5f6a1c16bb2ba708785a563190948c4e2151d48ea6a8c46b1aa336`.
  Parent tests now spy on Git mutation separately from the read-only root probe;
  backend also rejects bad undo ancestry before preparing a patch.
- `apply-backend-local-regressions`: 99 passed across nine files, log SHA-256
  `c04133c6aee937af99cafd51f377271c685ff100a2fed01a90c7ddc3ea6e8516`.
- `undo-root-mixed-fixed`: four tests passed, log SHA-256
  `5ffcb90fcffb370fe7401f856cea452d7dc5ca3f025a8ef1041bee11d156a632`.
- `apply-review-local-types-lint`: tsc and focused ESLint green, empty log hash.
- `binary-forward-inverse-negative`: one failed, 18 passed; failure occurs on
  the inverse apply, not initial forward applicability. Log SHA-256
  `a1c005cdc4aa94956b25e56edf6c60dd5def588613687b4034ffca15287c4135`.

Compatibility gate limitation found by reading
`scripts/spec/verify-modular-support-api-compat.mjs`: its N-1/N-2 sample imports
do not exercise patch APIs. Do not present that gate alone as patch compatibility
evidence. Existing Core wrapper tests and real lifecycle tests remain necessary.

Next actions: collect Kimi's live review; repair forward-only binary preparation
with a positive contextual Apply/Undo test; verify/refute all findings; restage
only these Apply paths, reload exact tree in qualification, rerun build/types/
lint/full suite/pack/live compatibility before any commit. No second paid review
panel solely for these corrections. Subsequent ownership and release work remains
part of the original goal, not dropped. Nothing pushed, installed or promoted.

### Second final reviewer completed

Kimi session 47812 is now TERMINAL, exit 0; do not poll/restart it.
Log SHA-256 `4d0ad80e70f6ef5daaa3391ba247a441d4ef3c2e028c67d144767e80a42e72c7`.
It reviewed the same frozen tree, before the fixes, not the current working bytes.
No processes from this turn remain live.

Kimi hypotheses and disposition:
- Empty-file inverse allegedly broken: added real-Git create-empty/delete-empty
  round trips to the existing inversion matrix. Receipt
  `empty-file-review-control` records the result; no speculative header synthesis.
  Both new empty-file cases PASS. The receipt as a whole is red because the
  repository test wrapper did not retain the requested name filter and also ran
  the known forward-only binary failure (20 passed, one failed). Thus the empty
  metadata defect is refuted, not a green suite claim. Log SHA-256
  `8a0b09f5b8860fee31be06f3493ff5fed73d28f587f4d9b22d017c7221cc920f`.
- Directory fsync missing after record unlink: source confirms this omission.
  Crash-replay consequences are not experimentally proven yet. Add a durability
  negative control and consolidate directory-sync handling before claiming
  durable consumption/failed-apply cleanup. This remains locally actionable.
- `git apply --allow-empty` version: `git show HEAD:.../patch-apply.ts` proves
  this flag was already used in direct Apply, Apply-with-Undo and Undo. It is not
  introduced by this slice. Claimed version date is unverified; do not add a
  module-load Git subprocess based on it. Minimum-Git release qualification
  remains part of the platform matrix.
- Allegedly missing unlink-failure/token-traversal tests: rejected as an absence
  claim. Existing lifecycle, backend and read-boundary tests cover these cases;
  not every test was included in the bounded review packet.
- The review's global assurances of copy safety and nested-cwd handling are
  rejected: the other reviewer supplied now-reproduced counterexamples.
- Mixed copy/rename/mode, new destination parents and true legacy record replay
  are useful remaining controls. Do not enlarge the production design merely
  to satisfy speculative reviewer wording.

## Qualified backend checkpoint bb629081

Committed locally: `bb6290818c005fcaf4cf8df0ea5fa3bbe3be40c3`
(`fix(modular): make patch undo durable and reversible`). Exact committed tree:
`cc0593077d4124d18a8ae9ab4deee58804285da8`.
Fourteen explicit paths, +1,283/-49 lines, mostly new behavioral tests.
Candidate index is empty. Qualification checkout is detached at this commit,
clean, with the identical tree. All unrelated WIP remains in the candidate.
No push, dependency install, global installation or personal-state modification.

Resolved the two remaining review findings before this checkpoint:
- Record deletion: one private directory-sync owner now handles publication and
  deletion. Successful Undo and failed-Apply/storage cleanup fsync the directory
  after unlink. A retirement fsync failure returns success-with-warning because
  the workspace is already reverted. Red control proved the previous code omitted
  both sync and warning; positive cases cover both failed-apply cleanup branches.
- Forward-only binary input: the existing private copy materializer now prepares
  context-dependent patch entries. It lives in `patch-materialization.ts`, not
  `patch-copy.ts` (the latter was never committed). It stages source bytes only in
  a private temporary Git index, applies the entry there, then generates a complete
  binary patch with rename detection and transforms disabled. Real target index/
  objects remain untouched. One owner handles copies and missing binary reverse
  data; record format is unchanged. Full contextual Apply/Undo succeeds for binary
  create/change/delete in recipients without producer objects. Pure content-only
  inversion reports missing context instead of manufacturing an invalid inverse.
  This is not blanket rejection of forward-only input at the backend.

Additional local evidence:
- `undo-retirement-sync-negative`: red, SHA-256
  `b8c100237d668cf5b143dadb46eedd3edcff347a5c823457ab66e7b7728a90eb`.
- `undo-retirement-sync-fixed`: green, SHA-256
  `bf8a0635663a45e98f521d74476f028ba8a1c0fcc71df86ef012cee20991f9b0`.
- `undo-failure-retirement-controls`: green, SHA-256
  `00a5a778ee7f80c1afeaf67741376363df6db696ba6219c94af8520c23bea4e3`.
- `binary-contextual-undo-first`: 45 passed, SHA-256
  `c1e3ff92e6269c80f478ceec60722d067792def9ac7b4d55e6240de8483730c1`.
- `binary-contextual-lifecycle-matrix`: green, SHA-256
  `19f27d3b8cf8f0c8e16014c14a34b0fba27455f664c8e89f7ae21c101abab9f5`.
- `contextual-patch-local-gates`: types/lint and 106 focused tests green, SHA-256
  `9e90097ac4c62364f0c83204857cbb92ed68a565ad36d000893055d8926aec4f`.

Final qualification receipts, all exit 0 with zero provider launches; raw log
SHA-256 verified against every receipt before commit:
- `apply-final-index-build`: build/types/re-export guard, 149.596s;
  `1890dd4128049a6d1204dbeef5277baffc683c2111fc63f6587de681784b60f2`.
- `apply-final-index-full`: **7,073 passed, six skipped**, 51.238s;
  `c49908f4f40e059ded9cb17f2a423e0842b515c13c16b730ad362a86121b50e0`.
  Native local sockets/watchers permitted; provider/browser blockers retained.
- `apply-final-index-lint`: lint and existing N-1/N-2 support compile gate,
  70.722s; `4ce9fce89badb200ac3b914dc9c056f788e8de64f595843ad689facad5458df8`.
  The earlier limitation of that gate remains explicitly acknowledged.
- `apply-final-pack`: dry-run packs with scripts disabled; support-worktree
  16 files/74,233 unpacked bytes; Core 729 files/2,562,543 bytes. Checked required
  entrypoints and forbidden source/state/auth paths; missing-entrypoint and added
  auth-file negative controls fail the validator. Built Core/support parser
  functions are the same owner, two-/three-argument apply boundaries preserved,
  private preparation/path helpers not exported. SHA-256
  `d78e29377623bfeb36917cc0bbacc6c7e988cb4dfabd7b1220302ada70cfd7b1`.
- `apply-final-built-live`: one real built-Core public Apply -> on-disk record ->
  nested-cwd Undo run, exact invalid-UTF-8 copy bytes/source/index preserved and
  record consumed; 0.343s. SHA-256
  `71460de32e6fe5057fd58aa6f0e698a150c9af9d297c4ca441c02fed6f305644`.
  Pack and live receipts embed the complete inline script, not missing stdin.

Qualification source checks: no unstaged tracked changes, no untracked files,
no ignored source-bearing files outside node_modules/dist/dist-tsc. Existing
isolated dependencies were reused; this is not a fresh-install release proof.
Default implementation review findings were locally fixed/refuted without a
second paid panel, as instructed. No processes from this turn remain live.

### Continue, not complete

Next Apply ownership slice was inspected after the commit:
- CLI `blocks/review.ts` should call physical Apply with injected
  `persistencePath('undo')`.
- Forge should use that physical owner, strict artifact reader and register
  returned undo tokens with the host; missing/throwing callbacks must not retry
  an already applied patch.
- `signals/dispatch/intent-meta.ts` should use physical Undo and surface its
  completed-with-warning result while clearing the consumed token.
- `models/handler-types.ts`: stage ONLY optional setLastUndoToken, not pending
  PlanPipelineUiEvent/Plan session edits.
- `surfaces/app.tsx`: stage ONLY the undo setter in buildContext and lastUndoToken
  dependency in handleSubmit, not pending listCesarPlans ownership edits.
- Public Core undo wrapper needs its warning return type, not algorithm ownership.
- Pending tests: Forge cases, forge-undo-app-wiring, modular-review-patch-owner,
  modular-undo-feedback, and the last two facade-retirement tests. The first four
  facade tests are already committed. Trace exact dependencies before staging.
- `handlers/review.ts` adapter-injection changes belong to Plan execution and
  must stay out of this Apply slice.

Do not call A13/CLI retirement complete from this backend checkpoint. Continue
the CLI slice, then Brainstorm/Plan ownership and the original same-subject
release requirements. Existing OSV findings and native/platform release limits
remain. The active goal is not complete or blocked.

Next-slice negative baseline completed on committed `bb629081`: temporarily
copied the three existing candidate tests for Review ownership, Undo feedback
and Forge host wiring into the qualification checkout. All five assertions were
red: legacy Core bindings still execute and the host lacks the setter/dependency
wiring (the two mutation controls also cannot remove absent wiring; not five
independent defects). Receipt `cli-apply-ownership-baseline`, exit 1, zero
providers, log SHA-256
`62d4713bca7f7e0e63043efb7cbe819df0d184027ab7049c9e49d70b2756a63c`.
The three temporary qualification copies were removed after recording; candidate
originals remain intact. Qualification is clean again at `bb629081`.

### CLI Apply/Undo ownership: review and corrections (2026-10-10)

Default isolated Agon reviewers completed against index tree
`716ade7a9b5e8d5eb284e21159611d91ccd5367f`. Packet SHA-256
`58e122ba344d9d297061eadb2aa0e7cb70c0964ef29a5d61a11bb01d58914d5b`.
Codex log: `162a6df12d1a951501f9c1cf5d054d1f5f50d7c137823e1e3492ebed87d3bcf0`.
Kimi log: `1478abb167aa961ea9bd692808dc289e2f4a7de4c6562df2c8491c880bc49dff`.
Both exit 0. Raw packets and logs remain beside this report.

Confirmed Codex finding: winner catch described every exception as a read/apply
failure, even after successful mutation. More seriously, the same exception
boundary in convergence could apply the ordinary winner after applying the
converged patch. Three negative controls reproduce lock-release, success-event,
and plan-save errors. `cli-apply-post-success-red`: 3 failed, 49 passed, zero
providers; log `34c4dc2f47acfbada365f1eebdb5e3fba662bcf5672fd042ab32194fe8402208`.
The lock case executed the physical apply twice. The other two swallowed the
error and returned the ordinary winner.

Correction: once a valid convergence artifact is selected, downstream errors
propagate without winner fallback. Lock cleanup reports a warning without
changing the apply result. Token handoff precedes success notification. Winner
errors distinguish unreadable input from an uncertain post-read outcome.
Callback warnings now say registration could not be confirmed, rather than
claiming a setter that changed state and then threw necessarily did nothing.
`cli-apply-post-success-green`: exit 0, zero providers; log
`093ad5b29f0db411f46888ad8288aa7eb182dac85fc439d8d4b635eae8e8bbc8`.

Other review adjudication:
- Review UI handoff exists in app.tsx: handleReviewActionCb stores the returned
  token. Confirmed source, not inferred from the truncated review packet.
- Undo failure retains its token; added focused assertion. The real-Git
  integration also proves conflict preservation, successful retry, record
  consumption, unchanged Git index, and a subsequent no-op Undo.
- `cli-review-undo-live-source`: exit 0, zero providers; log
  `99125d1e982b6d2248237d6d662c44f5e7e03c2cdd8274ce60a6503c8d5b228e`.
  This runs real Git and persistence through Review and the Undo dispatcher.
  The selected cwd is injected; this is not a live React/PTY proof.
- Retirement import guard covers direct named Core imports, not arbitrary
  namespace/dynamic/re-export indirection. No whole-repository retirement claim.
- Core public wrappers stay compatible. Their removal is not authorized by
  this slice's narrower CLI consumer evidence.
- Strict UTF-8 artifact reads are an intentional behavior change: reject invalid
  bytes before mutation rather than silently replace them.
- Review's pre-existing uncaught dispatch/errors and Forge pre-lock HEAD check
  remain separate follow-ups; no claim of hostile-writer isolation.

Initial tree build/typecheck/reexports passed (`cli-apply-index-build`). Corrected
tree `c630df6be9326c5b3f9169d081b30b9dfc4c6df4` build is in qualification.
The new real-Git integration test will change the final index tree. Final full
suite/lint and clean-subject qualification are still pending. No slice commit or
whole-release acceptance is claimed here. Unrelated Plan bytes remain unstaged.

CLI slice committed locally as `9b9f5e7378f21d4d23d7b8ac480dfd3ad5e8b9c2`,
tree `67608da1c95e27a5ca80c0da78c78ba97853d6b4` (12 explicit owned paths).
The two partially staged files contain only the undo setter and submit dependency;
their unrelated Plan edits remain in the candidate working tree.
Qualification checkout switched to the exact commit and is clean. No push.

Verified gates (all exit 0, no provider launches):
- Corrected production build, types, reexports: `cli-apply-corrected-index-build`,
  log `89809e00b80ea10aa976e7df96407b865280c595c43ce4e2616cd5f0954c4865`.
  Its tree differs from the final tree only by the added integration test.
- Final-tree full suite: `cli-apply-final-full`, 7,095 passed, six skipped;
  log `af2a817cc31fdcb7aac0f392d0010cdfe6d8b4989b1463fa57a96e6b801881d9`.
- Final-tree types, lint, reexports: `cli-apply-final-lint`,
  log `ff3aa042e8c93105446675a623e88ee871d419987523ef5e6baed099fda3d1a8`.
- Pack dry-run/public wrapper/negative controls: `cli-apply-pack`,
  log `7b777296fdce45a7595bc3d2f9b4ce00fd6a78b85499cbf0842bf54a10a3928e`.
  Reuses the full command preserved in `apply-final-pack.receipt.json`.
- Final real-Git Review/Undo workflow: `cli-apply-final-live`,
  log `7dfc6e4540f4c839f136bc8caff612a397ffa3df9127b34ada51f932ff18a4f3`.
  Three runs of this integration passed (candidate, full suite, final qualification).

Raw gate hashes were verified. Both index trees matched before commit; committed
tree equals the tested index. Qualification has no unstaged/untracked or ignored
source contamination outside node_modules/dist/dist-tsc. Dependencies were reused,
not freshly installed. This is a verified local increment, not final clean-install
or release acceptance. Live React/PTY token propagation is still not proven by
the structural App tests or dispatcher integration. Preserve that release cell.

Next work: verify the pending Brainstorm recording/session effects against the
committed source, including cancellation and partial persistence failures. Original
Plan, adapter, disabled-mod, and same-subject release dimensions remain active.

Brainstorm next-slice baseline: `brainstorm-record-cancellation-comparison`
loads the committed `session-record.ts` from Git and the candidate source,
transpiles each with the installed TypeScript compiler, and executes both against
the same effect recorder. Abort after checkpoint, user message, engine message,
bid tracking, winner tracking, and result storage: committed code continues to
write a completed receipt in all six cases; pending candidate code stops later
writes and emits one aborted receipt. This is one defect across six positions,
not six independent defects. No storage or provider effect was invoked.
Receipt exit 0 asserts both the expected red baseline and green candidate;
log SHA-256 `52a8a73b98fb02eadaec98fd7048844a5da09e07ba62bf002cc35a6a158f520f`.
The full executable comparison is preserved in the receipt. Candidate fixes
remain uncommitted and not yet independently reviewed. Partial-write receipt
idempotency and end-to-end session ownership still require separate checks.

### Brainstorm receipt recovery: in-progress five-file slice

The committed telemetry owner generated a new identity on every attempt and
overwrote JSON directly. New tests reproduce duplicate terminal receipts,
destruction of the previous ledger on an interrupted write, and overwriting
corrupt evidence. `brainstorm-telemetry-recovery-red` has four failed controls
(the post-rename injection also proves the old path lacks atomic publication);
log `c255cfc13a97b7882e2d96aeadbd7d62ff26b723e2ff17e77f50b6c8ce2c234f`.
Separate session controls reproduced missing stable IDs and replay of partial
history effects: `brainstorm-receipt-identity-red` and
`brainstorm-receipt-repeat-red` (raw commands/logs retained).

Proposed repair stays in existing owners: Brainstorm passes its existing run ID
to terminal telemetry, checks cancellation between effects, and refuses to replay
a partially started completion. Failure recording can retry. Telemetry accepts
an optional caller ID, preserves the first retained terminal receipt, performs
append under the existing support-persistence file lock, stages JSON exclusively,
flushes it, renames, and flushes the directory. New directory entries are flushed
up to their existing parent. UI read remains forgiving; append rejects malformed
or unreadable evidence. No separate store, dependency or generic manager added.

Five-path review subject: `bb004980620837c127ab4e9a4342fbbe94b3e78b`.
Packet hash `2d26464fec79e8a57c618e2d290c3da0a8822b253ef67d1363eb47dab3ff2c86`.
Codex review completed; log `592a41568e68bdfbbed187e2b25d2efd158162cded44a0ed323bf2b346667b8a`.
Kimi review is still running (session 92582); do not restart from silence.

Source-verified review corrections:
- The existing file lock reclaims live holders after its finite TTL. A new test
  reproduces a successful append stealing an aged live lock. Telemetry now sets
  staleMs to positive Infinity through the existing API: a valid live lock never
  expires by age, a dead local owner can still be reclaimed, a remote owner waits
  for intervention. No global lock-default change. This is local filesystem
  coordination, not a cross-host distributed lock or protection from tampering.
- Envelope-only validation accepted `{id: stable}` as a complete retained receipt.
  Matching and nonmatching malformed-row controls both failed. Append now checks
  required RunRecord fields and optional field types, preserving original bytes
  on rejection. It returns the actual stored first receipt on duplicate IDs.
- Newly created parent directories now receive directory flushes. File-fsync and
  post-rename directory-fsync failures have explicit controls; removing flushes
  makes those expected throws disappear. EACCES read control preserves evidence.
- Failed failure-recording retries use the same ID and settle only after return.

`brainstorm-receipts-review-red` reproduces all three new assertions; log
`aeb8a130d82cb48619dce45ab457524650f2effbb503232f3241f960f5ea5640`.
`brainstorm-receipts-flush-controls` passes, zero providers; log
`d044e70c898fa1fb72834ebe972e23a938e8bfe24bce073cb1a9b41d03d357e3`.
`brainstorm-telemetry-live-identity` also exercised real disk recording through
Brainstorm -> actual recordRun -> TelemetryLedger with a post-publication host
error; one completed receipt remains, not a contradictory second failure.

Corrected staged tree `dfef321f1842aac0571119967e5ebdae1f9af901` is currently
building in qualification (session 35381). The earlier frozen review tree built
successfully, but that is not evidence for the later corrections. Full suite,
lint, final filesystem qualification and Kimi adjudication remain pending.

Limits: first-ID retention ends when the ledger evicts that row (cap 2000).
History, ratings, result-store writes and terminal receipts are not one atomic
transaction. Advisory checkpoints do not prove cross-process workflow resume.
The existing public replacement `write` is not an append operation; only append
uses serialized read/modify/write. No whole Brainstorm ownership or release claim.
Pending session/render adapter retirement remains excluded. The partially staged
existing session-record test changes only two receipt assertions; its unrelated
adapter-removal changes remain unstaged.

Kimi review completed, exit 0; log
`0ae24c3fc1867d46be8f61177de3ac46a5d0b30bb4bfe02eb75a2b8811fc5add`.
Adjudication against current source:
- Generic-id collision is a hypothesis, not a confirmed caller regression.
  Traced recordRun calls in all CLI handlers: callers construct dedicated result
  objects; none passes an unrelated id. Stable identity is deliberately named
  like RunRecord.id. Omitted IDs remain generated; added two-real-call control.
- Reject the recommendation to swallow directory EACCES/EPERM/fsync errors.
  That would weaken the acknowledged durability contract. Windows is outside
  the requested platform matrix. The claimed false failure overwriting success
  is contradicted by same-ID dedup and the real post-publication recovery test.
  Unsupported storage must report an error, not pretend to have flushed.
- Retain directory sync on a duplicate: it completes an earlier uncertain
  post-rename flush. Removing it would allow acknowledgement without retrying
  the failed durability step. The file was already flushed before publication.
- Confirm expanded throw surface on corrupt input/lock contention. Preserving
  evidence is intentional, not a silent reset. Added public API documentation
  and actionable invalid-ledger path. Recovery after repairing evidence remains
  a normal same-ID failure-receipt retry; no auto-deletion of corrupt data.
- Partial history after cancellation and per-instance replay prevention are
  intentional bounded guarantees. No global restart-resume claim. Successful
  duplicate complete remains covered by existing session-record tests.
- Added controls for malformed envelope, forgiving UI read, first-failure
  retention, omitted IDs, cap trimming and later reuse of an evicted ID.

Native child-process pressure on the built owner: six concurrent processes,
each writes the same retry ID plus 20 unique IDs. All exited successfully;
121 unique receipts, zero duplicates or losses, ~10.5 s including module startup
under parallel full-suite/lint load. `brainstorm-receipts-process-pressure` log
`7782ee155467d84b4afa2548f1d8f4728441eeaf63501f85bd189d87648b4f29`.
Reproducer `telemetry-receipt-pressure.mjs` retained here. No provider launches.
This is concurrency evidence, not a performance-budget comparison.

Corrected full build/types/reexports passed (`brainstorm-receipts-corrected-build`,
log `33f3c2ef8ddcdc53ae627e2d433e11e6f36f37c875ce9fcfaf05a51365580755`).
Lint/reexports passed (`brainstorm-receipts-final-lint`). Full suite did NOT pass:
`brainstorm-receipts-final-full` logged 7,112 passed, six skipped, four failures.
The first runs-store prune timed out at 30 s; three later assertions saw the
still-in-progress prune. Both runs-store source and its test are byte-identical
to committed 9b9f5e73. Parallel child-process pressure and lint were active, but
load causality is not yet proven. Preserve this failed receipt; do not waive it.
Raw failure log `08cf683552f7571251c7fe8bf0bb93e2c6942ebe312956477e4d1d55828ece1a`.

Final staged tree now `958b32afab41434d647b822494fd59880551965c`: only additional
tests, documentation and actionable error text changed after the corrected build.
The affected CLI build/typecheck is running in qualification (session 60690).
The slice remains uncommitted. Next: finish gates without competing pressure,
then reproduce/qualify the pending run-store reliability fixes separately if the
failure remains. All original release requirements stay open where unproven.

Brainstorm receipt increment committed locally as
`19c63d96f68ad7c77eabbbe7e263e81dda1cc9e2`, tree
`958b32afab41434d647b822494fd59880551965c`. Qualification switched to the exact
commit, clean, no ignored source contamination outside dependency/build outputs.
Candidate's unrelated ownership work remains intact and unstaged. No push.

Final receipts, all zero providers:
- `brainstorm-receipts-final-cli-build`: affected final CLI build/types/guard pass;
  log `6a09215db01ae5bbb661a9bce498fc7f4c8ddd1b7bf8ff8ff56d958bdbd0d400`.
- `brainstorm-receipts-serial-full`: 7,120 passed, six skipped; log
  `dbe040c8e9d1e8cdd354197409a547c4efe6bc91fae74388da8721c68d5c3ca4`.
- `brainstorm-receipts-final-gates`: lint/types/reexports pass; log
  `3a370a0ebf5b309ad5fdeb055ae71b04cc66ebf07f41a90793f5cf11b186229d`.
- `brainstorm-receipts-final-live`: repeated native six-writer test passed,
  121 unique rows, zero loss/duplicates, 1.778 s including startup without other
  qualification workloads; log
  `7a3efcadfb41494428ad70b31c377c5cad2278e817c3fb96d6d924dbd53468bd`.
Two pressure runs passed. The earlier full-suite prune timeout is NOT erased by
the serial pass. Run-store load qualification remains open and is next. No final
release acceptance, clean-install claim, or complete Brainstorm ownership claim.

Next-slice evidence: copied the two already-pending run-store boundary tests into
the clean committed qualification checkout, ran them, then removed only those
temporary copies. Original candidate tests remain. Qualification is clean again.
`runs-store-boundary-baseline`: three failing assertions, log
`fb00b8f5179b158493efac0151fe49fc9113205a954c79f5c475341ed56b62fa`.
The scan-pause case selects paths in the replacement home after reading the old
home; the delete-pause case writes the completion stamp and refreshes counts in
the replacement home. This verifies a scope defect independent of timeout load.
The scan test also proves committed code issues only one stat at a time.
`runs-store-boundary-candidate`: all three pass with the existing pending fixes,
log `0bf3f045303df8ba93e633cb22649b6f1037666eb677dc110a38e5fdcae1433e`.
Do not equate the latter structural concurrency check with proof that load
timeouts are eliminated. Required next: review the three-path owner/test slice,
run actual large-directory and full-suite-under-load verification, preserve
prune policy/order, then continue Brainstorm session/render and Plan ownership.

## Run-store boundary and loaded qualification: 4efb6e05

Committed subject: `4efb6e053b90622521ad4796de1e284b4ced6392`.
Tested index and committed tree: `7d27b41092899342ad3d08af34c7e402a9df61ad`.
Three explicit paths only. The other candidate changes remain untouched.
The qualification checkout contains that committed tree with no source-bearing
ignored files under packages/src or tests. Existing dependencies were reused;
this is not fresh-install or whole-release qualification.

Change: capture the prune root before awaiting; keep stamp, scan, deletion, and
recount under it. Scan stats in batches of eight, preserving input order and the
existing retention policy. The CLI runs-store is a re-export of the persistence
package, not a second implementation. The changed helpers are module-private;
all call sites pass the selected root/stamp explicitly.

Independent review packet: `runs-store-boundary-review-input.txt`, SHA-256
`2fa395850e48455d2840d755c566a27d570afede0d9355e4a83dafbb82711dbf`.
Codex review log: `8219ebf7293f3db714bd656269e4b1f07a07ab76744059218cbc6f5cecc69dbf`.
Kimi review log: `789d1a7c7d1d17f4ccb2a2c5abcd7bcb06c5a92a133cc0dbec52ae735db29e03`.
Both exited zero. Neither found a new blocking defect. Codex's observation that
a throwing unlink mock could mask an attempted deletion was fixed with an
explicit zero-call assertion. Kimi's CLI re-export question was source-verified.
Its count-assertion caveat is valid: mocked directory enumeration alone does not
prove root-specific counts. The native probe below uses distinct actual roots
and verifies the untouched root's bytes and stamp, closing that evidence gap.

Receipts, all with zero provider launches:
- `runs-store-index-build`: root build/types/reexports pass, 158.6 s;
  log `5327573df14ff883bbc913a5ae438608ca5f8853c6246c64fdaf4d136f151405`.
- `runs-store-loaded-full`: 7,123 passed, six skipped; 54.68 s;
  log `4ed4818831620ee4c09928b18a85c1b0b03419c15248eda7e2c20ecc8523f64b`.
- `runs-store-loaded-lint`: lint/types/reexports pass, 72.617 s;
  log `545edb9a14cc995d690e20b92566c0f196a73067a3631b150b9f1e81e900cb3a`.
- `runs-store-loaded-writers`: six concurrent receipt writers passed, 121 rows;
  log `22d9a2c8381d04fcb3869bd2095ca2721cad0d80640de16c52b6bd7207ec3654`.
  These three commands ran concurrently, matching the previous load dimensions.
- `runs-store-live-baseline`: expected failure, original root still had 2,005
  records after the home switch; log
  `1426f6d140cd9b2df3c41e87b99f220cf111b6fe0d1ed48b8f91e3bd4a87c3fd`.
- `runs-store-live-candidate`: same native fixture passed. Original root pruned
  to 2,000; replacement's 2,005 records retained their bytes and had no stamp.
  A separate 10,000-record prune removed 8,000 in 572 ms, with 554 event-loop
  heartbeats. Log `0490d4d0b50b1383747cd531d436a3b3b7ece0aee0b489390e723e4c356f45a6`.

Native baseline uses the exact prior committed run-store source, transpiled with
the installed compiler; only its two dependency imports use the built public
persistence package. Probe and commands are retained outside the shipping diff.
The loaded suite passed once; this does not prove every contention schedule.
Inherited limitations remain explicit: no cancellation, snapshot staleness across
home changes, differing count semantics for unreadable/non-file JSON entries,
and scan-to-delete races. None is claimed fixed by bounded batching.
No push, install, personal-state mutation, or global Agon change.

## Brainstorm presentation ownership: qualification in progress

Base `4efb6e053b90622521ad4796de1e284b4ced6392`; staged tree
`8fdc52e89cfb7f4e7e837a87318ddb96a27b4658`. Ten scoped paths. This slice
moves display policy into mod-brainstorm and keeps terminal capabilities in the
CLI. It also moves the result type to its physical owner, with a Core type-only
re-export and workflow type conformance. No result parser, session orchestration,
Plan changes, or adapter retirement is silently included.

The legacy presentation fixture is byte-identical to the prior committed source
after removing its provenance comment and normalizing four import paths. Before
extraction, the ownership assertion failed while 13 behavior tests passed:
`brainstorm-presentation-baseline`, log
`4bbeff91e1b1f270325a809af647d63dd021e2c8462a585b104291c6c1928bb7`.

Review packet tree `a9aa724d3b0704d37579a18dbf1a7956d607771d`; packet hash
`d3618e7599341dfa74666acf0dd17bd97cb6f2d4069208d344e8a5020c46895e`.
Codex log `ea4bec05f374170fc104f881cbb0430fa7f53f7487cae993d902b40243467a52`.
No new production defect identified. Its timer-cadence gap was confirmed: elapsed
second dedup can hide a change from 250 ms to 500 ms. Added a direct injected-host
assertion for 250 ms and cancellation on completion before disposal. That test is
the only post-review-packet delta. Existing behavior tests independently check
fail/complete cancellation before disposal. Ownership tracing confirms the CLI
calls the mod's public export; forbidden-string checks alone are not that proof.

Receipts, zero provider launches:
- `brainstorm-presentation-owner-build`: root build/types/guard pass;
  log `6628fbc6a780c971a5218880877fad56dc78d28e8a2d2a412c98aa7edbc94702`.
- `brainstorm-presentation-owner-full`: 7,128 passed, six skipped, 54.768 s;
  log `71a375e7ba94822200b58915c950b7fbd760b681de2df51c2bccdfeca87fbf9a`.
- `brainstorm-presentation-owner-lint`: lint/types/generator drift pass;
  log `a1c6524a9c8f7f604243a60fe581bc15b74dda14b89fd4186d70794c6b0d9c05`.
- `brainstorm-presentation-owner-types-corrected`: strict public declaration
  compilation, bidirectional old/new structural assignment, and rejected string
  confidence pass. First attempt failed on compiler invocation TS5112; adding
  --ignoreConfig corrected only the invocation. Both logs are retained.
- `brainstorm-presentation-owner-pack-control`: offline npm pack dry-run matched
  the manifest exactly; every relative declaration dependency exists in the pack.
  Removing result.d.ts from the tested file list correctly fails the closure
  check. Log `54239aa180f8b71fe577532eb68f2d9414c66e2bedcaf40731ad640268bf4222`.
- `brainstorm-presentation-owner-live`: native real-clock run passed; two
  concurrent views stayed separate, progress advanced, late events were ignored,
  and disposed views stopped emitting. Actual Ink frames at 40/100 columns retain
  quality 71, confidence 0%, and body text. This uses the existing pseudo-TTY
  capture, not a human-operated terminal or full provider-backed chat session.
  Log `f980d1dc4eefab30c79e5cb332a0671051877c90d4d8da067d490402de0df9df`.

Kimi review completed, exit zero; log hash
`5c1508dffcacd7c99cc723568af354f7176dce5905343fb1147df620d0586d12`.
Source-verified adjudication:
- Alleged public-type drift: refuted. support-panel/seat-dispatch.ts:98 gives
  buildPanelHealth an explicit return annotation with exactly the prior fields,
  including banner:string|null. It is not an inferred, wider helper signature.
  The strict bidirectional public-declaration compilation also passes. The
  existing `as never` runtime fixtures alone would not establish this fact.
- Alleged Core/mod cycle: refuted. Brainstorm imports no agon-core and its
  manifest/package dependencies contain only mod-api, kernel peer, and shared
  support. Core already declares mod-brainstorm. The ownership roadmap requires
  retiring Core ownership, not returning the canonical type to legacy Core.
- Mutable scoreboard concern: no current defect. The mod only reads entries;
  CLI bindings close over an invocation-local board. Fresh entries() calls see
  each host mutation, so returning a current snapshot would also work. Freezing
  or inventing another ledger abstraction is not needed for the demonstrated
  ownership move. Future host implementations must honor the same operations.
- Narrow ownership/string tests: valid limitation, not sole acceptance evidence.
  Source tracing proves public delegation; raw-event parity and rendered runs
  prove behavior. Existing tests include completion with bids-only engines,
  panelHealth, concurrent views, repeated completion and failure/disposal.
  Malformed/duplicate event variants are not claimed exhaustive.
- Type-frozen fixture: runtime oracle imports erase; old/new public shape has a
  separate frozen structural compile fixture. The runtime oracle is not claimed
  to independently freeze public types.
- Alternative scoreboard abstraction: taste-level; keep the existing terminal
  implementation and narrow injected operations instead of adding another owner.

No unresolved demonstrated regression in this slice. Whole-release acceptance
remains open. No commit was claimed before review reconciliation.
Committed as `a23f130dbd3c58dc3573a45b09fc507f4454d015`; committed tree matches
the tested `8fdc52e89cfb7f4e7e837a87318ddb96a27b4658`. Qualification checkout
switched to that commit and is clean. Candidate index was checked against the
exact ten-path list and tree before committing because manifest/generator/result
files have additional unstaged session work. That work remains unchanged.

Next unresolved requirement: Brainstorm session preparation/settlement ownership
and A06 adapter retirement. The pending mod session workflow and CLI capability
binding have been read, not yet accepted. Check result parser compatibility,
cancel and diagnostic failures, generation-selected/disabled execution, fixed
chat-session binding, recorded effect order, and no duplicate invocation before
accepting those files. Then continue Plan ownership and the remaining roadmap.

## Brainstorm session extraction: review corrections in progress

Base a23f130d; initial review tree `6d747153e4dd82ebf1ab82da556ad03506e8776b`.
The existing pending implementation moves preparation/settlement into the mod,
injects the selected executor and host effects, and retires the CLI record adapter.
It does not yet retire every A06 binding or close all disabled-mod paths.

Confirmed baseline: `brainstorm-session-binding-baseline` fails because the
committed CLI presents success before receipt recording (call order 3 vs 10).
Log `449c0d6a74101c6a6db5f54ef425b176f9b09625bdc9f4dcae23e678d2687fbe`.
Pending extraction fixes that order. Added sparse-engine controls: one hole-only
array incorrectly reached execution because map/every skip holes. `Array.from`
normalization fixes it without changing valid strings. Red log
`6413184c18a22a40dc3545945fca0d3eea100b4dab88f5251981d880a2a62ce0`.
The rebuilt initial slice passes 71 focused tests; log
`83c6ab489ce7b1fc1d62ec1a4b8f37637f790a8f4af4052150cd9a3b4e108a08`.

Default review packet SHA-256:
`2b1a322198673c16565587381004853f1d9576d99bd1203e14a65988a2e43386`.
Codex log `90d2d41aab1bc5878b7f8f1c28142961adda077502a2f06ddef2453a63d1336f`.
Kimi log `3cedc7ebad9b686d8765b809de7ca6c48a68d99ae6eb59ccbaa822b52b6901c1`.
Both exited zero. Findings are hypotheses, not acceptance evidence:

1. Codex: catch read signal.reason after failure effects. Confirmed: a renderer
   abort could replace the original execution error. Capture the chosen error at
   catch entry; test presentation, receipt and diagnostic callbacks separately.
2. Codex: summary formatter throws after receipt commit, suppressing the answer.
   Confirmed with the real recorder. Recorder now treats optional formatting as
   non-fatal after settlement; an optional injected warning reports it. Diagnostic
   failure cannot replace the saved outcome. CLI binds this warning to dispatch.
   The old test's required formatter exception changes because it asserted the
   verified defect; its no-duplicate-receipt oracle remains and now also requires
   a successful receipt. No persistence exception is swallowed.
   Both bugs reproduced in `brainstorm-session-review-red`, log
   `7f36acf185f20071763a640f359fa59ceb940c38f75c9a5f8c43b671e5ad40ec`.
   Rebuilt recorder/session tests pass in `brainstorm-session-reviewed-package`,
   log `3e9afd5dce776d6066f095962249d00747d448e1c3750c9e0398d9a3cf4b8d83`.
3. Both reviewers: removed bare-result fallback. A public executor compatibility
   control reproduces this change. Preserve the fallback and validate its actual
   result shape, rather than silently narrowing the existing API. Red log
   `eb2962dcfccf99e6135c0d14fa674325fa128ef234738320112bc43d0cb61dbd`.
4. Kimi: validator/producer alignment was omitted from the review packet.
   Source confirms workflow returns question, bids, dedup, synthesis and health;
   buildPanelHealth has an explicit banner:string|null return field. Added parse
   assertions to the existing real-workflow parity scenarios, rather than relying
   only on handwritten valid-result fixtures. Not yet run at this entry.
5. Kimi: possible duplicate presenters. Refuted by a23f130d: CLI delegates to the
   public mod function, with a native rendered probe in the previous slice.
6. No-session input checks intentionally reject invalid requests before effects;
   historical-result readers do not call this new live-result parser.
7. Existing success-notification exceptions, checkpoint best-effort writes and
   partial multi-store history remain separate limitations, not claimed fixed.
   Kimi's statement that array spread preserves holes is incorrect: spread fills
   them with undefined; that control still usefully checks explicit undefined.

Invocation errors retained: two targeted attempts used stale public dist exports
before the corresponding package rebuild. These are not product regressions.
The initial root build overlapped review source corrections and is diagnostic,
not a frozen-subject acceptance receipt. Final qualification must use rebuilt
artifacts from the final staged source, then tests and native runs. No commit yet.

### Session extraction accepted locally: 2e079535

Final committed subject `2e0795350af7cf6682e7974352d6131a15833cd2`, tree
`d5a964a13d39e1441ad25399acca693bc086eca8`. Exactly 17 staged paths were
committed after checking the exact tested tree; unrelated candidate WIP remains.
Qualification checkout switched to the commit and is clean. No source-bearing
ignored files were found under packages/src or tests. Existing dependencies were
reused; no clean-install or release-wide acceptance claim.

All review corrections above are implemented. The bare-result fallback is retained
and structurally validated; the new bare-result control now passes in the full
suite. Real workflow parity scenarios pass through parseBrainstormResult without
normalization and retain object identity. The malformed winner/response/bid cases
now also run with other required fields valid, avoiding masked assertions.
The recorder's optional warn capability is backward-compatible; the CLI supplies
it. A warning callback that throws cannot change a committed successful receipt.
Failure error selection occurs before presentation/receipt/diagnostic callbacks.

Final receipts (all zero provider launches):
- `brainstorm-session-final-build`: complete root build/types/guard passed before
  the final bare-result line and test-only additions; log
  `c041f812e616d49ab34ae02bbf39ff245dc280834c98a611e39ccd0536b38885`.
- `brainstorm-session-final-owner-build`: both affected packages rebuilt after
  the final production correction, then types/guard passed; log
  `28d72e444a7122dd1c8f73c2b8b193088e14733018c592490138285db39c8c71`.
- `brainstorm-session-final-full`: 7,181 passed, six skipped, 54.859 s;
  log `09d35d1e35a5927359697e603f45686e43929f7b12f064054d79ca6e53df05dd`.
- `brainstorm-session-final-gates`: lint/types/reexports/generator and strict
  public consumer fixture compilation passed; log
  `1b09524b47434ef942d9083414a994fa2d6fcfd15527422b139b38173438f845`.
- `brainstorm-session-final-pack`: exact manifest pack list and declaration
  closure passed, including the missing-result-declaration negative control;
  log `6d6bd80420b897218867607e681ade9f39b12a3827c9b2b125fc751109a46ae9`.
- `brainstorm-session-final-live`: four actual compiled CLI-binding invocations
  with real native chat/checkpoint/telemetry files, fake executor only; passed.
  Receipt states: completed, aborted, crashed, completed. Four messages stayed in
  the original chat; replacement chat stayed empty. Six checkpoints share IDs
  with their four distinct receipts. Receipt exists before success presentation.
  No late events after cleanup. Log
  `0138602e0057161b1b0c4c94a64eadf5a2aea2603e2a6a53989e089127ed7118`.

Source tracing finds no old adapter import; the only source/test path mention is
the negative existence guard. The deleted adapter remains recoverable from Git
at a23f130d; no evidence archive was deleted. Generated S5 ledger check remains
green (36 packages, 344 assignments), which is not proof of all 872 assignments.
Disabled/generation execution uses the passed selected executor as before; the
native fixture above is not an end-to-end generation selection test. That broader
acceptance dimension remains open. No push/install/global or personal changes.

Next: retire remaining Brainstorm Forge/Core host and dedup adapters with parity
evidence, then finish Plan owners and full release qualification. Existing TUI
and Cesar host bindings are not declared retired by the record-adapter deletion.

Next slice started: A06-DEDUP. The qualification checkout has only the pending
`tests/unit/modular-dedup-owner.test.ts` copied over the committed version; this
is a deliberate red-baseline fixture, not accepted code. It checks retired-path
absence, scans production imports with the installed TypeScript parser, and has
static/type/re-export/dynamic import negative controls. The source body of the
frozen dedup oracle retains its original SHA assertion. Candidate originals are
untouched. Planned extraction scope: Forge import, the two-line adapter deletion,
direct consumer test import, frozen Brainstorm fixture import, parity mock target
and the removal guard. Do not include pending kernel logger changes when staging
the parity test. Those belong to a separate ownership slice.
`brainstorm-dedup-retirement-baseline` reproduces two expected failures: adapter
still exists and Forge still imports it. Oracle hash and import-detection negative
controls pass. Log SHA-256
`d2172d36d685ac0d867fc4138c809324e9b0d929e5eae54a5ea78e68689ba73a`.

### Dedup retirement qualification in progress

Staged six-file tree `69b684562d4075d1a8fd062f6c3667ae4e7eedbc` on 2e079535.
Only the existing public support import replaces the two-line Forge adapter.
No controller, sidecar, dependency, or kernel logger changes are included.
The Brainstorm fixture now uses the frozen dedup oracle; its controlled workflow
mock follows that path. Controller independence is proved separately by the
16-scenario raw result/process-effect parity suite and unchanged oracle-body hash.
`brainstorm-dedup-retirement-focused`: 37 tests passed, not 38; log
`cb80d7757add1a07ef9fbb9b05fff0cf7c50e3ea84765ebfbd73eb27d468d7f4`.

Default review packet hash:
`d23700c985bfa645f3397f84416c6682604e0d7f3e59416af58c1449532a27d2`.
Codex log `f88604976d990cc8dff9eb353bde5a7b9a0889bdb44af0f0f8dc7399eeb850d8`.
Kimi log `0fd9b30159b5a69fee474f3c9e24c58942f95e4f44c1f38c0e6cebec6fea9c08`.
Both exited zero; no new actionable production finding. Forge already declares
the support package and exports only its root, not the removed private path.
The guard covers source TS relative imports, including static/type/re-export and
literal dynamic forms; aliases/computed imports remain a stated scan limit.
Kimi's suggestion that deep relative imports are missed is refuted: dirname plus
resolve normalizes them to the exact target before comparison. No production
dedup-bridge reference remains in the inspected tree. Extensionless spelling is
not covered, and the guard does not claim arbitrary dynamic-code completeness.

Native subprocess probe prepared outside shipping source. It uses a fake Node
sidecar executable (not Python/model downloads), tests success/malformed output/
unavailability, and checks child PIDs are gone after timeout and operator abort,
including a fixture that ignores SIGTERM. Not yet run at this entry.
Inherited partial-render errors and stale scoreboard errors are not claimed
fixed by this mechanical move. No global state, install, or push.

### Dedup retirement accepted locally

Commit `22fbc4f32ef1b54e6bdb676779f34df62d161bad`, tree
`69b684562d4075d1a8fd062f6c3667ae4e7eedbc`. The exact six-path index was
verified before committing; the partially staged parity test excludes unrelated
kernel-logger work. Candidate worktree changes remain preserved.

Final receipts (all exit 0, zero provider launches):
- Full suite: 7,183 passed, 6 skipped, 53.124 seconds. Log SHA-256
  `ff40edbf58cde90a2bea56fd1d92a38a1f8372760be452882e7483e2efaa7cb2`.
- Lint, typecheck, re-export and first-party drift gates: 72.648 seconds.
  `6b07dbf690acd92b2252c7dcbcf9fd9310b3f8ecf10bfd7c09cd8e448fe7658d`.
- Offline Forge pack-content check: retired adapter absent, public entry present.
  `316ab0864fc338fadd3fe0c343cc0a34b6edaa852c28c276364829ab83927411`.
- One native subprocess run, 1.908 seconds: success, malformed JSON, unavailable
  sidecar, timeout and abort; hung children that ignore SIGTERM are terminated.
  `24ce30b3a4d4fa7fba06e9c88eea37d1497cde976ecef7c05b4be674361120d9`.
  This uses a fixture executable, not real Python inference or live providers.

The user explicitly approved OSV metadata submission. The existing recorded
online scan completed and reported 16 vulnerabilities across nine package entries
(two critical, seven high, six medium, one low). Scan exit 1 denotes findings,
not an authorization or connection failure. No dependency upgrades were made.
Receipt: `workspace-edge-osv-online.receipt.json`. Release security remains open.

This closes only the dedup adapter retirement, not all A06 ownership or release
acceptance. Next ownership boundary: kernel sidechain logging and Brainstorm host
capability adapters. No installation, promotion, personal-state change or push.

### Kernel sidechain ownership qualification in progress

Previous goal turn made authoritative progress: dedup retirement commit 22fbc4f3.
Current frozen staged tree in the isolated qualification checkout:
`42543bed9f4ca807cfc0e634645bb3ae868533e4` (eight paths; rename-aware seven).
Ownership ledger assigns SidechainEvent to minimal kernel machinery. Logger body
is byte-identical to 22fbc4f3, SHA-256
`266abce83c450811a018c767942cd9184d528fd60ab05ffd156c5d07ede06bd8`.
Core's public runtime and type exports remain. Existing Forge consumers keep
their public Core imports. Core already depends on kernel; logger adds only Node
built-ins, no reverse dependency or new package dependency.

Default bounded review packet SHA-256:
`2b6082873525d356f137b1c40d9ed930a1071b37937d10056d13156341cc41bf`.
Codex: exit 0, log `0d3f28002087dcf0647ea1a742042d851104e69f59bb93fbd62015506babe09b`.
Kimi: exit 0, log `463e9c6283ed53f1404e83f68dd24ddf23edd979daffa496dd0c2ad41502b437`.
Neither found a new move defect. Both correctly distinguish mocked workflow
evidence from real package exports; prepared native identity/JSONL and independent
public declaration consumers close that gap once run. Repository source scan
found no remaining old-path consumer beyond the intentional absence assertion.
Core export map exposes only its root, not the deleted source path.

Review limits: mock removal can weaken workflow parity; existing effect records
are compared but this is not proof of built exports. Byte hash is a move-integrity
guard, not a permanent prohibition on changing the logger. Future intentional
behavior changes must replace that oracle with explicit regression evidence.
Path components are not validated, logs are not redacted/bounded, and writes are
synchronous/best-effort. These are inherited and remain relevant to release
security, not evidence of safe untrusted usage. Traced all eight production
workflow IDs: randomUUID (sometimes sliced); sessionType is a literal. Thus no
current first-party caller passes untrusted filename components. Public callers
and third-party capability handling still need release-boundary qualification.

Focused pre-build run: 34 tests passed, receipt `sidechain-kernel-owner-focused`,
log `17efd58106790d7295d74b9e937419052f997387858c76f04cf8e49e2b00e3c9`.
One hash-integrity assertion was added afterward; final full tests must include
it. Full build is running. No slice acceptance or commit yet.

Qualification update: full build passed (154.980s), SHA
`0c6b187b9dc465e208fd126e865681175b9776b4221aa4d55a9f3cddf0946b37`.
Pack-content checks passed for kernel and Core; old Core declaration absent,
kernel declaration present, SHA
`9a8863ec4f10c24b593bda54687cbdbf25ed4794d316101f6cd8f60a54968f8a`.
Native public Core/kernel function identity and real JSONL parent/child output,
optional fields, nested directories and nonfatal write failure passed once,
SHA `547d277b04ce1af1b308eade66503a56bfea13c11294ee79def544fc83f832f5`.
Lint, repo typecheck, re-export and first-party drift gates passed. The following
external consumer command initially failed TS5112 because this local TypeScript
requires --ignoreConfig for explicit input files; corrected command passed in
`sidechain-kernel-owner-types.receipt.json`. No source change was needed.

Acceptance remains RED: full suite found four runs-store failures. First old-file
prune exceeded 30s (34.281s); three subsequent cases observed its still-running
singleton. 7,181 passed, 6 skipped. Receipt `sidechain-kernel-owner-full`, SHA
`768e03f98e3a205d7e9c222ed85b5691fdd0c967b866ddc7d8122dbe9fca6506`.
The earlier batching repair did not eliminate loaded-suite timeouts. Do not
dismiss this as unrelated or increase timeouts. Standalone unchanged runs-store
suite passed in 1.699s (receipt `sidechain-prune-isolated-diagnostic`, SHA
`4a67828c74bef35a820af48636f22a5584af7216ab876e5e54f1fc8bff91eb9f`).
An external preload now measures matching fixture synchronous seeding and async
readdir/stat/unlink durations during `sidechain-prune-loaded-diagnostic` (running
at this note). It changes no production code or test oracle. Await its terminal
receipt and inspect PRUNE-FS-DIAG before proposing a fix. Logger slice remains
staged only in qualification, frozen tree unchanged. Candidate still at 22fbc4f3.

First instrumented full-suite diagnostic passed in 51.858s, log SHA
`aeabd7789ffad4782c6d972bbbab3809f9afd445d0a1d23eb00b85093cac9faa`.
Its first prune seeded in about 2.3s and scanned/deleted/recounted within 80ms.
Across 6,017 stats: summed duration 1.155s, maximum 16.84ms; 41 timing samples.
This run had no simultaneous lint/typecheck, unlike the failing qualification.
It does not explain the earlier timeout. Started a paired run matching that
contention: `sidechain-prune-contended-diagnostic` and
`sidechain-prune-contended-gates`. Await both receipts; retain all failures.
No production fix, timeout increase, test exclusion or slice commit was made.

### Prune fixture contention: measured cause and bounded repair

The paired synchronous-fixture run passed narrowly (51.173s overall), with the
first setup spending 24.956s in writeFileSync and 1.984s in utimesSync before its
first scan. Stats/deletion took milliseconds. This proves fixture setup consumed
nearly the entire 30s deadline in that run, not that the original uninstrumented
failure had exactly the same timing. The original red receipt remains retained.
Paired diagnostic SHA `62b941f96b5214d371abe4846edf3459f6af5db2106b5c7b5fbeeebe752fad96`;
paired gates SHA `7617317431c9257caee946af74d4136d785d92c0aa4cf4567a8f187a5ce065b6`.

Test-only repair: eight concurrent write-then-utime chains per batch. All five
callers await completion. Same 2,005 names, bytes, mtimes, test count, expectations
and 30s deadline; no production or Vitest configuration change. Existing candidate
WIP already contained a similar optimization plus diagnostic mocks; retained
those WIP diagnostics outside the staged subject, using only the fixture repair.

Default review packet `f841f8a1084fa0feae4f594d5b3ec669d45cef41bf39cca398c82115c9137067`.
Codex log `7df8092ea972d6395613b573cc11ae601dd62f3efb295bc72d394b95b6b9e46c`;
Kimi log `188cac1bcdff0f5322e49fc1be8301289573cb645dc108027ae429fecb121064`.
Both confirm unchanged oracle. Codex's failure-path race was reproduced: one
write rejection leaves seven sibling writes pending under Promise.all. Kimi's
unqualified race-free claim is rejected by that executable counterexample.
Changed batch barrier to allSettled, then rethrow the first rejected result.
This drains started work on filesystem failure; it does not claim cancellation
of an arbitrary external test timeout.

External equivalence probe executes old/new helper bodies with the same clock,
compares every filename/content/mtime, rejects a deleted-file mutant, and injects
a failed write with seven delayed siblings. Negative receipt
`prune-fixture-failure-baseline` failed with pending=7, SHA
`044cdec072e2d2cbe47603bd5f396af102f801bad5103c0164f0849d7e01cb1a`.
Fixed receipt `prune-fixture-failure-fixed` passed (pending=0); full fixture
equivalence passed too, log `8428106425022b54c76fc2f3b535c7ab117ed8bbf2cd705be9b418f4a68d61fe`.

Loaded async-fixture full suite passed in 52.726s, SHA
`3073cd39f52c84e5b04664679754efa31494f204e7023291343baa030f85f121`.
First setup completed near 3.4s process elapsed, versus 27.8s before; summed async
durations overlap and are not wall time. Final uninstrumented full suite plus
concurrent gates now run on combined tree
`dfe005a35d29847d86115b2b8d6295fd54e0b688`, including the drain fix. Do not reuse
the earlier review as proof of that fix; its negative/positive control is above.

### Kernel sidechain ownership accepted locally

Commit `d4e795f693cd2fdd231d2c55d4b4dcfb79ec6743`, tree
`dfe005a35d29847d86115b2b8d6295fd54e0b688`. Nine physical paths, eight in
rename-aware diff. Candidate's exact index was checked before committing; Core
Plan changes and run-store diagnostic WIP remain unstaged. Qualification checkout
is detached at this commit and clean. No push or personal/global state change.

Final uninstrumented full suite: **7,185 passed, six skipped**, 54.641s, receipt
`sidechain-fixture-final-full`, log SHA
`16ffedb61b6edbe27ebc781c960913c683496f1918bf3e5f0fa4b140fbc29d84`.
Concurrent lint/typecheck/re-export/first-party gates: 73.902s, receipt
`sidechain-fixture-final-gates`, SHA
`7617317431c9257caee946af74d4136d785d92c0aa4cf4567a8f187a5ce065b6`.
Native real-FS/public-export probe repeated last, 0.180s, receipt
`sidechain-fixture-final-live`, SHA
`547d277b04ce1af1b308eade66503a56bfea13c11294ee79def544fc83f832f5`.
Two native logger probes total. All verification provider-launch lists are empty.
The initial full-suite failure remains recorded; the fixture repair preserves
file count, timestamps, assertions and deadlines. No universal no-flake claim.

Next traced boundary: Core Brainstorm host still binds Glicko ratings and task
classification. EngineRegistry already delegates physical catalog ownership but
injects Core's Glicko lookup. Core glicko.ts is still substantive; mod-ratings also
has a distinct ratings reader. Do not merely move the host adapter into another
folder and claim retirement. Trace rating algorithms, state schema and callers;
reconcile mod-ratings ownership and shared ranking behavior before extraction.
All earlier remaining Plan/Apply/disabled-mod/full-release requirements persist.

### Ratings ownership trace exposed a destructive compatibility regression

On clean d4e795f6, Core's glicko.ts is 406 lines and ratings-maintenance.ts is
178 lines; mod-ratings has a separate 119-line implementation. The Brainstorm
host cannot be retired honestly while its ratings effects still live in Core.
Before extraction, a confirmed behavior defect needs correction: legacy CLI
ratings.ts protects registry.listIds() plus config.ratingsPurgeKeepEngines and
--keep. Modular runRatings used engines.listActive(), whose CLI/MCP providers
filter inactive and default-excluded engines. Missing listActive became [].
Thus a valid --apply could move legitimate run history and remove ratings for
registered but inactive/filtered engines or configured historical IDs.

Regression baseline `ratings-protection-baseline` failed both cases: too broad
purge set and missing-host fail-open. Log SHA
`079862041d7ee971c45f649d010ffe4b7f76f7c93d36991d950ca3670b0ad141`.
Proposed correction adds one optional bundled ratings host capability supplying
the complete protection set. CLI/MCP bind it to registered IDs and legacy config;
the mod unions --keep, validates the response and refuses purge if capability is
absent. Active-engine selection retains its existing meaning and is not widened.
Existing package fixture now supplies this host. Host tests cover both surfaces,
config union, no dispatch and no capability on unrelated mods. Original focused
failure after implementation was the old fixture lacking the new host; retained
as `ratings-protection-focused`, not claimed successful.

Focused host + real-file purge tests passed in
`ratings-protection-host-focused`, SHA
`7e792a34da1ea40a98e60448ddfc96182c2363441862075c70d0ca780f219042`.
Full build running (`ratings-protection-build`). Seven-path proposal only in
qualification checkout. Candidate d4e795f6 and its unrelated WIP remain untouched.
Required before acceptance: default review, full build/gates/tests, compiled
real-FS probe, public contract checks and frozen subject receipt. This does not
yet consolidate the duplicated ratings storage/algorithm or retire Brainstorm
host capabilities. Async home switching, stale run-manifest mutation and state
redaction remain separate safety dimensions to trace, not silently waived.

Review packet for ratings protection frozen at tree
`360656bbf2222dd45c13f7fc05dd376c25e4f440`; reviews running under IDs
`ratings-protection-codex-review` and `ratings-protection-kimi-review`.
Additional malformed-host tests reproduced sparse-array bypass: Array.some
skipped a hole and allowed purge. Red receipt
`ratings-protection-malformed-baseline`, SHA
`3722f3637dba50b16e92a2d1195bf04273043d02e20926d9f439f1b15f611279`.
Validation now visits holes through Array.from and rejects padded IDs rather
than silently treating them as different protected engines. Null, string,
numeric ID, empty ID, padded ID and sparse-list tests are included. This source
change occurred during the first build; that build must not be final evidence.
Rebuild the affected package after it completes, then full qualification.
Codex's preliminary review additionally identifies existing home-switch,
permission-cancellation, stale manifest and false moved-file receipt risks;
verify and fix these before calling destructive ratings maintenance qualified.

### Ratings protection repair accepted locally

Commit `482d9c105c1381189800619bafd2cc72d5fe2a8e`, tree
`61344a041b9875a4cd48d6e90b9145d77ec6ba73`. Seven explicit paths; existing CLI
and dispatch-test ownership WIP preserved outside the index. Qualification
checkout clean at the same commit. No install, personal state change or push.

Default reviews both exit zero. Packet hash
`1a16c0adf7585d43924f0e9569173a26a4eb16973ecaa41b59b68fb41775082f`;
Codex log `fad8f113f04b1146ca63fd5c20d32f2614dd5445e1cc2831bda455749d801e89`;
Kimi log `cffdad451b39b2d7db08d9af30bd5c464b95b6e879bcf6fa431ada18e46ef72d`.
Source-verified adjudication:
- Complete registered/config/CLI keep union is restored. Registry.load also reads
  the user engine directory (support-engine-catalog/engine-registry.ts:212).
- Malformed/sparse/padded host values are rejected; earlier red evidence retained.
- Kimi's non-array config guard finding reproduced in both hosts, then fixed
  with the legacy Array.isArray behavior. Red SHA
  `47eb18362104f7ad663e601ad21668004c13522c79d8f1ce344573c51f0d3087`;
  fixed focused SHA `a2b66cae82ddcef962a2a4339b86e78fa99f800bb0d4400add1c77ca2e23c186`.
- Four permission-boundary cases reproduced: cancellation; home change during
  registry read; home change during permission; manifest gaining a protected ID
  while permission was pending. Red SHA
  `9ea539f929f137f35b916efc0a35897d609cad7164b1cc567766fcdfc88af65f`;
  fixed SHA `43ebd5d83036926696675e08bbf56b3087631e17012c5943b77f9d1bc4c3a5a4`.
  Cancellation/root checks precede writes; manifests are rescanned after approval.
- Applied runsPurged now contains successful moves only. ENOENT is omitted;
  other move errors throw with the backup recovery location, not false success.
- Kimi's second-granularity backup claim is false: ISO timestamp includes
  milliseconds. Same-millisecond collisions remain possible, not proved fixed.
  Its claim that legacy reports nonexistent no-op backup directories is also
  false: legacy uses lazy nullable backupDir; modular behavior still differs.

Build receipts: initial full build passed but overlapped subsequent edits and
is not final subject proof. Affected ratings package rebuild/typecheck/guard
passed (`ratings-protection-final-build`); corrected CLI/MCP workspace rebuild
passed (`ratings-protection-host-build-corrected`). Earlier command mistakenly
used nonexistent workspace @kernlang/agon-cli; actual package is @kernlang/agon.
That failed command is preserved, not counted as qualification.

Final full suite **7,205 passed, six skipped**, 54.688s; log SHA
`9cdd9fdbc4375134be45daadffc77268826e67ad9230ec4b2e309598c17a6738`.
Lint/typecheck/re-export/first-party drift gates passed in 75.316s; log SHA
`784c7889fc43959469e845e593befd62decf478591eaaf8930c8d50a21236e49`.
Native generated CLI dry-run/apply passed twice (four successful CLI invocations),
using isolated real ratings/run files, user definitions with missing binaries,
filtered ID kimi, config keep and --keep. Only fake data is moved; pre-purge
ratings and run bytes remain in backup. Final receipt
`ratings-protection-final-live`, 0.619s; SHA
`750d3d1b46eb06174d5e8c5b555d6eee5fca34408373ed19a77f87f7069ac1a3`.
All verification provider-launch lists empty. Two initial probe failures retained:
one assumed a single JSON document; one assumed bundled kimi existed in the
isolated catalog. Explicit user fixture definitions removed that catalog
assumption. Neither was hidden as an application pass.

Remaining confirmed follow-up: generated nested ratings command emits purge
JSON followed by parent leaderboard JSON. It should not run the parent action
after a selected child; trace generic generated CLI dispatch before fixing.
Other unresolved dimensions: cross-process manifest replacement between scan
and move, same-millisecond backups, no-op backup reporting, applied unknown-ID
report from pre-permission snapshot, ownership consolidation of Core Glicko and
mod-ratings. This commit fixes the demonstrated protection/await regressions,
not the entire ratings lifecycle nor full modular release acceptance.

### Generated nested CLI dispatch repair in qualification

Source cause: installed Citty runs a selected child and then parent.run. The
generated CLI parent used run-time-only authority checks and invoked its own
contribution afterward. Baseline tests reproduced duplicate child/alias output
and a disabled cached parent's child effect before refusal (three failures).
Receipt `cli-nested-dispatch-baseline`, log SHA
`e70bbb8ad257f63363d37f595c5e001b90d3bffe3063ed249aa25d5ee5c6986f`.

One production-function change: assert generation/availability in setup before
child selection; parent run skips its own contribution when Citty selected a
child. Existing direct-run authority checks remain. Children retain their own
before/after execution guards. Kernel/lifecycle lazy commands are unchanged.

Default reviewers saw initial tree b8b253c3e5453b5601698cdc8f0bd2aa874ca8fb.
Packet SHA `bdf3bfb343be0ffeac09154ac4c401fc1f1bf113c339e7f14ba6b63adcd8ea48`;
Codex log `a1ba0e228821f397c2ddba78afcf192fc3f63416de661683a1c0c8cd1c372f01`;
Kimi log `9376129c4dad276377b72a39fc334ff9efdca23598b9edc2025641268d6623e6`.
Codex identified empty-string divergence: some(non-option) is true for '',
but Citty treats its first candidate '' as no selected child. Reproduced in
`cli-nested-empty-baseline`, SHA
`d0a78e9213e9edb33535288202ef32b53f583e134dcf5f8a087fced9a105e9d1`.
Fixed with find + candidate truthiness. Kimi's claim of exact equivalence for
the original predicate is refuted by that test. Added generation-sensitive
cached rejection and enabled/disabled/stale direct-run checks. Both reviews'
scope limitation is retained: this is not a global generation proof.

Focused related tests, CLI rebuild and typecheck passed after fixes:
`cli-nested-review-fixed`, SHA
`e0f934757096e3bc269707b43c2ac8a7625311249a7b4d3f38528e7e18bca58b`.
Final staged tree `fc66a2e93cb61f51104c5030894a1ebb967809f3` has only two paths.
Full suite and standard gates are running. The compiled generated CLI dry-run
and apply probe now requires exactly one JSON document per child invocation;
it passes with all ratings protection assertions retained (`cli-nested-dispatch-native`,
SHA `97eec5ed35a42223ad15a9282edefd81efea2f8f44f1d64490dc4013e33a1db4`).
No commit or full-slice acceptance until remaining gates finish.

### Nested CLI repair accepted locally

Commit `db2a8c774128b1e74ec670890dffd7e8abf0c343`, tree
`fc66a2e93cb61f51104c5030894a1ebb967809f3`. Exactly two paths, no unrelated WIP.
Qualification checkout clean at that commit. Full suite **7,217 passed, six
skipped** in 56.253s, receipt `cli-nested-dispatch-full`, SHA
`29a0302693e5b480b2e4e6ed7f674fb7e7a07ee7279c2e9f7a3110cade06af27`.
Lint/typecheck/re-export/first-party gates passed, 76.456s, SHA
`c71eb0de99d017106a7677cafd054513f56998986a58edb991365f0933ad8fd2`.
Compiled CLI probe repeated last (dry-run/apply, one JSON document each),
`cli-nested-dispatch-final-live`, 0.615s, SHA
`97eec5ed35a42223ad15a9282edefd81efea2f8f44f1d64490dc4013e33a1db4`.
Four successful compiled CLI invocations in this slice. Provider launches zero.
No push, install or active/global state mutation.

Next implementation work is remaining physical ownership, not more speculative
CLI polish. Plan's pending execution/session/formatter work is preserved in the
candidate. Brainstorm's final host retirement also needs ratings ownership:
current accepted DAG gives Brainstorm no required ratings-mod edge, so do not
silently make disabling the ratings UI disable Brainstorm. Glicko's physical
source is not explicitly listed in the inspected ratings extraction sources;
resolve shared algorithm/state ownership against the roadmap before moving it.
The existing EngineRegistry wrapper injects Core's rating lookup. None of these
unresolved architecture requirements is discharged by today's regression fixes.

### Plan costing, validation and formatting extraction (in qualification)

Base: `db2a8c774128b1e74ec670890dffd7e8abf0c343`. Prior OSV approval response
was a status-only turn; this turn resumes implementation. Qualification checkout
was clean. Candidate WIP remains untouched. Impact search:
`rg -l 'plan-formatter|plan-validation|plan-cost-estimator' packages tests --glob '*.ts'`
returned seven existing consumer paths. Medium migration risk: pricing/history
sharing and user-visible approval Markdown must not change. Scope is 16 physical
paths (14 rename-aware), not the larger pending session/executor extraction.

Baseline typecheck, lint and full suite passed in 114.546s (`plan-presentation-base`,
SHA `e2efdadbe64140deeb77d668c40446fdee350796126cc2765eaeaa9fc248fb1a`).
New owner tests fail on the base: missing physical cost module plus owner assertion
(`plan-presentation-red`, SHA
`2a3132bd520ec92935387618fd78d845315e44c7a779ad86fa9f7c9de8337cee`).

Physical Plan now owns three algorithms. Core injects current pricing into one
estimator and shares it with its sanitizer and existing execution adapter. Public
Core exports are preserved; two old algorithm files are removed. Generator
exports and pack declarations include the new and existing transitive Plan types.
No dependency or accepted requirement changes. Legacy scheduler/session adapters
remain open, including the pricing binding's documented KL-011 retirement.

Frozen fixture algorithm bodies match committed legacy bytes (only imports and
the frozen type list are adjusted). Their SHA guards are:
- cost: `6adc7e9dee46a2e8955cb780e1d4af8b15413d62639d123b0520bd428d8b4fd7`;
- validation: `748f089e42ba396a2adadb23b2a76f618f8db1acbd0f13b3b11a44ca7f2ec437`;
- formatter: `90ccd81e294cdeb3f8ad773df13be55e711b3e8dca7193e8dd515a94900c4550`.

Build of Plan, repository typecheck and focused existing/parity tests pass
(`plan-presentation-focused`, 8.981s, SHA
`ba2c13b79f8536e965d6b4111cb0f529f6a8e381a96e68cb28e904222a53d446`).
Three temporary mutants (history threshold 2→3, trust supplied cost, omit shell
command heading) make all four parity tests fail; mutations restored.
Receipt `plan-presentation-mutants`, SHA
`9f30907a5e022ae2e8bd09e2442f6c422601dc010ad187e96e750ab9024e922a`.

Default Agon review packet is bound to staged tree
`99df1e73a44f522f2819fc8a20f33fbd174ab9dd`, packet SHA
`c434f3456dc8c6c6abbe45141043aef7d866457133f6f45ddf1cf374c679d52f`.
Codex found no extraction regression; identified two valid coverage gaps:
Core singleton sharing and fixed legacy type-list coverage. Added both tests.
Codex review SHA `bad3fc4d64d5960f8194f404ece31b6ee4a2e7528a5d52dd8676488fc43613f2`.
Kimi review and full build are pending. No commit or slice acceptance yet.

Both now finished. Kimi review SHA
`377ba0e67b30494ebb5ed4f7a77ecd99709a0dced8a80a1f47baa61659274de4`:
no extraction defect; advisory to verify Core type provenance is resolved by
`packages/core/src/cesar/plan.ts`, which only re-exports physical Plan types.
Kimi's claim that the original parity matrix would detect any removed step type
was too strong: it iterated current types. Codex's explicit fixed-list test now
covers removal. Two temporary mutants (independent Core sanitizer estimator and
removed final step type) fail exactly the two new tests; four old parity tests
pass. Mutations restored. Receipt `plan-presentation-review-mutants`, SHA
`6bcaa98d646ce0c4388de4af4cc634cfa9883e51a8cc1274640aa9e2d38513ba`.
The first three mutants collectively failed four tests; this is not a claim
that each individual mutant fails all four tests.

Full build passed in 161.416s (`plan-presentation-build`, SHA
`245ba7c2bd4f3e8d2cc089c25a76c084cdcad5ee64d527a96c2322b92392e368`).
Final staged tree after review tests: `959f728e4e3f616e8d05e0e8be432f4262809626`.
Full tests and hygiene/pack gates are running against that tree. External
declaration-consumer first attempt omitted explicit Node ambient types under
TypeScript 6 and failed on existing Core Buffer/child_process declarations
(`plan-presentation-public-api`). Corrected command selects the already-installed
Node types and type root; no dependency install, no skipLibCheck, no product
declaration suppression. Native probe checks public Core/Plan identity, real
two-step scheduler execution using a fixture executor (no providers), estimator
history feedback, persisted envelope ownership, reload and exact Markdown.

### Package gate failure and source-verified correction

`plan-presentation-full` passed **7,225 tests, six skipped**, 54.868s, SHA
`54cb15c7915d8ddc82e7efbc01e6b3b1d9e8ecd744d2a9fa7ad645b3bcb2372c`.
Corrected external declaration/native check passed (`plan-presentation-public-api-node`,
SHA `e7b29ac4689f231cb0a60fbf4cf20557f345a58b3bff614f7c0c70b42d3f9abb`).
`plan-presentation-gates` passed types/lint/re-exports/generator drift but failed
the strict pack-content check: Forge contains undeclared `dist/apply.d.ts`.
Receipt SHA `f6e99973604962ecb827f016c0dcbe4bd79bc1794982d96e599e33c4fc3a204f`.
This is a real missing declaration entry from the earlier Apply extraction, not
a stale artifact: `mod-forge/src/apply.ts` exists and implementation.ts imports it.
A read-only comparison of every first-party dist directory to its manifest
found exactly this one mismatch. No test exclusion or pack-oracle weakening.

The generator now declares that existing emitted type file for Forge; its two
generated manifests change by one line each. Candidate WIP already contained
this exact correction, so it needs qualification, not another implementation.
Scope is now 18 physical paths (16 rename-aware). Frozen final tree before pack
rerun: `48424dae755d35695f7c87e069cd85b81ea370ae`. Pack check rebuilds packages;
the final full suite must run after it ends to avoid build/test artifact races.
Full-suite result above is not the final clean-subject receipt.

Preservation check hashed 281 candidate WIP paths. Only the two new Plan test
files changed during integration of review feedback; all unrelated bytes and
deletions remain unchanged. Production candidate WIP is not overwritten.

### Plan presentation slice accepted locally

Commit `ddae2a6a67e37a26eb5c954674def21a73ad5d71`, tree
`48424dae755d35695f7c87e069cd85b81ea370ae`. Qualification checkout is clean.
Candidate index was empty, then loaded with exactly that verified tree (no
working-tree overwrite); only those 18 paths were committed. No trailers or push.
Backup ref: `backup/modular-before-plan-presentation-db2a8c77`.

All 36 first-party package gates pass after the Forge declaration correction:
344 occurrences, 259 contributions; strict pack, activation/disposal and disabled
registration checks plus duplicate-dependency negative control. Receipt
`plan-presentation-pack-fixed`, 116.240s, SHA
`b1e541bbe24b648ec1d2cddb189776bdb40918b0175fa80ef0ef495bbaef3d54`.
Final non-overlapping CLI build/typecheck/lint/re-export/full-suite/native runs:
`plan-presentation-final`, 116.208s, SHA
`25647d40489bc77dc55c8364e70ed9b72c68906a518a338eeebd047ae11202de`.
**7,225 passed, six skipped**. Three successful native two-step executions total
(one declaration/native run and two final repeats). Zero provider launches.
Post-commit preservation check passed for all 281 candidate WIP paths; only the
two review-strengthened test files changed. Snapshot retained in
`plan-presentation-wip-before.json` outside Git worktrees.

This closes costing/sanitization/Markdown physical ownership, not Plan activation
or full modular release. Next: Plan runtime composition and scheduler/state
facade retirement, then session and child-effect ownership. The current frozen
full-suite receipt is a baseline for that next increment, not a release receipt.

### Plan runtime composition and scheduler facade (in qualification)

Continued immediately from `ddae2a6a` rather than ending at the prior component.
Ten paths (initial chat estimate nine), bounded to runtime composition and its
private scheduler facade. The state facade and physical session activation remain
separate. Baseline is the preceding clean full suite, types/lint/build/pack and
native receipt. Production executor algorithm is unchanged.

Added existing pending `createPlanRuntime` and four tests to qualification.
Pre-implementation missing runtime fails (`plan-runtime-red`, SHA
`52557b85e561a824ce9bb8dd850b3d6befce10b3f4ea59eb09d69f8e180a7f78`).
Physical factory connects one injected estimator to sanitizer and scheduler;
Core retains current pricing and public exports. Retired
`core/src/cesar/plan-executor.ts`, retargeted consumers/types, strengthened its
guard from no-loop-in-facade to no-facade and no scheduler wiring in Core.
Generator includes runtime export/declaration. No new dependency.

Focused build/types and 48 tests passed (`plan-runtime-focused`, 9.969s, SHA
`bd4b29b8d11e8f765e6ebd9f356d0dcf6cc4e751be2527a57d2dc5e553d1dcd1`).
No-op history sink mutant fails the history-feedback and error-report tests;
restored (`plan-runtime-history-mutant`, SHA
`1402d9bd4630e5d3864171c9e269cc715d8557b5a9d08d87abba7e9f7e822783`).
Frozen review tree: `c3a2d5d2aa62a7a255d5ce54adf427f7186e8d78`.
Default Codex/Kimi Agon review and full build are running. Nothing committed yet.

### Runtime review adjudication and checks

Both default reviews completed. Packet SHA
`8df2810c70bbe6f4c4b30f3805116785b2e19da12db2ff39d153975790d04a9a`.
Codex SHA `ec34ae8ff8e0b34b90e5b51777b240344c349f07ad0d432850fef1b1f03eb1d9`;
Kimi SHA `862aec0d41faf25320875dda34a6912dd6739831aa33e3a1497ad159d13818cf`.
No reported runtime algorithm regression. Every Kimi finding checked:

1. Missing `PlanExecutionServices` export: refuted; root index already exports it.
2. Concrete estimator type rejects structural host estimators: reproduced with
   external compile-only consumer, `plan-runtime-structural-red` SHA
   `a34af39be2db21b06dd7bec500f94b4d097e97c0d5cf1d8cc6389b6f1b4eb0e1`.
   This was a restriction of a new API, not a regression in the existing public
   executor factory, which remains available. Removed unnecessary class coupling
   using existing `PlanStepEstimator & PlanExecutionServices` contracts and a
   generic that retains the caller's estimator type. No new interface/dependency.
3. Missing runtime.js/ownership entry: refuted. tsup bundles runtime JS into
   `dist/index.js` (contains `function createPlanRuntime`); ownership.json records
   legacy contribution assignments, not an enumeration of every implementation
   file. Exact Plan npm pack contents pass, including runtime.d.ts (receipt below).
4. Stale deep imports: none remain in packages/tests; the only matching string is
   the negative owner assertion. Full build/typecheck pass. Public roots preserved.
5. Core history behavior gap: prior presentation test already covers Core estimator
   to sanitizer, and native probe covers public execution to sanitizer. Added a
   direct test of public Core execution to the exported estimator as well. The
   reviewer-proposed second-instance mutant fails both this and the existing
   presentation test (two fail, nine pass), then restored: `plan-runtime-core-mutant`,
   SHA `27f6ccf4a0bd5ab7a2783cf37ba28e47f2a40734e3efff7c94186d74c3c946a7`.
6. Binding header: clarified runtime/pricing/warning responsibilities. KL-011
   retirement remains open because shared legacy host composition still exists.

Full build passes, `plan-runtime-build`, 160.400s, SHA
`bbb36e483037013ad441f77c69014879aa244112c357ced32a9dfe7312dca6b3`.
Exact Plan pack comparison passes, `plan-runtime-pack`, SHA
`039ce972f5d271eba18984a38909151d03e6b72520ccb1777e00b548e50830ba`.
Pre-review-fix final gates pass, `plan-runtime-final`, 115.082s, SHA
`83dedbeee6c62ea611dd1d28361cd5bf4765dd3c9b45df7ebe281b9c11fe4186`.
Review fixes rebuilt Plan, passed repository types, 49 focused tests and both
public structural requirements, `plan-runtime-review-fixes`, 10.304s, SHA
`685833569b4574544c02d6e24444a32bd8bd33dca8094552be1e31672ad2c41e`.
Final frozen tree is `596faf76054985bded5b8c558e96b42d8d6a281d`; reviewed-final
full suite/lint/types/consumer/native verification is running. No second review
panel after locally verified fixes. No commit until that final run passes.

### Runtime slice accepted locally

Commit `9031d4989da094bc0d894e855e732cb3efbee004`, tree
`596faf76054985bded5b8c558e96b42d8d6a281d`. Ten exact paths; candidate index
was verified empty before loading the qualified tree, without worktree writes.
Qualification checkout is clean. Backup:
`backup/modular-before-plan-runtime-ddae2a6a`. No push or authorship trailer.

`plan-runtime-final-reviewed` passed in 117.663s, SHA
`aa9e9573ac2e78c94d93b40c286adc07b0ee86e9a84c157c496dc5aa07be7aa6`.
**7,230 passed, six skipped**; types, lint, re-export guard, generated drift,
external public/structural consumers and two final native probe executions pass.
Four native probe executions during this runtime slice, including two before
review fixes. Each covers Core persistence/history and independent factory state.
No provider launches. Active/global Agon untouched; nothing installed/promoted.
Candidate 281-path preservation check passed before and after commit. Six files
changed only for the two slices' verified review fixes; all unrelated content
remains byte-identical to `plan-presentation-wip-before.json`.

Still open: state/store facade `core/src/cesar/plan.ts`, Plan session activation,
coordinator callbacks/durable checkpoint ownership, child workflow effects and
remaining disabled-mod/release requirements. Next source trace located nine
actual state-facade consumers plus three owner assertions. Ignore similarly named
`blocks/plan.ts` and CLI handler index imports; they are different owners.
The runtime commit does not close KL-011 or the full A20 host boundary.

## Plan state/store facade retirement and truthful relocation evidence

Base `9031d4989da094bc0d894e855e732cb3efbee004`. Initial 13-path facade
tree `8cdd6b73e8452597274d64a35a5e1d4e057218e0`; final candidate tree after
evidence corrections `34f08881f69b6fd874b4fe7688f8f298eb72925d` (19 paths).
No state/store algorithm change. Core root keeps the same public exports;
ListPlans binds the same physical function without the private forwarding file.
Frozen executor oracle now uses frozen state transitions, not live transitions.
Executor/state function bodies remain byte-identical (SHA-256 respectively
`0569e32953ff00a28138cf9e975b610d5b851f537b719cbad2cf9dddf8641198` and
`d5f95d5285ef1c2722e9b376ec1d8e2b97ca05b4dd03b316f4baa5b23c11a60e`).

### Tests and source-verified review

- `plan-state-facade-red`: two failures on the old facade/import edges, two
  controls pass; SHA `a87ec9ffe2ca8c688624e0b348dcb7c0c694a0ef6b6149158bdb3ce255ffb944`.
- `plan-state-facade-focused`: 80 tests plus types pass; SHA
  `855f3314de3c56c26dc1327db0b4debaa430fa27b8bc79f6c78bcafe75f881de`.
- Full build passes in 162.151s; SHA
  `58d3e687a661910760bf14a971b96a245bb70c2b5b3f8d4858bc69591861246b`.
- Default Codex/Kimi facade review packet SHA
  `c7e4bcdafe216d724f2bf8f628623af018b10f5494081b803e2ef8177d952baf`.
  Logs `0db469a12ed0ff518989284fba5c0980548bf5397948955ab40447222ee6e7d7`
  and `de3aa5b34e2a6386ce3582e5dcd6724caec35e7e818b23c9e19d041bd46c278e`.
  No concrete runtime regression reported. Core package exports only dot.
  No Core import exists in Plan source. The claimed second scheduler is refuted:
  Core's pricing binding calls physical createPlanRuntime/createPlanExecutor.
  No loop remains in Core. The claimed repeated assertion is absent in this tree.
  Import scanner covers literal relative TS/TSX imports, not arbitrary computed
  runtime imports; no surviving edge was found. It is not a universal module resolver.
  Public deep-import compatibility was never promised by Core's exports map.
- The deleted header's owner-checked activation prerequisite is NOT certified by
  removal of an unguarded re-export. Physical dispatch/session activation remains
  open. This slice retires only a redundant forwarding path. Public compatibility
  exports and historical readers remain; KL-011 and runtime cutover stay open.

### Migration-evidence defects found and corrected

The review's question about historical locators led to two real failures, not just
provenance strings: the explicit inventory refresh dereferenced the removed source
(`plan-state-inventory-refresh-red`, SHA
`794c3ecc8452f44de2c32f25d1eef6540689d6170e84ee0defd19601e9847bbc`), and the
S5 ledger refused the removed assignment (`plan-state-ledger-red`, SHA
`546284c8479356f91b238d89ce4ec8d6c0ff12bac668d9b5372caf5bf31c9bc9`).
Integrated existing candidate relocation helper/tests rather than a second owner.
It verifies exported type declarations through TypeScript AST, hashes source,
evidence and remaining bindings, and keeps route execution authority explicitly
legacy. It includes 13 source relocations without changing the 344 S5 assignments
or frozen 872-assignment baseline. Explicit refresh uses physical execution-model;
default frozen baseline still has category hash
`e19cc1b2d0686d9be2872999d3165196b2fc827683d8edca3bb746fd8d0c9772`.
Refresh probes wrote only isolated temporary evidence, not tracked baseline files.

The roadmap verifier also missed the already-extracted kernel logger. Added its
exact destination and existing SHA-pinned behavior/retirement test as evidence;
this does not claim any new execution cutover. Plan relocations are recomputed,
not accepted from stale JSON. `plan-state-ledger-controls` passes (SHA
`711c9e4bfb8d21a07cee23d13410b0de15d62d84fb50c57ac0bc77c155f151a3`).
New evidence code received its own bounded default review, not a repeated panel
on the runtime fixes. Codex found one weak negative fixture; it now removes only
the agent literal from a full valid declaration and requires the exact missing-route
error. `plan-state-review-controls` passes, SHA
`d97116212044c5bc32424d7cc5b6df702d703dce62df20af7c0e1b5974719060`.
Kimi evidence review and final reviewed-tree gates still pending at this entry.

`plan-state-final` passes: 7,248 tests, six skipped, types/lint/guard/generator/
roadmap checks and two compiled native probes. 114.251s, SHA
`5d6f73425889b0f2ca964586907565c7312782bce81cefb9e07466693063a6f3`.
Native checks exercise public Core/Plan identities, real ListPlans invocation,
save/reload/exit/state filtering, malformed-file isolation, two-step execution
and estimator history. Synthetic executors, zero provider launches. Not release
or live-provider qualification. No commit until remaining review is adjudicated.

### Next integration hazard reproduced, not yet fixed

Pending candidate `execution-record.ts` rejects actual plans created by the current
compiled mod's MCP proposal tool. Both autoApprove=false and true are affected:
legacy proposals omit totalEstimatedTokens, totalEstimatedCostUsd, totalActualTokens,
totalActualCostUsd and stepContext. Old persistence reader accepts them; pending
validator returns false. Proof `plan-historical-shape-confirmed`, SHA
`ff2a0a683d59edd1757bd298c8ced75dffbfa4079d4ba704f1bd4c739d56d53d`.
Probe uses isolated storage and in-memory TypeScript compilation of pending pure
validator code; no production cutover or writes to candidate source. First probe
had a harness error (assumed outer MCP wire result instead of Mod API Json), corrected
before this finding was accepted. A compatibility migration is needed before store
unification. Do not blindly integrate the stricter reader or invent missing history.

### Relocation review adjudication

Packet SHA `8a33b6169c0b1e61bfb8915b40b122d483c98c5f7414392ac979320145d35861`.
Codex log `5f3e3492f06f8f22950eeccaad584deb1a944f1f53363e97b474baca9fbe8d5f`;
Kimi log `77ac2512d76f39aca2db7c07f1f5e05d067632f1b9d6ea59e4a912441a905556`.
No source-verified runtime regression. Codex's narrow fixture improvement was
implemented and locally tested without another panel. Kimi's six hypotheses:

1. Hashing a test does not prove semantics: true limitation, but no false acceptance
   demonstrated. This ledger is not sealed acceptance evidence. The actual test ran
   red on the old facade/imports and green on this tree; full qualification runs it.
   Adding a self-maintained hash pin to the test would not establish semantics and
   would duplicate the immutable review/receipt subject binding. Reject proposed pin.
2. Filter all rows to Plan ownership: refuted by frozen source. Ten routes belong to
   several mods, self and two interfaces belong to kernel; none of these 13 frozen
   rows belongs to Plan. `definitionOwner` is deliberately distinct from the unchanged
   legacy contribution owner. Suggested filter would erase all relocation evidence.
   Review's count description is also wrong: 11 routes plus two interfaces, not
   ten routes plus three types. S5 subset has ten routes; full relocation list has 13.
3. Remaining bindings are static: correct. They are conservative unfinished-work
   obligations, not derived proof of liveness. Both files currently execute Plan
   host effects. Their hashes force regeneration on edits; no automatic authority
   advancement occurs. Keep until those host effects are separately retired.
4. Kernel evidence could become unreferenced: source-refuted for the frozen contract.
   Ownership contains the logger assignment, and verifier requires each assignment
   in its package's extractionSources. Dropping that row therefore fails. Exact
   implementation SHA and actual logging behavior are tested separately. The roadmap
   verifier checks traceability, not full behavioral acceptance by itself.
5. Interface-name verification is not structural parity: true, explicitly presence
   and byte-hash evidence only. Types, raw state/store parity and runtime probes are
   separate required gates. No unsupported structural-proof claim accepted.
6. Commit refreshed inventory: rejected. Frozen 872-assignment input must NOT be
   refreshed during extraction. Default self-test verifies exact category hash;
   explicit refresh executes only into temporary output in the probe. Committing
   that output would move the acceptance target.

Checked: private-import/public API compatibility, algorithm/oracle identity,
frozen inventory, removed-source consumers, AST evidence controls, remaining host
authority, review claims, compiled state/store effects. Whole Plan ownership and
release acceptance remain explicitly open.

## Plan selection-policy owner (in progress)

Previous goal turn made progress: two verified local commits, not a wait or a
status-only turn. Current base `a57b5aa3e8406819fe0b35ccffa8127f2d2655ae` is
clean in qualification. Refactor scope: six paths, medium approval-policy risk;
ten consumer/test files found by `rg -l 'plan-queries|findPendingCesarPlan|findResumableCesarPlan|shouldApprovePendingCesarPlanInput' packages/cli/src tests/unit`.
Baseline full gates and compiled invocation probes passed on that exact base.
Backup `backup/modular-before-plan-selection-a57b5aa3`.

Staged tree `87ba44163a77ca8a92ae0254511adf70a43f8557` moves input matching,
pending/resumable selection and status formatting into physical Plan. CLI retains
only HandlerContext-to-snapshot mapping, injected saved-plan reader, existing
public exports and keyboard question helper. No policy change: natural approval
needs a live pending plan; resume lookup never falls back to disk; explicit pending
lookup keeps proposal, active, newest saved precedence. Storage failures propagate.
Sorting does not mutate the saved-plan array. Existing temporary A05 host binding
is not claimed retired wholesale.

New owner tests run red before the move: three fail, eleven pass,
`plan-selection-red`, SHA
`bc19a1bed593f8f55ac79a599bfc9bf2157925fc4b304e16ed46c2e1dc7389ad`.
After physical package build/types: 59 focused tests pass, including existing
dispatch and resume tests. `plan-selection-focused`, SHA
`05258909474abf2071a42b2418cd903724faf7bac49d416126a07d319def4b62`.
Compiled physical policy compared with exact legacy Git source from a57b5aa3:
12,680 comparisons, zero differences. Includes 7x7 live-state combinations,
three storage arrangements, eighty phrase variants, read counts, input-array
preservation and status text. Old source SHA
`4185729e8ec2f5a283d6c40491f0a3ebc9db13d149d273149b1f4b24c3407daf`.
`plan-selection-parity` receipt SHA
`e08a9ff15e1d46ca0c3d947862bf8f7251554c28dc2084375a005e69749410ef`.
External probe was then extended with real isolated Plan storage; its final runs
are pending, so the initial parity receipt does not claim those storage checks.
Full build/default reviews pending. No code change to pending strict-reader
migration; the reproduced historical proposal compatibility hazard remains open.

### Selection review adjudication and negative control

Default packet SHA `180395bf1ccbb31f9aa203a7eadd9b6ce55a243ceea7b6a31056505bcd350597`.
Codex log `a7f9090f6a53e2d093c41e8407e297c5c7bf46b111fb83f91e5f0be0dc8d0fba`;
Kimi log `ff260c5dc03c4906271b640dc47b8c012d1af7c48ed888ffc224920bf4e7926a`.
Both found the mechanical policy move faithful. Hypotheses resolved:

- Saved data source changed: refuted. Core directly re-exports physical
  listCesarPlans; prior native identity probes prove exact function identity.
  Final current probe additionally asserts Core/Plan reader identity and reads
  the same real persisted files through both roots. No parallel store introduced.
- CesarPlan type/object identity changed: refuted. Core type is a direct physical
  type re-export. Snapshot stores the same plan references; selection returns
  those references, not clones. Tests use toBe and differential probe uses strict
  identity. Type annotations do not create a new runtime object identity.
- Source-string ownership assertions are brittle: accepted and improved. Removed
  the string checks. Spies now wrap the actual public physical selection functions
  and verify CLI delegation for pending, resume and approval. Formatter identity
  is checked directly. Existing behavioral tests remain.
- Full gate pending: addressed by running it, not by accepting review confidence.
  Build passed in 161.205s, `plan-selection-build`, SHA
  `fe608b9d5a085c0ab60e4d3d763f716304c2200bb1d6dfbc566e6deeca5f9953`.

A behaviorally equivalent local CLI copy was temporarily substituted for physical
pending selection. The new test fails specifically because the physical policy
was not called (zero calls vs one), not because the selected plan changed.
`plan-selection-duplicate-owner-mutant`, SHA
`e685c8feaa3a9a2535cd4ddba5beecdbb924eb2d41c58e265650b354f84d18fb`.
Restored exact staged source; no unstaged diff remains in qualification.
Final tree after test improvement: `cc797fa90dcb7a612ff2202803ef9aceda40d904`.
No second review panel after locally verified test improvement. Final full suite,
compiled parity and real-storage probes running; no commit until green.

### Selection policy accepted locally

Commit `f973bf6d392fcfd51ce717eacb8efeb9023a07cd`, tree
`cc797fa90dcb7a612ff2202803ef9aceda40d904`, six paths. Clean qualification;
no push. Final gates `plan-selection-final` pass in 114.402s, SHA
`7dcf671979f6e9c2ecf56c2f16847cc9bb4bef562da8fefd802df8e717c6eb5e`.
7,266 tests passed, six skipped. Two final native runs each compare 12,680 cases
with zero differences and exercise real stored plans through identical Core/Plan
reader functions. Initial parity-only run is separate; total three parity runs,
two with real storage. Exact pack check passes, SHA
`e83183e836f1992db21efe216bb70e0ec02a169633be338ef18c46f76186032f`.
281-path preservation check passes, SHA
`02d1cc08d7addf8f50f2e912c102a104435d9c67d26535a186f712ef9e7d6869`.
No provider launches in tests/probes; no global installation or personal-state
change. Approval policy stays unchanged. Continuing with session lifecycle
orchestration, not claiming the whole Plan/Agon migration is complete.

## Plan invocation scope physical owner (in progress)

Base `4d5de879225b750b120af119fabb905cc6f7a9c9`; reviewed staged tree
`06f1061375e969bcd6813b141d0eaa2998701aa9`. Ten rename-aware paths, 54 additions,
seven deletions. Backup `backup/modular-before-plan-session-scope-4d5de879`.
Move the existing 23-line CLI AsyncLocalStorage scope to mod-plan/session-scope.
Only the comment changes in the moved implementation. Both CLI consumers use
the same public Plan package. Generator exports scope and host and adds the one
new declaration to the exact pack list. No new dependency or runtime abstraction.
Public scope tests keep existing mismatch/concurrency/abort/late-return cases and
add nested-failure restoration plus expiry after owner failure. Existing TUI
test crosses from CLI task dispatch into the physical Plan host.

Red owner test proves missing physical exports and surviving CLI owner:
`plan-session-scope-red`, SHA
`a0e87b678488569d6404a7932b2ba099f19db0a7735a8c832f957e9fada9665b`.
First focused run passed types but failed seven public-import cases because the
bundle had not been rebuilt (`withPlanSession` missing); log SHA
`d1cae4617daffde79735cb9f7417400f69aee92d0866ab9a1059bad74130f43f`.
No test workaround: full build must refresh actual package exports before rerun.
In-memory negative control removes only `session.active = false`; native probe
then fails exactly on late effects escaping the expired invocation (exitCode 0
instead of 2), SHA
`4247588684477e83fee7f8243d4af44c97b3a57187ee569896bf9a87687bfe22`.
No repository mutation from that control. Build, Kimi review and final gates are
pending. Codex review reports no concrete regression, with correct caveat that
runtime packaging needs the rebuilt artifact and public-import test evidence.
Already-started effects are not cancelled by scope expiry; unchanged behavior.
Do not confuse invocation scope ownership with complete Plan orchestration or
disabled-mod/release acceptance.

### Session scope review and packaging checks

Default reviewer packet SHA
`7b892aafb78245c1043a5853707bccd8f9c58a229483a9e8109f801db322f066`.
Codex log `9d3f39827ace99fb3a9a97cbc19387f680fb8b41d6b2bb20142a4aae4ae0fc4a`;
Kimi log `96491f344e6f2249222197467b712553022a87da4860257e14043224adaa86d6`.
No concrete behavioral regression found. Packaging questions checked locally:

- CLI package.json already declares `@kernlang/agon-mod-plan: 1.0.0` (line 101).
- Fresh CLI build bundles the scope once into chunk-B726ENXW.js. Both app and
  first-party-services import the respective scope/host binding from that same
  chunk. A separately loaded physical mod delegates through injected
  `services.planSession`; it does not use its own package scope implicitly.
  Native probe now tests exactly that compiled-CLI-to-physical-mod boundary,
  including refusal after the compiled invocation returns. Do not claim all
  modules are externalized; that would be false.
- Remaining old path strings are the retirement tests and a historical audit
  paragraph, not imports or build configuration. Prior audit evidence is retained.
- Tests resolve package JS from dist. Build-before-test remains necessary;
  this repository already has many such public-package tests. Do not introduce a
  test-only alias that hides shipped export or singleton faults.
- Generator ran rather than hand-editing its outputs. Exact Plan pack contents
  pass, including session-scope.d.ts: `plan-session-scope-pack`, SHA
  `2441186303f0e77c19db585f17761f80363f368d0aaa14e40b4be773316d19b1`.

Full rebuild plus 32 focused tests pass in 165.663s:
`plan-session-scope-build`, SHA
`426380480e5157adbce9d740d489e6639d0708cbace281ceae889b5dcc9e3c4d`.
Final full gates/native probe remain pending at this entry. Preservation of all
281 prior WIP paths passes with only explicitly reviewed edits, SHA
`a0e85fd6c317ad8f88ee79fb2a480fad255ec8257bdea87ecee26026117b0542`.

### Invocation scope slice accepted locally

Commit `a57b5aa3e8406819fe0b35ccffa8127f2d2655ae`, tree
`06f1061375e969bcd6813b141d0eaa2998701aa9`. Qualification checkout clean.
`plan-session-scope-final` passed in 115.093s, SHA
`85a64cc7c3315c99b3613a044c811aabafffe28cadd0baccd3e65cdbc295eb6d`.
7,252 tests passed, six skipped. Build, lint, types, re-export guard, generated
metadata, roadmap and exact Plan pack checks pass. Two compiled native probe
runs exercise 16 concurrent scopes each, absent/mismatched identity, both expiry
paths, nested restoration, abort and actual compiled CLI-to-physical-mod injection.
The removed-expiry mutant failed for the intended reason. Default review findings
resolved with source and built artifacts, no extra panel after verification.
All test/probe receipts record zero provider launches. Local commit only; active
Agon, personal state and unrelated candidate WIP preserved. No installation.

Next unresolved requirement: Plan orchestration/session selection and host-effect
ownership. Before canonical headless store cutover, fix the reproduced historical
proposal compatibility defect described above. Full KL-011, disabled-mod and
release acceptance remain open; these two bounded commits do not close them.

### State facade slice accepted locally

Commit `4d5de879225b750b120af119fabb905cc6f7a9c9`, tree
`34f08881f69b6fd874b4fe7688f8f298eb72925d`. Backup
`backup/modular-before-plan-state-9031d498`. Qualification is clean; no push.
Candidate worktree bytes were not replaced by qualification content. Index was
empty, then loaded with the exact reviewed tree without `-u`, checked and committed.
The 19 paths contain 759 additions/78 deletions, largely generated relocation
evidence (496 additions/38 deletions) and negative tests, not new runtime machinery.
Runtime change is removal of ten forwarding lines and two import retargets.

`plan-state-final-reviewed`: 7,248 passed, six skipped; types, lint, guard,
generated metadata and roadmap checks pass. 114.911s, SHA
`f60a2e782980315a2485ce67d5fa17724f46d9bfa33efeb0d3353268fe69e5d5`.
Four native state-facade probes total (two before the review fixture improvement,
two after), zero provider launches. Source-build passed earlier; only evidence
scripts and tests changed afterward. Preservation check confirms 281 prior WIP
paths with only nine explicitly reviewed changes, SHA
`7c5f960a2bc9ba7ae2110ae268af34a959ae6e79b097e5455082b0f3e9c447f7`.
Nothing installed, promoted or pushed. Global Agon untouched.
Remaining work includes Plan invocation/session host ownership and the reproduced
historical proposal migration gap; no full-modularity or release claim.

## Plan session lifecycle owner (current verification)

Base `f973bf6d392fcfd51ce717eacb8efeb9023a07cd`. Qualification tree
`a2f604323cfe080872767b70b1c2ede1df6edcc9`. Ten paths: start, resume and exit
policy moves to mod-plan; CLI keeps router/UI effects. Public exports and exact
pack list come from the existing generator. No new dependency or policy.
The refactor skill required separate baseline, focused and full verification.

The first focused run correctly failed typecheck: the new typed host binding
exposed the old undeclared `justExitedPlanMode` field. Added that optional boolean
to CesarState, matching the existing runtime writer/readers and candidate WIP.
No cast or changed behavior. Fixed run: 81 tests and typecheck pass, SHA
`18ed18907553218cce3b18c89f7a8dad2b7e8ae86cd8f861a26b57d0b78f4ba4`.
Four further regression cases were added after review.

Default review used the same frozen packet on tree
`ab33eec9dfe350c85166554efef804cf0572d905`, packet SHA
`bd135eef8fe90732104cf921130d7833608765641e395e18b140400a1b5873b6`.
Codex log SHA `969c3497f3e19f99f8ec8438c783a2c91c0b8c8a636f12f14ce8c1c61625dd48`;
Kimi log SHA `d61009265435a1d4665c8908522512cadf70bf0a7b43cbd5f3ef71b8abcc6e81`.
Both were bounded static reviews, not release approval.

Source-verified adjudication:

- Codex synchronous effects contract: documented that exit effects cannot return
  promises. Existing CLI persistence is synchronous. No newly observed runtime bug.
- Missing explicit-ID fallback and non-pending proposal tests: added. A current
  plan is available in the missing-ID case but must never be consulted.
- Resume completion/rejection: added a deferred promise test, not a timing sleep.
- Exit wrapper coverage: external probe transpiles the exact old Git function
  and the current host binding. It compares results, state and effects across
  seven states, four reasons, dispatch/Cesar/setter presence and archive failure.
  Timestamps are frozen rather than stripped from the oracle.
- Kimi model divergence: rejected. Core index lines 285–286 re-export the exact
  physical values and types. Native probe asserts function identity; the prior
  state-facade probe already exercises Core-created records through physical
  storage. There is no second model in this boundary.
- Kimi accidental public `planExitRefusal`: rejected as a public-subpath claim.
  package.json exports only root, manifest and ownership; declaration files are
  shipped for type resolution. The module-local helper supports current exit
  policy and pending internal headless control; no root API expansion is needed.
- Kimi unrelated assignment hashes: explained by source. Each affected package
  owns a relocated route whose ledger records the shared remaining plan-mode
  runtime binding. Its hash changed; per-package assignmentHash hashes those
  owned records. This is deliberate traceability, not nondeterministic ordering.

Full build passed in 158.042s, SHA
`12d8914902b456b52b07881e39be4e3cf48f8d75386dea7ff10c7116b69c92c9`.
Exact pack dry-run passed, SHA
`1771d0e2fd06d9a7fee2fff6b53f23f24f7c6114bbeb7962b295b525e7bf61cb`.
The in-memory mutant removes running-exit refusal; parity fails on the running
case, reporting PLAN_EXITED instead of BLOCKED. SHA
`c12f41062aa1554c205c3e15f8f91464ad223995ad7e4d974bd3c40c8633e77f`.
No production or compiled file was mutated. Preservation checks confirm all
281 baseline paths with only previously reviewed edits and this slice's test
and synchronous-contract comment changes; SHA
`b2e5b9bde9c580d40bdffce11bbe2e93ea737307f34b51483a8b6ecb128f6772`.
Full-suite and native outcomes follow below. No push/install/promotion.

First full run used the restricted shell rather than the required local-socket
permission. It failed: 47 tests, 16 unhandled errors, 29 skips. Daemon/HTTP binds
report `listen EPERM`; fs.watch tests received watchdog instead of event.
This run is not acceptance evidence. Receipt SHA
`24c7ed4c8bc726d28c9d56dd2db17b2d6ba83ee2a4183205e5622ad3b35549ef`.
The identical command is rerunning with local socket permission and the same
isolated homes/provider blockers. No test, timeout or source change for rerun.
Process correction: use the established escalated run.py path for full suites
that include daemon sockets, HTTP listeners and filesystem watcher tests.

Separate native probe passed: 448 raw exit comparisons, Core/Plan function
identity, real physical save/resume/exit/reload. SHA
`4649a6d189591a53745dccb41ad5f70552df2b7be051eabada8f6233e2a3cf4e`.

### Plan lifecycle accepted locally

Commit `a4a82ce81f2545328f28a10d8406236c38605585`, tree
`a2f604323cfe080872767b70b1c2ede1df6edcc9`. Ten paths, 336 additions and
105 deletions, including tests and generated binding hashes. Backup:
`backup/modular-before-plan-session-workflow-f973bf6d`.
The exact verified tree was loaded into the empty candidate index without `-u`.
The commit preserves all ambient WIP bytes; qualification is clean at this commit.

`plan-session-workflow-final-sockets`: 7,294 passed, six skipped, no failures;
types, lint, re-export guard, generated metadata and roadmap gates pass.
116.356s, SHA `7f347bd7574a7936e80fe6e5bd8c5f9979f3d78cdaf478c059edabdabde9e3da`.
Two native probes ran last in this receipt; three positive native runs total.
Each checks 448 exact old/new comparisons plus real persisted resume/exit/reload.
Zero provider launches in verification. Both default reviewer findings were
fixed or source-refuted above. No extra panel after local review fixes.

Nothing installed, promoted or pushed. OSV remains a recorded release concern,
not a request for dependency upgrades. Remaining Plan proposal, execution and
host-effect ownership, historical record migration, Brainstorm ownership and
whole-release qualification are still open. This commit does not close KL-011
or certify a fully modular release.

## Plan proposal-publication owner

Base `a4a82ce81f2545328f28a10d8406236c38605585`. Ten-path slice, medium risk:
publication policy moves from CLI to physical Plan; filesystem/UI effects stay
in the host. No strict reader, headless store migration or execution cutover.
The shared initializer creates an awaiting-approval proposal, never running work.
Final staged tree `a1282f427aed02b88f90a5da565cfa2b5e952717`.

Baseline: preceding full suite, 7,294 pass/six skipped, clean qualification.
Initial red: new owner module missing, old raw fixture parity 5/5 passing;
`plan-publication-red`, SHA
`297e3a328168a386a2836a66fe3f7c84da6782ddcd7508f16afa16c3daee5708`.
Focused build/types/tests passed, SHA
`ea8f2c731d0ddb397f4ad66511edc85fc947c7e90062967c70b584688ec0555e`.

Default review packet tree `c57c275b84cd71b170b54db3689d3573ea5288ff`, SHA
`2066d2c9888146c415746307bc369786cdef065842682755501e5fb3394e1553`.
Codex log SHA `34874538990f14041556ac38ddecc781e8d2072ace6a7409144e899f9144b59b`;
Kimi log SHA `cf29dd05a6138cffd71687130310f86adae3f543631881047171e6cb208125b3`.

Source-verified adjudication:

- **Confirmed regression, fixed:** eager auto-mode read happened before malformed
  step notification. Codex identified this; Kimi called it benign. A synchronous
  notification that changes auto-mode disproved that benign claim: old proposal
  has autoApprove=true, extracted proposal did not. Red receipt
  `plan-publication-auto-order-red`, SHA
  `acf2d870b65b16cd2ba7e3543f75689dee597137f4aabb7a81f9fbb416768e6d`.
  Changed the injected boolean into a callback, called after sanitization,
  notification and proposal creation, matching old evaluation order. Green SHA
  `d94e4e5df92047431867ffe54e2c40a33776a9372572a03b8b1e0b7042a2fd0e`.
- Same-ID, first-prior cleanup failure, estimator/notification/publication failure
  gaps: added five discriminating cases. Replacement failure preserves old
  approval opportunity. Final publication failure preserves preceding effects.
- History-sensitive estimator: native probe seeds both real Core estimator
  instances and compares default/history paths. estimate only reads history;
  recordStepCompletion writes it. No production history rewrite is needed.
- Packaging query: runtime is bundled in dist/index.js; declarations use their
  separate files. Exact npm pack dry-run verifies manifest/file equality.
- Ledger hash churn: each affected owner records the remaining shared plan-mode
  runtime binding. Its bytes changed; assignmentHash hashes those owned records.
- Fixture coupling: legacy workflow body matches immutable base Git body after
  trailing whitespace removal only. Shared primitives did not change here except
  adding the separate initializer. Raw persisted files/events are not normalized.

Full build passed, 159.073s, SHA
`051479fdd325899dcb0b8fa882f868cde8ba943e22397a622eb5246953c56ba2`.
After the review fix, physical Plan and CLI were rebuilt. Focused 24 cases pass;
actual compiled CLI matches immutable old publication over 180 cases, SHA
`b3d0013d67cfc9a9f6a21c8cb0cdbea3809cad1625c9fc05781898267f8da1e8`.
Final probe expands to 360 cases by adding seeded cost history. The first probe
attempt had a missing helper brace and failed before execution; corrected, not
counted as a pass (receipt `plan-publication-native-initial`).

An in-memory mutation moves replacement persistence after supersede/clear.
The safety oracle fails with effects `[prior, clear, replacement]` instead of
`[replacement]`. SHA
`e3050f29bbeb7e8358ad3e7b2886923546bf72c544688896e438a973609af375`.
No source/compiled mutation and no provider calls.
Pack receipt SHA `556d200bec65fb43b2416c843952eeeafa777376caea3ef14236d4c0d796901b`.
WIP preservation receipt SHA
`c9a5bca62b95220349266b4b4306e1bec2516305568333e48f5188b247681b15`.
All 281 prior WIP paths checked; only named reviewed changes differ.
No global Agon or personal-state changes. No push/install/promotion.

Publication commit: `b6149df7d63dced828b2ee6c459c092a68c3fe05`, tree
`a1282f427aed02b88f90a5da565cfa2b5e952717`. Qualification clean at this commit.
Candidate index was empty, then loaded with exact qualified tree without `-u`;
ambient candidate WIP was not replaced. Backup
`backup/modular-before-plan-publication-a4a82ce8`.
`plan-publication-final`: 7,318 passed/six skipped; types, lint, re-export,
generated metadata and roadmap pass, followed by two compiled native 360-case
raw parity runs. SHA
`80367228b4dc28c481d07f1e2316e69055aa2251de072324ef700054ecba70ee`.
Three positive native runs total (first 180 cases, last two 360 cases). Zero
verification provider launches. No locally actionable review finding remains
for this bounded slice. Full release and historical-state compatibility remain
unqualified; proposal activation/rejection, execution callbacks and executor
host ownership are not closed by publication extraction.

## Plan approval policy ownership

Base `b6149df7d63dced828b2ee6c459c092a68c3fe05`. Eight-path slice moves
approval decisions into physical Plan. CLI retains lease evaluation and pricing.
Public CLI exports remain available. The exported mutating-type Set is now a
compatibility snapshot; private policy authority cannot be changed through it.
This is an intentional integrity fix, not a sandbox claim. Exact old Git code
allows safe-only self execution after clearing the public Set; the new code
rejects it. No production mutation consumers exist (`rg MUTATING_STEP_TYPES
packages tests`); only declarations, re-exports and the regression test match.

Default isolated reviews used packet SHA
`10cff40b7d428b3ec8ff4b69ef79432b348036703887b8978eb6d9272569781f`,
tree `0e54f678409150d519a2ce34db66c3c3350b7113`.
Codex log SHA `1c149364c1566fe2e490bf3f7732abb4db6bab92f133c5ce125a7e044258d0ed`;
Kimi log SHA `736405503791413b8c0244896065612a1a4901b71c913e486fe7567900c25e4e`.
Both found no blocker. Findings adjudicated:

- Codex host-wiring gap: added real CLI wrapper test with a real task lease,
  actual lease evaluation spies, exact action/command order, and review-cost
  estimation after boundary checks. The test passes. Production code unchanged.
- Kimi snapshot mutation consumers: no production writers. The snapshot contract
  is explicit; no speculative configuration API added.
- Kimi decision string: optional typing suggestion, not a defect. The host port
  fails closed for every value other than `allow`.
- Kimi missing coverage: existing tracked `auto-approve-policy.test.ts` has 27
  cases covering unknown mode, fitness interlock, absent ceiling, lease gates,
  reserve cost and ordinary auto approval. New tracked tests add 25 cases and
  negative controls. The exhaustive differential helper remains external audit
  evidence, not shipping test infrastructure. It compares 69,984 returned/error
  values and effect traces against immutable old Git source, including null
  ceilings. Its absence from the shipping diff is deliberate, not a claimed
  clean-checkout test. Receipts retain the exact reproduction command.
- Kimi hostStringSet: source at `packages/cli/src/lib/kern-host.ts:39` is exactly
  an insertion-ordered `new Set(values ?? [])`; no semantic difference.
- Kimi spies could silently stop intercepting: refuted by explicit
  `toHaveBeenCalledExactlyOnceWith` assertions. The added callback wiring case
  also verifies the actual lease and pricing seams.
- Kimi unused-wrapper housekeeping: no unrelated removal; existing gates apply.

Full build passed: `plan-approval-owner-build`, SHA
`cda3e4a56bc86596a727287cf677b080ac214b0a1e204de88646e196d4be15b3`.
Focused tests: 52 passed. External native helper first failed by importing a
non-exported compiled function. Corrected to use exported compiled
`handleProposedCesarPlan`; five rejection/manual-approval paths pass with exact
events and selected state. No approved executor/provider path is launched by
that probe. Actual positive lease/pricing wiring is covered in the unit test.
A subsequent helper command hit TypeScript's explicit-file config requirement;
the final command uses `--ignoreConfig` with explicit compiler settings. Failed
receipts are retained and are not counted as passing qualification.

Exact package/manifest contents pass (`plan-approval-owner-pack`), SHA
`ff8072ceb918fbae724069ce474154fae5902764af259df97e6d3fbb8bfa6a39`.
WIP preservation (`plan-approval-owner-preservation`), SHA
`775e381ce227ba24cf776aab73d1e476190f8599ea4a5fc3ab25c6d2130c5d84`:
281 paths checked, no unrelated changes. Archive retained unchanged.
Final qualification `plan-approval-owner-final` passed in 114.849s: independent
compile-only public consumer, types, lint, re-export guard, generated metadata,
roadmap, 7,343 tests passed/six skipped, then two actual compiled-host probes
(five refusal paths each) and 69,984 old/new comparisons per run. Receipt SHA
`9e7b1b80ea9c4a60ad0ac723f6788dd0422d46f44a97196c600f00ec0b9c3a2f`.
Zero verification provider launches. Qualified tree
`6963c5570d93f744a517f39bb1afc7562dd2fe80`, local commit `2ece2047`.
Candidate index was empty before loading the qualified tree without `-u`;
only the eight reviewed paths were committed, leaving future candidate WIP intact.
Backup `backup/modular-before-plan-approval-b6149df7`. No push/install/promotion.
This closes approval-policy ownership, not activation, execution, historical
record compatibility, or whole-release acceptance.

## Plan proposal rejection ownership

Base `2ece2047d634821387015719e8ae4c7f2e5aed49`; backup
`backup/modular-before-plan-rejection-2ece2047`. Five-path slice: existing
proposal-workflow, CLI dispatch binding, generated index/template and focused
owner tests. Physical Plan now owns rejection ordering, outcome text and
best-effort recovery. CLI retains concrete persistence, selection, Markdown,
chat, and dispatch. No behavior change intended. Existing public CLI entry
remains; this does not retire execution/activation adapters.

Red test `plan-rejection-owner-red` failed on absent physical rejection export,
SHA `692f73de956a644976429945d0b05015b8be1aaa660371ab9c1ac6784bd3a153`.
Focused build/types/dispatch/owner tests passed, SHA
`02b5c76d460b407a6ca650c2d4a57dfde23bfef05060da2722f0d8ed3aec09c1`.
Full build passed in 156.745s, SHA
`c0ffb90ab66a0d624bfa0c73b827d3055975a2f32d7858d88ab7af131bff748d`.

Default Agon review packet SHA
`480d5d9ac59a316e70951742742a428ddb596852056258cacd0f7a90b7ab003b`,
reviewed tree `4575ec6f7397f672f5dcef503330c61ddcf279ca`.
Codex log SHA `bfd21e2418c61be1b16b297a7fe3d6bb67e6fd097dd91e64ddbef782b2046c7d`;
Kimi log SHA `356d2a0de148d9e8c6dca4876a54458d39ef03fea3cdf249c8ad57adbef3456c`.
No blocking findings. Adjudication:

- Codex fixture state and exact text: now uses awaiting_approval; original state
  remains unchanged; complete chat rejection text is asserted.
- Missing Markdown and dispatch failure: two added cases pin skipped Markdown,
  cancelled-record identity, propagation and suppression of subsequent effects.
- Absent chat and matching/nonmatching proposal: compiled parity corpus covers
  both chat presence values and proposed/active states, including selection of
  the active proposal while a different non-pending proposal remains unchanged.
- CLI wiring: `dispatch-routing.test.ts` exercises real dispatchIntent('/cancel'),
  persisted cancellation, plan-cancelled, success outcome, cleared proposal, and
  appended chat message. `keyboard.test.ts` proves Reject maps to planControl
  cancel; `surfaces/app-keyboard.ts:404` routes that action through submit.
  This is layered route evidence, not a new interactive terminal recording.
- Exact raw warnings, payloads and persisted files: compared by native corpus.
- Kimi missing cancel import: already imported for publication at the top of
  proposal-workflow.ts. Types and actual compiled execution confirm it.
- Kimi non-null Markdown assertion: inherited synchronous same-object invariant;
  physical owner checks truthiness before the host callback. Missing-path test
  now fails if that invariant is removed. No speculative API expansion.

`plan-rejection-live.mjs` runs the actual compiled CLI handler against the exact
old function from base Git, using real current storage/formatter/chat helpers
which did not change in this slice. Selection injection is the same current
physical selector/list binding. Fixed clock, shared isolated root; no output
normalization. 192 combinations: proposed state × active state × chat presence
× Markdown presence × normal/persistence/Markdown/chat fault. Raw events, errors,
warnings, selected state, context, JSON, Markdown and chat files match.
Old source SHA `ab745f04030d7431c92335c14583564d0bc43332ace96edb5d6a4ff5c31fcf41`.
Initial helper had a missing closing brace and failed before execution; preserved
as `plan-rejection-native-initial`, not counted green. Added syntax check before
rerunning. Corrected native receipt SHA
`c4cac2fa1fda9cc9ba5e547f67f05f2018d246e7caedb6ad4d3b1f68bfca7c00`.
In-memory removal of cancelled-event dispatch makes the prompt-release oracle
fail (`[]` instead of `['cancelled']`), SHA
`36c99727e2fade1950d6a1ab554a5d010ceaddca0c1f2f965c161ed4fd5b5a4c`.

Pack/manifest equality SHA
`ff8072ceb918fbae724069ce474154fae5902764af259df97e6d3fbb8bfa6a39`.
281-path preservation SHA
`32aca4ba495e408cbc558710002ad54b5ace207fb3024b66a2a41563457d97f5`.
Only the focused test refinement was mirrored into candidate WIP; pending
activation tests and future implementation remain intact. Final suite pending.

Qualification caught stale S5 migration-ledger hashes after the CLI runtime
binding changed. Failed receipt `plan-rejection-owner-final`, SHA
`536a747149624fe0c96df74b9501038b09b4f06688dbccbbb4aec9a0e9b8e0c0`.
Regenerated with the existing generator. A recursive comparison against Git
proves all 29 changed fields are assignmentHash or the specific
plan-execution.ts runtimeBindingHash; owner/status/coverage claims unchanged.
This adds one generated evidence file (six total paths). No oracle weakened.
Final staged tree after test refinements and ledger regeneration:
`90bfff2efe31ddd44102b96fea1cfcc3f6984aee`.

Final `plan-rejection-owner-final-ledger` passed in 112.837s: types, lint,
re-export guard, generated metadata, roadmap, 7,350 tests/six skips, then two
192-case raw compiled-runtime comparisons. SHA
`2d1bd71a5b94511df3bd8a417f20208475f0327810987f33ae6b8f96ac03ae09`.
Three positive native runs total, plus the expected failing mutation control.
Zero verification provider launches. Local commit
`fc921e826de51851b6aebd74415046d9972c2751` has the exact qualified tree.
Candidate index was empty before loading the six-path qualified tree without
`-u`; no ambient WIP bytes were replaced. Qualification worktree is clean at
the commit. No push, install, personal-state change or archive removal.

## Plan entry authority and proposal activation (in progress)

Base `fc921e826de51851b6aebd74415046d9972c2751`; backup
`backup/modular-before-plan-entry-fc921e82`. Seven paths: CLI execution binding,
physical proposal workflow, generated index/template, migration-ledger hashes,
existing proposal tests and new entry-authority tests. Previous turn was progress:
rejection ownership was committed and independently qualified.

Confirmed defect: direct, manual approval, automatic approval and resume bypassed
disabled Plan; resume/restart also accepted an answer after generation change.
Real DurableModHost tests: six red cases, four enabled controls green. Receipt
`plan-entry-authority-red`, SHA
`2910623114c2317ffb6cd868a2391fab71459e063bd4210e3b63af34aac45e53`.
The shared execution entry now checks selected Plan availability before writes
or executor construction. Resume checks before asking and after accepting an
answer. Physical Plan owns proposal activation; CLI supplies policy/effects.
executeApprovedPlan returns invocation acceptance, not task success. Manual
approval still returns handled=true on refusal to prevent legacy fallthrough.
Refused automatic proposals remain unchanged and available for manual approval.

A further red case proved pending resume approval survived host disposal and
reinitialization. Bound it to the existing captureProcessSurfaceAuthority guard.
Red SHA `0aa6b7178efdd4a6fc472e517cc4f33e16bf04e5caba7c44b3f6f9506c17b280`;
fixed SHA `c0c670fc42e35dfd7df7fd84fc249b5aa2d27e8cda6739dbc5bf1e27258a3a54`.
No new global state or lifecycle machinery.

Default reviewers inspected tree `2fb2a43b43d13c1bf234ed62b82eb2c1baf3879e`.
Packet SHA `745c6c53babcd6386d0a41e92e839686a94e0c1cfb712d8777b7d392bea931d4`.
Codex log SHA `26b80074f190b1af691db82dfd9ffd366144c883745eefb442716275d2dc9a66`;
Kimi log SHA `9a015614c1f1b0a56e4d58d59481291ac7a2d3e26eef8db1851c7a713286b56b`.
Adjudication:

- Capture-time error: reproduced as a rejected resume promise without a dispatched
  refusal. Wrapped capture and dispatches its error before asking/executing.
  Red SHA `27a958468d5d5e14b223593b9cb8a15f49e156f5d0faf214e763a9f69418eeba`;
  fixed SHA `fec83ff5d25440cec79f60fb1995b140b27af0d40b7e638c3413f63404dacc32`.
- Post-disposal entry: tested with real disposed host. It refuses already, because
  registry contributions have been disposed. The retained selector does not imply
  a live registration. No speculative kernel change.
- New synchronous invocations after a new initialization use that current host;
  pending resume permission is pinned across its asynchronous question. Captured
  step executors and ongoing effects remain separate unfinished work.
- Acceptance boolean: tests now prove false on authority refusal, true when the
  coordinator accepts an invocation but reports failed work; automatic activation
  does not resurrect its old awaiting-approval proposal after accepted failure.
- Proposal retention: stateful callback test proves automatic refusal -> live
  active proposal -> repeated refused manual approval -> execution after explicit
  reinitialization with Plan enabled. No pending state is silently lost.
- Contradictory disabled automatic notice: reproduced. CLI policy binding now
  refuses unavailable Plan before announcing policy approval. Physical workflow
  API did not need another callback. Red SHA
  `1fc7ccb179b43043de81e6c96f867fdccd9e12168b5a2408919354d932460f9c`.
- Public return contract: repository call sites traced; ignored-result await
  callers remain valid. Promise<boolean> is not claimed universally assignable
  to Promise<void>. Full compilation covers current consumers. Documented exact
  acceptance semantics on PlanProposalEffects.execute.
- Rejection remains available when Plan is disabled; no cancellation guard added.
- Multiple authority checks cover different boundaries: before a question,
  after its answer, and at the shared execution entry also called independently.
  The last check remains even when a particular caller has checked earlier.

Final focused types plus 63 tests passed (`plan-entry-review-fixed`), SHA
`b374b5d0f7e63cc4df6bc7b81f4b06bf100a68b4cd8ef2d6f2550a9d47d4faf7`.
Initial full build passed, SHA
`569fbd1edce2784791bd0a610b6aa0b0460673b86f8be56901ea4d2f5200596c`;
review fixes are being rebuilt. Current staged tree
`2f5934013a63157576d511d47315f7e581256b3b`.

Native probe development failures are retained, not counted green. Compiled CLI
has a private executeApprovedPlan and no exported disposal function; the probe
now uses actual public approval/automatic/resume functions in separate processes.
The fixture's CommonJS transpilation could not require import-only packages;
preloads now use their declared ESM import export. No shipping code changed for
these helper failures. First real enabled execution paused an empty plan, contrary
to the probe's initial done expectation. Immutable base executor source explicitly
requires nonempty completed steps, otherwise pauses. The probe asserts source
byte equality with base, then checks paused persisted state and observed running
state; it does not weaken an existing production oracle or claim completed work.
Disabled/changed cases require no persisted plan. Native completion still pending.

Rebuilt review fixes passed (`plan-entry-review-build`, 165.389s), SHA
`71f8bdb94c5c81858f4bf89415550fbc23d6cf92c2712c885280a1eb77bb6d82`.
First complete native run passed (`plan-entry-native-final`, eight fresh child
processes), SHA
`80b351e3e750e89db246a073807c62d9e93f2504ea92334a82376b347e361c62`.
Public compiled approve/automatic/resume routes run against real durable selected
generations. Three disabled cases persist nothing; three enabled cases persist
the expected paused empty plan after observing running state; two changed-pointer
resume/restart answers persist nothing. Host-disposal/reinitialization remains
covered by real-host Vitest, not falsely claimed as a compiled public disposal API.
No helper invokes private compiled exports or changes package exports for testing.
No live provider launches. Full final suite still pending.
Preservation receipt SHA
`650a99d3530e85afb186ff7ea82338e39054e65bbefcce352abbaa01365e0c9d`;
all 281 baseline WIP paths checked. New authority tests mirrored into candidate;
future execution/resume-owner changes preserved. Archive retained unchanged.

Full suite caught one compatibility regression: existing
`plan-coordinator-persistence.test.ts:132` requires public executeApprovedPlan
to resolve undefined even after handled callback-construction failure. Receipt
`plan-entry-owner-final` failed with 7,369 passing/one failing/six skipped, SHA
`a05f66165deeb546d066e730bf3d3b19c9758022340a4d354824d9770202f95e`.
The old test was NOT changed. Public executeApprovedPlan keeps Promise<void>;
a private executePlanInvocation owns the single guard/coordinator call and returns
the acceptance boolean to activation. Public wrapper only awaits it. This is
one implementation with a result-compatibility facade, not parallel execution.
This supersedes the proposed public boolean contract described above.
New authority tests assert preserved undefined results while still asserting
no side effects on refusal; physical activation tests assert the boolean contract.
The exact old persistence regression passes together with all new cases:
`plan-entry-public-contract-fixed`, 80 focused tests/types, SHA
`5f10a7e3c8e883c7f557b8300beae127c13612690aa580f94075d27d7fe30c01`.
Final candidate tree now `43a20f97851f3af5f96b8e77ae5a8edbe76fd95a`;
full rebuild and final suite pending again. No red gate carried forward.

Final qualification passed on tree `43a20f97851f3af5f96b8e77ae5a8edbe76fd95a`:
`plan-entry-compat-build` (153.201s), SHA
`a99c045a7dc58becbfb0a0fa568027ceebbcfa67fd483bc6e7d229690ae6c3bf`;
`plan-entry-compat-final` (123.679s), SHA
`9eada14e8d23ef8e36309def9953a76a3bd4c56163804b7da6d75a8ea499160d`.
Types, lint, re-export guard, generated first-party drift, roadmap, full suite
(7,370 passed, six skipped), and two native runs of eight fresh processes passed.
Both runs exercised the public compiled approval/automatic/resume paths against
the real selected durable generation. Zero live provider launches.
Preservation recheck `plan-entry-compat-preservation` passed all 281 baseline
paths with only the recorded allowed changes; the new authority test also
matches byte-for-byte between candidate and qualification worktrees.
Committed locally as `f4b6bf342da26945b0c9b6441e213894956312c3`
(`fix(modular): guard plan activation authority`). Exact seven-file verified
index; candidate future working-tree changes preserved. No push or installation.
This closes entry authority and proposal activation, not cached step authority,
remaining resume/execution ownership, or whole-release acceptance.

## Plan resume approval ownership (in progress)

Base `f4b6bf342da26945b0c9b6441e213894956312c3`; backup
`backup/modular-before-plan-resume-f4b6bf34`. Seven-path slice. The physical
Plan package now owns resume prompt content, accepted aliases, dismissal,
resume/restart selection and execution sequencing. CLI retains authority
capture, the choice UI, dispatch and the shared execution boundary. The existing
resume policy is byte-identical. No historical-record validation changes.
The pending candidate has stricter saved-record validation and an error
translation; these remain uncommitted future work, not silently adopted here.

Sixteen owner tests failed before the export existed (`plan-resume-owner-red`,
SHA `cf05d550ad4873fdadcf1ef144989bb7da904a953738a961f884cca4d28057bb`).
The initial post-edit focused run failed because package imports resolve built
`dist/index.js`; typecheck emitted declarations but did not rebuild that bundle.
Its source export existed, its built export did not. No test oracle was weakened.
Full rebuild is running before another test run. Receipt preserved as
`plan-resume-owner-focused`, SHA
`d2e8408d66402e00b92f24a5c75c70e7e1dead50d5f1b0192aee322bc6d608ff`.
Staged review subject `327783138374b50dc4dcca159f80c158b8f4604f`.
The manifest declares the new `.d.ts`; existing generators regenerated exports
and migration ledger. Default isolated reviews and native comparison pending.

Codex review completed, packet SHA
`a1bd2f8fbecb67849df82da885fe7f8214703278b65937509a011204262cd0c7`,
log SHA `318ff2bd04e006286db07594621c28788e382b1f55f5ad9383ec52789f76c795`.
No confirmed defect. It identified one boundary difference: the physical owner
also checks availability immediately before rendering, after the CLI captures
authority. That additional fail-closed read can suppress a prompt when authority
changes in that interval; it grants no new permission. Retained deliberately.
Seven tests added for complete prompt labels/colors/summary, each failed effect,
dismissal after authority change, and awaiting accepted execution. The parity
probe additionally compares all choices, six saved step states, costs, authority
states and question/execution errors against immutable base source. It is not
claimed to cover every possible concurrent filesystem interleaving.

Full build passed in 165.061s (`plan-resume-owner-build`), SHA
`ed3c47a04d2900120cb563d1f4b96b2f96748402064ae0064b69364ca95618ef`.
Exact package allowlist passed, including `dist/resume-workflow.d.ts`:
`plan-resume-owner-pack`, SHA
`f680cab7679f0ed83873d4a6d1832c8616607187d388e3c8ff2dfce8b563c2b0`.
Negative control removes the acceptance-choice guard in memory, not on disk.
`plan-resume-choice-negative` fails on the first dismissed-answer case because
execution replaces cancellation; SHA
`8b18f17c03d5e8d49628ce55f27dc198d820af4bf26b581aa2a48a75bc34ba63`.
The preservation check initially rejected the newly extended resume test (the
prior slice allowlist did not name it). Verified that this is the only newly
changed baseline path. Candidate equals qualification plus its existing future
invalid-record test. Added only that exact path to the per-run allowed list;
281-path preservation passed (`plan-resume-owner-preserved`), SHA
`08a3065ffabd176875b7b1a3a6a8a1625cf3853974df3cfc047df053136e04d3`.
Final staged tree `f37af6bb0127276f83cba573a7b06d5474021c74`.
No production change after the review packet; added tests only.

Kimi completed with no definite regression; log SHA
`08b2e09703b6d522d2f65b76f92fbae6bcddacc8d1d0c9ead46a5b0c4cc75b05`.
Its additional-check observation agrees with Codex. Rejected its inference that
the interval is unreachable solely because there is no await: another process
can change a filesystem generation pointer. The extra check is fail-closed.
Its presentation/error/dismissal gaps are covered by the added tests. Refusal
input immutability is checked in every native parity case. The unavailable-after-
question test requires exactly one notification (the original summary), so any
spurious cancellation notification fails. Removed imports have no remaining
consumers; typecheck passed. Generated drift and exact tarball contents are
checked by existing commands, not asserted from the reviewer's confidence.
No second review panel is needed for these test-only additions.

Final resume qualification passed (`plan-resume-owner-final`, 136.125s), SHA
`a1ddf11e8ac010d7f6394d90c81ef690477b20f1aa021d2b2f90c758864331b0`.
7,393 tests passed, six skipped; types/lint/re-export/generated-drift/roadmap
gates passed. 1,728 old/new comparisons passed against immutable base, followed
by two real compiled CLI/durable-host runs, eight fresh processes each. Zero
provider launches. All raw receipts remain outside the shipping diff.
Committed locally as `5a0e9b8cd0377e83c4ae9847e6ef72ba7f8779a9`
(`refactor(modular): move plan resume approval`), exact tree
`f37af6bb0127276f83cba573a7b06d5474021c74`. Seven qualified paths only.
Candidate future validation/callback/executor WIP retained; qualification clean.
No push, install, promotion or personal-state write. Whole acceptance remains open.

Next bounded ownership slice: execution callbacks (CLI's current 300ms debounce,
UI events and final flush). Candidate physical callbacks contain an optional
flush(snapshot) checkpoint repair coupled to future coordinator changes. Extract
the existing callback behavior first; verify immutable-source event/write/timer
parity, then qualify checkpoint repair separately. Do not silently bundle it.

## Plan execution callback ownership (in progress)

Base `5a0e9b8cd0377e83c4ae9847e6ef72ba7f8779a9`; backup
`backup/modular-before-plan-callbacks-5a0e9b8c`. Nine paths. Move the existing
callback state machine, UI decisions and trailing debounce to physical Plan;
CLI supplies filesystem, persistence, display and warning effects. Keep legacy
core persistence/formatter facades for remaining callers. No new state store.
Do not include the candidate's future optional flush(snapshot) behavior.

Before extraction, nine existing-behavior parity cases passed; ownership guard
failed and the owner test could not import the not-yet-existing file. Receipt
`plan-callback-owner-red`, SHA
`40ab0dfb7458fcbff8560b88b893ee1f14bf08fb4449f8b5c01ee474d1d555b5`.
Types passed, SHA `be1cf12bc2c9d30c2cc1484ecb5ad9f709e037352543b5aeaf93337177ed2a06`.
Full build passed in 157.817s, SHA
`e2bd45006d9eccf099f94da333fe3acf86c0b5db09b62430f8efa43793464924`.

The fixture body, after only reversing the exported function rename, matched
the immutable base function byte-for-byte before stripping blank-line spaces.
Original function SHA (without final newline):
`8b423f49a28a51ea96c26006bb3491d5f07be191076994703fe795bbd35b3471`.
The committed fixture records that provenance and whitespace-only adjustment.
It freezes callback behavior, not separate formatter/store implementations.
Do not regenerate the oracle merely to accommodate a regression; intentional
behavior changes require a separately verified delta and updated expectations.

Default review subject `478442c2ba9296a2e7b04bab26ee186d069e9666`;
packet SHA `1a5aa2a32d333444f0186f15d76131d2d1c6c8e8ccb8178ecff4e0c1521918e3`.
Codex log SHA `554b44c546f88727bfa1bd6332be4c13dd37d122d6cb9feb70957b37cb0b1813`;
Kimi log SHA `720364dfc3348d68534a5961a4c279167744d8a484dee8bcb4534bd820c3c75b`.
Neither found a concrete extraction regression. Added exact appended-step
payloads, automatic debounce expiry, state-row transitions and cross-effect
terminal order tests; parity uses strict equality. Native probe additionally
covers missing markdown path, multi-engine selection, actual files/timers,
and actual coordinator/executor with deterministic provider-step stubs through
verification and fallback. Public CLI entry runs remain separately exercised.

Kimi's possible formatter fork is refuted by core/src/index.ts:167, a direct
export from mod-plan. Exact native markdown equality also checks the consequence.
Identifier guard alone is not proof of ownership; consumer tracing and real
callback execution are required. Synchronous disk writes/truncation remain
existing behavior, not new correctness failures. Codex notes inherited handling
of thrown null/undefined and warning-sink errors; these need a separate small
best-effort error-contract probe/repair after extraction, not a weakened parity
oracle or a claim that whole acceptance is complete.

Native negative-control helper initially had a missing brace; syntax failure
receipt retained and NOT counted as killed mutation. Added the brace and ran
node --check before rerunning. `plan-callback-flush-negative-checked` removes
only pending-timer cancellation in memory and fails with two writes after
terminal flush where zero are required; SHA
`83e75d329f8d1e32cecaee4c42d9e8dd06a01f225b53812bf1071102cb84d08b`.
Exact tarball/manifest check passed, including execution-callbacks.d.ts, SHA
`1575c8f1bab763238681fb1b7098c233bc30eb5cf3919019b4bf7354fbfb1687`.
All 281 baseline WIP paths preserved except named intentional changes; only
the callback owner test was added to the per-run allowed list. It matches
qualification byte-for-byte. Receipt SHA
`758edca2eb962ecd000076d9d4dd34c6d907d620989217d106861bf785ab6c00`.
Final staged tree `cf1c1407dc973a9e48062bddc6a788569fb9aac5`.
Full final suite/native gate pending. No shipping code changes after review.

Initial final gate passed all 7,411 tests (six skipped) and all hygiene/drift
checks, then failed the prototype coordinator review assertion. Its first
fixture declared no working-tree changes, which correctly suppresses review in
the unchanged coordinator. I corrected that fixture during the pending run;
the process had already loaded the old helper. No production code changed.
Process fix: freeze helper contents before starting a run, and print its hash
at startup. Failed receipt SHA
`5fad5334e269c720b89bfc04369a8d7d515894980a8da2b0084fc7f49c7c64ed`.
Corrected native probe passed (`plan-callback-native-corrected`, 8.902s), SHA
`a1a20e88e90ba5cfcabbeb230660389fc9fd9233e7627fe303a6193c73838102`.
It runs 11 real-file/timer old/new comparisons and two actual coordinator/executor
runs with fallback plus appended review. Provider steps and working-tree
observation are explicit stubs; persistence, callbacks and timers are real.
Frozen helper SHA `c97fcdedd9d9837758fcd329edb1495b910bcb82c6f182ad82c76d58da2cef88`.
The full final gate is repeating with this unchanged helper. Original fixture
body and provenance rechecked against Git, with only blank-line spaces removed.

Inherited null/undefined error handling is now reproduced on BOTH immutable
legacy callbacks and the extracted compiled owner: host save throws null or
undefined, flush itself throws TypeError, no warning is emitted, and markdown
is skipped. Four observations, no filesystem/provider effects. Diagnostic
`plan-callback-null-error-probe`, SHA
`9e994c0987ad9117b124f47943a39523c1115f8dfda882ded7cc71f394fbc721`.
Its passed flag means the defect was reproduced, not that this behavior is good.
Next repair: make the existing warning path null-safe and isolate warning-sink
failure so it cannot skip the remaining best-effort write. Keep ordinary Error
message payloads and non-Error values, add failing tests first, retain legacy
oracle unchanged for established normal behavior. No new dependency or public API.

Final callback gate passed (`plan-callback-owner-qualified`, 135.974s), SHA
`81d0aa27572b8a044c2536c2de650ffdcf8d116328f25a5cfbe5ed0ebc8031ef`.
All 7,411 tests passed, six skipped; types, lint, re-export, drift and roadmap
checks passed. Two native runs each passed 11 old/new file/timer comparisons
and two coordinator flows (normal + fallback, both appending review), followed
by eight compiled CLI/durable-authority scenarios. Zero live provider launches.
Local commit `856de71048c1ef1fa06051068ae0fa971f949121`, exact tree
`cf1c1407dc973a9e48062bddc6a788569fb9aac5`. Qualification clean; unrelated
candidate work preserved. Nothing pushed, installed or promoted. This is a
behavior-preserving extraction checkpoint, not acceptance of the inherited
null-error behavior or whole modular release. Repair begins next.

## Callback best-effort error repair (in progress)

Base `856de71048c1ef1fa06051068ae0fa971f949121`; backup
`backup/modular-before-callback-errors-856de710`. Two paths: physical callback
owner and its tests. Four new cases failed before the fix (null, undefined,
throwing warning sink, throwing message getter); 12 controls passed. Red receipt
`plan-callback-errors-red`, SHA
`6aca479524bbf2e13de5cf975b492b2b315908507723e36409870533c3aa762f`.
The existing warning path now uses null-safe message access inside a local
reporting guard. It cannot interrupt the remaining best-effort write. It does
not change required coordinator persistence. No dependency or public API added.
Types and all 16 initial focused tests passed, SHA
`8c5f66031b8731b2e9a8682a3828cbdb370efd8a087017f2c03059250fa7cdb6`.

Default reviews found no concrete defect. Reviewed production tree
`62b35350ec1e220eba25dc544cf25a30fb064511`; packet SHA
`f954da94ff756a07c1a99d0f5e71a8610406dc99fbbd8b8669906a00864c6964`.
Codex log SHA `0c7c3f6c8acb1b4ff5ca37313447e9008d6df9793102c3fe0836c76c68f6b1fe`;
Kimi log SHA `7f6b7f65361199a603cf57def684fa51d98133e21c94d501a7f61c25898f54f1`.
Added test-only coverage for timer failure/recovery, absent markdown path,
falsy message/primitive payloads, original object identity and both getter
failure sites. Both writes failing with a working warning sink was already
covered by the retained existing test; Kimi's gap claim there is refuted.
Do not unify coordinator/callback warning payloads just for appearance: their
existing unknown-valued contracts permit both shapes; that would change output
outside this repair without a demonstrated defect.
Final staged tree `e4072517ac33ab574f37fde68e38c4eb82866ad0`.
Build and final suite/native checks pending. Candidate optional flush(snapshot)
future work remains intact; only warning logic and tests mirrored there.

Expanded test-only tree now `e4072517ac33ab574f37fde68e38c4eb82866ad0`.
Build passed in 151.351s, SHA
`ac6fe8fdaa4dcdb8286a7fac8c4d31fd333fa8061022eec6ef57fb0efd44cced`.
Pack contents remain exact; SHA
`1575c8f1bab763238681fb1b7098c233bc30eb5cf3919019b4bf7354fbfb1687`.
Preservation check passed all 281 baseline paths with callback source added to
the exact intentional-change list, SHA
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
Native helper freezes its own SHA at startup. Against immutable old callback
source it fails on the first manual null save with the original .message
TypeError, proving the oracle rejects the old behavior. Negative receipt SHA
`e84757a515675e03c73717f71d0cc3fd6e8a4540e06201153f38c3fff7f164c0`.
Helper SHA `89878d221e67dc3db647603046be034c07d2fa4bf9f6e0e3868e61cb7de81fb6`.
The repaired native matrix covers both nullish values, save/markdown failures,
manual/timer delivery and working/broken warning sinks with real surviving
file writes. Two additional coordinator probes require initial save failures
to prevent executor construction and report that no work started.
Full final qualification remains pending; do not interpret the negative-control
exit 1 as a green current-runtime test.

Final gate passed (`plan-callback-errors-final`, 133.199s), SHA
`a1b6dd6beb2d83b83ec837ef8687b9fed7ef5a995a174ef951fa8b6d49ea140d`.
7,429 tests passed, six skipped; types/lint/re-export/generated-drift/roadmap
passed. Native repair matrix ran twice, callback parity/coordinator once, and
eight compiled CLI authority cases once. Zero provider launches.

Self-review caught a helper-oracle weakness: asserting the warning payload
inside the warning sink could itself be swallowed by the new reporting guard.
Moved that assertion outside the callback, after recording raw payloads. Did
not alter production code or existing unit oracles. New negative control injects
an incorrect payload and is rejected by the outside assertion; receipt SHA
`a671b3d910f1f688dc985fada6fd6ea9e9d3260622088374335db3b794a75248`.
Corrected helper SHA `c33c363b38d28678057ffa6127211cedccb19405a6949ba24a692a6fb5411bca`.
Two corrected native 18-case runs passed (`plan-callback-errors-native-external-oracle`,
6.173s), SHA `23cc5faca1b1dcbeec505d6f4261432225e00c7d7d9673da7168ebe867a5a84e`.
These supersede the earlier native payload assertion, not its valid filesystem
checks. Required initial persistence still prevents executor construction.

Local commit `6e6a9dd6c1ab62e044c1e52e957ce1721b9188ad`, exact tree
`e4072517ac33ab574f37fde68e38c4eb82866ad0`, two verified paths only.
Qualification clean. Candidate future flush(snapshot) change and all unrelated
work retained. No push/install/global or personal-state change.

Next source-confirmed gap: committed CLI buildStepExecutors still creates its
output directory without a Plan guard, returns cached unguarded executor
closures, and its self fallback calls runDelegate without checking Agent.
Candidate already has guard/physical-executor work, but do not adopt it wholesale:
trace each entry and preserve owner identity from the executor key rather than
the caller-controlled step.type. Selected generation/host-lifetime checks and
real disabled-owner negative controls come before further executor extraction.
