"""Review a bounded source packet through Agon without personal-state writes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

repo = Path('/Users/ra/dev/agon-audit-remediation')
output = Path('/Users/ra/dev/modular-agon-remediation')
root = Path('/tmp/amr-review')
engine = sys.argv[1]
review_id = sys.argv[2] if len(sys.argv) > 2 else 'review-target'
if review_id not in ('council-runtime-owner', 'mutation-artifact', 'mutation-sandbox-owner', 'mutation-result', 'mutation-execution', 'mutant-runner-owner', 'goal-file-grading', 'mutation-containment', 'canonical-mutant-owner', 'goal-mutation-admission', 'goal-mutation-owner', 'goal-oracle-owner', 'goal-journal-owner', 'goal-policy-owner', 'goal-review-cost', 'plan-session-composition', 'plan-execution-session', 'plan-natural-owner', 'plan-final-bindings') and review_id not in ('plan-brainstorm-closure-assessment', 'worktree-command-retirement', 'session-worktree-retained-failures', 'worktree-prune-safety', 'goal-oracle-preservation', 'goal-pr-handoff', 'goal-per-task-push', 'cli-kebab-projection', 'goal-retained-worktree-retry', 'goal-retained-worktree', 'conquer-pr-handoff', 'conquer-physical-publication', 'conquer-committed-publication', 'conquer-publication-owner', 'git-pr-link-bounds', 'git-pr-links-owner', 'pr-text-owner', 'conquer-retained-worktree', 'conquer-clean-reproduction', 'conquer-physical-falsifier', 'plan-session-routing', 'review-target', 'review-engines', 'jobs-contract', 'jobs-router', 'jobs-scheduler', 'jobs-authority', 'archive-two-largest', 'spec-anchor', 'http-jobs-authority', 'jobs-runner-owner', 'jobs-runner-output', 'daemon-jobs-execution', 'daemon-prompt-authority', 'daemon-prompt-shutdown', 'jobs-workflow-owner', 'jobs-session-owner', 'jobs-cli-contract', 'jobs-cli-client', 'jobs-cli-cutover', 'daemon-controller', 'daemon-owner-collision', 'daemon-stale-owner', 'daemon-command-owner', 'explicit-approval', 'patch-facades', 'copy-undo-design', 'apply-backend-final', 'cli-apply-owner'):
    if review_id not in ('brainstorm-receipts', 'runs-store-boundary', 'brainstorm-presentation-owner', 'brainstorm-session-owner', 'brainstorm-dedup-retirement', 'sidechain-kernel-owner', 'prune-fixture', 'ratings-protection', 'cli-nested-dispatch', 'plan-presentation-owner', 'plan-runtime-owner', 'plan-state-facade', 'plan-source-relocations', 'plan-session-scope', 'plan-selection-owner', 'plan-session-workflow', 'plan-publication-owner', 'plan-approval-owner', 'plan-rejection-owner', 'plan-entry-owner'):
        if review_id not in ('plan-resume-owner', 'plan-callback-owner', 'plan-callback-errors', 'plan-step-admission', 'plan-nested-phase', 'plan-provider-guard', 'plan-panel-return', 'plan-panel-owner', 'plan-forge-return', 'plan-remaining-return', 'api-tool-authority', 'agent-session-integration', 'cesar-self-integration', 'plan-agent-review-extraction', 'plan-build-step-extraction', 'plan-checkpoint', 'plan-store-precedence'):
            if review_id not in ('plan-headless-owner', 'plan-record-admission', 'plan-scheduler-admission', 'plan-outcome-contract', 'platform-attribution', 'release-performance', 'ratings-owner', 'cli-signal-cleanup', 'sustained-load', 'ratings-runtime', 'qualification-diagnostics', 'classifier-owner', 'brainstorm-host-owner', 'brainstorm-host-owner-retry', 'metadata-representation'):
                if review_id not in ('daemon-readiness-boundary', 'brainstorm-engine-host', 'release-artifact-refresh', 'plan-artifact-evidence', 'model-probe-owner', 'doctor-sidecar-owner', 'tui-probe-owner', 'roadmap-status', 'config-store-owner', 'engine-settings-owner', 'shared-settings-owner', 'tui-settings-boundary', 'mod-settings-transport'):
                    if review_id not in ('mod-settings-schema', 'migration-source-preservation', 'lifecycle-commit-boundary', 'forge-settings-owner', 'remaining-settings-owner', 'settings-alias-bridge', 'activation-artifact-retention', 'durable-config-design', 'setup-selected-state', 'selected-desired-owner', 'config-publication-fence', 'config-source-revision', 'durable-config-integration', 'config-staging-qualified', 'config-lazy-startup'):
                        if review_id not in ('config-generation-reader', 'config-invocation-scope', 'job-generation-leases', 'tui-local-pause', 'job-generation-handshake', 'candidate-runtime-design', 'candidate-activation-boundary', 'setup-payload-shortcut', 'clean-runtime-preparation', 'purge-exact-approval', 'sbom-external-closure', 'lifecycle-recovery-receipts', 'purge-journal-reference', 'host-lease-fence', 'npm-frozen-closure', 'reclaim-marker-recovery', 'retention-inspection', 'installer-frozen-closure'):
                            if review_id not in ('plan-legacy-authority', 'plan-export-retirement', 'plan-host-actions', 'retention-bytes', 'artifact-leases', 'artifact-retention-cli', 'foundation-implementation-mutations', 'brainstorm-legacy-routing', 'retention-unreferenced-inventory', 'forge-fitness-contract', 'forge-fitness-contract-isolated', 'forge-workspace-overlay', 'chalk-runtime-declaration', 'worktree-plan-owner', 'worktree-plan-authority', 'qualification-plan-edge', 'forge-result-policy', 'forge-judge-report', 'purge-cli', 'lifecycle-writer-cleanup', 'roadmap-dependency-drift', 'transaction-writer-cleanup', 'authority-writer-cleanup'):
                                if review_id not in ('rollback-writer-cleanup', 'external-writer-cleanup', 'transaction-recovery-context', 'retention-rollback-selection', 'retention-rollback-selection-complete', 'retention-storage-accounting', 'worktree-overlay-owner', 'payload-fixture-lifecycle', 'artifact-hydration-publication', 'forge-synth-plan-owner', 'forge-public-type-owner', 'fitness-process-owner', 'forge-corpus-owner'):
                                    if review_id not in ('package-generator-drift', 'gauntlet-validation-errors', 'gauntlet-owner', 'forge-scoring-owner', 'forge-fitness-quality-owner', 'forge-post-fitness-diff', 'forge-fitness-cancellation', 'forge-phase-cancellation', 'forge-terminal-status', 'forge-candidate-drain', 'forge-stage-owner'):
                                        if review_id not in ('forge-prompt-owner', 'forge-refinement-owner', 'forge-manifest-owner', 'result-envelope-owner', 'winner-owner', 'forge-workflow-cutover', 'retention-generation-inventory', 'result-owner-kill-list', 'retention-completion-design', 'retention-receipt-binding', 'retention-rollback-window', 'retention-selection-links', 'retention-collection-protocol', 'retention-collection-cli', 'retention-evidence-accounting', 'retention-quota-transition', 'retention-immutable-payload', 'retention-binary-cache-owner', 'retention-quota-coordinator'):
                                            if review_id not in ('payload-identity-fixture-lifecycle', 'first-party-owner-generator-repair', 'support-metadata-contract-repair', 'release-artifact-coverage', 'fitness-pid-publication', 'surface-owner-identity-refresh', 'directory-fixture-lifecycle', 'acceptance-boundary-662b2edb', 'slice-receipt-git-binding', 'pinned-checkout-subject', 'physical-bridge-retirement', 'ask-failure-diagnostics', 'retention-quota-cli', 'forge-invocation-host-owner', 'brainstorm-invocation-authority'):
                                                if review_id not in ('forge-gauntlet-config-owner', 'role-ranking-owner', 'plan-executor-assembly', 'plan-proposal-coordinator', 'run-directory-retention', 'api-catalog-owner', 'host-ownership-closure', 'brainstorm-config-boundary', 'review-subject-coupling', 'brainstorm-final-owners'):
                                                    if review_id not in ('review-hash-policy', 'plan-brainstorm-binding', 'conquer-option-forwarding', 'ownership-source-precedence', 'conquer-builder-boundary', 'conquer-budget-validation', 'conquer-timeout-parity', 'conquer-completion-owner', 'conquer-nero-pool', 'conquer-engine-resolution', 'gauntlet-cancel-diagnostics', 'shared-git-diff-owner', 'conquer-done-evidence', 'conquer-tui-budget', 'gauntlet-pid-readiness', 'conquer-deleted-tests', 'nero-verdict-owner', 'conquer-controller-convergence', 'conquer-test-renames', 'conquer-falsifier-owner'):
                                                        if review_id not in ('artifact-readonly', 'goal-witness-command', 'goal-differential', 'goal-task-isolation', 'goal-oracle-snapshot', 'goal-frozen-state', 'goal-exhaustive-mutation', 'mutation-evidence-recovery', 'goal-review-defaults', 'goal-artifact-owner', 'goal-competition-recovery', 'api-agent-usage', 'api-agent-usage-host-review', 'goal-oracle-recovery', 'forge-synthesis-accounting', 'goal-default-routing'):
                                                            if review_id not in ('goal-supervisor-contract-delta', 'api-artifact-usage', 'modular-dispatch-cost', 'goal-consensus-policy', 'goal-supervisor-missing-queue', 'goal-supervisor-invocation-cancel', 'goal-historical-status', 'goal-historical-resume-design', 'goal-resume-attempt-limit', 'goal-supervisor-startup-recovery'):
                                                                if review_id not in ('goal-tui-registry', 'goal-historical-strict-read', 'modular-safe-startup', 'modular-mcp-safe-startup', 'modular-project-memory', 'modular-mcp-memory-retirement', 'modular-async-host', 'modular-host-boundary-design', 'modular-host-error-owners', 'modular-git-owner'):
                                                                    if review_id not in ('modular-support-map', 'modular-plan-default', 'modular-config-placement', 'modular-plan-envelope-status', 'modular-token-owner', 'modular-apply-test-isolation', 'modular-pressure-stub-guard', 'modular-config-owner', 'ratings-invocation-boundary', 'ratings-tui-scope', 'team-role-position', 'team-intent-input', 'team-shared-owners', 'team-ratings-disabled', 'team-raw-baselines'):
                                                                        if review_id not in ('team-brainstorm-physical-command', 'team-brainstorm-session-owner', 'team-tribunal-cooperative', 'tribunal-policy-owner', 'tribunal-runtime-host', 'tribunal-presentation-owner', 'tribunal-mcp-host', 'tribunal-command-cutover', 'tribunal-session-owner', 'tribunal-command-retirement', 'plan-tribunal-owner', 'conquer-session-owner', 'conquer-cli-presentation', 'conquer-command-retirement', 'campfire-runtime-owner'):
                                                                            if review_id not in ('campfire-session-owner', 'campfire-cli-owner', 'plan-campfire-direct', 'think-owner-metadata', 'think-runtime-cli-owner', 'think-session-owner'):
                                                                                raise ValueError('Unknown review packet')
if engine not in ('codex', 'kimi'):
    raise ValueError('Only the default review roster is allowed')
env = {'PATH': os.environ['PATH'], 'LANG': 'en_US.UTF-8'}
for key, suffix in {'HOME': 'home', 'AGON_HOME': 'agon', 'CODEX_HOME': 'home/.codex',
                    'KIMI_SHARE_DIR': 'home/.kimi', 'XDG_CONFIG_HOME': 'config',
                    'XDG_CACHE_HOME': 'cache', 'XDG_DATA_HOME': 'data',
                    'XDG_STATE_HOME': 'state', 'TMPDIR': 'tmp'}.items():
    path = root / engine / suffix
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    env[key] = str(path)
env.update(AGON_ENGINE_ISOLATION='inherit', DISABLE_AUTOUPDATER='1',
           GIT_TERMINAL_PROMPT='0', PYTHON_KEYRING_BACKEND='keyring.backends.null.Keyring')
copies = [('.codex/auth.json', 'home/.codex/auth.json')] if engine == 'codex' else [
    ('.kimi/config.toml', 'home/.kimi/config.toml'),
    ('.kimi/credentials/kimi-code.json', 'home/.kimi/credentials/kimi-code.json')]
created = []
try:
    for relative, target in copies:
        destination = root / engine / target
        if destination.exists():
            raise RuntimeError('Refusing to overwrite an existing auth copy')
        destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        shutil.copyfile(Path('/Users/ra') / relative, destination)
        destination.chmod(0o600)
        created.append(destination)
    prompt = ('Independent bounded review. No tools. Check the supplied source for concrete '
              'regressions, unsafe Git inputs and missing behavior tests. The change moves '
              'the existing CLI Review resolver to shared verification and removes the second '
              'incomplete resolver. Verify named branch/base, auto-base, ranges and untracked '
              'files. Distinguish inherited defects from new ones. Do not certify the release.\n')
    for relative in ['packages/support-verification/src/review-target.ts',
                     'tests/unit/modular-review-target-contract.test.ts']:
        prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    prompt += '\nCLI now imports and re-exports the same shared resolver; its callers retain their exports.\n'
    if review_id == 'review-target':
        old = subprocess.run(['git', 'show', 'cd41cf1a:packages/cli/src/handlers/review.ts'],
                             cwd=repo, capture_output=True, text=True, check=True).stdout
        prompt += '\nOLD CLI RESOLVER\n' + old[old.index('/**\n * True when'):old.index('// ── Module: ReviewEngineSelection')]
    if review_id == 'review-engines':
        prompt = ('Independent bounded review. No tools. Review explicit reviewer selection: '
                  'named available reviewers must not be filtered by default orchestration exclusions. '
                  'Removed, unknown, unavailable, or empty reviewers must fail before dispatch. '
                  'Find concrete defects and missing regression cases. Do not certify the release.\n')
        for relative in ['packages/support-verification/src/review-engines.ts',
                         'packages/mod-review/src/implementation.ts',
                         'packages/cli/src/first-party-services.ts',
                         'packages/mcp/src/first-party-services.ts',
                         'tests/unit/modular-review-engine-selection.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'jobs-contract':
        prompt = ('Independent bounded review. No tools. Agon is a TypeScript npm-workspace project. '
                  'Preserve existing observable behavior, narrow public boundaries and one execution owner. '
                  'Review this INCOMPLETE Jobs migration for concrete new defects. The legacy daemon JobService '
                  'has moved to mod-jobs unchanged except replacing three imported config defaults with the same '
                  'values 256/100/4. Core reexports it. MCP metadata and argument builder moved to mod-jobs; '
                  'the MCP host injects its existing daemon client. MCP no longer submits to the factory-local '
                  'scheduler. That duplicate still exists for non-MCP paths and its retirement is explicitly '
                  'unfinished, not a release claim. Inspect MCP kind/payload, afterSeq, error propagation, '
                  'lifetime, cancellation and missing controls. Do not certify the release.\n')
        for relative in ['packages/mod-jobs/src/job-service.ts',
                         'packages/mod-jobs/src/mcp-contract.ts',
                         'packages/mod-jobs/src/implementation.ts',
                         'packages/mcp/src/job-tools.ts',
                         'packages/mcp/src/first-party-services.ts',
                         'tests/unit/modular-jobs-contract.test.ts',
                         'tests/integration/daemon-survival.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'jobs-router':
        prompt = ('Independent bounded review. No tools. Check a mechanical ownership move: '
                  'daemon Jobs request routing moves from CLI to mod-jobs; Jobs request/response '
                  'type unions move from Core to mod-jobs and Core composes them into its existing '
                  'protocol. CLI imports the public mod-jobs router and still guards requests with '
                  'isDaemonJobRequest after parsing. No intended wire or runtime behavior change. '
                  'Find concrete regressions, boundary mistakes and missing behavior tests. '
                  'The remaining factory-local scheduler and host enforcement are unfinished; '
                  'do not certify the whole release. Distinguish old defects from extraction defects.\n')
        for relative in ['packages/mod-jobs/src/daemon-contract.ts',
                         'packages/mod-jobs/src/daemon-job-router.ts',
                         'packages/core/src/sessions/daemon-protocol.ts',
                         'tests/unit/daemon-job-router.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        for relative in ['packages/cli/src/jobs/daemon-job-router.ts',
                         'packages/core/src/sessions/daemon-protocol.ts']:
            before = subprocess.run(['git', 'show', 'HEAD:' + relative], cwd=repo,
                                    capture_output=True, text=True, check=True).stdout
            prompt += '\nOLD FILE ' + relative + '\n' + before
    if review_id == 'jobs-scheduler':
        prompt = ('Independent bounded review. No tools. Review consolidation of two Jobs schedulers. '
                  'The former ModularJobService now extends the existing JobService and keeps only '
                  'its existing task-function API, configured defaults, and persisted observation writing. '
                  'JobService has a protected observation hook. Pending writes coalesce to one latest '
                  'envelope per job behind one writer; persistence failures are logged and flush rejects. '
                  'Mod disposal cancels local jobs, waits for idle, flushes state and unregisters in finally. '
                  'MCP daemon jobs are independent and must survive MCP disposal. Check behavioral parity, '
                  'failure handling, boundedness, races and missing tests. Remaining CLI/TUI workflow '
                  'routing and disabled-host enforcement are unfinished, not release claims.\n')
        for relative in ['packages/mod-jobs/src/job-service.ts',
                         'packages/mod-jobs/src/persisted-job-service.ts',
                         'packages/mod-jobs/src/implementation.ts',
                         'packages/mod-jobs/src/implementation.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        for relative in ['packages/core/src/jobs/job-service.ts', 'packages/mod-jobs/src/implementation.ts']:
            before = subprocess.run(['git', 'show', 'HEAD:' + relative], cwd=repo,
                                    capture_output=True, text=True, check=True).stdout
            prompt += '\nOLD FILE ' + relative + '\n' + before
    if review_id == 'jobs-authority':
        prompt = ('Independent bounded review. No tools. Check a daemon admission repair. '
                  'The CLI entry initializes process surface authority before running commands. '
                  'Previously a running daemon accepted raw Jobs socket requests after the durable '
                  'generation changed to disable Jobs. Now runDaemonServer captures its host lifetime '
                  'and each of the six Jobs request variants checks that lifetime and the existing '
                  'job CLI contribution before routing. Ping and shutdown remain available for recovery. '
                  'A real isolated daemon test commits a Jobs-disabled generation and verifies all six '
                  'request variants reject without a provider launch. The red run accepted new work. '
                  'Review regressions, missed authority paths, recovery semantics and test adequacy. '
                  'Current factory routing and full ownership are unfinished; do not certify the release. '
                  'Legacy-authoritative bootstrap without a durable host is an existing supported path.\n')
        for relative in ['packages/cli/src/commands/daemon.ts',
                         'packages/cli/src/surface-authority-runtime.ts',
                         'packages/mod-jobs/src/daemon-job-router.ts',
                         'tests/integration/daemon-survival.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'archive-two-largest':
        prompt = ('Independent bounded review. No tools. Audit removal of two HISTORICAL raw '
                  'artifacts from tracking, not deletion of evidence. Source copies remain local ignored; '
                  'a durable archive outside every worktree was verified byte-for-byte and retrieval '
                  'tested. Its original manifest hash and all 392 file hashes were reverified. The two '
                  'target files also match their recorded Git blobs and commit bytes. No history rewrite, '
                  'push, schema/fixture/generator-input removal, or current acceptance relaxation. '
                  'The old Slice1A receipt references its full-suite log, but is explicitly superseded; '
                  'the receipt is unchanged and the supersession now points to retrieval guidance. '
                  'Search of scripts/tests/docs including ignored files finds no read consumer of the '
                  'captured host-manifest file. Slice1A verification writes a new log at the old path; '
                  'it does not consume the historical bytes. Other logs remain tracked. '
                  'Check provenance, retrieval, clean-checkout risks, misleading claims and smallest '
                  'necessary correction. Full tests will run with both raw files physically absent.\n')
        for relative in ['docs/specs/evidence/modular-agon-archive-index.json',
                         'docs/specs/evidence/modular-agon-archive.md',
                         'docs/specs/evidence/modular-agon-slice1a-audit-supersession.md',
                         'docs/specs/evidence/modular-agon-slice1a-verification-receipt.json',
                         '.gitignore']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'spec-anchor':
        prompt = ('Independent bounded review. No tools. Review a narrow Markdown anchor validator fix. '
                  'The old slug collapsed repeated spaces and hyphens. A real existing heading '
                  'Apply workflow extraction — development qualification has a valid double-hyphen '
                  'link which the old checker rejected. GitHub rules preserve each space as a hyphen '
                  'and remove punctuation; the correction preserves those separators. Four constant '
                  'regression examples and a negative assertion run during every consistency check. '
                  'The old implementation fails these checks; the new implementation passes the '
                  'existing full consistency scan. No document links, acceptance counts or package '
                  'rules changed. Do not expand this to a complete Markdown parser; distinguish '
                  'inherited limitations from regressions. Find concrete defects or missing controls.\n')
        relative = 'scripts/spec/check-modular-agon-consistency.mjs'
        prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', relative], cwd=repo, capture_output=True,
            text=True, check=True).stdout
    if review_id == 'http-jobs-authority':
        prompt = ('Independent bounded review. No tools. Review HTTP Jobs disabled-owner enforcement. '
                  'AgonServe has a distinct per-runtime JobService; the daemon socket guard does not '
                  'protect its HTTP routes. A real local HTTP negative run accepted Jobs with the '
                  'owner disabled at boot, after a durable generation change, and after host replacement. '
                  'Now the bridge captures host lifetime, checks the Jobs CLI owner on every Jobs '
                  'request and after body reads, rechecks queued execution, and uses the existing '
                  'cooperative authority monitor for running Jobs. Bearer auth remains first; attach '
                  'and cleanup remain available. Typed owner errors return 403, restart errors 409. '
                  'Existing bridge and SSE conformance tests pass. Review new reachable defects, '
                  'race and cleanup behavior, meaningful negative controls. Keep current non-Jobs '
                  'semantics; do not call the whole release complete. No new dependency or scheduler.\n')
        for relative in ['packages/cli/src/bridge/agon-serve.ts',
                         'packages/cli/src/surface-authority-runtime.ts',
                         'tests/integration/serve-jobs-authority.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages/cli/src/bridge/agon-serve.ts'], cwd=repo,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'jobs-runner-owner':
        prompt = ('Independent bounded review. No tools. Review a mechanical Jobs ownership move. '
                  'The subprocess runner and output chunk emitter moved from CLI workflow-job.ts '
                  'to mod-jobs/workflow-process.ts. Their complete definitions match the old Git '
                  'bytes exactly. CLI imports and re-exports the same public functions. Planning, '
                  'engine validation, runtime config defaults and command sequencing remain CLI '
                  'responsibilities for a subsequent slice, not claimed extracted here. Real fixture '
                  'subprocess tests passed before and after the move: stdout/stderr chunks, exit 7, '
                  'pre-cancellation, live SIGTERM; new identity assertion proves the CLI forwarding. '
                  'The manifest, generated index and generator include workflow-process.d.ts; pack '
                  'dry-run matches the exact manifest allowlist. Only the command-finished ledger '
                  'row moves its implementationPath; the legacy binding remains explicitly open. '
                  'Find extraction regressions and meaningful gaps; distinguish inherited bugs. '
                  'Do not invent a new process supervisor or certify complete Jobs/release ownership.\n')
        for relative in ['packages/mod-jobs/src/workflow-process.ts',
                         'packages/cli/src/jobs/workflow-job.ts',
                         'tests/unit/daemon-workflow-job.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nOLD CLI FILE\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/cli/src/jobs/workflow-job.ts'], cwd=repo,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'jobs-runner-output':
        prompt = ('Independent bounded review. No tools. Review two reproduced inherited Jobs runner '
                  'defects and their fixes: String(chunk) corrupted split UTF-8; invalid chunk lengths '
                  'could silently lose output or loop forever. Three regression assertions failed '
                  'before changes. Now each pipe has a StringDecoder flushed before command-finished; '
                  'the public emitter and runner reject non-positive/non-safe-integer limits before '
                  'emitting or spawning. Cancellation and return values remain unchanged. Mocked '
                  'byte boundaries and real child stdout/stderr, cancellation and exit checks pass. '
                  'Check correctness and missing relevant evidence. Distinguish inherited issues '
                  'from new regressions. No new process supervisor or release certification.\n')
        for relative in ['packages/mod-jobs/src/workflow-process.ts',
                         'tests/unit/modular-workflow-process.test.ts',
                         'tests/unit/daemon-workflow-job.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'daemon-jobs-execution':
        prompt = ('Independent bounded review. No tools. The daemon already checks Jobs authority '
                  'at request admission, but queued/running execution escaped revocation. The new '
                  'resolver wrapper retains its host-lifetime check, rechecks authority on actual '
                  'execution, and uses the existing cooperative monitor also used by HTTP Jobs. '
                  'No new supervisor, timer abstraction, scheduler, or runtime option. Two unit '
                  'checks failed before the fix because revoked work ran. Real Unix-socket tests '
                  'with real durable host and scheduler, but a controlled workflow executor, verify '
                  'disable/replacement abort running work, await cleanup, refuse queued execution, '
                  'and preserve ping/shutdown. Removing the monitor makes both integration cases '
                  'fail; it has been restored. Review concrete new defects and gaps. Do not claim '
                  'full release completion or instantaneous revocation: monitor interval is 100ms.\n')
        for relative in ['packages/cli/src/commands/daemon.ts',
                         'packages/cli/src/surface-authority-runtime.ts',
                         'packages/mod-jobs/src/daemon-job-router.ts',
                         'tests/integration/daemon-jobs-execution-authority.test.ts',
                         'tests/unit/daemon-start-readiness.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'daemon-prompt-authority':
        prompt = ('Independent bounded review. No tools. Repair daemon prompt authority. '
                  'Previously runHeadlessTurn dispatched without a cancellation signal and could '
                  'publish an answer after the host generation changed. It now captures authority '
                  'at entry, uses the existing cooperative monitor around dispatch, forwards its '
                  'signal, and rejects aborted/stale results before the ledger engine-block. The '
                  'existing error ledger and ack-sequence behavior are preserved. Real Unix socket '
                  'tests use the real durable host and ledger but a controlled adapter; disable '
                  'and replacement failed before because no signal reached the provider, and now '
                  'pass while stale answers stay absent. Unchanged-host success still publishes. '
                  'Jobs guards were independently reviewed; shared helper result policy remains '
                  'unchanged because Plan owns typed refusal results. Check regressions and missing '
                  'evidence, not release certification. Shutdown cancellation of prompt dispatch '
                  'was already absent and remains a separately tracked lifecycle issue.\n')
        for relative in ['packages/cli/src/commands/daemon.ts',
                         'packages/cli/src/surface-authority-runtime.ts',
                         'tests/integration/daemon-jobs-execution-authority.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'daemon-prompt-shutdown':
        prompt = ('Independent bounded review. No tools. Repair active daemon prompt shutdown. '
                  'The old lifecycle cancelled/drained Jobs but abandoned prompt dispatch. A real '
                  'socket regression proved shutdown did not abort the provider signal. The daemon '
                  'now owns one lifetime AbortController and activeTurn promise instead of a busy '
                  'boolean. Shutdown closes prompt/Jobs admission synchronously; cleanup aborts '
                  'the lifetime and awaits Jobs and prompt concurrently within the existing configured '
                  'jobShutdownTimeoutMs. Timeout warns explicitly that provider cleanup remains pending. '
                  'runHeadlessTurn forwards the parent signal through the existing authority monitor '
                  'and checks cancellation before publication. Ping/shutdown remain recovery paths. '
                  'Review races, lifecycle leaks, error semantics and tests. No new scheduler or '
                  'configuration, no claim of forcibly stopping a signal-ignoring provider.\n')
        for relative in ['packages/cli/src/commands/daemon.ts',
                         'packages/cli/src/surface-authority-runtime.ts',
                         'tests/integration/daemon-jobs-execution-authority.test.ts',
                         'tests/unit/daemon-start-readiness.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'jobs-workflow-owner':
        prompt = ('Independent bounded review. No tools. Review physical extraction of daemon '
                  'Jobs planning, allowlist/payload validation, engine-flag validation and command '
                  'sequencing from CLI into mod-jobs. The CLI supplies the SAME existing command '
                  'compiler, roster validator and config defaults. The existing runtime callers '
                  '(daemon and HTTP) retain resolveDaemonWorkflowJob. No intended behavioral change. '
                  'Check package boundaries, validation ordering, execution/error/cancellation '
                  'semantics and test oracles. Do not certify unfinished Jobs factory/CLI/TUI '
                  'cutover. Distinguish inherited defects from extraction defects.\n')
        for relative in ['packages/mod-jobs/src/daemon-workflow.ts',
                         'packages/mod-jobs/src/workflow-process.ts',
                         'packages/cli/src/jobs/workflow-job.ts',
                         'tests/unit/daemon-workflow-job.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nBEFORE EXTRACTION\n' + (output / 'jobs-workflow-before.ts.txt').read_text()
    if review_id == 'jobs-session-owner':
        prompt = ('Independent bounded review. No tools. Repair generated TUI /jobs and /focus: '
                  'they previously used a separate empty factory-local scheduler instead of the '
                  'existing interactive JobManager. The session now injects its existing manager '
                  'and dispatch function into a typed invocation context. Mod-jobs owns list/focus/'
                  'cancel semantics copied from intent-meta; the old fallback also calls that one '
                  'implementation. The router invokes these synchronous control actions directly '
                  'instead of creating a background job to list jobs. Factory disposal rejects cached '
                  'handlers. CLI daemon and MCP paths remain separate and CLI factory cutover remains '
                  'unfinished. Check safety, lifecycle, public boundaries, parity and missing oracles. '
                  'No release certification. Existing public module code is trusted, not sandboxed.\n')
        for relative in ['packages/mod-jobs/src/session-jobs.ts',
                         'packages/mod-jobs/src/implementation.ts',
                         'packages/cli/src/signals/dispatch/intent-router.ts',
                         'tests/unit/modular-jobs-session.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        tui = (repo / 'packages/cli/src/signals/dispatch/intent-session.ts').read_text()
        prompt += '\nTUI HOST\n' + tui[tui.index('export async function runPhysicalTuiContribution('):]
        prompt += '\nOLD SESSION HANDLERS\n' + (output / 'jobs-session-before.txt').read_text()
    if review_id == 'jobs-cli-contract':
        prompt = ('Independent bounded review. No tools. Review a mechanical extraction of eight '
                  'CLI Jobs validators, payload construction, capability probe and exit-code helpers '
                  'into the physical mod-jobs package. CLI imports/reexports the same functions. '
                  'No behavior change intended; daemon transport and generated CLI cutover remain '
                  'unfinished. jobsCapability accepts only the structural fields it reads instead '
                  'of importing Core protocol types. Check actual regressions and package boundaries. '
                  'Do not certify the release or request speculative abstractions.\n')
        for relative in ['packages/mod-jobs/src/cli-contract.ts',
                         'packages/cli/src/commands/job.ts',
                         'tests/unit/job-command.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        original = subprocess.run(['git', 'show', 'HEAD:packages/cli/src/commands/job.ts'],
                                  cwd=repo, capture_output=True, text=True, check=True).stdout
        prompt += '\nBEFORE\n' + original
    if review_id == 'jobs-cli-client':
        prompt = ('Independent bounded review. No tools. Review extraction of the remaining CLI '
                  'Jobs request/poll/output logic and six action handlers into mod-jobs. CLI '
                  'retains Citty argument metadata and supplies daemon IPC, start/quiet-start, '
                  'terminal streams and exit-code effects. The physical client owns behavior. '
                  'No intentional runtime change. Compare the supplied exact pre-extraction '
                  'working source (not HEAD, which predates other verified repairs). Find concrete '
                  'regressions, boundary defects, missing tests. The generated factory CLI cutover '
                  'is still unfinished; do not certify release or demand unrelated improvements.\n')
        for relative in ['packages/mod-jobs/src/cli-client.ts',
                         'packages/cli/src/commands/job.ts',
                         'tests/unit/modular-jobs-cli-client.test.ts',
                         'tests/unit/modular-jobs-type-boundary.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nEXACT BEFORE\n' + (output / 'jobs-cli-client-before.ts.txt').read_text()
    if review_id == 'jobs-cli-cutover':
        prompt = ('Independent bounded review. No tools. Generated Jobs CLI cutover: one physical '
                  'client now owns six daemon-backed commands, with shared Jobs-owned metadata. '
                  'The legacy CLI lazy import is removed. Generated invocations inject transport '
                  'and terminal effects with captured generation checks. The factory no longer '
                  'creates a separate scheduler or dispatches providers for CLI submission. Parent '
                  'job is a no-op after Citty child dispatch. Daemon lifecycle still uses its legacy '
                  'loader; the unused generated daemon handler explicitly refuses instead of '
                  'falsely listing jobs. Review lifecycle, disabled/cached access, CLI compatibility '
                  'and missing tests. Tests for the retired factory scheduler were moved to its '
                  'retained public class; factory tests now cover in-flight IPC disposal, cleanup '
                  'aggregation, and no-host refusal. Do not certify release.\n')
        for relative in ['packages/mod-jobs/src/implementation.ts',
                         'packages/mod-jobs/src/cli-invocation.ts',
                         'packages/mod-jobs/src/cli-projection.ts',
                         'packages/cli/src/jobs/cli-host.ts',
                         'packages/cli/src/lazy-commands.ts',
                         'packages/mod-jobs/src/implementation.test.ts',
                         'tests/unit/modular-jobs-cli-projection.test.ts',
                         'tests/unit/modular-jobs-session.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'daemon-controller':
        prompt = ('Independent bounded review. No tools. Check a behavior-preserving physical '
                  'ownership move from CLI daemon.ts into the Jobs package. Process identity, '
                  'readiness, status, start, stop, file cleanup and formatting move to a factory '
                  'with injected directory, home creation, ping/shutdown transport, server entry, '
                  'spawn and terminal output. The CLI retains socket serving and headless engine '
                  'dispatch for now; this is not a release claim. Compare old and new logic. '
                  'Report concrete extraction regressions and missing safety tests; distinguish '
                  'inherited defects. Existing tests import CLI exports and therefore exercise '
                  'the new physical controller. No private imports or new dependencies.\n')
        for relative in ['packages/mod-jobs/src/daemon-controller.ts',
                         'packages/cli/src/commands/daemon.ts',
                         'tests/unit/daemon-start-readiness.test.ts',
                         'tests/unit/daemon-command.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nEXACT BEFORE\n' + (output / 'daemon-controller-before.ts.txt').read_text()
    if review_id == 'daemon-owner-collision':
        prompt = ('Independent bounded review. No tools. Fix a reproduced ownership bug: a second '
                  'foreground Agon daemon overwrote and deleted the first live daemon PID/socket. '
                  'The new server rejects a live existing PID before effects, uses successful Unix '
                  'socket bind as exclusive ownership, then publishes PID and heartbeat only after '
                  'socket permission setup. Failed bind cleanup must never remove foreign files. '
                  'Cleanup checks its published PID identity before removing the PID file. '
                  'A real two-process regression failed before and now passes. Unit tests model '
                  'a competing publication between preflight and listen failure. Verify lifecycle '
                  'races, cleanup, state preservation and new regressions. Distinguish still-open '
                  'legacy probe/stop flaws from introduced defects. No new lock implementation or '
                  'dependencies. This is not a complete release claim.\n')
        for relative in ['packages/cli/src/commands/daemon.ts',
                         'packages/mod-jobs/src/daemon-controller.ts',
                         'tests/unit/daemon-start-readiness.test.ts',
                         'tests/integration/daemon-survival.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
        prompt += '\nPREVIOUS SERVER\n' + (output / 'daemon-controller-before.ts.txt').read_text()
    if review_id == 'daemon-stale-owner':
        prompt = ('Independent bounded review. No tools. Inspect daemon stale-observation fixes. '
                  'Before: a failed awaited ping could delete newly published ownership; a dead PID '
                  'caused socket unlink without ping; stop could send SIGTERM from a stale PID '
                  'observation after awaited shutdown changed ownership. Four new tests failed '
                  'before repair. Current fix snapshots PID/socket inode, timestamps and size '
                  'before reads and checks after awaits. A responding socket prevents stale cleanup '
                  'even with a dead PID record. Errors during stale removal now propagate instead '
                  'of reporting cleanup success. Keep established stale-socket recovery and graceful '
                  'shutdown semantics. Identify concrete new regressions and remaining reachable '
                  'races. These checks are not an interprocess lock or proof against arbitrary '
                  'path replacement between synchronous syscalls, or OS PID reuse. Do not certify '
                  'the release. Prior server collision/publication fixes are included as context.\n')
        for relative in ['packages/mod-jobs/src/daemon-controller.ts',
                         'packages/cli/src/commands/daemon.ts',
                         'tests/unit/daemon-command.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'daemon-command-owner':
        prompt = ('Independent bounded review. No tools. Check daemon command ownership cutover. '
                  'Jobs now owns action dispatch, CLI schema and metadata. Generated CLI creates '
                  'the real Jobs contribution instead of loading the old daemonCommand. CLI '
                  'injects raw host bindings; Jobs constructs its controller inside the invocation '
                  'and combines mod-active, cancellation and captured host-generation guards. '
                  'Guards run around awaited probes/shutdown and before subsequent effects. '
                  'The existing JobSubmit startup caller now forwards its guard inside startup, '
                  'rather than checking only before and after the full call. The old daemonCommand '
                  'is a temporary thin compatibility export, no longer the live CLI loader. The '
                  'server/socket loop and headless dispatch still live in CLI and are explicitly '
                  'not yet fully extracted. No new dependencies. Check behavior parity, disabled '
                  'and stale-generation enforcement, cleanup, package boundaries, failure paths, '
                  'and test oracles. Distinguish new defects from inherited server PID/path races. '
                  'Do not certify the whole release. Previous tests were red before implementation.\n')
        for relative in ['packages/mod-jobs/src/cli-invocation.ts',
                         'packages/mod-jobs/src/cli-projection.ts',
                         'packages/mod-jobs/src/daemon-controller.ts',
                         'packages/mod-jobs/src/implementation.ts',
                         'packages/cli/src/commands/daemon.ts',
                         'packages/cli/src/lazy-commands.ts',
                         'packages/cli/src/jobs/cli-host.ts',
                         'tests/unit/modular-jobs-cli-projection.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (repo / relative).read_text()
    if review_id == 'explicit-approval':
        prompt = ('Independent bounded review. No tools. Review only the frozen staged approval '
                  'repair, not unfinished ownership work elsewhere. Empty answers can mean a '
                  'dismissed question and must not approve execution. Build, Forge, Plan and '
                  'convergence now require exact trimmed case-insensitive y/yes. Dismissed drafts '
                  'remain draft; a disk-loaded draft becomes the current draft so later /approve '
                  'uses the displayed draft. Run and suggested workflows reject y-prefix words. '
                  'Commit preserves its existing custom-message input, but blank/n/no/cancel '
                  'cancel. Explicit upstream approval and configured auto mode remain supported. '
                  'Find concrete new defects, state races and missing tests; distinguish inherited '
                  'defects and do not certify the whole release. No new dependency.\n')
        staged_tree = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                     text=True, check=True).stdout.strip()
        if staged_tree != '509e0de316d61c3425cc25050afecacdd881c745':
            raise RuntimeError('Approval review subject changed')
        prompt += '\nSUBJECT TREE ' + staged_tree + '\n'
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan.ts',
                         'packages/cli/src/handlers/commit.ts',
                         'packages/cli/src/handlers/build.ts',
                         'packages/cli/src/lib/explicit-approval.ts',
                         'tests/unit/plan-approval-refusal.test.ts']:
            prompt += '\nSTAGED FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', staged_tree + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'patch-facades':
        prompt = ('Independent bounded review. No tools. Mechanical removal of two private Core '
                  'forwarding modules: patch-parser and utils/patch. Existing support-worktree '
                  'already owns the algorithms and is already declared as a Core/CLI dependency. '
                  'Core package-root exports stay public and become direct reexports of the same '
                  'functions/types. Core Git normalization imports that owner; CLI Review imports '
                  'only parse/summary directly. Apply/undo runtime binding remains unchanged and '
                  'its later retirement is unfinished. No parser behavior, manifest, dependency or '
                  'version change. Git grep finds only Core git/index and three integration-test '
                  'imports of retired paths. Those files are not public package subpaths. Check '
                  'observable compatibility, cyclic initialization, consumer coverage, test guards '
                  'and unnecessary machinery. Do not certify the full release.\n')
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'fc13858f14bfeed1c8548b17f6d54111773fbb24':
            raise RuntimeError('Patch facade review subject changed')
        prompt += '\nSUBJECT TREE ' + subject + '\n'
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout
        for relative in ['packages/core/package.json', 'packages/cli/package.json',
                         'packages/support-worktree/package.json', 'packages/support-worktree/src/index.ts']:
            prompt += '\nCOMMITTED FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'copy-undo-design':
        prompt = ('Independent bounded architecture review. No tools. Review the supplied pending '
                  'Apply/undo backend, specifically Git copy patches. Real-Git tests below prove '
                  'both invertPatch and git apply --reverse fail for an unchanged copy (the source '
                  'remains and destination must disappear). Most inversion cases now pass, including '
                  'binary payloads, rename and modes. No copy fix has been implemented. Goal: preserve '
                  'valid existing behavior and avoid more speculative machinery. Compare minimal safe '
                  'repairs: contextual copy materialization before mutation; temporary Git index/tree '
                  'canonicalization; new reverse-original records; explicit fail-before-mutation for '
                  'currently unsupported format. Do not invent a claim that standalone content-only '
                  'inversion can reconstruct absent source bytes. Explain capability losses, storage '
                  'compatibility, concurrency, security, complexity, and necessary negative controls. '
                  'Recommend the smallest complete repair, separating facts from hypotheses. Public '
                  'invertPatch(content) and Core applyPatchWithUndo(cwd, content) already exist. The '
                  'goal does not authorize silently weakening acceptance to unsupported rejection. '
                  'Generated Forge patches use git diff --binary --no-ext-diff HEAD; external patch '
                  'files also enter Apply. No release certification. Keep response bounded.\n')
        for relative in ['packages/support-worktree/src/patch-parser.ts',
                         'packages/support-worktree/src/patch-apply.ts',
                         'packages/support-worktree/src/patch-content.ts',
                         'tests/unit/modular-patch-inversion.test.ts']:
            content = (repo / relative).read_text()
            prompt += '\nFILE ' + relative + ' SHA256 ' + hashlib.sha256(content.encode()).hexdigest() + '\n' + content
        prompt += '\nREAL GIT FAILURE LOG\n' + (output / 'apply-copy-reverse-control.log').read_text()
    if review_id == 'apply-backend-final':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '4cc760724d175fbf39fde3983325fa3fc6172ba2':
            raise RuntimeError('Apply backend review subject changed')
        prompt = ('Independent final implementation review of one Apply backend slice. No tools. '
                  'Frozen staged tree ' + subject + '. Do not certify the whole modular release. '
                  'Find concrete correctness/security/compatibility defects and missing tests; distinguish '
                  'inherited defects from new ones and prefer smallest complete repairs. Backend now '
                  'stores and fsyncs inverse before Apply, rejects unsafe record reads/parent links, '
                  'consumes successful Undo records, preserves exact UTF-8, fixes text/metadata/binary '
                  'inverse handling, and materializes copy patches using real source bytes in a private '
                  'temporary repo before mutation. Copy source bytes/mode/type are revalidated just '
                  'before Git apply. This is not a sandbox or atomic protection against arbitrary '
                  'same-user concurrent writers. No native/dependency/global-install changes. '
                  'Core public compatibility wrapper remains. Pure invertPatch(content) now throws '
                  'for copy input because content-only copies omit bytes; contextual Apply still succeeds. '
                  'Default design reviews disagreed: actual Git rejected both --reverse and no-hunk '
                  'deletion metadata. 17 live Git copy lifecycles pass. Check mixed patch semantics, '
                  'source/destination/mode handling, path safety, old records, cleanup, compatibility, '
                  'and unnecessary new machinery. Full clean-checkout build/tests run separately.\n')
        for relative in ['packages/support-worktree/src/patch-apply.ts',
                         'packages/support-worktree/src/patch-copy.ts',
                         'packages/support-worktree/src/patch-parser.ts',
                         'packages/support-worktree/src/git-path.ts',
                         'tests/unit/modular-copy-undo.test.ts',
                         'tests/unit/modular-undo-publication.test.ts',
                         'tests/unit/modular-undo-read-boundary.test.ts']:
            content = subprocess.run(['git', 'show', subject + ':' + relative], cwd=repo,
                                     capture_output=True, text=True, check=True).stdout
            prompt += '\nFILE ' + relative + '\n' + content
        prompt += '\nFULL SLICE DIFF STAT\n' + subprocess.run(
            ['git', 'diff', '--cached', '--stat'], cwd=repo, capture_output=True, text=True, check=True).stdout
    if review_id == 'cli-apply-owner':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '716ade7a9b5e8d5eb284e21159611d91ccd5367f':
            raise RuntimeError('CLI Apply review subject changed')
        prompt = ('Independent bounded review. No tools. Review the frozen CLI Apply/Undo '
                  'ownership and token-handoff slice, tree ' + subject + '. The physical backend '
                  'was separately qualified in bb629081: it creates a durable inverse before Apply, '
                  'returns an undo token, consumes it only after successful Undo, and may return '
                  'ok:true plus warning if record retirement fails after workspace reversal. '
                  'This slice migrates CLI Review/Forge/Undo from the old Core binding to that '
                  'physical owner with the existing persistencePath(undo) injection. Public Core '
                  'two-argument wrapper stays compatible. Forge remembers tokens through an optional '
                  'host callback; absent/throwing callback warns without retrying applied work. '
                  'Strict artifact reading rejects invalid UTF-8. React buildContext now supplies '
                  'the setter and handleSubmit refreshes when lastUndoToken changes. Plan ownership '
                  'changes in those files are deliberately excluded. Five baseline test assertions '
                  'failed on bb629081; focused tests now pass. Check correctness, effect authority, '
                  'closure/state lifetimes, callback failure, error messaging, missing discriminating '
                  'tests and actual boundary retirement. Distinguish existing problems from new ones. '
                  'Do not certify the whole release or assume structural UI tests are live UI proof.\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout
        for relative in ['packages/cli/src/blocks/review.ts',
                         'packages/cli/src/signals/dispatch/intent-meta.ts',
                         'packages/core/src/blocks/patch-apply.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
        forge = subprocess.run(['git', 'show', subject + ':packages/cli/src/handlers/forge.ts'],
                               cwd=repo, capture_output=True, text=True, check=True).stdout.splitlines()
        prompt += '\nFROZEN FORGE CONTEXT\n' + '\n'.join(forge[138:208] + forge[867:932] + forge[968:1020])
    if review_id == 'brainstorm-receipts':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'bb004980620837c127ab4e9a4342fbbe94b3e78b':
            raise RuntimeError('Brainstorm receipt subject changed')
        prompt = ('Independent bounded review; no tools. Inspect this frozen five-file slice, tree '
                  + subject + '. It addresses Brainstorm cancellation and partial recording failures, '
                  'not all session ownership or release acceptance. Existing runId now identifies '
                  'terminal telemetry attempts. The existing ledger keeps the first retained receipt '
                  'for an ID, serializes append with existing withFileLock, writes an exclusive '
                  'temporary file, flushes, renames, and syncs the directory. Corrupt input is no '
                  'longer treated as empty on append; UI read remains forgiving. Other callers '
                  'retain generated IDs. Session completion cannot replay partial history writes; '
                  'fail remains retryable. This is NOT an atomic transaction across history, ratings '
                  'and receipts, not permanent dedup beyond the retained 2000 rows, and not a '
                  'hostile same-user filesystem sandbox. Public write is an existing replacement '
                  'API; only append claims serialized read/modify/write. Find concrete regressions, '
                  'incorrect durability/identity claims, missing negative controls and smaller '
                  'complete repairs. Tests reproduced four ledger failures and missing stable IDs '
                  'before fixes; real file fault injection and Brainstorm-to-recordRun now pass. '
                  'Broader Plan/Brainstorm ownership changes remain excluded.\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/telemetry/index.ts',
                         'packages/mod-brainstorm/src/session-record.ts',
                         'packages/support-persistence/src/file-lock.ts',
                         'packages/cli/src/blocks/brainstorm-session-record.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'runs-store-boundary':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'ed2ce3081d54dbdb4ebc80480c3cb34411904015':
            raise RuntimeError('Run-store review subject changed')
        prompt = ('Independent bounded review. No tools. Inspect a three-file run-store fix at tree '
                  + subject + '. Config path changes while an async prune is scanning can make '
                  'it delete names from the wrong home and stamp/refresh another home. Pin one '
                  'path before awaits and use it for all prune effects. Stat scanning now uses '
                  'batches of eight, preserving readdir order; prune policy unchanged. Full-suite '
                  'under parallel lint plus six receipt writers hit a 30 s prune timeout followed '
                  'by three in-progress failures; the same committed suite passed when run alone. '
                  'Do not claim batching fixes that timing issue until live load evidence exists. '
                  'The two boundary tests reproduced three failures on committed 19c63d96 and '
                  'pass against this candidate. Verify path scope, interleavings, count semantics, '
                  'cleanup, tie order, cancellation/lifetime, and test discrimination. Distinguish '
                  'inherited problems from new defects. No hostile same-user symlink sandbox claim. '
                  'No dependencies or configuration changes. Do not certify the release.\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/support-persistence/src/runs-store.ts',
                         'tests/unit/runs-store.test.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'brainstorm-presentation-owner':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'a9aa724d3b0704d37579a18dbf1a7956d607771d':
            raise RuntimeError('Brainstorm presentation review subject changed')
        prompt = ('Independent bounded review. No tools. Review physical ownership extraction '
                  'of Brainstorm presentation decisions from CLI into mod-brainstorm. Tree '
                  + subject + '. CLI injects terminal primitives: clocks, timer cancellation, '
                  'dispatch, icons, colors, and scoreboard operations. Result type moves from '
                  'Core to the mod with a Core re-export. Workflow satisfies that same type. '
                  'No new result parser or session execution is included. Existing timer and '
                  'event behavior must remain identical. Check disposal, repeated completion, '
                  'errors, late events, concurrent invocations, public type/pack boundaries, '
                  'accidental complexity and raw-event parity test discrimination. Baseline '
                  'ownership test fails; 13 behavior assertions pass on the old owner. '
                  'Find concrete regressions, distinguish inherited flaws, and do not certify '
                  'the whole release. Frozen legacy fixture adjusts import paths only.\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['tests/unit/modular-brainstorm-presentation.test.ts',
                         'packages/cli/src/cesar/scoreboard.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'brainstorm-session-owner':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '6d747153e4dd82ebf1ab82da556ad03506e8776b':
            raise RuntimeError('Brainstorm session review subject changed')
        prompt = ('Independent bounded review. No tools. Inspect Brainstorm session ownership '
                  'tree ' + subject + '. Existing CLI preparation/settlement moves into the '
                  'physical mod with injected host capabilities and generation-selected executor. '
                  'The old CLI session-record adapter is removed; its host bindings move to the '
                  'remaining session binding. Result structural validation preserves identity and '
                  'extra evidence, rejects sparse/malformed typed fields, not model truth. '
                  'A confirmed old bug presented success before writing a receipt: corrected '
                  'order records then presents. Pending fixes preserve cancellation reason and '
                  'execution errors through diagnostic/cleanup failures. Sparse selected engine '
                  'arrays bypassed every(): reproduced and fixed with Array.from normalization. '
                  'Check actual behavior, error/abort interleavings, history/receipt identity, '
                  'result compatibility, redundant owners, disabled routing and test discrimination. '
                  'No new dependencies, no historical stored-result migration, no transaction '
                  'claim for multiple host writes. Broader Plan and generation authority changes '
                  'are excluded. Distinguish inherited defects, source facts and hypotheses. '
                  'Do not certify the full release.\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-brainstorm/src/session-record.ts',
                         'packages/mod-brainstorm/src/presentation.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'brainstorm-dedup-retirement':
        subject = subprocess.run(['git', 'write-tree'], cwd=repo, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '69b684562d4075d1a8fd062f6c3667ae4e7eedbc':
            raise RuntimeError('Dedup retirement review subject changed')
        prompt = ('Independent bounded review. No tools. Six-file adapter retirement, tree '
                  + subject + '. Delete a two-line private Forge re-export; its sole production '
                  'consumer imports the same shared-support public function directly. Tests use '
                  'the public owner. Frozen Brainstorm legacy fixture now references the already '
                  'frozen legacy dedup implementation rather than a live adapter; its parity '
                  'mock target follows that fixture import. A TypeScript import-scanning guard '
                  'rejects restored static, type, re-export and dynamic production imports. '
                  'Baseline reproduced two failures: adapter exists and consumer still imports '
                  'it; oracle hash and negative controls pass. Check coverage, oracle independence, '
                  'public dependency availability, scope and hidden consumers. The controller '
                  'and Python implementation are unchanged. Distinguish inherited process '
                  'limitations from new defects. No complete Brainstorm or release claim.\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=repo,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/support-dedup/src/brainstorm-dedup.ts',
                         'packages/forge/package.json', 'packages/forge/tsconfig.json',
                         'tests/unit/modular-dedup-parity.test.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=repo,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'sidechain-kernel-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '42543bed9f4ca807cfc0e634645bb3ae868533e4':
            raise RuntimeError('Sidechain ownership review subject changed')
        prompt = ('Independent bounded review. No tools. Review a byte-identical logger move '
                  'from Core to kernel, whose ownership ledger assigns SidechainEvent to kernel. '
                  'Core keeps its public runtime/type re-exports; existing Forge consumers remain '
                  'compatible. Core Brainstorm host imports the kernel public owner. Tests follow '
                  'the moved file; workflow parity mocks are retargeted to intercept the same logger. '
                  'No dependencies added. Check public boundary, cycles, behavior compatibility, '
                  'test independence, missing consumers and package artifacts. Flag inherited '
                  'security limitations separately from move regressions. Body SHA is unchanged '
                  'from 22fbc4f3. This does not close all Brainstorm adapters or the release. '
                  'Frozen tree: ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--no-renames'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/core/package.json', 'packages/mod-kernel/package.json',
                         'packages/mod-kernel/tsup.config.ts', 'tests/unit/sidechain-logger.test.ts']:
            prompt += '\nFROZEN FILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'prune-fixture':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        relative = 'tests/unit/runs-store.test.ts'
        current = (qualified / relative).read_text()
        prompt = ('Independent bounded fixture review. No tools. A full suite failed at the '
                  '30-second deadline; its first prune was still pending and polluted three '
                  'following tests. External filesystem instrumentation in a repeat under the '
                  'same concurrent lint load measured 24.96s in 2007 synchronous writes and '
                  '1.98s in utimes before the first scan; scan/deletion was milliseconds. '
                  'That repeat narrowly passed. Standalone suite passes in 1.7s. Change ONLY '
                  'the test fixture to eight bounded asynchronous writes with each utime '
                  'after its write. Preserve 2005 files, names, ages, assertions, timeout, '
                  'test count and production implementation. All five callers await setup. '
                  'Does this weaken the oracle or introduce races? Distinguish facts and '
                  'hypotheses. This is not a release review. Source SHA256: '
                  + hashlib.sha256(current.encode()).hexdigest() + '\n')
        prompt += subprocess.run(['git', 'diff', 'HEAD', '--', relative], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        prompt += '\nCURRENT TEST\n' + current
    if review_id == 'ratings-protection':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '360656bbf2222dd45c13f7fc05dd376c25e4f440':
            raise RuntimeError('Ratings protection subject changed')
        prompt = ('Independent bounded review. No tools. Verify a destructive compatibility '
                  'repair: legacy ratings purge protects every registered engine plus configured '
                  'ratingsPurgeKeepEngines plus --keep; modular purge instead used filtered '
                  'listActive and defaulted absent capability to [], risking valid data. '
                  'Add a narrow optional bundled ratings host for complete protected IDs. CLI/MCP '
                  'supply registry.listIds plus configured keep; mod unions --keep and refuses '
                  'missing/malformed host. Existing engine selection is unchanged. Two baseline '
                  'tests failed; focused host and real-file purge tests now pass. Check correct '
                  'contract, public API, destructive paths, test discrimination and missing '
                  'callers. Separate introduced regressions and inherited safety risks such as '
                  'home switching during awaits or stale manifest decisions. No complete release '
                  'claim. Frozen tree: ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-ratings/src/implementation.ts',
                         'packages/cli/src/commands/ratings.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'cli-nested-dispatch':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'b8b253c3e5453b5601698cdc8f0bd2aa874ca8fb':
            raise RuntimeError('Nested CLI subject changed')
        prompt = ('Independent bounded review. No tools. Four-line generated CLI fix. '
                  'Citty runs child then parent.run. Generated parents currently invoke both '
                  'contributions; worse, cached disabled parent is checked only after its child '
                  'acts. Add setup authority check; skip parent contribution when Citty has '
                  'selected a child by its first non-option argument rule. Direct parent runs '
                  'remain supported. Baseline: child/alias double dispatch and disabled parent '
                  'late check fail (3); direct parent, disabled child, unknown child and child '
                  'failure pass (4). Review scope, authority, stale lifetime, direct run tests, '
                  'aliases and argument grammar. No whole-release claim. Tree ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        prompt += '\nLAZY COMMANDS\n' + (qualified / 'packages/cli/src/lazy-commands.ts').read_text()
        citty = (qualified / 'node_modules/citty/dist/index.mjs').read_text()
        prompt += '\nINSTALLED CITTY RUNNER\n' + citty[citty.index('async function runCommand('):citty.index('async function runCommand(') + 1800]
    if review_id == 'plan-presentation-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '99df1e73a44f522f2819fc8a20f33fbd174ab9dd':
            raise RuntimeError('Plan presentation subject changed')
        prompt = ('Independent bounded review. No tools. Review Plan costing, sanitization and '
                  'Markdown ownership extraction from Core to mod-plan. Preserve algorithms and '
                  'public Core exports; Core retains pricing injection and the shared estimator instance. '
                  'The scheduler and session host are deliberately separate unfinished migration work. '
                  'Check state sharing, package boundaries, public declaration closure, consumer updates, '
                  'parity oracles and negative controls. Frozen fixture algorithm bodies are SHA-guarded '
                  'against db2a8c77. Baseline typecheck/lint/full tests passed. Focused tests passed; '
                  'temporary history-threshold, trusted-cost and hidden-shell-heading mutants failed '
                  'all four parity tests, then were restored. Do not claim whole-release completion. '
                  'Distinguish inherited defects from extraction regressions. Tree ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/formatter.ts',
                         'packages/mod-plan/src/cost-estimator.ts',
                         'packages/mod-plan/src/step-validation.ts',
                         'packages/core/src/cesar/plan-executor.ts',
                         'packages/mod-plan/package.json']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-runtime-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'c3a2d5d2aa62a7a255d5ce54adf427f7186e8d78':
            raise RuntimeError('Plan runtime subject changed')
        prompt = ('Independent bounded review. No tools. Plan runtime factory now owns the '
                  'composition of sanitizer and executor around an injected estimator. Core keeps '
                  'pricing injection and public exports but deletes its private scheduler facade. '
                  'The executor algorithm is unchanged. Separate session/activation/state-facade '
                  'work remains unfinished. Find concrete regressions in history sharing, errors, '
                  'public types, consumer routing and package closure. Existing 48 targeted tests '
                  'including raw legacy scheduler parity pass. A no-op history-sink mutant makes '
                  'runtime history/reporting tests fail; restored. No whole-release claim. '
                  'Frozen tree: ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/executor.ts',
                         'packages/mod-plan/src/cost-estimator.ts',
                         'packages/mod-plan/src/step-validation.ts',
                         'packages/core/src/cesar/plan-cost-estimator.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-state-facade':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '8cdd6b73e8452597274d64a35a5e1d4e057218e0':
            raise RuntimeError('Plan state facade subject changed')
        prompt = ('Independent bounded review. No tools. Delete private Core Plan state/store '
                  're-export facade; all production state/store algorithms already live in mod-plan. '
                  'Retarget Core root exports and ListPlans tool to public mod-plan; keep root API '
                  'and algorithms unchanged. Core package exports only dot, no private subpaths. '
                  'Tests now reject facade restoration and static/type/dynamic/re-export edges. '
                  'Scheduler oracle now imports frozen state transitions instead of live production '
                  'state; oracle function bodies unchanged. 80 focused tests/types pass, including '
                  'raw events and store-byte parity. New tests fail on base (facade and imports) '
                  'while public identity and inline negative edge controls pass. Historical source '
                  'locator strings in the frozen inventory/catalogs intentionally remain provenance; '
                  'default inventory generator checks frozen data, not current source. Physical '
                  'session activation and KL-011 remain open. Review concrete regressions, ownership, '
                  'public compatibility and test integrity; no whole-release claim. Tree ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/core/src/tools/tool-list-plans.ts',
                         'tests/fixtures/modular-plan-state-legacy.ts',
                         'tests/unit/modular-plan-store-owner.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-source-relocations':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'f7e3169df3a83eafeb87c59e3f731e51fd14cb4d':
            raise RuntimeError('Plan relocation evidence subject changed')
        prompt = ('Independent bounded review. No tools. Review only the added migration-evidence '
                  'correction, not another review of the previously reviewed Plan facade change. '
                  'Deleting a private forwarding facade broke the migration ledger and explicit '
                  'inventory refresh: reproduced both. New helper statically verifies 13 frozen '
                  'declaration assignments, keeps 344 first-party assignments and all 872 frozen '
                  'assignments unchanged. Routes remain legacy-runtime-until-s6 with hashed remaining '
                  'CLI bindings; declaration relocation is explicitly NOT execution cutover. '
                  'Roadmap verifier now consumes these evidence records and the independently '
                  'extracted kernel sidechain logger, previously omitted from its first-party-only '
                  'ledger. Existing logger test pins exact legacy implementation SHA and behavior. '
                  'Default inventory remains frozen; explicit refresh changes only isolated output '
                  'in tests. Check evidence honesty, missing controls, stale paths, regression or '
                  'unnecessary machinery. Do not certify release. Subject ' + subject + '\n')
        for relative in ['scripts/spec/modular-plan-source-relocations.mjs',
                         'scripts/spec/generate-modular-first-party-migration-ledger.mjs',
                         'scripts/spec/verify-modular-agon-roadmap.mjs',
                         'tests/unit/modular-plan-migration-ledger.test.ts',
                         'tests/unit/sidechain-logger.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += subprocess.run(['git', 'diff', '--cached', '--',
                                 'scripts/spec/generate-modular-agon-inventory.mjs'],
                                cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-session-scope':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '06f1061375e969bcd6813b141d0eaa2998701aa9':
            raise RuntimeError('Plan session scope subject changed')
        prompt = ('Independent bounded review. No tools. Mechanical physical owner move of '
                  'Plan AsyncLocalStorage invocation scope from CLI to mod-plan. Source unchanged '
                  'except comment. Public mod-plan exports new host/scope bindings; both CLI '
                  'consumers import the same public package. Removed private CLI implementation, '
                  'retargeted tests and removed old-path mock. Generator includes new d.ts in '
                  'exact pack list. Existing concurrent, mismatch, abort and late-work tests '
                  'retained; added nested-throw restoration and failed-owner expiry. Ownership '
                  'tests fail on base. Typecheck passes; first public-import test run used stale '
                  'compiled JS and failed (missing exports), full build is now running. Check '
                  'singleton identity, import/build boundary, cleanup, scope leakage and concrete '
                  'compatibility regressions. Remaining CLI session orchestration and KL-011 '
                  'are NOT claimed complete. No providers used in tests. Tree ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--find-renames'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/session-scope.ts',
                         'packages/mod-plan/src/session.ts',
                         'tests/unit/modular-plan-session-host.test.ts',
                         'tests/unit/modular-plan-session-tui.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-selection-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '87ba44163a77ca8a92ae0254511adf70a43f8557':
            raise RuntimeError('Plan selection subject changed')
        prompt = ('Independent bounded review. No tools. Move existing Plan approval/resume '
                  'selection and status formatting from CLI to physical mod-plan. Preserve exact '
                  'behavior. CLI retains a minimal HandlerContext-to-snapshot binding and injected '
                  'saved-plan reader, unchanged exports and keyboard question helper. No new '
                  'dependency or capability. Existing natural approval requires live pending state; '
                  'resumable lookup never reads disk. Explicit pending lookup retains historical '
                  'saved-plan fallback. Do not redefine that policy in this ownership move. '
                  '59 focused tests/types pass, including old dispatch tests; new owner test fails '
                  'on old code. Compiled physical policy matches exact pre-move Git source across '
                  'all 7x7 session-state combinations, 3 storage cases and 80 phrase variants, '
                  'including reads and non-mutation. Full build pending. Check regressions, '
                  'unsafe boundary changes, approval authority, useful tests and excess abstraction. '
                  'Remaining Plan orchestration and release gates stay open. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        prompt += '\nOLD FILE\n' + subprocess.run(['git', 'show',
            'HEAD:packages/cli/src/signals/dispatch/plan-queries.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-session-workflow':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'ab33eec9dfe350c85166554efef804cf0572d905':
            raise RuntimeError('Plan session workflow subject changed')
        prompt = ('Independent bounded review. No tools. Move Plan start/resume/exit lifecycle '
                  'decisions from CLI into physical mod-plan. Preserve legacy behavior, including '
                  'best-effort exit archival, no implicit disk discovery on resume, explicit saved '
                  'ID selection, running-exit refusal and router job/proposal precedence. CLI '
                  'retains router/UI effects via small injected interfaces. Added optional type '
                  'for existing justExitedPlanMode state (old writer used any). 81 focused tests '
                  'and typecheck pass. Full build underway. New owner tests failed on base. '
                  'Review regressions, side-effect order, promise failures, type/public boundary '
                  'and test gaps. No new dependency. Remaining proposal/executor migration and '
                  'release acceptance explicitly unfinished. Do not certify release. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-publication-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'c57c275b84cd71b170b54db3689d3573ea5288ff':
            raise RuntimeError('Plan publication subject changed')
        prompt = ('Independent bounded review. No tools. Move existing Plan proposal publication '
                  'policy from CLI into physical mod-plan. CLI retains filesystem/UI effects and '
                  'injects the same Core estimator. Core createCesarPlan/save/load/types already '
                  'directly re-export physical Plan; there is no second model. createPlanProposal '
                  'adds the existing awaiting_approval/autoApprove/selfReview fields, not execution. '
                  'No headless store cutover or strict-record validator in this slice. Those remain '
                  'blocked on a reproduced historical-record compatibility defect. Preserve cost '
                  'estimator authority, supersede after replacement persistence, failure order, '
                  'raw saved JSON/Markdown and events. Focused tests/types pass. New owner module '
                  'missing on base; old fixture parity passed on base. Fixture copied old function '
                  'body, whitespace-only trim. Raw comparison now asserts same temporary home and '
                  'does not normalize results. Full build ongoing. Review correctness, security, '
                  'public boundaries, test gaps and unnecessary machinery. No release claim. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/step-validation.ts',
                         'packages/core/src/cesar/plan-cost-estimator.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-approval-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '0e54f678409150d519a2ce34db66c3c3350b7113':
            raise RuntimeError('Plan approval subject changed')
        prompt = ('Independent bounded review. No tools. Transfer auto-approval decision policy '
                  'from CLI into physical Plan. CLI retains existing pricing and task lease '
                  'effects. Public Core types already re-export Plan. Preserve config modes, '
                  'cost ceilings including equality/null/undefined, two-review reserve, exact '
                  'action and shell boundary text/order, errors and output messages. One deliberate '
                  'integrity correction: exported mutable step set becomes a compatibility snapshot '
                  'rather than authority itself. Baseline old code allows safe-only self approval '
                  'after a caller clears the set; new code refuses despite snapshot mutation. '
                  'This is not a sandbox against arbitrary trusted code. Focused tests/types pass. '
                  'In-memory comparison against exact old Git source covers normal and agentic '
                  'policy plus effect traces. Full build underway; final suite/native pending. '
                  'Owner tests now spy actual CLI delegation, not source text. Existing mutation '
                  'cases kill ceiling and phrase defects. Check API/behavior/security/test gaps, '
                  'not unrelated style. No full-release claim; this is one remaining Plan boundary. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        prompt += '\nOLD POLICY\n' + subprocess.run(['git', 'show',
            'HEAD:packages/cli/src/cesar/auto-approve-policy.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-rejection-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '4575ec6f7397f672f5dcef503330c61ddcf279ca':
            raise RuntimeError('Plan rejection subject changed')
        prompt = ('Independent bounded review. No tools. Transfer existing proposal rejection '
                  'workflow into physical Plan; CLI binds real persistence, Markdown, chat, '
                  'dispatch and selection. Preserve exact observable behavior, ordering, '
                  'best-effort errors, prompt release and transcript outcome. No deliberate '
                  'behavior changes. Existing dispatch integration and five new owner tests '
                  'pass; types pass. Full build and raw old/new compiled CLI parity pending. '
                  'Check concrete regressions, ownership and test gaps. This does not close '
                  'Plan activation or execution ownership, and is not a release claim. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        old = subprocess.run(['git', 'show', 'HEAD:packages/cli/src/signals/dispatch/plan-execution.ts'],
                             cwd=qualified, capture_output=True, text=True, check=True).stdout
        start = old.index('export function cancelPendingCesarPlan(')
        prompt += '\nOLD REJECTION\n' + old[start:old.index('\n}\n', start) + 3]
    if review_id == 'plan-entry-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '2fb2a43b43d13c1bf234ed62b82eb2c1baf3879e':
            raise RuntimeError('Plan entry subject changed')
        prompt = ('Independent bounded review. No tools. Close selected-generation bypasses '
                  'at existing CLI Plan execution/resume/approval entries and move proposal '
                  'activation sequencing into physical Plan. Six tests reproduced disabled '
                  'or stale Plan execution; four enabled controls passed before the fix. '
                  'Additional red test proved a resume prompt survived host disposal/reboot; '
                  'now uses existing captureProcessSurfaceAuthority before prompt and checks '
                  'captured authority after answer. Eleven authority cases and existing routing '
                  'tests pass. executeApprovedPlan now returns whether invocation authority '
                  'accepted, not work success; coordinator retains its prior behavior. Automatic '
                  'refusal restores the unchanged proposal to manual approval. Manual approval '
                  'returns handled=true to prevent legacy fallback even when execution refuses. '
                  'Full build/native validation pending. Ongoing child effects and executor '
                  'construction wrappers are separate unfinished ownership; do not certify all '
                  'disabled reachability or the whole release. Review concrete regressions, '
                  'host lifetime/state transitions, public API and test gaps. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'scripts', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nAUTHORITY IMPLEMENTATION\n' + (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text()
        prompt += '\nOLD ENTRY IMPLEMENTATION\n' + subprocess.run(['git', 'show',
            'HEAD:packages/cli/src/signals/dispatch/plan-execution.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-resume-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '327783138374b50dc4dcca159f80c158b8f4604f':
            raise RuntimeError('Plan resume subject changed')
        prompt = ('Independent bounded review. No tools. Review a behavior-preserving ownership '
                  'move: resume approval sequence moves from CLI into mod-plan. CLI keeps the '
                  'selected-generation guard, captured host-lifetime authority, choice UI and '
                  'shared execution entry. New physical owner takes four injected effects. '
                  'Keep exact choices, messages, accepted aliases, dismissal behavior, input '
                  'immutability and error propagation. No policy or saved-record validation '
                  'change belongs in this slice. Historical state validation remains separate. '
                  'Identify concrete regressions and missing tests, not taste. No whole-release '
                  'claim. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'scripts', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/resume-policy.ts',
                         'tests/unit/modular-plan-entry-authority.test.ts',
                         'tests/unit/plan-approval-refusal.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        old = subprocess.run(['git', 'show',
            'f4b6bf342da26945b0c9b6441e213894956312c3:packages/cli/src/signals/dispatch/plan-execution.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        start = old.index('export async function resumeCesarPlan(')
        prompt += '\nOLD RESUME\n' + old[start:old.index('\n}\n', start) + 3]
    if review_id == 'plan-callback-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '478442c2ba9296a2e7b04bab26ee186d069e9666':
            raise RuntimeError('Plan callback subject changed')
        prompt = ('Independent bounded review. No tools. Review physical ownership extraction '
                  'of CLI Plan callbacks into mod-plan. Preserve exact events, pause rendering, '
                  'step lookup through latest snapshot, 300ms debounce, final flush, markdown '
                  'and best-effort warning behavior. CLI supplies effects; no new storage owner '
                  'or config. Legacy core save/format facade remains until later retirement. '
                  'The fixture function body was verified byte-for-byte against base 5a0e9b8c '
                  'before removing only blank-line trailing spaces. Five direct owner tests '
                  'and nine raw parity scenarios plus ownership guard are included. Types pass; '
                  'full build, suite and native real-file/timer checks pending. Later required '
                  'checkpoint and historical-record validation changes are not part of this '
                  'slice. Identify concrete regressions and useful missing coverage; distinguish '
                  'inherited defects. Do not certify whole release. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'scripts', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nCOORDINATOR\n' + (qualified / 'packages/mod-plan/src/execution-coordinator.ts').read_text()
    if review_id == 'plan-callback-errors':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '62b35350ec1e220eba25dc544cf25a30fb064511':
            raise RuntimeError('Plan callback error subject changed')
        prompt = ('Independent bounded review. No tools. Two-file repair of an inherited '
                  'best-effort persistence reporting defect: save throwing null/undefined '
                  'previously crashed flush while reading .message and skipped markdown. '
                  'A throwing warning sink or message getter also skipped the next write. '
                  'Four regression cases failed before this patch; all 16 owner tests and '
                  'types now pass. The local warning helper now uses null-safe access and '
                  'catches reporting failure. Normal Error message and primitive/object '
                  'payloads stay unchanged. Required coordinator checkpoints remain throwing '
                  'and are untouched; this only repairs existing best-effort callback writes. '
                  'No new public API or dependency. Review concrete defects and useful missing '
                  'tests. Full build/native validation pending. Do not certify whole release. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/execution-callbacks.ts',
                         'packages/mod-plan/src/execution-coordinator.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
    if review_id == 'plan-step-admission':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '7cad346409fa3c902bde39795613ad9929e9bd0c':
            raise RuntimeError('Plan step admission subject changed')
        prompt = ('Independent bounded review. No tools. Repair Plan executor admission. '
                  'Assert Plan before output directory creation; capture generation/host lifetime; '
                  'check the selected executor key rather than caller-supplied step.type at entry. '
                  'The self fallback must additionally admit Agent/delegate before dispatch. '
                  'All wrappers retain Promise rejection semantics. Catalog checks allow duplicate '
                  'declarations from one owner but reject conflicting owners. Fourteen negative '
                  'tests failed on base and enabled control passed. Now 17 admission tests plus '
                  '16 Plan entry tests pass with real isolated durable hosts and mocked provider '
                  'boundaries. Full build underway. Async child/effect authority after awaits '
                  'remains separately unfinished; this is not whole-execution enforcement or '
                  'release certification. Identify concrete new defects, inherited defects and '
                  'useful test gaps, with source evidence. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/surface-authority-runtime.ts',
                         'packages/cli/src/handlers/plan-mode.ts',
                         'packages/mod-kernel/src/surface-generation.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-nested-phase':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '00c4167120fdc8d76857f0847e026ac13c8d5654':
            raise RuntimeError('Plan nested phase subject changed')
        prompt = ('Independent bounded review. No tools. Follow-up to Plan admission repair: '
                  'the existing three-phase Plan step now checks each child owner immediately '
                  'before its backend call and rechecks captured Plan/Pipeline authority and '
                  'the child after the awaited call. A shared local assertion preserves prior '
                  'entry checks and now rejects an already-cancelled signal. Six negative tests '
                  'failed on base; enabled three-phase control passed. Focused 28 tests and types '
                  'passed before four added cancellation controls. All workflow backends mocked; '
                  'no live Pipeline or providers ran. Do not mistake this for cancellation of '
                  'internal backend retries during an outstanding call: guarded adapters and '
                  'cooperative monitoring remain unfinished, as do other step types and physical '
                  'extraction. Review concrete new regressions, state/error ordering and test '
                  'gaps. No release claim. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-provider-guard':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'c5fb76cb0f7b75576a4e4047fc84b7e402c6aa7c':
            raise RuntimeError('Plan provider guard subject changed')
        prompt = ('Independent bounded review. No tools. Add a nonmutating guarded adapter '
                  'for provider entries in modular Plan workflows. Preserve method receiver, '
                  'arguments, results, optional methods and async-generator return values. '
                  'Capture host lifetime and recheck selected owner before each new call; '
                  'reuse the existing cooperative authority monitor for outstanding steps. '
                  'Legacy-authoritative bootstrap intentionally retains original adapter identity. '
                  'Wired into forge/teamforge, four panel/delegate backends, self fallback and '
                  'the nested three-phase backend calls. Live self brain, Review and Agent-specific '
                  'adapter injection remain unfinished, as do physical extraction and post-await '
                  'workspace effects. Do not certify them or the release. Seven negative tests '
                  'reproduced late provider dispatch after revocation. New monitor exposed three '
                  'existing assertions: authority cancellation was mislabeled user cancellation. '
                  'Pipeline now uses SurfaceGenerationError reason to keep authority failures '
                  'failed, while ordinary cancellation stays cancelled. Tests were not relaxed. '
                  'Focused 56 tests and types pass, full build underway. Review concrete regressions, '
                  'lifecycle leaks, contract loss and missing controls. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/surface-authority-runtime.ts',
                         'packages/support-engine-runtime/src/types.ts',
                         'packages/mod-plan/src/executor.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-panel-return':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '9a9919e319260c2ac46fc23b818e13fa40906846':
            raise RuntimeError('Plan panel return subject changed')
        prompt = ('Independent bounded review. No tools. Four-line production repair: after '
                  'Brainstorm/Tribunal/Campfire/Delegate return, call the existing selected '
                  'Plan/step authority check before publishing success or context. Check is '
                  'inside each existing catch, preserving failed-step usage accounting. Twelve '
                  'regressions failed before the fix: each kind after generation revocation, '
                  'same-generation host replacement or caller cancellation. Mocked backends '
                  'deliberately ignore cancellation and return stale text. Now types and 78 '
                  'focused tests pass. Existing provider guards/monitor unchanged. This does '
                  'not undo backend effects, stop noncooperative providers, or close remaining '
                  'self/Forge/Review/Agent effect boundaries. Physical ownership extraction is '
                  'next, not part of this behavior repair. Review concrete regressions and useful '
                  'test gaps. No full-release claim. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-panel-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '4c6abc07d2fae5c6d3c3b965af19e33a73aeb52a':
            raise RuntimeError('Plan panel owner subject changed')
        prompt = ('Independent bounded review. No tools. Assess this physical extraction of '
                  'four Plan step algorithms from CLI into mod-plan. Preserve output, backend '
                  'arguments, usage accounting, cancellation and authority. CLI retains process '
                  'authority monitoring and guarded adapter injection. The owner receives narrow '
                  'backend capabilities, not a core registry. The four post-return checks were '
                  'already committed before this extraction. 128 focused tests and 36 native '
                  'compiled-owner parity cases passed with stub backends; full build and gate '
                  'are pending. Frozen oracle uses pre-extraction Git source but current shared '
                  'authority code, so it is algorithm parity, not independent authority proof. '
                  'Identify concrete new defects and useful missing tests. Remaining self, Forge, '
                  'Review and Agent effect boundaries are not claimed complete. No release '
                  'certification. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-forge-return':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'a91cf1e3a66089217590ddeaaebdd458d4d14e64':
            raise RuntimeError('Forge return subject changed')
        prompt = ('Independent bounded review. No tools. Two-line fix checks captured Plan '
                  'and selected Forge/teamforge authority immediately after backend completion, '
                  'before inspecting the manifest, no-op success or applying the winner patch. '
                  'Twelve regression cases failed before the fix: two step kinds, three stale '
                  'transitions and winner/no-op results. Six extra tests run real git apply in '
                  'isolated workspaces, proving healthy results change a file and generation '
                  'revocation/cancellation leave it unchanged. Focused types/tests pass. Review '
                  'new correctness regressions and missing essential checks. Existing synchronous '
                  'patch backend, progress callbacks, self/Review/Agent remaining ownership are '
                  'not rewritten here. Check cleanup and measured failed-step usage. No whole '
                  'release claim. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-remaining-return':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '7e385e6c63a01736d7597f1ffd3ab3f0481eb933':
            raise RuntimeError('Plan remaining return subject changed')
        prompt = ('Independent bounded review. No tools. Five-line repair: check selected '
                  'authority after self fallback delegation, after its verification command, '
                  'and after Review/Agent/team-agent completion before success/context. Twelve '
                  'new cases failed before the fix: four kinds after revocation, host replacement '
                  'or cancellation. Healthy controls passed. Focused 116 tests and types pass. '
                  'Self tests now also use a real verification command creating an isolated '
                  'marker, expected only for the healthy case. Backend generation is stubbed. '
                  'Live Cesar brain, guarded context adapter injection for Review/Agent and '
                  'physical extraction remain explicitly unfinished. Find concrete new defects '
                  'and essential evidence gaps, not a whole-release certification. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'api-tool-authority':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '21706d896f87660ab7a85f35dbd81e1d4913092e':
            raise RuntimeError('API/tool authority subject changed')
        prompt = ('Independent bounded review. No tools. Shared execution-boundary foundation '
                  'for modular Agent/Cesar: optional synchronous executionRefusal hook, only '
                  'undefined permits execution, thrown/empty refusal fails closed. Tool registry '
                  'checks before permission/hooks/execution and after async approvals/hooks. '
                  'API loop checks provider/retry entry, provider return and terminal return; '
                  'passes hook to tool context. Reuses candidate draft code, no new package. '
                  'Fourteen tests failed before guards; four more caught empty-reason bypass. '
                  'Now types, support package build and 23 tests pass. Real tool writes use '
                  'temporary directories; provider stream is stubbed. Session/team/Plan/Cesar '
                  'wiring is NEXT, not claimed complete here. Review concrete regressions, '
                  'async gaps, cancellation, data/result semantics and essential missing tests. '
                  'No whole release certification. Subject ' + subject + '\n')
        for relative in ['packages/core/src/models/tool-types.ts',
                         'packages/core/src/signals/tool-registry.ts',
                         'packages/support-agent-runtime/src/agent-loop.ts',
                         'tests/unit/api-agent-authority.test.ts',
                         'tests/unit/tool-execution-health.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'agent-session-integration':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '165fe4da8adca1d68dec2da4194f23ac0b851796':
            raise RuntimeError('Agent session integration subject changed')
        prompt = ('Independent bounded review. No tools. Inspect this integration against base '
                  '69f3836b (shared API/tool authority checks already qualified). A synchronous '
                  'executionRefusal hook permits only undefined, refuses empty strings/throws. '
                  'This change threads Plan authority through solo/team handlers, real sessions, '
                  'team members, fallback and synthesis paths; gates later fitness/persistence '
                  'effects; fixes Plan false success for failed/missing Agent outcomes and team '
                  'counts of unsuccessful members. Corrects fitness 60ms to 60 seconds, proven '
                  'with two real local processes killed before and completing after. '
                  'Tests have negative controls, real temporary file tools, isolated Git teams '
                  'and real durable-host generations; no live providers. Source-hash ledger '
                  'regenerated without changing ownership assignments. Assess concrete bugs, '
                  'async authority/cancellation gaps, accounting, cleanup, boundary ownership, '
                  'test discrimination, maintainability, and behavioral regressions. '
                  'Distinguish inherited issues. Refuse perfection claims: physical Plan owner '
                  'extraction, live Cesar and final release qualification remain unfinished. '
                  'Name essential missing tests; do not request unrelated expansion. Subject '
                  + subject + '\nSTAGED DIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/support-agent-runtime/src/agent-session.ts',
                         'packages/core/src/cesar/agent-team.ts',
                         'packages/core/src/cesar/agent-synthesis.ts',
                         'packages/cli/src/handlers/agent.ts',
                         'packages/cli/src/handlers/plan-mode.ts',
                         'packages/support-agent-runtime/src/agent-loop.ts']:
            source = subprocess.run(['git', 'show', subject + ':' + relative],
                                    cwd=qualified, capture_output=True, text=True, check=True).stdout
            if relative.endswith('/handlers/agent.ts'):
                source = source[source.index('export interface RunAgentTeamOptions'):]
            elif relative.endswith('/handlers/plan-mode.ts'):
                source = '\n'.join(source.splitlines()[60:92] + source.splitlines()[660:])
            elif relative.endswith('/agent-loop.ts'):
                source = '\n'.join(source.splitlines()[245:445])
            prompt += '\nSOURCE CONTEXT ' + relative + '\n' + source
    if review_id == 'cesar-self-integration':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '2bd23ae001ad2245dbb9d2e171e1e49264b856d2':
            raise RuntimeError('Cesar/Self integration subject changed')
        prompt = ('Independent bounded review. No tools. Review staged Cesar authority and '
                  'physical Plan Self integration against d3bc9727. Do not certify the release. '
                  'Owner assertions are run-local and permit only current active turns. The '
                  'brain bridges parent cancellation without overwriting its abort handle; '
                  'checks suspended budget/acquisition/fallback/stream boundaries; preserves '
                  'incurred usage; shares captured native/companion/eager/XML/MCP refusal. '
                  'Callbacks deny after owner disable, cancellation, replacement or terminal '
                  'completion. New terminal hosts deny new callbacks; legacy no-host callers '
                  'retain compatibility. Completed tool receipts are intentionally retained. '
                  'Self algorithm moves to mod-plan, injected host effects only. CLI retains '
                  'withProcessSurfaceAuthority monitoring and guarded Delegate fallback. '
                  'Verified defect corrections: failed/timed_out/cancelled/superseded brain '
                  'results must not become successful Plan steps; partial failure receipts '
                  'remain; separate Delegate owner rechecks survive extraction. Missing '
                  'terminalState remains legacy-compatible. 449 focused behavior tests and '
                  'workspace lint passed; meaningful red controls exist for each guard family. '
                  'Full repository qualification is in progress. No live providers in tests. '
                  'Check concrete races, forgotten effect boundaries, cleanup, retained state, '
                  'cancellation and error contracts, public boundaries, test discrimination '
                  'and avoidable duplication. Check session creation internals and native '
                  'special-tool awaits critically. Distinguish inherited defects from new '
                  'regressions; only name findings supported by supplied source. Other Plan '
                  'factories, complete owner retirement and release acceptance are unfinished. '
                  'Subject ' + subject + '\nSTAGED DIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests', 'scripts'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        contexts = {
            'packages/mod-plan/src/self-step-execution.ts': [(1, 10000)],
            'packages/cli/src/cesar/session.ts': [(660, 1070), (1530, 10000)],
            'packages/cli/src/cesar/brain.ts': [(140, 180), (760, 970), (1280, 1470), (2100, 2240)],
            'packages/cli/src/cesar/tools.ts': [(95, 10000)],
            'packages/core/src/signals/tool-registry.ts': [(45, 245)],
            'packages/cli/src/cesar/turn-runtime.ts': [(60, 245)],
        }
        for relative, ranges in contexts.items():
            source = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                    capture_output=True, text=True, check=True).stdout.splitlines()
            for first, last in ranges:
                prompt += '\nSOURCE ' + relative + '\n' + '\n'.join(
                    f'{number + 1}: {line}' for number, line in enumerate(source)
                    if first <= number + 1 <= last)
    if review_id == 'plan-agent-review-extraction':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '1b1ad46db38837428768e7d31beb69d5008d52a6':
            raise RuntimeError('Plan Agent/Review extraction subject changed')
        prompt = ('Independent bounded review. No tools. Review physical Plan Review, Agent '
                  'and Team Agent extraction against f91bd221. CLI keeps host effects, '
                  'withProcessSurfaceAuthority, parent signals and live executionRefusal. '
                  'The new owner imports only same-package context/executor contracts. '
                  'Unlike an older draft, it preserves terminal outcome checks: missing, '
                  'failed, cancelled, budget-exceeded and no-winner outcomes cannot succeed. '
                  'Thirteen red controls discriminated draft defects; corrected owner passes '
                  '35 tests. Real durable-generation admission plus owner tests pass 172; '
                  '51 raw parity scenarios compare the exact current inline bodies without '
                  'result normalization. Callback/signal identities are checked at boundaries. '
                  'Build, types, focused lint and generator checks pass; full gate is running. '
                  'Find concrete regressions, boundary leaks, lost cancellation or error '
                  'semantics, bad ownership and essential missing tests. Distinguish inherited '
                  'defects. No release certification; Forge/Pipeline ownership and full release '
                  'qualification remain unfinished. Subject ' + subject + '\nSTAGED DIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests', 'scripts'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/mod-plan/src/panel-step-execution.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-build-step-extraction':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'a603cc3ff8db3bc6d3b7f1ed72bd0aa8560a8b0b':
            raise RuntimeError('Plan build-step extraction subject changed')
        prompt = ('Independent bounded review. No tools. Review physical Plan Forge, TeamForge '
                  'and existing pipeline-step policy extraction against 7a9178e2. This does not '
                  'activate the Multi-AI Build Pipeline. CLI retains withProcessSurfaceAuthority, '
                  'entry guards, guarded adapters and host effects. Cancellation classification '
                  'is injected to preserve SurfaceGenerationError versus user cancellation. '
                  'Owner tests, raw parity and real-generation admission tests passed 275 cases; '
                  'five additional frozen-legacy controls passed. These prove old final workflow '
                  'validation could emit issues and still succeed, thrown validators could lose '
                  'the terminal event, and a synchronous patch-read callback could cancel before '
                  'patch application without stopping it. New owners fail closed. Exact partial '
                  'output now names both completed phases after Tribunal failure. Tests assert '
                  'outside caught backend callbacks and independently require expected status. '
                  'The frozen fixture shares original helpers once, with source and branch hashes. '
                  'Find concrete regressions, authority gaps, boundary leaks, bad error/lifecycle '
                  'semantics and missing essential tests. Distinguish inherited defects from new '
                  'ones. Do not certify release readiness. Subject ' + subject + '\nSTAGED DIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests', 'scripts'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/mod-plan/src/panel-step-execution.ts',
                         'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-checkpoint':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '1ee169470262350ff57c078ed3a40aa919134aa9':
            raise RuntimeError('Plan checkpoint subject changed')
        prompt = ('Independent bounded review. No tools. Review required Plan persistence '
                  'checkpoints against 77835e32. Five physical-owner files change plus a '
                  'real-file regression test. Existing UI saves remain best effort/debounced; '
                  'the persistent coordinator adds onCheckpoint before effects and after '
                  'results, stops its phase on required-write failure, preserves known results '
                  'and flushes authoritative recovery state over older UI snapshots. Optional '
                  'callback keeps non-persistent public callers compatible. Resume refuses '
                  'running/no-result and done/no-result records; explicit restart is separate. '
                  'Nine controls failed on baseline, initial 156 focused tests/types passed, '
                  'expanded suite passed; rebuilt tests and compiled SIGKILL/restart probes '
                  'are currently running. This is process-crash recovery, not a power-loss '
                  'fsync guarantee. Do not assume test totals prove correctness. Find concrete '
                  'bugs in result preservation, parallel batches, cancellation, stale writers, '
                  'fallback/review flow, public boundary compatibility and missing essential '
                  'tests. Distinguish inherited defects. Headless-store unification and strict '
                  'historical-record validation are explicitly NOT in this increment. No '
                  'release certification. Subject ' + subject + '\nSTAGED DIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/execution-coordinator.ts',
                         'packages/mod-plan/src/execution-callbacks.ts',
                         'packages/mod-plan/src/executor.ts',
                         'packages/mod-plan/src/resume-workflow.ts',
                         'packages/mod-plan/src/resume-policy.ts',
                         'packages/mod-plan/src/execution-state.ts',
                         'packages/mod-plan/src/execution-store.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-store-precedence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '1d77dcf49ec9393034245fff1d0ba9020cc43a19':
            raise RuntimeError('Plan store precedence subject changed')
        prompt = ('Independent bounded source review. No tools. Review a Plan storage repair '
                  'against 54af546c. One production file and one new regression file change. '
                  'IDs must be exact, not sanitized aliases. Canonical records supersede legacy '
                  'copies even when corrupt or unreadable. Fallback is allowed only for absence. '
                  'Reads preserve bytes and emit bounded diagnostics. Load/list share record '
                  'identity checks; valid old payload formats remain readable. Full shape '
                  'validation and headless/generic store unification are separate forthcoming '
                  'increments, not claimed solved here. Ten baseline controls failed and the '
                  'fixed 34-test focused group plus types passed, including frozen save-byte '
                  'parity. Do not use counts as proof. Find concrete regressions, unsafe record '
                  'selection, data loss, compatibility mistakes and missing essential tests. '
                  'Distinguish inherited defects. No release certification. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/execution-store.ts',
                         'tests/unit/modular-plan-store-owner.test.ts',
                         'packages/support-persistence/src/persisted-envelope.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-headless-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '653698b65526743352f20976e021949fbe4e01ce':
            raise RuntimeError('Headless Plan owner subject changed')
        prompt = ('Independent bounded review. No tools. Review one physical Plan writer consolidation. '
                  'Headless proposals/read/list/exit now use the existing canonical Plan state/store. '
                  'New proposals never claim execution merely from autoApprove. Exit rejects a running '
                  'plan through existing shared refusal policy. Dead private approve/retry/auto branches '
                  'are removed; their registered interactive routes already use runPlanSession. '
                  'Historical payloads must remain inspectable and byte-preserved on read. Three '
                  'real synthetic envelopes were captured from the accepted old compiled factory. '
                  'Strict historical execution admission and migration remain unfinished, not claimed '
                  'solved. Find concrete regressions, ownership drift, unsafe writes, and missing tests. '
                  'Distinguish inherited from introduced defects. Do not certify release readiness. '
                  'Four regression cases failed before this repair; focused tests and types pass. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/implementation.ts', 'packages/mod-plan/src/execution-store.ts',
                         'packages/mod-plan/src/execution-state.ts', 'packages/mod-plan/src/session-workflow.ts',
                         'packages/mod-plan/src/execution-model.ts', 'packages/mod-plan/src/session.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-record-admission':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'db2fc52bb40c2f7b26e3f56607b6d897c362d4be':
            raise RuntimeError('Plan record admission subject changed')
        prompt = ('Independent bounded review. No tools. Review Plan execution-shape admission. '
                  'The accepted old headless factory wrote real historical envelopes without total '
                  'estimates, actuals or stepContext. Those must stay inspectable and must not be '
                  'silently normalized or executed with NaN costs. Three failing controls showed '
                  'executor, coordinator and resume UI admitted them. This change validates before '
                  'effects/writes and adds one iterative graph owner shared with proposals. '
                  'Historical migration/restart UX and cross-process stale-write fencing remain '
                  'explicitly unfinished. Do not certify the release. Check compatibility with '
                  'valid model fields, execution boundaries, semantic gaps and missing controls. '
                  'Report only concrete source-grounded findings, distinguish inherited defects. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/execution-model.ts', 'packages/mod-plan/src/executor.ts',
                         'packages/mod-plan/src/execution-coordinator.ts', 'packages/mod-plan/src/resume-workflow.ts',
                         'packages/mod-plan/src/resume-policy.ts', 'packages/mod-plan/src/execution-state.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-scheduler-admission':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '0d8fe335dd252c78c35b79bb053047aec887a795':
            raise RuntimeError('Plan scheduler admission subject changed')
        prompt = ('Independent bounded review. No tools. Review dependency readiness and saved '
                  'parallel-writer policy against 13b53458. Four baseline controls failed: dependent '
                  'pending steps ran before prerequisites (sequential and parallel), a dependent '
                  'stayed blocked after a saved successful skipped prerequisite, and a saved parallel '
                  'forge pair bypassed the proposal restriction. New code derives readiness from '
                  'successful dependency results and shares the existing five-type writer policy '
                  'between proposals and saved-record admission. Do not broaden that historical '
                  'writer type list casually: supported parallel self work has frozen parity tests. '
                  'Check valid workflow compatibility, ordering, result proofs and controls. '
                  'Malformed result/estimate handling, historical migration and cross-process '
                  'fencing remain separate unresolved requirements, not claimed solved here. '
                  'Frozen raw oracle scenarios and four actual scheduler mutants pass locally. '
                  'No release certification. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/executor.ts', 'packages/mod-plan/src/execution-state.ts',
                         'packages/mod-plan/src/execution-record.ts', 'packages/mod-plan/src/dependency-graph.ts',
                         'packages/mod-plan/src/resume-policy.ts', 'tests/unit/modular-plan-executor-owner.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-outcome-contract':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'ab2cfd02123157327381e0abc52e97c101f8ad5f':
            raise RuntimeError('Plan outcome contract subject changed')
        prompt = ('Independent bounded review. No tools. Review malformed returned backend '
                  'outcomes and review estimates against caa97b71. Baseline controls reproduced '
                  'undefined responses becoming synthetic failures, incomplete success becoming '
                  'done, and invalid review estimates being persisted. Reuse the saved-result '
                  'validator; unknown outcomes retain started markers and cannot authorize retry. '
                  'Drain parallel siblings and preserve their known results. Existing backend '
                  'thrown errors retain legacy behavior in this bounded change. Review estimates '
                  'must fail before the new review plan is published or persisted. Check cancellation, '
                  'parallel ordering, resume/fallback, required evidence and user recovery. '
                  'Do not mistake preserved unknown markers for an archive of malformed raw output. '
                  'No new quarantine store is implemented. Historical migration and cross-process '
                  'fencing remain open. Distinguish new regressions from inherited problems. '
                  'Focused tests/typecheck and compiled real-filesystem sequential/parallel probes '
                  'passed locally; full gates are running. Do not certify the entire release. '
                  'Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached', '--', 'packages', 'tests'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-plan/src/executor.ts', 'packages/mod-plan/src/execution-coordinator.ts',
                         'packages/mod-plan/src/execution-state.ts', 'packages/mod-plan/src/execution-record.ts',
                         'packages/mod-plan/src/resume-policy.ts', 'packages/mod-plan/src/execution-callbacks.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'platform-attribution':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'cc91e3ade90a16bcdbc21957d01450e018202fa4':
            raise RuntimeError('Platform attribution subject changed')
        prompt = ('Independent bounded review. No tools. Review the platform release checker '
                  'repair against 4726ab50. Old code labels every local execution darwin/arm64 '
                  'and assumes the invoking Node is always major 26. Actual script-body VM '
                  'controls failed for three other supported targets. Repair derives process '
                  'target, selects current Node by its actual major, retains cached archive '
                  'verification only for built-in cached nodes, and checks runtime identity '
                  'before running tests. Seven focused controls and types pass. One real Mac '
                  'arm64 run passed Node26; eleven cells remain blocked. VM tests are label '
                  'tests, NOT native runner evidence. Find source-grounded defects, false-green '
                  'risks, portability issues and missing essential controls. Distinguish inherited '
                  'from introduced defects. This is not whole release certification. Subject '
                  + subject + '\n')
        for relative in ['scripts/spec/verify-modular-platform-matrix.mjs',
                         'tests/unit/modular-platform-matrix.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--cached', '--', 'scripts/spec/verify-modular-platform-matrix.mjs',
             'tests/unit/modular-platform-matrix.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'release-performance':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'a305dbe73b54a55b167eb1a5526e0dfe1edf93bb':
            raise RuntimeError('Release performance subject changed')
        prompt = ('Independent bounded review. No tools. Review missing S9 performance aggregation '
                  'and a measured CLI startup repair against 01c5dab0. All eight existing measurement '
                  'scripts retain their budgets and implementations. New runner executes them '
                  'sequentially with isolated state, retains output, and requires passing verdicts. '
                  'S9 consumes fresh aggregate JSON rather than old stored performance flags. '
                  'First real aggregate was red on cold startup. Import probes found eager Core '
                  'loading expensive. Auth already belongs to the declared public support-engine-runtime '
                  'dependency; Core auth-store merely reexports it. CLI now imports that owner '
                  'directly and loads Core config inside its sole interactive consumer. Auth load '
                  'timing and surface authority checks are unchanged. Real aggregate now passed '
                  'all eight measurements: version p95 143.6ms, help 136.3ms (185ms budget). '
                  'Metadata stdout remained byte-identical. Find concrete regressions, false-green '
                  'aggregation, lifecycle/timeouts, missing tests and boundary issues. Distinguish '
                  'inherited from introduced issues. This does not claim sustained-load completion '
                  'or release readiness. Subject ' + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['scripts/spec/measure-modular-release.mjs',
                         'scripts/spec/qualify-modular-agon-slice9.mjs',
                         'packages/cli/src/index.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'ratings-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'f0c163b4d5a21449741b7e7fd618f19316e91323':
            raise RuntimeError('Ratings ownership subject changed')
        prompt = ('Independent bounded review. No tools. Review consolidation of duplicate ratings '
                  'maintenance into its assigned physical mod-ratings owner. Baseline a25ff39d. '
                  'Core retains its public synchronous API and injects its existing load/save/path '
                  'codec through an explicitly approved internal workspace dependency. The mod retains '
                  'protected-engine lookup, permissions, cancellation, storage-root stability checks '
                  'and output envelope. Shared owner handles selection, pruning, lock, backup and run '
                  'moves. Non-ENOENT move failures were correctly fatal in the mod; the obsolete Core '
                  'copy swallowed them. Unified owner keeps the safer behavior and reports actual moves. '
                  'Codecs, no-op backup reporting (Core null, mod proposed path), and preview unknown-ID '
                  'reporting remain compatible. Tests cover partial filesystem failures, byte-exact '
                  'backup, protected engines, cancellation and malformed/mixed manifests. Check '
                  'behavior drift, public types/pack boundaries, recovery, concurrency and missing '
                  'meaningful controls. Distinguish introduced from inherited defects, verify every '
                  'finding from supplied source. Full release remains unfinished. Subject ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-ratings/src/maintenance.ts',
                         'packages/mod-ratings/src/implementation.ts',
                         'tests/unit/modular-ratings-protection.test.ts',
                         'packages/core/src/signals/glicko.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'cli-signal-cleanup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '3648e31f3c0f97e75661337e4eab78d1c57213b9':
            raise RuntimeError('CLI signal cleanup subject changed')
        prompt = ('Independent bounded review. No tools. Review CLI termination and engine cleanup. '
                  'A real daemon Think job using a local fixture reproduced this: cancellation marks '
                  'the job cancelled, kills the workflow CLI group, but leaves its separately detached '
                  'engine alive after 3.5 seconds. Node default SIGTERM skips the existing runtime JS '
                  'exit hook. The CLI now installs default SIGINT/SIGTERM handlers before command '
                  'handlers. With no other signal handler it calls process.exit(130/143), running '
                  'existing owned-group cleanup. With another handler it defers to that command. '
                  'Tests cover stream/non-stream children, both signals and once-handlers before/after '
                  'installation. The real daemon reproducer passes after rebuilding, fixture gone in '
                  '26ms. Check concrete behavior regressions, lifecycle policy, cleanup and coverage. '
                  'Source search found command on/once handlers (daemon, app, room, attach, goal, ext, '
                  'browser-host), no later prepend handlers in the repo. Do not assume passing tests '
                  'prove the whole release. Return actionable findings with exact source evidence; '
                  'do not invent a larger signal framework without a reachable defect. Subject ' + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/support-engine-runtime/src/process.ts',
                         'packages/mod-jobs/src/workflow-process.ts',
                         'packages/cli/src/index.ts',
                         'packages/cli/src/commands/daemon.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'sustained-load':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '4c800a3c398414d564eb29e5528fe3e91c0e8be7':
            raise RuntimeError('Sustained load subject changed')
        prompt = ('Independent bounded review. No tools. Review the new sustained-load release gate '
                  'and S9 fresh-evidence consumer. Inspect false-green risks, actual workload coverage, '
                  'subprocess ownership, cleanup, isolation and discriminating negative controls. '
                  'Two phases each last at least 120 seconds: real daemon transport echo, then actual '
                  'daemon Think jobs executing a local Node engine fixture, four workers and eight-job '
                  'batches. This is not a live-model quality test. Budgets were fixed from prior measured '
                  'baselines, not raised to fit: p95 50ms, daemon RSS 192MiB, process-tree RSS 1728MiB, '
                  'settled growth 32MiB. First gate run passed in 244 seconds behind external provider '
                  'blockers, zero provider launches. Failure, cancellation, recovery and shutdown are '
                  'real process checks. Review standalone isolation as well as wrapper execution. '
                  'No release-completion claim. Report source-grounded actionable findings, distinguish '
                  'inherited issues and avoid speculative new machinery. Subject ' + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['scripts/spec/qualify-modular-agon-slice9.mjs',
                         'packages/mod-jobs/src/workflow-process.ts',
                         'packages/cli/src/commands/think.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'ratings-runtime':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '6e56a8f1919bbee1a88743c50671592ff364bccb':
            raise RuntimeError('Ratings runtime subject changed')
        prompt = ('Independent bounded review. No tools. Review physical rating ownership extraction '
                  'from Core to the existing mod-ratings package. Base 37f2dec6. Core public exports '
                  'are direct bindings to a new glicko namespace; persisted types move unchanged. '
                  'No new dependency. Existing persistence lock remains authoritative. One shared '
                  'file reader/normalizer and publisher now serves both existing callers. Preserve '
                  'their distinct warning policy, home fallback, temporary filename and timestamp '
                  'mutation ordering. Registry dependency narrows to list() of existing EngineDefinition. '
                  'Core host Date/Math/JSON wrappers were direct builtins and are replaced identically. '
                  '134 focused tests passed. A source-bound legacy comparison outside the shipping diff '
                  'matched 2007 checks including exact persisted records and warnings, and killed a '
                  'mutated scale constant. Review concrete behavioral drift, public types, package '
                  'cycles/private imports, storage failure ordering, missing controls and ownership. '
                  'This does not claim the remaining Brainstorm host adapter or full release is done. '
                  'Do not redesign inherited rating formulas. Subject ' + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/core/src/blocks/host-runtime.ts',
                         'packages/mod-ratings/package.json',
                         'packages/mod-ratings/src/maintenance.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'qualification-diagnostics':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review two verification-only corrections, '
                  'not a production behavior change or release approval. The kill-list checker looked '
                  'for a job envelope in implementation.ts after that producer moved to '
                  'persisted-job-service.ts. It now checks the producer, its storage call and public '
                  'export chain, with negative controls for their removal. Self-test requires a green '
                  'baseline so an already-red gate cannot make its mutations pass vacuously. This is '
                  'a structural guard, not proof of runtime durability: the daemon uses JobService '
                  'and its existing specification excludes persistence across restart. The exported '
                  'ModularJobService API has separate behavioral persistence tests. Do not require '
                  'new daemon durability solely to satisfy this checker. Second change: bounded '
                  'stderr and existing socket trace in a real CLI test failure. Original test failed '
                  'in 619ms with a null acknowledgement, not the 3-second timeout. One focused, one '
                  'full suite and eight repeats subsequently passed; cause remains unresolved. '
                  'No retries or timeouts changed. Review concrete regressions, false-green risks '
                  'and missing discriminating controls. Base 37f2dec6.\n')
        subjects = {
            'scripts/spec/verify-modular-kill-list.mjs': '66e1a717dca95344be3f27405ab92c1fd4d966a2390f2e18c70e2534b57f4deb',
            'tests/integration/daemon-survival.test.ts': '20ec3963b6183da79c05999f4214b5c672d2d66a979e4df2fbfe72e0ef92d6b2',
        }
        for relative, expected in subjects.items():
            source = (qualified / relative).read_bytes()
            if hashlib.sha256(source).hexdigest() != expected:
                raise RuntimeError('Qualification diagnostic subject changed: ' + relative)
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + expected + '\n' + source.decode()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '37f2dec6', '--', *subjects], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-jobs/src/persisted-job-service.ts',
                         'packages/mod-jobs/src/implementation.test.ts']:
            prompt += '\nCONTEXT ' + relative + '\n' + (qualified / relative).read_text()
    if review_id == 'classifier-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '2cb38d64d92da43a5a4d0291fc31da574407c4d2':
            raise RuntimeError('Classifier ownership subject changed')
        prompt = ('Independent bounded review. No tools. Review task-classifier extraction from '
                  'Core to support-dedup, which already owns the Python asset and resolver. No new '
                  'dependency. Public Core functions/constants/cache bind the same owner. Output type '
                  'is inferred from existing literals, avoiding a type-only dependency on another '
                  'support package. Exact TypeScript emit comparison of the old source from 45749f24 '
                  'and new owner produced identical JavaScript. Public return/cache compatibility '
                  'is checked with a real TypeScript compiler program, not only a Vitest type assertion. '
                  'Local executable fixtures test argv/stdin, all output classes, caching, bypass, '
                  'failure and real two-second timeout; no Python/model download. Three in-memory '
                  'mutations target regex priority, cache and bypass. Baseline had 20 behavioral '
                  'passes and the expected missing-owner failure. Also reconciled three pre-existing '
                  'S4 ledger disposition changes after tracing direct support imports in telemetry, '
                  'git.ts and workspace.ts. They remain adapters, not claimed retired. Check behavior '
                  'drift, public boundaries, cache identity, test discrimination and missing controls. '
                  'Do not redesign inherited classification policy or certify the release. Subject '
                  + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/support-dedup/src/dedup-resolver.ts',
                         'packages/support-dedup/package.json',
                         'packages/support-engine-runtime/src/types.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id in ('brainstorm-host-owner', 'brainstorm-host-owner-retry'):
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'f4320b0ce339f6556d08ab621bf3646ca83decae':
            raise RuntimeError('Brainstorm host subject changed')
        prompt = ('Independent bounded review. No tools. Review Brainstorm host assembly moving '
                  'from Core to its physical mod. Existing Core two-argument public factory stays '
                  'as an effect-injection compatibility facade. The mod owns dispatch option assembly, '
                  'preflight binding and rating-input mapping. No new dependencies. Registry has a '
                  'generic structural boundary; Core selects its concrete type explicitly. Preserve '
                  'lazy opening, invocation cwd/signal, lookup timing, retry, textOnly, timeout, '
                  'outputDir, raw prompt, rating order and exceptions. Legacy Forge binding still '
                  'uses process.cwd(), intentionally unchanged in this slice. Config ownership and '
                  'facade retirement are unfinished, not claimed complete. Challenge unnecessary '
                  'abstraction versus actual responsibility transfer. Find concrete regressions and '
                  'missing controls. Existing 16 raw legacy parity tests and new 5 host tests pass; '
                  'changing seat cwd to process.cwd() makes the new test fail. Do not certify release. '
                  'Subject ' + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-brainstorm/src/runtime.ts',
                         'tests/unit/modular-brainstorm-workflow-parity.test.ts',
                         'packages/mod-brainstorm/package.json',
                         'packages/forge/src/brainstorm.ts']:
            prompt += '\nCONTEXT ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'metadata-representation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'efb4c45a209649cff705e15c467ffbb5079be18e':
            raise RuntimeError('Metadata representation subject changed')
        prompt = ('Independent bounded review. No tools. Audit F4 remediation: 36 generated mod '
                  'indexes import their existing agon.mod.json and ownership.json instead of embedding '
                  'copies. tsup bundles the JSON; TypeScript resolveJsonModule already enabled. Keep '
                  'validateManifest and SOURCE_OCCURRENCES export/freeze. No JSON or evidence removed. '
                  'All non-metadata export tails are byte-identical to base 253a53af. All 36 build/pack/ '
                  'activate/project/dispose/disabled-registration checks pass. Runtime metadata compared '
                  'against embedded literals from that immutable Git base, with 36 same-count negative '
                  'controls. Net 7949 generated source lines removed; not claimed runtime speedup. '
                  'The package gate exposed old Plan drift: four public step declarations missing '
                  'from manifest, while broad dist packed two unreferenced internal declarations. '
                  'Added the four public paths and restricted Plan files to the explicit declaration '
                  'allowlist. Compiler consumer with Plan filesystem restricted to that allowlist passes; '
                  'removing each public declaration produces TS2307. No private declaration needed. '
                  'This is the ONLY allowed manifest delta from base; remaining JSON is unchanged. '
                  'No dependencies, installs or oracle regeneration. Check build/runtime/typing/pack '
                  'regressions, static-discovery implications and false-green risks. Reviewer gets '
                  'generator/verifier, representative indexes and Plan pack diff, not 8000 repeated '
                  'deleted metadata lines. Do not certify whole release. Subject ' + subject + '\nDIFF\n')
        paths = ['scripts/spec/generate-modular-first-party-packages.mjs',
                 'scripts/spec/verify-modular-first-party-packages.mjs',
                 'packages/mod-plan/agon.mod.json', 'packages/mod-plan/package.json',
                 'packages/mod-ask/src/index.ts', 'packages/mod-brainstorm/src/index.ts']
        prompt += subprocess.run(['git', 'diff', '--cached', '--', *paths], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['scripts/spec/verify-modular-first-party-packages.mjs',
                         'packages/mod-ask/tsup.config.ts', 'packages/mod-ask/tsconfig.json',
                         'tsconfig.base.json']:
            prompt += '\nCONTEXT ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        for relative in ['metadata-parity.mjs', 'plan-packed-types.mjs']:
            prompt += '\nEVIDENCE HELPER ' + relative + '\n' + (output / relative).read_text()
    if review_id == 'daemon-readiness-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '1aab0ceffe5667f9379fd89217b854825df0bb77':
            raise RuntimeError('Daemon readiness subject changed')
        prompt = ('Independent bounded review. No tools. Review only the daemon test readiness fix. '
                  'Full suite failed on one-shot job-submit with ECONNREFUSED, connected=false, '
                  'bytes=0, elapsedMs=1, daemon exitCode/signalCode null, stderr empty. The test '
                  'previously waited for only socket existence. The production server publishes '
                  'the PID file with ready:true only after the listen callback and chmod succeed. '
                  'Other tests already wait for PID plus socket. Fix aligns the cancellation test '
                  'and asserts the PID belongs to the spawned child and ready:true. No production '
                  'code, timeout or retry change. Existing controlled unit test now explicitly '
                  'checks that a socket without listen completion has no PID publication. Check '
                  'whether this is a sound readiness fix, test weakening or missing evidence. '
                  'Do not certify release or claim a flaky failure is exhaustively resolved. '
                  'Subject tree ' + subject + '\n')
        paths = ['tests/integration/daemon-survival.test.ts',
                 'tests/unit/daemon-start-readiness.test.ts']
        prompt += subprocess.run(['git', 'diff', '--cached', '--', *paths], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in paths + ['packages/cli/src/commands/daemon.ts',
                                 'packages/mod-jobs/src/daemon-controller.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'brainstorm-engine-host':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'b0f9e65c326282c3364bdbf5eef03e1ff35eb7a3':
            raise RuntimeError('Brainstorm engine host subject changed')
        prompt = ('Independent bounded review. No tools. Audit extraction of the remaining Forge '
                  'Brainstorm dispatch binding into mod-brainstorm host.ts. Forge keeps the public '
                  'functions through existing createBrainstormRuntime and injects effects. New '
                  'createBrainstormEngineServices keeps options registry/adapter, late process.cwd, '
                  'options signal, selected-engine lookup capture, classify-before-map rating order. '
                  'Existing invocation-bound factory intentionally retains different captured context '
                  'and map-before-classify semantics. No dependencies or new runtime algorithm. '
                  'Old preflight facade injected {loadConfig}; new factory does the same directly. '
                  'Kernel logger and support dedup/panel are already package dependencies. '
                  'Independent mod build, types and 29 tests pass, including 16 unchanged frozen '
                  'raw workflow/scout oracle cases. Actual source wrong-cwd mutant fails the new '
                  'engine-option test and is restored. Check behavior, API declarations, ownership, '
                  'unnecessary abstractions and missing discriminating tests. Do not certify release. '
                  'Subject tree ' + subject + '\nDIFF\n')
        prompt += subprocess.run(['git', 'diff', '--cached'], cwd=qualified,
                                 capture_output=True, text=True, check=True).stdout
        for relative in ['packages/mod-brainstorm/src/host.ts',
                         'packages/mod-brainstorm/src/runtime.ts',
                         'packages/forge/src/health-check.ts',
                         'tests/unit/modular-brainstorm-host-owner.test.ts',
                         'tests/unit/modular-brainstorm-workflow-parity.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'release-artifact-refresh':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'a33c9e795ec7bca7df39231705daf5710561d32d':
            raise RuntimeError('Release artifact subject changed')
        prompt = ('Independent bounded review. No tools. Review generated release metadata refresh, '
                  'not whole-release acceptance. No source or generator edits. Base e15c0572. '
                  'The prior artifact set predates ownership repairs. Old BOM/SBOM remain in a '
                  'verified durable archive. Existing generators rebuilt 49 modular tarballs plus '
                  'launcher using npm pack --ignore-scripts, without install/publish. Both '
                  '--check --self-test gates passed after regeneration. Full rebuild and gates '
                  'are running separately. Identity, versions and modular dependency lists remain '
                  'unchanged (151 edges). Launcher now includes the already committed '
                  '@kernlang/agon-support-verification dependency from dfd08272. Hash/size changes '
                  'and added declarations follow committed ownership changes. CLI hashed chunk '
                  'names change. npm provenance remains explicitly externally blocked. Find '
                  'concrete inconsistencies, false-green risks and required verification. '
                  'Do not equate regeneration with release readiness. Subject tree ' + subject + '\n')
        for relative in ['scripts/spec/verify-modular-release-set.mjs',
                         'scripts/spec/verify-modular-supply-chain.mjs',
                         'packages/cli/package.json']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nGENERATED DIFF\n' + subprocess.run(
            ['git', 'diff', '--cached', '--', 'packages/cli/release-channel.json',
             'docs/specs/evidence/modular-agon-release-set.json',
             'docs/specs/evidence/modular-agon-sbom.cdx.json'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-artifact-evidence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != 'db58494be5e789f73d8eceaa27ff8fd3b5ca53ed':
            raise RuntimeError('Plan artifact subject changed')
        prompt = ('Independent bounded review. No tools. Assess this Plan artifact-evidence repair, '
                  'not the whole modular release. Base 33510c6e. Requirements: unrelated dirty '
                  'files cannot prove a Forge patch applied; actual no-change outcomes may finish; '
                  'Pipeline must apply its selected patch before Tribunal. Preserve cancellation, '
                  'disabled-mod checks, accounting and raw persistence. Existing Forge apply logic '
                  'is shared internally, not duplicated. Optional result artifact has applied '
                  'cwd/path/sha256 or explicit no-change reason. Historical results remain readable '
                  'but unproven application pauses finalization. Pipeline retains applied evidence '
                  'on later failure. CLI uses existing exact UTF-8 reader so empty artifacts survive; '
                  'Apply reader is unchanged. Public non-shipping PipelineHost now requires read/apply '
                  'effects; only production consumer is updated CLI. 335 focused tests, types, lint, '
                  're-export guard pass; raw parity asserts only intentional differences. Real Git '
                  'apply, second-apply refusal and saved envelope roundtrip pass. Full suite rerun '
                  'remains due after correcting nine obsolete fixtures and a stale generated ledger. '
                  'Check concrete defects, provenance overclaims, retry after partial application, '
                  'authority boundaries and missing behavioral tests. Do not invent whole-project '
                  'acceptance from this bounded review. Subject tree ' + subject + '\n')
        for relative in ['packages/mod-plan/src/execution-model.ts',
                         'packages/mod-plan/src/execution-record.ts',
                         'packages/mod-plan/src/execution-coordinator.ts',
                         'packages/mod-plan/src/forge-step-execution.ts',
                         'packages/mod-plan/src/pipeline-step-execution.ts',
                         'packages/mod-plan/src/resume-policy.ts',
                         'packages/mod-plan/src/executor.ts',
                         'packages/cli/src/handlers/plan-mode.ts',
                         'tests/unit/modular-plan-pipeline-step-owner.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nCHANGE DIFF\n' + subprocess.run(
            ['git', 'diff', '33510c6e', subject, '--', 'packages', 'tests'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'model-probe-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '57cc564ffbe2a8dff2478225eb6f5592f0fea0fe':
            raise RuntimeError('Model probe subject changed')
        prompt = ('Independent bounded review. No tools. Check a physical asset ownership fix. '
                  'Engine-runtime already ships python/agon-model-probe-wrapper.py; catalog '
                  'previously searched only legacy CLI paths. Move its resolver to runtime, '
                  'first resolve its own python asset, retain all legacy paths and optional '
                  'moduleUrl contract. Catalog imports/reexports the same resolver. Existing '
                  'catalog-to-runtime dependency, no new edge, no asset deletion, no Python '
                  'change. Three tests failed before the fix; 24 focused tests now pass. '
                  'Check public compatibility, ESM/bundled layout, fallback and test adequacy. '
                  'Do not certify release; full gates and packed-runtime proof remain due. '
                  'Subject tree ' + subject + '\n')
        paths = ['packages/support-engine-runtime/src/model-probe-assets.ts',
                 'packages/support-engine-runtime/src/index.ts',
                 'packages/support-engine-catalog/src/cli-models-registry.ts',
                 'tests/unit/cli-model-probe.test.ts']
        prompt += subprocess.run(['git', 'diff', '2e6dacb2', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in paths + ['packages/support-engine-runtime/package.json',
                                 'packages/support-engine-runtime/tsup.config.ts',
                                 'packages/support-engine-catalog/package.json',
                                 'packages/support-engine-catalog/tsup.config.ts',
                                 'packages/cli/tsup.config.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'doctor-sidecar-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '2c984bc20296c196877c9aadefac29a15c89c950':
            raise RuntimeError('Doctor sidecar subject changed')
        prompt = ('Independent bounded review. No tools. Doctor checked history-search.py '
                  'through the legacy dedup resolver, but the execution bridge uses the physical '
                  'persistence resolver. Fix uses that existing public resolver; no dependency '
                  'change. Diagnostics name missing asset owners rather than claiming all five '
                  'files live in the legacy dedup package. Keep Python subprocess/dependency '
                  'probing, installer advice, statuses and timeout. Four regression tests failed '
                  'before the fix; two Python-failure controls passed. Existing subprocess test '
                  'now also checks real asset resolution with a fake successful Python executable, '
                  'not real Python dependency qualification. Check correctness, compatibility and '
                  'test discrimination. Do not certify the whole release. Tree ' + subject + '\n')
        paths = ['packages/cli/src/commands/doctor.ts',
                 'tests/unit/doctor-sidecar-ownership.test.ts',
                 'tests/unit/dedup-python-resolver.test.ts']
        prompt += subprocess.run(['git', 'diff', '7cb51822', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in paths + ['packages/support-dedup/src/dedup-resolver.ts',
                                 'packages/support-persistence/src/history-search-bridge.ts',
                                 'packages/cli/package.json']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'tui-probe-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = subprocess.run(['git', 'write-tree'], cwd=qualified, capture_output=True,
                                 text=True, check=True).stdout.strip()
        if subject != '1302e8eaa9dd5caea1a8b9d48deb55fb90bdeab7':
            raise RuntimeError('TUI probe subject changed')
        prompt = ('Independent bounded review. No tools. TUI probe asset consumer migration: '
                  'support-verification already ships python/agon-tui-probe.py. Add its owned '
                  'resolver, use it first in CLI, retain existing legacy py fallback and CLI '
                  'binary search. No Python code changes or asset deletion. CLI passes --agon-bin '
                  'explicitly; never launch support-verification/dist/index.js as the CLI. '
                  'Existing dependency and externalized support import, no install or new edge. '
                  'One ownership assertion failed before this fix; focused tests now pass. '
                  'pyte is absent on available isolated interpreters: real TUI rendering is '
                  'explicitly unverified, and legacy asset retirement is not authorized by these '
                  'path checks. Check regressions, layout, public shape and verification gaps. '
                  'Do not certify the release. Tree ' + subject + '\n')
        paths = ['packages/support-verification/src/tui-probe-assets.ts',
                 'packages/support-verification/src/index.ts',
                 'packages/cli/src/cesar/tool-tui-probe.ts',
                 'tests/unit/tui-probe-tool.test.ts']
        prompt += subprocess.run(['git', 'diff', '9b523a34', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in paths + ['packages/support-verification/package.json',
                                 'packages/support-verification/tsup.config.ts',
                                 'packages/cli/tsup.config.ts',
                                 'packages/support-verification/python/agon-tui-probe.py']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'roadmap-status':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '5481feb414202f895cf389837ecb4c43f4ad696d'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Roadmap status subject changed')
        prompt = ('Independent bounded documentation review. No tools. Correct stale roadmap '
                  'claims without weakening any accepted requirement. Product code is unchanged. '
                  'All JSON fields except claims are byte-equivalent as parsed objects. '
                  'Review for unsupported acceptance claims, ambiguity, contradictory status and '
                  'accidental requirement changes. Physical packages are not full ownership proof; '
                  'implementation existence is not release qualification. No installs or promotion '
                  'are authorized. Do not certify the release. Subject tree ' + subject + '\n')
        prompt += subprocess.run(['git', 'diff', 'f11c6602', subject, '--',
                                 'docs/specs/modular-agon-acceptance-roadmap.md',
                                 'docs/specs/evidence/modular-agon-implementation-roadmap.json'],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in ['packages/core/src/blocks/brainstorm-host.ts',
                         'scripts/spec/verify-modular-agon-roadmap.mjs',
                         'scripts/spec/assess-modular-agon-slices.mjs']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        for name in ['roadmap-current-clean-diagnostic.log', 'roadmap-status-assessment.log']:
            prompt += '\nOBSERVATION ' + name + '\n' + (output / name).read_text()
    if review_id == 'config-store-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'be592fa3534231569ab1b856fd169fdf74e180c5'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Config store subject changed')
        prompt = ('Independent bounded code review. No tools. Move existing scoped config I/O, '
                  'mtime cache, clone isolation, atomic write and invalidation mechanics from '
                  'Core into Kernel. No dependency added: host injects dynamic path resolver, '
                  'existing sync file lock and unchanged merge/normalization policy. Defaults '
                  'span nine frozen owners and deliberately do NOT move to Kernel. Core API, '
                  'ConfigError identity, permissions and run pruning must stay unchanged. '
                  'Not full config/Brainstorm ownership retirement and not release acceptance. '
                  '100 focused checks pass; replacing Core with exact old source makes the '
                  'same-cache ownership regression fail. Examine behavior parity, cache identity, '
                  'failure semantics, public API, package boundaries, unnecessary abstraction '
                  'and missing meaningful controls. Separate inherited defects from regressions. '
                  'Subject tree ' + subject + '\n')
        paths = ['packages/core/src/signals/config.ts',
                 'packages/mod-kernel/src/scoped-config-store.ts',
                 'packages/mod-kernel/src/index.ts',
                 'tests/unit/modular-config-store.test.ts']
        prompt += subprocess.run(['git', 'diff', '64ecbc42', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in paths[:2] + ['tests/unit/config-memo.test.ts',
                                     'packages/core/src/models/errors.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'engine-settings-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '0f0b677f43dff9f896971689467fc6470b5d2839'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Engine settings subject changed')
        prompt = ('Independent bounded code review. No tools. Physical owner extraction of '
                  '13 existing config settings assigned by the frozen ownership ledger to '
                  'support-engine-runtime. Move exact field types, defaults, normalization. '
                  'Core AgonConfig extends the public owned type and composes defaults by '
                  'individual field references to preserve key order; no new package edge. '
                  'Other eight config owners and host adapters remain unfinished. Compare '
                  'behavior, optional/required types, default identity/order, normalization, '
                  'public boundary and test oracles. Do not turn inherited behavior into '
                  'scope expansion or certify release acceptance. Subject ' + subject + '\n')
        paths = ['packages/core/src/models/types.ts', 'packages/core/src/signals/config.ts',
                 'packages/support-engine-runtime/src/engine-settings.ts',
                 'packages/support-engine-runtime/src/index.ts',
                 'tests/unit/modular-engine-settings.test.ts']
        prompt += subprocess.run(['git', 'diff', 'fb77dc97', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in paths:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nPLANNED ADDITIONAL PARITY CHECK\n' + (output / 'engine-settings-parity.mjs').read_text()
    if review_id == 'shared-settings-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'a066bd92fd867e8c3cb3b5fbd9563676d440bd9e'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Shared settings subject changed')
        prompt = ('Independent bounded review. No tools. Move 99 existing configuration '
                  'field types/defaults to frozen owners: Kernel 92, persistence 6, browser '
                  'bridge 1. These exact owner assignments are already accepted requirements; '
                  'do not silently reassign fields by taste. Existing Core dependency edges '
                  'only. Core preserves AgonConfig and DEFAULT_AGON_CONFIG with individual '
                  'field references to retain key order. Nine user-mod fields remain in Core '
                  'and are NOT declared extracted. Move existing normalization and permission '
                  'aggregation unchanged to Kernel/browser, retaining engine-owner delegation. '
                  'Check actual behavior, public type/default parity, scope permissions, cycles, '
                  'unnecessary abstraction and test evidence. Default comparison against old '
                  'Git object and fresh built Core will run after full build. Do not certify '
                  'full config namespaces, host retirement or release. Subject ' + subject + '\n')
        paths = ['packages/core/src/models/types.ts', 'packages/core/src/signals/config.ts',
                 'packages/mod-kernel/src/settings.ts', 'packages/mod-kernel/src/index.ts',
                 'packages/support-persistence/src/settings.ts', 'packages/support-persistence/src/index.ts',
                 'packages/support-browser-bridge/src/settings.ts', 'packages/support-browser-bridge/src/index.ts',
                 'tests/unit/modular-shared-settings.test.ts']
        prompt += subprocess.run(['git', 'diff', '0f92bff3', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [paths[1], paths[2], paths[4], paths[6], paths[8]]:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nPENDING INDEPENDENT BASELINE CHECK\n' + (output / 'shared-settings-parity.mjs').read_text()
    if review_id == 'tui-settings-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '4917266ec5c486ff3032aee4dccd93a28da56f2c'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('TUI settings subject changed')
        prompt = ('Independent bounded review. No tools. Fix both TUI invocation paths that '
                  'currently pass the entire host configuration to mods. The accepted runtime '
                  'contract assigns each mod a canonical-ID namespace. Select config.mods[owner.id] '
                  'only; absent owner/settings means empty, never host fallback. Snapshot deeply '
                  'and reject malformed selected JSON. This is data minimization, NOT sandboxing '
                  'or authorization. Full-code trust remains full-code trust. CLI/MCP/Cesar '
                  'transport, scoped namespace merging, owner schemas/defaults and migrations '
                  'are still pending separate original-goal work, NOT certified by this fix. '
                  'Check concrete regressions, unnecessary machinery, mutable/inherited data, '
                  'both dispatch tests and real first-party behavior. First-party services retain '
                  'their existing config injection. Do not certify the whole release. Tree ' + subject + '\n')
        paths = ['packages/mod-kernel/src/mod-settings.ts', 'packages/mod-kernel/src/index.ts',
                 'packages/cli/src/signals/dispatch/intent-session.ts',
                 'tests/unit/modular-brainstorm-slash-session.test.ts']
        prompt += subprocess.run(['git', 'diff', '77d6b300', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [paths[0], paths[2], paths[3], 'packages/cli/src/blocks/brainstorm-session.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'mod-settings-transport':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '177e402cb2f983b96c86ab24bb7ff050792ff2cf'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Mod settings transport subject changed')
        prompt = ('Independent bounded review. No tools. Complete owner-only namespace '
                  'transport through generated CLI, MCP, Cesar tool and Cesar route execution. '
                  'TUI already uses selectModSettings from the previous accepted increment. '
                  'Reuse existing Core/Kernel scoped config store, merging mods by owner and '
                  'top-level setting field in global/project/private order. Nested fields replace, '
                  'not deep merge. Unknown/inactive namespace values remain data without activation; '
                  'selected malformed data fails. No new dependencies or config store. Public '
                  '121 legacy types/defaults remain unchanged. Authority checks must precede '
                  'execution; settings never grant trust or activate code. Schema/default/migration '
                  'completion remains explicitly OPEN, not certified here. Check concrete defects, '
                  'missing controls, ownership, performance/import cycles and excessive machinery. '
                  'The selector blacklist/depth bound follows frozen security requirements; '
                  'do not remove those by taste. This is not sandboxing. Subject ' + subject + '\n')
        paths = ['packages/mod-kernel/src/mod-settings.ts', 'packages/mod-kernel/src/index.ts',
                 'packages/core/src/signals/config.ts', 'packages/cli/src/lazy-commands.ts',
                 'packages/cli/src/surface-authority-runtime.ts', 'packages/cli/src/cesar/tools.ts',
                 'packages/mcp/src/surface-authority.ts', 'tests/unit/modular-config-store.test.ts',
                 'tests/unit/modular-external-surfaces.test.ts']
        prompt += subprocess.run(['git', 'diff', 'a3ebba91', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [paths[0], paths[2], paths[6], paths[7], paths[8], 'packages/mod-kernel/src/scoped-config-store.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'mod-settings-schema':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '13247c7bcd3d618052d56000175991b0c9b0e2e2'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Mod settings schema subject changed')
        prompt = ('Independent bounded review. No tools. Verify owner-registered settings '
                  'schemas/defaults at the existing registry execution boundary. Preserve sync, '
                  'async, streaming shapes, signal identity and owner-only settings; reject '
                  'disposed records. No persistence or activation changes, no public signature '
                  'changes. All six executable contribution kinds use the same wrapper. '
                  'Existing schema validator is authoritative. Check correctness, default '
                  'conflicts, legacy compatibility, leaks, missing controls and proportionality. '
                  'Concrete first-party schemas and migration lifecycle are separate unfinished '
                  'requirements; do not certify the release. Security key/depth limits are frozen '
                  'requirements, not optional taste. Focused tests pass. Subject ' + subject + '\n')
        paths = ['packages/mod-kernel/src/mod-settings.ts', 'packages/mod-kernel/src/registry.ts',
                 'tests/unit/modular-registry.test.ts', 'tests/unit/modular-external-surfaces.test.ts']
        prompt += subprocess.run(['git', 'diff', 'f01298af', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [*paths[:2], 'packages/mod-kernel/src/json-schema-input.ts',
                         'packages/mod-api/src/index.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'migration-source-preservation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '331365c422b5f230ccdb4917d52298edf08b859a'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Migration source preservation subject changed')
        prompt = ('Independent bounded review. No tools. Existing staged-copy migration '
                  'engine overwrote its source with a success receipt when stagedPath equals '
                  'sourcePath; a failing callback deleted that same source in cleanup. Both '
                  'reproduced. Repair reserves previously absent output using injected IO '
                  'exclusive write before callbacks; failed reservations cannot perform cleanup. '
                  'Preserve normal staged output, byte-exact source, typed failures and current '
                  'public API. Tests cover direct aliases, symlinked parent aliases, preexisting '
                  'data and two writers. No new IO interface, dependency or migration store. '
                  'The engine still needs lifecycle integration as a separate original requirement. '
                  'Assess concrete correctness, failure cleanup, regressions, proportionality. '
                  'Full-code callbacks are trusted, not sandboxed. Do not certify release. '
                  'Subject ' + subject + '\n')
        paths = ['packages/mod-kernel/src/migration-engine.ts', 'tests/unit/modular-migration-engine.test.ts']
        prompt += subprocess.run(['git', 'diff', '86a87d82', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [*paths, 'packages/mod-kernel/src/host-io.ts', 'tests/unit/modular-release-state-migrations.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'lifecycle-commit-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '33c63a66ab4c19a0cd7c418d05e91c95ba77c729'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Lifecycle commit boundary subject changed')
        prompt = ('Independent bounded review. No tools. Verify transaction commit-point and '
                  'cleanup repair. Reproduced: nested host commits then throws, outer installer '
                  'deletes selected prefix; pointer rename succeeds but fsync fails before committed '
                  'flag; rollback has same classification error; prefix rename succeeds but freeze '
                  'fails before promoted flag. Fixes reread canonical pointer, preserve unknown '
                  'outcomes for existing recovery, verify generation/installation ownership before '
                  'prefix cleanup, and acknowledge prefix rename before freeze. Tests cover before/'
                  'after rename with unreadable pointer, fresh-host recovery, rollback/re-entry, '
                  'preexisting fault cases and freeze failure. No new dependencies, store or API. '
                  'Assess false-green risks, races, destructive cleanup, journals, release safety '
                  'and simplicity. Treat findings as hypotheses with exact reachable scenarios. '
                  'Config migrations remain unconnected; do not certify whole release. Subject '
                  + subject + '\n')
        paths = ['packages/mod-kernel/src/durable-host.ts', 'packages/mod-kernel/src/managed-lifecycle.ts',
                 'packages/mod-kernel/src/host-rollback.ts']
        prompt += subprocess.run(['git', 'diff', '23876c9d', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [*paths, 'packages/mod-kernel/src/host-io.ts', 'packages/mod-kernel/src/lifecycle-recovery.ts',
                         'tests/unit/modular-lifecycle-fault-injection.test.ts', 'tests/unit/modular-rollback.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-settings-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '2a1f7427797fb6ec90ee7f5c8f3f6ada558340fc'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Forge settings owner subject changed')
        prompt = ('Independent bounded review. No tools. Extract two legacy Forge settings '
                  'to its existing static configuration schema. Existing package generator now '
                  'reads owner-authored schemas and emits Core compatibility types/defaults '
                  'only for properties assigned by the frozen ownership ledger. No new dependency '
                  'or runtime Core-to-Forge import. Keep exact old optional types/default values '
                  'and order. Forge registers this schema without the resource identity $id '
                  'annotation. Defaults/validation now apply at existing registry execution '
                  'boundary. Seven other mod fields, namespace-to-flat compatibility precedence '
                  'and durable versioned migration remain explicitly unfinished. Review '
                  'ownership, build/pack/drift correctness, safety, simplicity and missing '
                  'negative controls. Do not certify whole release. Subject ' + subject + '\n')
        paths = ['scripts/spec/generate-modular-first-party-packages.mjs',
                 'packages/mod-forge/schemas/config.schema.json', 'packages/mod-forge/agon.mod.json',
                 'packages/mod-forge/src/implementation.ts', 'packages/core/src/models/types.ts',
                 'packages/core/src/models/first-party-settings.generated.ts', 'tests/unit/modular-forge-settings.test.ts']
        prompt += subprocess.run(['git', 'diff', 'fe6e6c8e', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [paths[0], paths[1], paths[5], paths[6], 'packages/mod-kernel/src/mod-settings.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'remaining-settings-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '9cbbf0de8ad62d0582655207662d31c247e0bc47'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Remaining settings owner subject changed')
        prompt = ('Independent bounded review. No tools. Continue the verified Forge settings '
                  'extraction pattern for Review, Agent, Mutate and Synthesis (seven fields). '
                  'Existing owner schemas author types/defaults; existing generator produces '
                  'Core static compatibility data without importing mod runtime. All nine mod-owned '
                  'fields are now represented. Preserve 121-field optional public types, defaults '
                  'and key order. Existing config registrations now use owner schemas without $id. '
                  'Check exact type/default parity, all registration sites, duplicate ownership, '
                  'array-default aliasing, schema semantics and tests. No dependency/API additions. '
                  'Namespace-to-flat precedence and durable migration are still unfinished and '
                  'are not claimed. Report only source-grounded defects and necessary tests. '
                  'Do not certify release. Subject ' + subject + '\n')
        paths = ['packages/core/src/models/types.ts', 'packages/core/src/models/first-party-settings.generated.ts',
                 'tests/unit/modular-forge-settings.test.ts']
        for name in ['review', 'agent', 'mutate', 'synthesis']:
            paths.extend([f'packages/mod-{name}/schemas/config.schema.json', f'packages/mod-{name}/src/implementation.ts'])
        prompt += subprocess.run(['git', 'diff', 'ac4b6dd0', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [*paths[:3], 'scripts/spec/generate-modular-first-party-packages.mjs', 'packages/mod-kernel/src/mod-settings.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'settings-alias-bridge':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'e3880793e88dd411816ff84d2d5287418f3c59fa'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Settings alias bridge subject changed')
        prompt = ('Independent bounded review. No tools. Connect existing flat legacy mod settings '
                  'to canonical mod namespaces for nine owner-assigned fields. Project each '
                  'global/project/private layer before merging: explicit namespace beats same-layer '
                  'flat alias, higher-priority scope wins regardless of spelling. Unknown/inactive '
                  'namespaces remain data; no activation or trust changes. Existing config store adds '
                  'an optional owner write-policy callback inside its existing lock/atomic rename. '
                  'Core updates alias and namespace together and refuses malformed selected namespace. '
                  'No new store/cache/dependency. Check precedence, mutation, cache behavior, '
                  'permission boundaries, unknown retention, compatibility, errors and negative controls. '
                  'Frozen public defaults/types must remain unchanged. Durable versioned migration '
                  'is still unfinished, not claimed here. Do not certify release. Subject ' + subject + '\n')
        paths = ['packages/core/src/models/first-party-settings.generated.ts', 'packages/core/src/signals/config.ts',
                 'packages/mod-kernel/src/scoped-config-store.ts', 'scripts/spec/generate-modular-first-party-packages.mjs',
                 'tests/unit/modular-config-store.test.ts']
        prompt += subprocess.run(['git', 'diff', '257fb2df', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [*paths[:3], paths[4], 'packages/mod-kernel/src/mod-settings.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'activation-artifact-retention':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'e80f959ed31b1ace88791fff9d7a34142f1156d8'
        actual = subprocess.run(['git', 'write-tree'], cwd=qualified,
                                capture_output=True, text=True, check=True).stdout.strip()
        if actual != subject:
            raise RuntimeError('Activation artifact retention subject changed')
        prompt = ('Independent bounded review. No tools. Review two reproduced defects in the '
                  'existing durable activation path. First-party enable/disable previously retained '
                  'installation.json only and dropped other immutable generation files. Now copy '
                  'all declared validated artifacts byte-for-byte except host-regenerated lock, '
                  'desired state and index. Preserve missing installation descriptor refusal. '
                  'Second, rollback followed by apply failed because selected+1 already existed. '
                  'Under the existing writer fence allocate above all retained canonical generation '
                  'numbers, including incomplete entries. Keep selected-generation CAS. No new '
                  'API/dependency. Check crash/recovery, stale plans, retention, integrity, source '
                  'mutation, concurrency, integer limits and meaningful controls. Source tests '
                  'reproduced both failures. Full config migration and release remain unfinished. '
                  'Do not certify the release. Subject ' + subject + '\n')
        paths = ['packages/mod-kernel/src/first-party-activation.ts', 'packages/mod-kernel/src/durable-host.ts',
                 'tests/unit/modular-first-party-activation-matrix.test.ts', 'tests/unit/modular-rollback.test.ts']
        prompt += subprocess.run(['git', 'diff', 'ddf4b761', subject, '--', *paths],
                                 cwd=qualified, capture_output=True, text=True, check=True).stdout
        for relative in [*paths, 'packages/mod-kernel/src/activation-service.ts', 'packages/mod-kernel/src/host-rollback.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'durable-config-design':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'c2b4c115e47277b448705c74409061abff3f62ea'
        prompt = ('Bounded architecture review of the next original Modular Agon requirement. '
                  'No tools. Compare alternatives symmetrically, do not assume the proposed overlay '
                  'is correct. Need implement durable versioned mod settings migration, not another '
                  'untouched helper. Runtime contract: each mod owns schema/defaults/pure versioned '
                  'migrations; declarative migrations run on staged copies; immutable generation '
                  'includes outputs; one atomic generation pointer; rollback restores previous schema '
                  'snapshot; source backups/unknown/disabled namespaces retained; no destructive down '
                  'migration. Existing synchronous Core loadConfig/configSet API and three-scope '
                  'precedence must remain. No new dependencies. Kernel cannot import Core/support '
                  'because of the graph. Global/personal installs prohibited in this development task. '
                  'All tests use isolated roots. Current migrateStagedCopy has no production caller. '
                  'Schemas/defaults and nine flat-to-mod namespace aliases are implemented; setup and '
                  'actual config readers still lack durable migration. Existing config lock is a '
                  'synchronous support-persistence callback with TTL reclaim, different from async '
                  'Kernel WriterFence. Do not suggest sharing their path or holding that short lock '
                  'over asynchronous staging. Current host now preserves retained artifacts on '
                  'enable/disable and allocates above retained generations after rollback. '
                  'A) materialize migrated snapshots at legacy config path; B) select immutable '
                  'base plus generation/version-bound mutable edits through existing generation '
                  'pointer; C) a genuinely simpler existing-mechanism option if justified. '
                  'Trace ordinary read/write, update, failure before/after pointer switch, concurrent '
                  'user edit, stale host, rollback with newer edits retained, enable/disable and '
                  'legacy downgrade. Distinguish config schema snapshot from current values. '
                  'Recommend smallest full vertical implementation, concrete file/contract changes '
                  'and discriminating acceptance tests. Identify genuine product questions versus '
                  'locally decidable engineering choices. Do not certify current release or propose '
                  'future-only scaffold. Label source facts versus inferences. Subject ' + subject + '\n')
        selections = {
            'packages/mod-kernel/src/scoped-config-store.ts': None,
            'packages/mod-kernel/src/migration-engine.ts': None,
            'packages/core/src/signals/config.ts': (1, 117),
            'packages/mod-kernel/src/durable-host.ts': (309, 424),
            'packages/mod-kernel/src/managed-lifecycle.ts': (115, 170),
            'packages/cli/src/commands/setup.ts': (40, 86),
            'packages/mod-kernel/src/host-rollback.ts': (64, 87),
            'packages/mod-api/src/manifest.ts': (30, 80),
            'packages/mod-api/src/index.ts': (135, 148),
        }
        for relative, lines in selections.items():
            content = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                     capture_output=True, text=True, check=True).stdout
            if lines:
                content = '\n'.join(content.splitlines()[lines[0] - 1:lines[1]])
            prompt += '\nSOURCE ' + relative + ' ' + str(lines or 'complete') + '\n' + content
    if review_id == 'setup-selected-state':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '51c1b7dfb915d617b723184059e7582d759c8e6d'
        prompt = ('Independent bounded code review. No tools. Check setup/update selection authority. '
                  'Immutable generation selected by current pointer is authoritative; mutable desired '
                  'mirror may be stale/missing after a committed rollback fault. Change reads/hash-checks '
                  'the selected desired artifact, rejects selection changes before planning and binds '
                  'plan base hash; removes catch-all treating a corrupt install as missing; --plan '
                  'must not write stable launcher on already installed matching selection. Existing '
                  'managed service enforces plan hash under fence on apply. Tests use real host and '
                  'fixture-only installer, no npm/provider operations. Source test redirects only '
                  'bundled release-channel path to the same tracked input. Find concrete regressions '
                  'and missing tests; distinguish inherited defects. Durable mod-settings migration '
                  'is still unfinished, not claimed complete. Frozen tree ' + subject + '\n')
        for relative, bounds in {
            'packages/cli/src/commands/setup.ts': None,
            'tests/unit/modular-setup-selection.test.ts': None,
            'packages/mod-kernel/src/managed-lifecycle.ts': (350, 405),
        }.items():
            content = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                     capture_output=True, text=True, check=True).stdout
            if bounds:
                content = '\n'.join(content.splitlines()[bounds[0] - 1:bounds[1]])
            prompt += '\nSOURCE ' + relative + '\n' + content
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'c2b4c115', subject, '--',
            'packages/cli/src/commands/setup.ts'], cwd=qualified, capture_output=True,
            text=True, check=True).stdout
    if review_id == 'selected-desired-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'dd1eb5782f6c9b15056dd917198599f5c310480f'
        prompt = ('Independent review of a newly traced shared authority boundary. No tools. '
                  'Initial setup-only fix was reviewed separately; actual CLI probe then showed '
                  'startup, activation and management UI also treated mutable desired-state mirror '
                  'as authority. They now consume generation-bound desired bytes through one host '
                  'method. This review covers that expanded production boundary, not another panel '
                  'for fixes to the initial setup review. Required: preserve disabled enforcement, '
                  'stale-host rejection, recovery, safe mode and pristine bootstrap. Mirrors may be '
                  'stale/missing/corrupt after commit. Verify exact bytes, pointer consistency and '
                  'all consumers. Tests include stale/missing/malformed mirrors on five surfaces; '
                  'real bundled CLI setup/update and mod list passed six isolated processes after '
                  'showing both earlier failures. No real npm installs/providers used. Full suite '
                  '8584 passed/6 skipped before final management fix; performance cold start red '
                  '(186.6ms vs185ms), retained not waived. Do not certify release. Concrete findings '
                  'only; distinguish source facts from assumptions. Frozen tree ' + subject + '\n')
        for relative, bounds in {
            'packages/mod-kernel/src/durable-host.ts': (205, 250),
            'packages/mod-kernel/src/activation-service.ts': None,
            'packages/mod-kernel/src/first-party-surface-bootstrap.ts': (45, 112),
            'packages/cli/src/commands/setup.ts': (35, 104),
            'packages/cli/src/commands/mod.ts': (105, 153),
            'tests/unit/modular-production-surface-bootstrap.test.ts': None,
            'tests/unit/modular-setup-selection.test.ts': None,
        }.items():
            content = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                     capture_output=True, text=True, check=True).stdout
            if bounds:
                content = '\n'.join(content.splitlines()[bounds[0] - 1:bounds[1]])
            prompt += '\nSOURCE ' + relative + '\n' + content
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'c2b4c115', subject, '--',
            'packages/mod-kernel/src', 'packages/cli/src/commands/mod.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'config-publication-fence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'fa4f53e96fa37aff41ebe40e03352581bd5e288e'
        prompt = ('Independent bounded concurrency/compatibility review. No tools. Agon configSet '
                  'must stay synchronous; durable host commit/rollback/recovery use existing async '
                  'WriterFence on hostRoot/locks/writer.json. New sync client shares record creation '
                  'and ownership checks with async WriterFence, not the incompatible legacy TTL '
                  'config lock. Core composes existing config lock outside sync host fence. All '
                  'writes participate even before first install, so first config write may create '
                  'host locks directory (no pointer/desired/trust/install created). Dynamic AGON_HOME '
                  'and AGON_MODULAR_HOST_ROOT supported. Busy lock refuses write with source bytes '
                  'unchanged. Tests 38 pass; real built Core writes failed exclusion before and now '
                  'pass during actual host after-lock fault hook. Separate diagnostic processes proved '
                  'same-record-protocol exclusion, no TTL reclaim and killed-owner recovery. '
                  'Find concrete regressions in ownership, errors, crashes, lock order, asynchronous '
                  'API compatibility and missing tests. This is a used production prerequisite, not '
                  'a claim that versioned config migration is implemented. Default reviewers only, '
                  'no release certification. Frozen tree ' + subject + '\n')
        for relative in ['packages/mod-kernel/src/writer-lock.ts', 'packages/core/src/signals/config.ts',
                         'tests/unit/modular-writer-lock-safety.test.ts', 'tests/unit/modular-config-store.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(['git', 'show', subject + ':' + relative],
                cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '6f252733', subject, '--',
            'packages/mod-kernel/src/writer-lock.ts', 'packages/mod-kernel/src/index.ts',
            'packages/core/src/signals/config.ts'], cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'config-source-revision':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '9da1556471a0eca9115516281453f7838fa5d787'
        prompt = ('Independent bounded review; no tools. Find concrete defects in config-source '
                  'revision binding through actual setup preview, hashed lifecycle plan and host '
                  'publication. Frozen tree ' + subject + '. Core configSet already participates '
                  'in the same host writer fence. Optional source revision preserves non-config '
                  'lifecycle callers; actual setup always supplies one. Missing file is distinct '
                  'from empty file; unreadable is an error. Existing source-change reproductions '
                  'failed before the fix and now 54 focused tests pass. Check early/late mutation, '
                  'plan binding, cleanup, rollback, compatibility, missed integration and tests. '
                  'This prerequisite does NOT claim durable versioned settings snapshots, migration '
                  'outputs or selected-generation config readers are implemented. Do not invent '
                  'those as regressions; they remain required follow-up. Arbitrary external editors '
                  'do not obey the fence; final hash check is not an OS-wide compare-and-swap. '
                  'No new dependencies, installs or personal-state operations.\n')
        for relative, start, end in [
            ('packages/mod-kernel/src/migration-engine.ts', 1, 170),
            ('packages/mod-kernel/src/durable-host.ts', 322, 477),
            ('packages/mod-kernel/src/managed-lifecycle.ts', 494, 680),
            ('packages/cli/src/commands/setup.ts', 1, 103),
        ]:
            source = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                    capture_output=True, text=True, check=True).stdout
            prompt += f'\nSOURCE {relative}:{start}-{end}\n' + '\n'.join(source.splitlines()[start - 1:end])
        prompt += '\nCOMPLETE CHANGE\n' + subprocess.run(
            ['git', 'diff', '72f50bee', subject], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'durable-config-integration':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'd7562383518cc29e9cefbd5e754b70c470e2b2e8'
        prompt = ('Bounded implementation-design review, no tools. Need a concrete smallest vertical '
                  'implementation of the EXISTING durable modular config migration contract. Do not '
                  'propose more scaffolding-only prerequisites. Current committed source ' + subject + '. '
                  'Already implemented: static owner JSON schemas/defaults for all 121 legacy fields; '
                  'nine user-mod aliases projected per sparse global/project/private layer, with '
                  'atomic flat/namespaced writes; owner schema/default validation at invocation; '
                  'synchronous Core writes share existing async host WriterFence; setup plans bind '
                  'global config path/hash, host checks under the fence, lifecycle snapshots plans. '
                  'Still absent: production migrateStagedCopy caller, declarative owner migration '
                  'descriptor, immutable selected settings outputs, schema-aware normal writes and '
                  'rollback. Setup currently emits installation.json only. Activation already copies '
                  'every immutable generation artifact.\n'
                  'Requirements: keep sync configSet and existing commands/defaults; preserve unknown '
                  'and disabled namespaces, source backups and later edits; pure/declarative migrations '
                  'without importing disabled mod code; static discovery; source-hashed plans; one '
                  'generation pointer, pinned old invocations; rollback prior schema without deleting '
                  'newer edits; project/private files remain sparse and directly editable; preserve '
                  'security semantics, immediate permission/grant revocation, no stale permissions '
                  'pinned to old mod schemas. Global config.json is also directly editable now. '
                  '69 package files contain loadConfig calls, including legacy workflows beneath '
                  'new registry routes. Guard/permission readers also access legacy config.json. '
                  'No dependency installs, new active/global state, or silent scope reduction.\n'
                  'Earlier review preferred immutable generation config base plus schema-bound '
                  'mutable edits. Resolve its concrete ambiguity: how do direct edits to global '
                  'config.json, new project files, rollback, old pinned jobs and security settings '
                  'coexist without two independent authorities, lost edits or forced generation '
                  'creation for every project read? Compare against materializing legacy config '
                  'under the existing transaction. Give a file/record layout, precise read/write/'
                  'migration/rollback rules and a dependency-ordered vertical implementation path. '
                  'State any unavoidable behavior trade-off; do not invent product requirements or '
                  'claim arbitrary external editors obey locks. Distinguish source facts and design '
                  'inferences. Prefer reuse of existing owners and minimal public API changes.\n')
        for relative, start, end in [
            ('packages/mod-kernel/src/scoped-config-store.ts', 1, 150),
            ('packages/core/src/signals/config.ts', 1, 127),
            ('packages/mod-kernel/src/migration-engine.ts', 1, 175),
            ('packages/mod-kernel/src/managed-lifecycle.ts', 110, 178),
            ('packages/mod-kernel/src/managed-lifecycle.ts', 495, 625),
            ('packages/mod-kernel/src/durable-host.ts', 320, 430),
            ('packages/mod-kernel/src/host-rollback.ts', 1, 135),
            ('packages/cli/src/commands/setup.ts', 1, 104),
            ('packages/mod-kernel/src/mod-settings.ts', 1, 130),
            ('packages/mod-api/src/index.ts', 38, 54),
            ('packages/mod-api/src/index.ts', 125, 150),
            ('packages/mod-kernel/src/registry.ts', 287, 308),
            ('packages/cli/src/surface-authority-runtime.ts', 206, 236),
            ('docs/specs/modular-agon-runtime-contract.md', 224, 248),
            ('docs/specs/modular-agon-runtime-contract.md', 403, 420),
            ('docs/specs/modular-agon-security-and-distribution.md', 286, 309),
        ]:
            source = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                    capture_output=True, text=True, check=True).stdout
            prompt += f'\nSOURCE {relative}:{start}-{end}\n' + '\n'.join(source.splitlines()[start - 1:end])
    if review_id == 'config-staging-qualified':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'de9a0c504d78ecd19c540ec9b9344a840694dca8'
        prompt = ('Independent code review, no tools. Frozen tree ' + subject +
                  ', baseline d7562383. Review this INCOMPLETE durable configuration integration. '
                  'Find reachable defects, compatibility regressions, data loss, unsafe boundaries, '
                  'unnecessary machinery and weak tests. Prior completed pieces include source-hashed '
                  'plans, synchronous config writes sharing the host fence, immutable generation '
                  'artifacts, artifact-preserving activation and rollback. New change: strict writes '
                  'refuse malformed config; content-hash read cache; existing alias projection moved '
                  'to Kernel and reused for declarative staged migration; five owner schemas declare '
                  'nine aliases; plan-bound static manifest/schema verification before migration; '
                  'staged outputs/backups/receipts published in the generation; checked asynchronous '
                  'generation artifact/config reader; setup static verification and idempotence fixes. '
                  'No mod code executes for migration. Only legacy representation 0 to version 1 is '
                  'implemented; forward arbitrary representation versions, normal synchronous Core '
                  'reads under selected rules, invocation snapshots, and full runtime-file tarball '
                  'integrity remain required follow-up, NOT completed claims. Source config remains '
                  'editable and migration never replaces it. Existing tests proved timestamp stale '
                  'reads, malformed-write data loss, static tamper acceptance and false setup shortcuts; '
                  'mutation controls remove staging/shortcut checks and fail. Real built Kernel copied '
                  'the actual Forge pack-listed files into an isolated fixture and published two '
                  'generations, then rolled back without overwriting later source edits. No install '
                  'or provider execution in these tests. Review the supplied diff and integration '
                  'seams, do not certify the whole release. Report exact source locations and '
                  'minimal corrections. No unrelated style changes or new dependencies.\n')
        for relative in [
            'packages/mod-kernel/src/configuration-migration.ts',
            'packages/mod-kernel/src/mod-settings.ts',
            'packages/mod-kernel/src/scoped-config-store.ts',
            'packages/cli/src/commands/setup.ts',
            'packages/mod-kernel/src/migration-engine.ts',
        ]:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        for relative, start, end in [
            ('packages/mod-kernel/src/durable-host.ts', 230, 272),
            ('packages/mod-kernel/src/managed-lifecycle.ts', 493, 701),
        ]:
            source = subprocess.run(['git', 'show', subject + ':' + relative], cwd=qualified,
                                    capture_output=True, text=True, check=True).stdout
            prompt += f'\nSOURCE {relative}:{start}-{end}\n' + '\n'.join(source.splitlines()[start - 1:end])
        prompt += '\nCOMPLETE DIFF\n' + subprocess.run(['git', 'diff', 'd7562383', subject],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'config-lazy-startup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = 'ae6aa9409032d76958204df798bd6270a762fd96'
        paths = ['packages/cli/src/lazy-commands.ts', 'packages/cli/src/surface-authority-runtime.ts',
                 'tests/unit/modular-surface-cutover.test.ts']
        prompt = ('Independent bounded review. No tools. Frozen tree ' + subject +
                  '. Review only this startup repair: two eager Core imports become dynamic at '
                  'existing async execution boundaries. Cesar rechecks generation after the new '
                  'await; CLI already rechecks before contribution execution. All existing behavior '
                  'must remain, including disabled/stale-mod refusal, nested CLI commands, streams, '
                  'config scope, error propagation and jobs. Tests prevent Core loading for metadata '
                  'and fail if both old eager imports are restored. 65 dispatch tests passed; '
                  '21 surface/jobs regressions passed. Startup p95 reduced from about 200-213 ms '
                  'to 128-135 ms (185 ms limit). One TUI timing sample failed at 14.17 ms, later '
                  '11.63 ms passed under the unchanged 12 ms limit. Do not certify performance '
                  'or the release from those samples. Report concrete new defects or meaningful '
                  'missing regression cases, not unrelated style changes. The surrounding config '
                  'migration work is separately reviewed and not the subject of this review.\n')
        for relative in paths:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'd7562383', subject, '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'config-generation-reader':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '2e3a14cb1f6e8e53f90afbfdcc43778a6621a6e1'
        prompt = ('Independent bounded code review. No tools. Frozen tree ' + subject +
                  ', baseline 3927c3ff. Review selected-generation config reads/writes. '
                  'Core previously ignored selected schema defaults. It now uses a synchronous '
                  'checked generation reader, sharing content validation with DurableModHost, '
                  'and applies owner defaults after sparse source merging. Writes validate the '
                  'affected owner under the existing writer fence. Editable source remains '
                  'authoritative for values; rollback selects old interpretation without deleting '
                  'edits. Permissions remain live; safe mode bypasses mod configuration. '
                  'No cache or secondary selection authority added. Full suite 8671 passed, '
                  '6 skipped, eight performance gates green before seven extra corruption controls '
                  '(also green). Built-runtime probe covers two generations, rollback, invalid/valid '
                  'writes, direct edits, permission revocation, sparse overrides and safe mode. '
                  '1000 fixture-host reads p95 about 0.30 ms. Inspect data loss, scope, schema '
                  'defaults/validation, corruption, races, disabled/unknown data, API compatibility, '
                  'unnecessary duplication and meaningful missing controls. Invocation-generation '
                  'binding across nested calls/streams remains incomplete follow-up, not a claim '
                  'of completion. Full install/distribution integrity also remains unfinished. '
                  'Do not certify the whole release. Report concrete defects with locations and '
                  'counterexamples; distinguish new regressions from inherited behavior.\n')
        paths = ['packages/core/src/signals/config.ts', 'packages/mod-kernel/src/configuration-migration.ts',
                 'packages/mod-kernel/src/host-contracts.ts', 'packages/mod-kernel/src/mod-settings.ts',
                 'packages/mod-kernel/src/scoped-config-store.ts', 'tests/unit/modular-generation-settings.test.ts',
                 'tests/unit/modular-host-corruption.test.ts']
        for relative in paths:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nCOMPLETE DIFF\n' + subprocess.run(['git', 'diff', '3927c3ff', subject],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'config-invocation-scope':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '77563ad66782fe09b680f4fb685fdff42e757372'
        prompt = ('Independent bounded review. No tools. Frozen tree ' + subject +
                  ', baseline c4791ce0. Review invocation configuration generation binding. '
                  'A built registry command reproduced old context default 91 but new nested Core '
                  'read 137 after a durable generation switch. Kernel now supplies bootstrap-selected '
                  'immutable owner rules to registry calls through AsyncLocalStorage, including '
                  'promises and lazy iterators. Core reads current sparse values under those rules; '
                  'permissions remain live and writes validate current selected rules. No dependency '
                  'or second activation pointer. Legacy boot carries explicit empty rules. '
                  'Focused tests cover concurrent iterators, completion/return/throw, promises, '
                  'source mutation isolation and actual Cesar-to-Brainstorm dispatch using fixture '
                  'engines. Built probe now reads 91 inside and 137 outside with revoked permissions '
                  'visible inside. Out-of-process job binding, future representation migrations and '
                  'full install integrity remain unfinished; do not certify the whole release. '
                  'Find concrete new defects, compatibility changes, unsupported machinery or missing '
                  'meaningful controls. Check cleanup, scope leakage, stale settings/security and '
                  'bootstrap identity. Report exact counterexamples, not style preferences.\n')
        paths = ['packages/mod-kernel/src/configuration-scope.ts', 'packages/mod-kernel/src/registry.ts',
                 'packages/mod-kernel/src/first-party-surface-bootstrap.ts',
                 'packages/mod-kernel/src/configuration-migration.ts', 'packages/core/src/signals/config.ts',
                 'tests/unit/modular-registry.test.ts', 'tests/unit/modular-cesar-lazy-authority.test.ts']
        for relative in paths:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nCOMPLETE DIFF\n' + subprocess.run(['git', 'diff', 'c4791ce0', subject],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'job-generation-leases':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '075f1c717e1a002508762b567f6196ecd76fc1e6'
        prompt = ('Independent bounded review. No tools. Frozen Git tree ' + subject +
                  ', baseline 90d91e28. Job and Plan invocation wrappers previously never acquired '
                  'a generation lease. Three regression cases observed zero leases during run and '
                  'cleanup. Concurrent kernel acquisitions rejected seven of eight jobs. Changes '
                  'connect the existing durable lease owner to the invocation wrapper and bound '
                  'writer contention waits at five seconds without reclaiming any lock. Cleanup '
                  'errors are no longer swallowed in the store. 150 focused tests, types and lint '
                  'pass with provider shims. Inspect correctness, concurrency, cancellation, cleanup, '
                  'false success, overhead and missing negative controls. Explicit unfinished work: '
                  'child-process generation handshake, qualified prefix verification, lease-aware '
                  'artifact retention, full release qualification. Do not certify the whole product. '
                  'Report concrete findings with counterexamples, not stylistic preferences.\n')
        paths = ['packages/cli/src/surface-authority-runtime.ts',
                 'packages/mod-kernel/src/generation-leases.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'packages/mod-kernel/src/host-io.ts',
                 'tests/unit/modular-generation-leases.test.ts']
        for relative in paths:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nCOMPLETE DIFF\n' + subprocess.run(['git', 'diff', '90d91e28', subject],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'tui-local-pause':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review only this TUI performance fix. '
                  'The release typing gate failed at p95 13.83ms against an unchanged 12ms budget. '
                  'A diagnostic omission of whole-App typing-pause state reduced it to 6.76ms, '
                  'but omission was not accepted because it removed behavior. This fix moves '
                  'the existing 350ms cosmetic pause and snippet suppression to BottomChromeSection. '
                  'Input handling stays in App and gets called before the local pause update. '
                  'A behavioral test covers reset, latest snippet restoration and unmount. '
                  '74 focused tests, types and CLI build pass; one unmodified release performance '
                  'run passes all eight groups, typing p95 10.61ms. Check timing, cleanup, '
                  'callback freshness, semantic output, and meaningful negative controls. '
                  'Find concrete regressions, not style issues. Do not certify the whole release.\n')
        for relative in ['packages/cli/src/surfaces/app.tsx',
                         'packages/cli/src/surfaces/app-views.tsx']:
            prompt += '\nDIFF ' + relative + '\n' + subprocess.run(
                ['git', 'diff', 'HEAD', '--', relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        for relative in ['tests/unit/bottom-chrome-interaction.test.ts',
                         'packages/cli/src/blocks/composer.tsx']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
    if review_id == 'job-generation-handshake':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '88d331cbb427eeb5827b88a5ed1da11fedd09a02'
        prompt = ('Independent bounded review. No tools. Frozen Git tree ' + subject +
                  ', baseline 5337a18a. Existing daemon jobs hold a generation lease around '
                  'execution but spawned CLI children selected state independently. Add a '
                  'version-1 IPC ready/start handshake to the existing Jobs process runner. '
                  'Production daemon launch supplies generation plus parent authority callback. '
                  'Child CLI forces bootstrap, verifies actual generation and waits for approval '
                  'before runMain; the environment marker is consumed before later child processes. '
                  'Direct legacy runner calls remain compatible. 67 focused tests pass, including '
                  'real CLI matching/mismatch, child/parent revocation, malformed frames, wrong '
                  'protocol, disconnect, timeout, early exit and SIGKILL escalation before admission. '
                  'Removing the CLI admission call fails both actual CLI controls, including output '
                  'escaping from a mismatched child. Parent-initiated IPC disconnect on Node 26 '
                  'omitted ChildProcess.close even after exit and both pipes ended; that direct '
                  'fixture test now observes exit plus both streams, without changing runner policy. '
                  'Full gates and load tests are running. Qualified installation/package-byte '
                  'identity and lease-aware retention remain open requirements; generation handshake '
                  'does not prove those. Find concrete regressions, race/deadlock, cleanup, disabled '
                  'mod enforcement, effect-before-admission risks and unsupported abstractions. '
                  'Distinguish existing defects from new ones. Do not certify the whole release.\n')
        paths = ['packages/mod-jobs/src/workflow-handshake.ts',
                 'packages/mod-jobs/src/workflow-process.ts',
                 'packages/mod-jobs/src/daemon-workflow.ts',
                 'packages/cli/src/jobs/workflow-job.ts',
                 'packages/cli/src/index.ts',
                 'tests/integration/job-generation-handshake.test.ts']
        for relative in paths:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '5337a18a', subject, '--', *paths], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'candidate-runtime-design':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        subject = '897c01823d053542b6062311f4e1ef09fe499df1'
        prompt = ('Bounded architecture review, no tools. We must implement the existing spec, not '
                  'invent another framework. Setup currently verifies static metadata then safe-mode '
                  '--version only. A test replaces a fixture mod entrypoint with a top-level throw; '
                  'verification still returns passed=true. Need exact installed first-party runtime '
                  'integrity and normal sacrificial import/registration of the selected profile before '
                  'promotion. Use existing lifecycle, bootstrap, registry and subprocess owners. '
                  'No installs or new dependencies authorized for this work; isolated copy/fixture '
                  'tests are allowed. Analyze a concrete smallest implementation path, including '
                  'staged config, minimal profiles, package resolution anchored in candidate prefix, '
                  'reverse disposal, no live providers, bounds, symlink containment and launcher identity. '
                  'The embedded release channel has 49 packages; separate external BOM has launcher too. '
                  'Avoid self-referential CLI hashes. Existing tarball contentHash must not silently '
                  'become a tree hash. npm can place dependency node_modules inside package roots, so '
                  'blind whole-directory hash versus packed tree is not generally equivalent. '
                  'Options: plan-bound packed-file inventory/tree hash before imports, then a candidate '
                  'kernel bootstrap probe with desired-state and staged config; versus verified archive '
                  'or npm integrity anchoring then existing CLI normal bootstrap. Compare honestly; '
                  'give exact smallest seams to reuse, not speculative infrastructure. Distinguish '
                  'pre-install integrity from later runtime tampering and identify any truly missing '
                  'authority. Source below is frozen at ' + subject + '. No release certification.\n')
        for relative in ['packages/cli/src/commands/setup.ts',
                         'packages/mod-kernel/src/managed-lifecycle.ts',
                         'packages/mod-kernel/src/candidate-process.ts',
                         'packages/mod-kernel/src/first-party-surface-bootstrap.ts',
                         'packages/mod-kernel/src/configuration-migration.ts',
                         'scripts/spec/verify-modular-release-set.mjs']:
            prompt += '\nSOURCE ' + relative + '\n' + subprocess.run(
                ['git', 'show', subject + ':' + relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'candidate-activation-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent implementation review, no tools. Review this unfinished release-boundary '
                  'increment for concrete new defects and missing controls. Do not certify the whole release. '
                  'New: plan-bound packed payload hash generated from actual archives; bounded no-follow '
                  'installed payload reads; candidate selected-profile bootstrap sharing normal resolver and '
                  'registry; installer passes actual staged config bytes; sacrificial runner imports its '
                  'own verified candidate kernel, checks five projections and emits plan-bound completion '
                  'only after disposal; parent rejects early exit/duplicate receipt/wrong plan and checks '
                  'payloads after each code-execution phase; isolated HOME/XDG and process-group deadlines. '
                  'Known OPEN, do not misreport as newly solved: launcher identity not yet plan-bound; '
                  'nested node_modules resolution/shadow kernels not yet authenticated; idempotent setup '
                  'shortcut does not yet rehash installed bytes; full copied/packed installation gate '
                  'not yet rerun. Root node_modules excluded ONLY from package-owned payload identity. '
                  'Archive hash and payload hash are distinct. Fixture kernel runner in setup tests '
                  'tests protocol, not production activation. Separate actual built runner tests exercise '
                  'minimal and full-compat profiles, no live providers. Review clarity, boundedness, '
                  'hash ambiguity, cleanup, selected config, process semantics, source ownership, '
                  'false-green risks. Prefer existing owners, not more frameworks. Give file/symbol '
                  'evidence and smallest fix. No personal configs or credentials in this packet.\n')
        for relative in ['packages/cli/src/commands/setup.ts',
                         'packages/mod-kernel/src/candidate-process.ts',
                         'packages/mod-kernel/src/candidate-activation-runner.mjs',
                         'packages/mod-kernel/src/folder-mod-bounds.ts',
                         'packages/mod-kernel/src/first-party-surface-bootstrap.ts',
                         'packages/mod-kernel/src/configuration-migration.ts',
                         'packages/mod-kernel/src/activated-surface-generation.ts',
                         'scripts/spec/verify-modular-release-set.mjs',
                         'tests/unit/modular-setup-selection.test.ts',
                         'tests/unit/modular-candidate-process.test.ts',
                         'tests/unit/modular-production-surface-bootstrap.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nLIFECYCLE DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-kernel/src/managed-lifecycle.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'setup-payload-shortcut':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded implementation review. No tools. Review the supplied diff and '
                  'sources for concrete defects, missing controls, and needless machinery. This is NOT '
                  'whole-release certification. Existing setup shortcut compared metadata/config owners '
                  'but never rehashed installed payload. New check reuses existing package containment '
                  'and payload hash, with realpath of prefix for macOS /tmp alias. Added/modified/missing '
                  'files, internal scope symlinks and moved installation-prefix symlinks must fall through to existing fresh staging, not '
                  'execute old code or write launcher. Positive unchanged fixture copies actual BOM '
                  'files and must still take shortcut. Before-fix negative controls failed as expected; '
                  '8788 tests, build/types/lint/reexport, pack, performance and sustained-load gates now pass. '
                  'A 4097-directory negative control timed out at the default worker count on a 28-CPU host; '
                  'the same full suite passed with eight workers. Vitest now caps workers at min(8, availableParallelism), '
                  'without changing assertions, timeouts, selection, within-test concurrency or independent load budgets. '
                  'The scheduling configuration is not included in this approved source packet; do not claim to review it. This does not authenticate launcher '
                  'payload, nested dependency trees, or protect against an adversarial same-user writer '
                  'racing every read; those are separate existing open boundaries. Review this increment '
                  'against its honest scope while flagging any newly introduced defect. Include exact '
                  'symbol/call-site evidence and smallest correction. Subject: 5d6be5ea plus diff below.\n')
        for relative in ['packages/cli/src/commands/setup.ts',
                         'packages/mod-kernel/src/folder-mod-bounds.ts',
                         'packages/mod-kernel/src/discovery.ts',
                         'tests/unit/modular-setup-selection.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/commands/setup.ts', 'tests/unit/modular-setup-selection.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'clean-runtime-preparation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review the one-line acceptance-harness fix below. '
                  'The exact committed clean checkout installed its frozen lock and independently compiled '
                  'Mod API and kernel, but its test:modular-slice1a command now selects all modular unit tests. '
                  'Those later activation/docs tests failed on unbuilt mod-ask and mod-routing-docs package exports. '
                  'We add the existing build:cli:workspaces command AFTER independent API/kernel build checks '
                  'and BEFORE the unchanged test selection. All ten steps of the exact staged-index '
                  'clean run passed. Stored review evidence remains mismatched and must stay red. '
                  'Do not certify release or recommend dropping tests. Check for weakened independence, '
                  'hidden source inputs, build ordering and the smallest correct repair. Original global '
                  'installation and personal state stay untouched. Subject cb4afed9 plus supplied staged diff.\n')
        for relative in ['scripts/spec/qualify-modular-agon-clean-checkout.mjs', 'scripts/build-modular-packages.mjs',
                         'tests/unit/modular-docs-projection.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        scripts = json.loads((qualified / 'package.json').read_text())['scripts']
        prompt += '\nPACKAGE SCRIPTS\n' + json.dumps({key: value for key, value in scripts.items()
            if 'build' in key or 'slice1a' in key}, indent=2)
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--cached', '--',
            'scripts/spec/qualify-modular-agon-clean-checkout.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'purge-exact-approval':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Review only the purge exact-approval '
                  'repair and its regressions below. The original implementation accepted a changed '
                  'data target with an unchanged approval hash and also allowed caller mutation during '
                  'lock acquisition. Both regression tests failed before this patch and pass afterward. '
                  'The fix snapshots input before await and checks the canonical unsigned plan hash. '
                  'Existing lifecycle/retention tests, typecheck, lint and re-export guard passed. '
                  'The same two-file diff also protects host and trust/grant namespaces, rejects '
                  'symlink components and takes lifecycle then generation writer locks with reverse '
                  'release. Review these changes too. Purge journaling, lease-aware retention, '
                  'dependency freezing and global release acceptance remain open. Do not certify '
                  'those or the release. '
                  'Identify concrete introduced defects or missing exact-approval tests, with source '
                  'evidence and smallest fixes. Subject cb4afed9 plus this exact two-file diff.\n')
        paths = ['packages/mod-kernel/src/lifecycle-recovery.ts',
                 'tests/unit/modular-lifecycle-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'sbom-external-closure':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review the SBOM generator only. '
                  'It previously emitted only 51 local artifacts and omitted 69 external npm '
                  'locations (62 name/version pairs). A new coverage check failed before the fix. '
                  'Current generator and self-tests pass with 120 components and 337 edges. '
                  'Source catalog is derived by the existing createNpmReleaseCatalog owner '
                  'from lockfile v3: it relocates workspace locations to node_modules, preserves '
                  'metadata and verifies exact resolved bindings, not just semver. Do not review '
                  'that unseen implementation or certify the release. The supplied change '
                  'compares channel metadata to that source catalog, retains nested locations '
                  'as distinct references, records SHA512 archive and SHA256 payload identities '
                  'separately, and preserves declared license expressions including AGPL-3.0. '
                  'Legal/license approval and publication provenance remain open. '
                  'Find concrete correctness defects, misleading evidence or missing negative '
                  'controls. Distinguish inherited defects and give minimal fixes.\n')
        relative = 'scripts/spec/verify-modular-supply-chain.mjs'
        source = (qualified / relative).read_text()
        prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', relative],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        channel = json.loads((qualified / 'packages/cli/release-channel.json').read_text())
        selected = ['node_modules/@kernlang/protocol', 'node_modules/ink', 'node_modules/ink/node_modules/chalk']
        prompt += '\nPUBLIC LOCK METADATA EXAMPLES\n' + json.dumps({path: channel['npmCatalog']['packages'][path] for path in selected}, indent=2)
    if review_id == 'lifecycle-recovery-receipts':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review, no tools. Review recovery-receipt retry only, '
                  'not earlier purge approval changes or the full release. Recovery finalized a '
                  'journal before writing its receipt; failure to write the receipt was never '
                  'retried because terminal journals were skipped. Both commit/rollback regression '
                  'cases failed before this change. Current change retries only terminal journals '
                  'with recovery markers; it does not repeat deletion or generation selection. '
                  'Existing valid receipts are synced again because a prior sync may have failed. '
                  'Malformed or mismatched existing receipts fail closed without overwrite. '
                  'New rollback journals retain the generation selected during recovery, so later '
                  'receipt repair does not substitute a newer generation. Older rollback journals '
                  'stored null, so existing positive generation evidence remains accepted for them. '
                  'Missing old receipt with unknown selected generation stays null. No new '
                  'dependencies, personal state, or global installation changes. Find concrete '
                  'introduced defects and missing discriminating tests. Do not certify retention, '
                  'purge journaling, other receipt families or release acceptance.\n')
        paths = ['packages/mod-kernel/src/lifecycle-recovery.ts',
                 'packages/mod-kernel/src/host-io.ts', 'tests/unit/modular-lifecycle-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF FROM 8b5def8c\n' + subprocess.run(['git', 'diff', '8b5def8c', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'purge-journal-reference':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review. No tools. Review lifecycle-recovery.ts '
                  'and supplied tests for purge replay and retained-reference integrity. '
                  'Subject 8b5def8c plus exact hashed files/diff below. Version-2 purge plans '
                  'add a fresh UUID; journal phases preserve replacement data when retrying '
                  'after rename/removal interruption. New reference checks validate generations '
                  'before interpreting absent installation records, bind their journal identity '
                  'and hash the installation bytes used. Three reference corruption controls '
                  'deleted fixture data before the fix. Three actual SIGKILL purge cases, '
                  'ENOSPC phase controls and existing lifecycle cases pass. Full build, release '
                  'checks, 8933 tests (six skipped), types, lint and exports passed on this '
                  'dirty working-tree subject, with zero providers. This is NOT release '
                  'acceptance. Missing production purge command, full reference/size report, '
                  'lease-aware retention and quota remain explicitly unfinished. '
                  'Check introduced correctness defects, crash durability, lost approval '
                  'boundaries, regression risks, complexity and discriminating test gaps. '
                  'Separate verified source findings from hypotheses requiring unseen source. '
                  'Give smallest fixes; do not propose a parallel lifecycle implementation.\n')
        paths = ['packages/mod-kernel/src/lifecycle-recovery.ts',
                 'packages/mod-kernel/src/host-io.ts',
                 'tests/unit/modular-lifecycle-recovery.test.ts',
                 'tests/unit/modular-purge-retention.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF FROM 8b5def8c\n' + subprocess.run(['git', 'diff', '8b5def8c', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'host-lease-fence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review. No tools. Review the supplied diff for '
                  'generation ID high-water allocation, lease inventory integrity, and stale '
                  'writer-lock recovery. This is not a release review. Retired generation '
                  'directories must not allow historical generation IDs to be reused, so '
                  'existing journals are scanned under the writer fence. Lease files bind their '
                  'filename to parsed lease ID; nonregular inventory entries refuse inspection. '
                  'Stale lock recovery validates shape and re-reads after each of two liveness '
                  'observations. Existing tests, full build/types/lint and the previous full '
                  '8933-test run passed. New unrelated purge corrections are undergoing full '
                  'verification now and are not in this review. Check concrete correctness '
                  'regressions, false-green tests and compatibility risks. Distinguish inherited '
                  'defects from new ones, cite exact source, propose minimal corrections. '
                  'No quota, retention-window or hostile same-user filesystem sandbox claim '
                  'is made. Mutation cost scales with retained journals; recorded cold startup '
                  'probe remained within its current budget. Do not certify those measurements '
                  'from source alone.\n')
        paths = ['packages/mod-kernel/src/durable-host.ts',
                 'packages/mod-kernel/src/generation-leases.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'packages/mod-kernel/src/host-contracts.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        tests = ['tests/unit/modular-host-boundaries.test.ts',
                 'tests/unit/modular-lease-corruption.test.ts',
                 'tests/unit/modular-rollback.test.ts',
                 'tests/unit/modular-writer-lock-safety.test.ts']
        prompt += '\nDIFF FROM 8b5def8c\n' + subprocess.run(['git', 'diff', '8b5def8c', '--', *paths, *tests],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'npm-frozen-closure':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review. No tools. Review the new npm-lock owner '
                  'and its tests only; do not certify setup, the installer or full release. '
                  'Files are currently untracked implementation work. Source lockfile v3 '
                  'workspace locations are translated to release locations while retaining '
                  'exact dependency bindings. Candidate manifests/locks select a closure '
                  'for npm ci with scripts, audit, fund, bin links and optional dependencies '
                  'disabled by the caller. Local artifact locators override already locked '
                  'first-party versions; external packages retain frozen integrity. '
                  'Inspect closure semantics, optional/peer interactions, path and identity '
                  'validation, relocation, malformed input, and missing discriminating tests. '
                  'Find concrete defects with an exact input and expected behavior. Treat '
                  'npm semantics not established by the packet as hypotheses requiring '
                  'verification. No new dependency or alternate resolver is wanted.\n')
        for relative in ['packages/mod-kernel/src/npm-lock.ts', 'tests/unit/modular-npm-lock.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
    if review_id == 'reclaim-marker-recovery':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review. No tools. Review WriterFence recovery '
                  'after a killed reclaimer. Previous shared .reclaim marker had no process '
                  'identity and wedged retries. Current unique PID/UUID filenames preserve '
                  'identity even with partial contents. Never reclaim a live PID by age; '
                  'unknown or legacy shared markers fail closed for explicit inspection. '
                  'Both sync and async acquisition scan recovery markers and recheck owner '
                  'identity before returning. Recovery removes only dead unique markers, '
                  'scans competing markers, preserves two old-writer liveness probes with '
                  'identity rereads, and removes only its own marker in cleanup. Partial '
                  'publication cleanup is tested. No new package/API or global state. '
                  '98 focused tests pass including two actual SIGKILL recovery-boundary '
                  'tests and subsequent fresh safe-mode CLI recovery. Full gates pending. '
                  'Attack mutual exclusion, replacement/cleanup races, PID reuse, stale '
                  'markers, I/O failure, error behavior and false-green tests. Do not assume '
                  'tests prove concurrency; give an exact interleaving for any finding. '
                  'Distinguish inherited defects from regressions. No hostile same-user '
                  'filesystem sandbox or mixed old/new candidate process qualification '
                  'is claimed. This is not whole-release acceptance.\n')
        paths = ['packages/mod-kernel/src/writer-lock.ts',
                 'packages/mod-kernel/src/host-io.ts',
                 'tests/unit/modular-writer-lock-safety.test.ts',
                 'tests/unit/modular-first-party-cli-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nWRITER DIFF FROM 8b5def8c\n' + subprocess.run(
            ['git', 'diff', '8b5def8c', '--', paths[0]], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-inspection':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review. No tools. Review retention inspection only. '
                  'The existing referencedInstallations scanner now retains all generation IDs '
                  'per installation, preserving its previous generation/committed selection for '
                  'recovery, cleanup and purge consumers. It rejects active leases without a '
                  'validated generation. inspectManagedRetention takes lifecycle then host fences '
                  'and reports retained installation generations plus unreleased process leases. '
                  'The new mod retention command is inspection only; no deletion is added. '
                  'DurableModHost.activeGenerationLeases simply delegates to its existing store. '
                  'Missing lease directory means no leases; errors reading individual lease files '
                  'still propagate. No old process lease is automatically expired. No on-disk '
                  'schema change. Rollback-window/artifact lease policy, complete quota/cache '
                  'reporting and garbage collection remain unfinished original requirements. '
                  'Do not certify these or the full release. Find concrete regressions, races, '
                  'misleading output, lock/cleanup problems and missing discriminating controls. '
                  'Do not reopen unrelated earlier purge/writer repairs without a new reachable defect.\n')
        for relative in ['packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/generation-leases.ts',
                         'tests/unit/modular-purge-retention.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        for relative, start, end in [
            ('packages/cli/src/commands/mod.ts', 'const retentionCommand', None),
            ('tests/unit/modular-first-party-cli-recovery.test.ts', "  it('reports retention", "  it.each(['marker-published'")]:
            source = (qualified / relative).read_text()
            begin = source.index(start)
            excerpt = source[begin:source.index(end, begin) if end else None]
            prompt += '\nEXCERPT ' + relative + '\n' + excerpt
    if review_id == 'installer-frozen-closure':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Review frozen candidate setup, '
                  'launcher identity, nested dependency integrity and their tests. The catalog '
                  'comes from lockfile v3 and the first-party release channel. Existing npm-lock '
                  'owner validates exact dependency locations and canonical archive integrity; '
                  'it was separately reviewed. This packet covers its setup integration, not '
                  'another solver review. npm ci runs only in disposable prefixes, scripts/audit '
                  'disabled, and leaves the frozen lock unchanged. First-party and external '
                  'payloads are checked before and after sacrificial activation and launcher '
                  'smoke. Nested kernel/API copies must fail. The launchers own payload hash '
                  'is computed from the trusted running bootstrap inventory because embedding '
                  'its archive hash in itself is circular. No claim of hostile-code sandboxing. '
                  '82 of 84 installed qualification cells passed; the two TUI failures are '
                  'a confirmed undeclared chalk import, separately pending dependency approval. '
                  'Do not re-report that known defect or certify release readiness. Identify '
                  'other concrete defects, false-green checks, meaningful missing tests, '
                  'smallest corrections, and source support. Preserve existing public behavior.\n')
        for relative in ['packages/cli/src/commands/setup.ts',
                         'packages/mod-kernel/src/folder-mod-bounds.ts',
                         'packages/mod-kernel/src/candidate-process.ts',
                         'tests/unit/modular-setup-selection.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
    if review_id == 'plan-session-routing':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review Plan session routing ownership '
                  'and behavior parity. Previously the physical Plan contribution called the '
                  'host callback which re-entered CLI dispatchSessionInfoIntent. Now both routes '
                  'bind UI effects to one dispatcher in the existing Plan session module. '
                  'Preserve pending-versus-legacy approval/cancellation ordering, job results, '
                  'post-dispatch events, exception propagation, invocation expiry and disabled '
                  'mod enforcement. Other Plan execution adapters remain open; this is not whole '
                  'release acceptance. Find concrete regressions and meaningful missing checks. '
                  'Prefer existing owners; do not propose parallel machinery.\n')
        paths = ['packages/mod-plan/src/session.ts',
                 'packages/mod-plan/src/session-scope.ts',
                 'packages/cli/src/signals/dispatch/intent-session.ts',
                 'tests/unit/modular-plan-session-route.test.ts',
                 'tests/unit/modular-plan-session-owner.test.ts',
                 'tests/unit/modular-plan-session-tui.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        diff = subprocess.run(['git', 'diff', 'HEAD', '--', *paths], cwd=qualified,
                              capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF AGAINST bb72626c\n' + diff
    if review_id == 'plan-legacy-authority':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Verify a disabled-mod safety fix. '
                  'Synthetic legacy-shaped Plan requests previously bypassed the selected '
                  'generation before task routing. Three tests failed: disabled plan-task, '
                  'auto and unknown with explicit autoMode. Enabled controls passed. The '
                  'fix uses existing surface authority before legacy session actions and '
                  'autonomous effects. Normal unknown input and historical status stay usable. '
                  'Generated contributions already check registry membership; no new catalog. '
                  'Find concrete regressions, missing behavior checks and authority gaps. '
                  'Do not claim full release acceptance. Give source evidence, not guesses.\n')
        paths = ['packages/cli/src/signals/dispatch/intent-router.ts',
                 'packages/cli/src/signals/dispatch/intent-session.ts',
                 'packages/cli/src/signals/dispatch/intent-skills.ts',
                 'packages/cli/src/surface-authority-runtime.ts',
                 'tests/unit/modular-plan-natural-input.test.ts',
                 'tests/unit/modular-plan-session-tui.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        diff = subprocess.run(['git', 'diff', 'HEAD', '--', *paths], cwd=qualified,
                              capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF AGAINST e4e56305\n' + diff
    if review_id == 'plan-export-retirement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review removal of three unused '
                  'internal CLI exports: finalizePlanWithReviewGate wrapper and two fallback '
                  'policy reexports. Production search found only their definitions and CLI '
                  'barrel. CLI package exposes a binary, no exports/main library entry. The '
                  'physical Plan package public exports and algorithms remain unchanged. '
                  'dispatch-routing test now imports public Plan directly; coordinator test '
                  'replaces facade identity with absence guards while preserving behavioral '
                  'tests. Removal guard failed before removal. Do not confuse absence of '
                  'one seam with completion of all ownership. Find concrete regressions, '
                  'lost test coverage or overlooked boundary obligations.\n')
        paths = ['packages/cli/src/signals/dispatch/plan-execution.ts',
                 'packages/cli/src/signals/dispatch.ts',
                 'tests/unit/modular-plan-coordinator.test.ts',
                 'tests/unit/dispatch-routing.test.ts',
                 'packages/cli/package.json', 'packages/mod-plan/src/index.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        diff = subprocess.run(['git', 'diff', 'HEAD', '--', *paths], cwd=qualified,
                              capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF AGAINST 51f8f715\n' + diff
    if review_id == 'plan-host-actions':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review typed Plan host binding. '
                  'The physical mod now dispatches its existing action policy directly and '
                  'converts its result, instead of re-entering a CLI request callback. The '
                  'published callback form remains compatible. CLI supplies typed effects '
                  'and completion notification; legacy-shaped routing shares those effects. '
                  'Check async errors, scope expiry, cancellation, events, background jobs '
                  'and behavior parity. A negative control caught missing await on completion; '
                  'it is now awaited. Do not certify all Plan ownership or the release. '
                  'Report only concrete findings with source evidence.\n')
        paths = ['packages/mod-plan/src/session-scope.ts',
                 'packages/mod-plan/src/session.ts',
                 'packages/cli/src/signals/dispatch/intent-session.ts',
                 'tests/unit/modular-plan-session-host.test.ts',
                 'tests/unit/modular-plan-session-owner.test.ts',
                 'tests/unit/modular-plan-session-tui.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        diff = subprocess.run(['git', 'diff', 'HEAD', '--', *paths], cwd=qualified,
                              capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF AGAINST e643afcc\n' + diff
    if review_id == 'retention-bytes':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Check read-only retained installation '
                  'size reporting. The existing inspector holds lifecycle and generation writer '
                  'fences; it now counts regular-file bytes per path once per installation ID, '
                  'not once per generation reference. No deletes, quotas, cache policy or new '
                  'dependency. Logical bytes are not physical/reclaimable space; hard-linked '
                  'paths count separately. Missing/unreadable/linked/special entries fail closed. '
                  'Check traversal safety, overflow, cleanup, API compatibility and tests. '
                  'Hostile concurrent same-user filesystem mutation is not a claimed sandbox. '
                  'Find concrete defects only. Do not certify overall retention or release.\n')
        paths = ['packages/mod-kernel/src/lifecycle-recovery.ts',
                 'packages/mod-kernel/src/host-io.ts',
                 'packages/mod-kernel/src/folder-mod-bounds.ts',
                 'tests/unit/modular-purge-retention.test.ts',
                 'tests/unit/modular-first-party-cli-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        diff = subprocess.run(['git', 'diff', 'HEAD', '--', *paths], cwd=qualified,
                              capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF AGAINST b4ba409a\n' + diff
    if review_id == 'artifact-leases':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review durable artifact generation leases '
                  'added to the existing process lease store and writer fence. Strict v2 artifact '
                  'records have owner/artifact/hash identity, no PID or heartbeat, and no age '
                  'expiry. Process v1 API remains typed separately. Older readers reject v2, '
                  'not silently discard protection. Recovery/purge inspect artifact references. '
                  'Artifact identity is caller-declared, not verified content or a sandbox. '
                  'Inspect corruption, cancellation, failed writes, cleanup, retry durability, '
                  'wrong-owner releases, compatibility, missing generations and tests. '
                  'Two red controls caught missing release re-sync and post-validation abort '
                  'checks; both are fixed. No automatic artifact attachment, rollback window, '
                  'quota or full release acceptance is claimed. Give concrete findings only.\n')
        paths = ['packages/mod-kernel/src/generation-leases.ts',
                 'packages/mod-kernel/src/host-contracts.ts',
                 'packages/mod-kernel/src/host-io.ts',
                 'packages/mod-kernel/src/lifecycle-recovery.ts',
                 'tests/unit/modular-generation-leases.test.ts',
                 'tests/unit/modular-lease-corruption.test.ts',
                 'tests/unit/modular-purge-retention.test.ts',
                 'tests/unit/modular-first-party-cli-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        diff = subprocess.run(['git', 'diff', 'HEAD', '--', *paths, 'packages/mod-kernel/src/durable-host.ts'], cwd=qualified,
                              capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF AGAINST 907c69e5\n' + diff
    if review_id == 'artifact-retention-cli':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review operator artifact retention CLI '
                  'using existing saved plans and exact hash approval. No file deletion. Caller '
                  'declares artifact identity; this is not verification of artifact bytes or a sandbox. '
                  'Each approved retain has a UUID request ID: under the existing writer fence '
                  'it returns the original lease, including released state, and never resurrects '
                  'released protection. Calls without a request ID retain independent leases. '
                  'Check approval binding, stale generation and identity, cancellation, durability, '
                  'concurrency, actual citty dispatch, compatibility and test discrimination. '
                  'Do not certify whole release. Prior red tests caught retain replay resurrection '
                  'and duplicate JSON from parent dispatch; both now have fixes. Concrete findings only.\n')
        paths = ['packages/cli/src/commands/mod.ts',
                 'packages/mod-kernel/src/generation-leases.ts',
                 'packages/mod-kernel/src/host-contracts.ts',
                 'tests/unit/modular-generation-leases.test.ts',
                 'tests/unit/modular-first-party-cli-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF AGAINST cae5bcfd\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', *paths, 'packages/mod-kernel/src/durable-host.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'foundation-implementation-mutations':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the existing foundation gate extension '
                  'for real implementation mutations. It archives committed HEAD into a disposable '
                  'directory, links existing node_modules, runs a green source-test baseline, changes '
                  'six exact source sites one at a time, and requires specific assertion failures. '
                  'No production source rewrite or dependency installation. Current runtime/test '
                  'tracked changes refuse the committed-subject run. Faults cover unknown manifest '
                  'fields, duplicate dependencies, source precedence, duplicate registry owner, '
                  'canonical key order and a forbidden kernel type import into Mod API. Six faults '
                  'were all killed by expected assertions in real Vitest runs. Real survivor and '
                  'syntax-error controls also passed. Inspect false-green risks, report validation, '
                  'subject identity, dependency loading, cleanup, maintainability and boundedness. '
                  'The logged scope explicitly is six faults, not an exhaustive mutation score or '
                  'whole-release certification. Identify concrete actionable defects only.\n')
        paths = ['scripts/spec/verify-modular-foundation-mutation.mjs', 'vitest.config.ts',
                 'tests/unit/modular-manifest.test.ts', 'tests/unit/modular-resolver.test.ts',
                 'tests/unit/modular-registry.test.ts', 'tests/unit/modular-lock.test.ts',
                 'tests/unit/modular-boundary.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', paths[0]],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'brainstorm-legacy-routing':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Two legacy Brainstorm intent paths still '
                  'called a duplicate CLI handler rather than the generated mod execution owner. '
                  'Both now use existing runPhysicalCesarWorkflow, forwarding the job AbortSignal '
                  'through a closure around withThreadOutcome (whose callback takes no arguments). '
                  'The now-unreferenced internal legacy handler and barrel export are removed. '
                  'Tests first reproduced both bypasses, then passed with the changed routing. '
                  'Review cancellation, disabled authority, behavior preservation and source ownership. '
                  'Do not demand unrelated rewrites or certify the whole release. Identify concrete '
                  'defects with evidence. The caller retains thread outcomes and Cesar continuation.\n')
        paths = ['packages/cli/src/signals/dispatch/intent-orchestration.ts',
                 'packages/cli/src/signals/dispatch/intent-meta.ts',
                 'packages/cli/src/blocks/brainstorm-session.ts',
                 'packages/mod-brainstorm/src/session-workflow.ts',
                 'tests/unit/modular-brainstorm-interactive-recovery.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        for relative, start, end in [('packages/cli/src/signals/dispatch/cesar-router.ts', 0, 90),
                                     ('packages/cli/src/signals/dispatch/delegation.ts', 62, 155)]:
            source = (qualified / relative).read_text()
            prompt += '\nEXCERPT ' + relative + '\n' + '\n'.join(source.splitlines()[start:end])
        prompt += '\nCOMPLETE DIFF\n' + subprocess.run(['git', 'diff', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-unreferenced-inventory':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. The existing read-only retention report '
                  'omitted installation prefixes without a generation reference. Add a separate '
                  'unreferenced list/byte total, preserving retained-list and total semantics. '
                  'Use existing lifecycle then host fences and the same logical-size walker. '
                  'Reject invalid names, links, non-directory prefixes, incomplete scans and '
                  'unsafe totals. Missing installation root is normal for an empty host. '
                  'No deletion, retention expiry, quota policy or eligibility claim is introduced. '
                  'All modified trees in tests are isolated. Report concrete defects, unsafe '
                  'assumptions or missing discriminating controls; do not certify release.\n')
        for relative in ['packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/host-io.ts',
                         'tests/unit/modular-purge-retention.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        source = (qualified / 'packages/mod-kernel/src/folder-mod-bounds.ts').read_text()
        prompt += '\nSYMLINK CHECK\n' + '\n'.join(source.splitlines()[:33])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id in ('forge-fitness-contract', 'forge-fitness-contract-isolated'):
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. The physical Forge intent parser emits '
                  'fitnessCmd but runForgeCompetition consumed only CLI test, silently substituting '
                  'true. Three parser-to-run tests failed before the fix. Normalize at the existing '
                  'execution owner, preserving CLI test precedence. Tests also execute real Git '
                  'worktrees with injected fixture dispatch and true/false shell commands, checking '
                  'outcome and cleanup. Review this bounded fix, command preservation and tests. '
                  'The larger inherited hardened/gauntlet/synthesis parity gaps are separately '
                  'recorded and NOT certified by this fix. No release certification.\n')
        for relative in ['packages/mod-forge/src/implementation.ts',
                         'tests/unit/modular-forge-settings.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/mod-forge/src/implementation.ts', 'tests/unit/modular-forge-settings.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-workspace-overlay':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Physical Forge arena linked all root '
                  'node_modules to the source checkout. A real Node import test observed SOURCE '
                  'rather than CANDIDATE for npm workspace links; pnpm per-package links were '
                  'unresolvable. Move existing Core dependency-overlay/hydration functions '
                  'byte-for-byte into already-declared support-worktree, preserving Core exports, '
                  'then use them in Forge arena. Register the created candidate before overlay '
                  'so cleanup knows it if initialization fails. No new dependency. Review concrete '
                  'regressions, API/boundary correctness and isolation claims. This is workspace '
                  'import correctness, NOT a filesystem sandbox: external dependencies stay shared. '
                  'The separate mod-worktrees runtime overlay has different error behavior and '
                  'remains a recorded consolidation gap; do not certify all duplication gone.\n')
        for relative in ['packages/support-worktree/src/dependency-overlay.ts',
                         'packages/support-worktree/src/forge-arena.ts',
                         'packages/support-worktree/src/index.ts',
                         'tests/unit/worktree-pnpm-link.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/core/src/blocks/git.ts', 'packages/support-worktree/src',
            'tests/unit/worktree-pnpm-link.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'chalk-runtime-declaration':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Operator approved declaring existing '
                  'locked chalk 4.1.2 as a direct CLI runtime dependency. Installed TUI failed '
                  'ERR_MODULE_NOT_FOUND chalk; the root development install masked it. No version, '
                  'resolved URL, integrity or package membership changed. npm lock-only offline '
                  'regeneration removes dev-only markers for chalk and its five transitive '
                  'dependencies. Source code is unchanged. Review manifest and lock consistency '
                  'and the actual import. Existing packed TUI harness will rerun. OSV reports '
                  '16 pre-existing findings in nine other packages; no security-release claim.\n')
        for relative in ['packages/cli/package.json', 'packages/cli/src/blocks/prompt-input.tsx']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/cli/package.json', 'package-lock.json'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'worktree-plan-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move legacy worktree Plan approval, '
                  'show, retry, list and cancellation policy from CLI into physical mod-plan. '
                  'Operator approved existing internal support-worktree dependency. Preserve '
                  'selection, stale-answer/dismissal safety, save/event order, error propagation '
                  'and Forge forwarding. Existing Plan types/state functions stay in support-worktree. '
                  'CLI supplies effects and compatibility PlanStateError factory. Common explicit '
                  'approval predicate moves unchanged into support-verification with CLI re-export. '
                  'No production Forge algorithm change. Verify against the old source included. '
                  'Flag concrete regressions and missing tests; distinguish inherited problems. '
                  'Do not certify the release. Seventy focused tests and typecheck passed.\n')
        for relative in ['packages/mod-plan/src/worktree-workflow.ts',
                         'packages/cli/src/handlers/plan.ts',
                         'packages/support-worktree/src/plan.ts',
                         'packages/support-verification/src/explicit-approval.ts',
                         'tests/unit/modular-worktree-plan-workflow.test.ts',
                         'tests/unit/plan-approval-refusal.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nOLD CLI SOURCE\n' + subprocess.run(['git', 'show',
            'HEAD:packages/cli/src/handlers/plan.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/mod-plan', 'packages/cli/src/handlers/plan.ts',
            'packages/cli/src/lib/explicit-approval.ts', 'packages/support-verification/src',
            'docs/specs/evidence/modular-agon-package-map.json', 'package-lock.json'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'worktree-plan-authority':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Confirmed existing defect: selected '
                  'generation disables Forge, but interactive Plan approve/retry/show-draft '
                  'still call legacy handleForge and save state. Three tests failed before fix. '
                  'Use existing process authority capture in CLI host and availability checks in '
                  'physical Plan workflow before entry, after question, before saving approval '
                  'or retry. Forge required only for execution, not cancellation. Check stale '
                  'host/generation, refusal persistence, error behavior and enabled behavior. '
                  'No new dependency. Do not certify whole release.\n')
        for relative in ['packages/cli/src/handlers/plan.ts',
                         'packages/mod-plan/src/worktree-workflow.ts',
                         'packages/cli/src/surface-authority-runtime.ts',
                         'tests/unit/modular-plan-entry-authority.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/cli/src/handlers/plan.ts', 'packages/mod-plan/src/worktree-workflow.ts',
            'tests/unit/modular-plan-entry-authority.test.ts',
            'tests/unit/modular-worktree-plan-workflow.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'qualification-plan-edge':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        names = ['clean-checkout', 'slice2', 'slice3', 'slice4', 'slice5', 'slice6', 'slice7', 'slice8', 'slice9']
        files = [f'scripts/spec/qualify-modular-agon-{name}.mjs' for name in names]
        files += ['tests/unit/modular-package-graph.test.ts', 'tests/unit/modular-platform-matrix.test.ts']
        prompt = ('Independent bounded review. No tools. The approved mod-plan to support-worktree '
                  'edge is already committed. Generated graph has 49 packages and 152 edges. '
                  'Nine release qualifiers still expected 151 and falsely rejected that graph. '
                  'This patch updates only expected counts and one test fixture. Nine new tests '
                  'failed before correction; now 54 focused tests, types and lint pass. '
                  'Check for weakened gates or missing regression coverage. No release acceptance '
                  'is claimed: separate Forge regressions remain open, and full qualification is pending.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-result-policy':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/result-policy.ts', 'packages/mod-forge/src/implementation.ts',
                 'packages/mod-forge/src/index.ts', 'packages/mod-forge/agon.mod.json',
                 'packages/forge/src/stages-impl.ts', 'packages/forge/package.json',
                 'packages/forge/tsconfig.json', 'tests/unit/modular-forge-settings.test.ts']
        prompt = ('Independent bounded review. No tools. Four reproduced no-diff verdict regressions '
                  'in physical Forge are fixed by moving the existing pure legacy policy unchanged '
                  'to mod-forge and re-exporting from legacy stages. The internal legacy forge to '
                  'mod-forge dependency is explicitly approved. Nine real-worktree cases now pass; '
                  '65 focused tests and typecheck pass. Check cancellation, fitness, report handling, '
                  'default changes, package boundaries and compatibility. Do not certify full Forge: '
                  'synthesis, gauntlet and other parity work remains open. Source only, no personal state.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'scripts/spec/generate-modular-first-party-packages.mjs', 'package-lock.json'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-judge-report':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/implementation.ts', 'packages/mod-forge/src/implementation.test.ts']
        prompt = ('Independent bounded review. No tools. A validation report can win Forge with no patch, '
                  'but the physical judge previously received only the empty patch. A real temporary Git '
                  'worktree test reproduced the missing report. The fix includes existing retained dispatchStdout '
                  '(already capped at 5000 characters) in the judge prompt and labels it unverified data, '
                  'not instructions. No winner selection, review authority or legacy prompt changes. '
                  'Focused tests and types pass. Verify this narrow fix and test for concrete defects. '
                  'Full Forge extraction and final release acceptance remain unfinished.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'purge-cli':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/cli/src/commands/mod.ts', 'packages/mod-kernel/src/lifecycle-recovery.ts']
        tests = ['tests/unit/modular-first-party-cli-recovery.test.ts', 'tests/unit/modular-lifecycle-recovery.test.ts']
        prompt = ('Independent bounded review. No tools. Implement the already-specified production '
                  'agon mod purge caller using the existing kernel preview/apply API, not new removal '
                  'logic. Repeatable --installation/--data create a saved exact preview; plan plus '
                  '--approve applies its hash. Reject replacement flags, wrong plan kinds, empty '
                  'selections and relative data paths. Kernel now also protects pending-authority. '
                  '146 focused tests plus types pass, including real built safe-mode CLI preview, '
                  'refusal, removal and replay preserving replacement data. No operator data touched. '
                  'Review destructive-authority mistakes, path escape, stale plans, replay, malformed '
                  'inputs and scope. Quota/automatic collection/complete release acceptance remain open.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files, *tests], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'lifecycle-writer-cleanup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/lifecycle-recovery.ts', 'packages/mod-kernel/src/writer-lock.ts']
        prompt = ('Independent bounded review. No tools. Purge and lifecycle recovery swallowed both '
                  'writer release failures in finally, reporting success with a retained lock. '
                  'One local helper now attempts both releases in reverse acquisition order and '
                  'preserves operation plus cleanup errors. No lock stealing, automatic retry, '
                  'new state or broad writer API change. Sixteen combinations cover purge/recovery, '
                  'host/lifecycle lock, remove/sync failure and success/failure of the operation. '
                  'The first recovery fixture injected too early in host replay; corrected to arm '
                  'at lifecycle journal enumeration. Both corrected cases failed before the fix. '
                  'Focused tests and types pass. Inspect exception preservation, ordering, and '
                  'test gaps. Existing purge effects remain irreversible; failure cannot mean '
                  'rollback. This is not full release acceptance.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'tests/unit/modular-lifecycle-recovery.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'roadmap-dependency-drift':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['scripts/spec/verify-modular-agon-roadmap.mjs',
                 'tests/unit/modular-package-graph.test.ts']
        prompt = ('Independent bounded review. No tools. The roadmap validator passed 151 edges '
                  'while the authoritative map has 152 after an approved Plan -> support-worktree '
                  'dependency. It checked IDs but not dependency equality. The fix compares sorted '
                  'lists, retains duplicate/order checks, adds the missing roadmap edge and moves '
                  'worktree before Plan. Tests execute the verifier with isolated mutated roadmap '
                  'inputs; source relocation computation is stubbed because this test targets graph '
                  'drift only. Missing/extra/same-count-swapped cases failed before this fix; '
                  'valid/permuted lists pass, duplicate and invalid order reject. All 18 focused '
                  'tests, direct roadmap verification and types now pass. Check concrete defects '
                  'and discriminating coverage. No new dependencies, runtime changes or release '
                  'acceptance claims. Historical subject-labelled counts remain unchanged.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/evidence/modular-agon-implementation-roadmap.json',
            'docs/specs/modular-agon-acceptance-roadmap.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'transaction-writer-cleanup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/durable-host.ts',
                 'packages/mod-kernel/src/managed-lifecycle.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'packages/mod-kernel/src/lifecycle-recovery.ts']
        prompt = ('Independent bounded review. No tools. Host commit/recovery and managed install '
                  'silently discarded final fence-release failures. Three new tests reproduced '
                  'success despite a retained lock. Existing lifecycle release helper moved '
                  'unchanged to writer-lock (not public index), reused by all five paths. '
                  'It preserves original operation plus cleanup errors; existing translated '
                  'errors still propagate unchanged when cleanup succeeds. Crash simulation '
                  'retains its old skip-release behavior. Check exception semantics, selected '
                  'prefix retention, nested host/install failure, cleanup masking, and coverage. '
                  'Tests cover removal/sync failures after success or pre/post-commit errors; '
                  '196 focused tests/types passed before post-commit expansion. No global state, '
                  'new dependency, retry, or release acceptance.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            if relative.endswith('/durable-host.ts'):
                excerpt = source[source.index('  async commitGeneration('):source.index('  async #recoverTransactionsUnderFence(')]
            elif relative.endswith('/managed-lifecycle.ts'):
                excerpt = source[source.index('  async apply('):source.index('  async readSelectedInstallation(')]
            elif relative.endswith('/writer-lock.ts'):
                excerpt = source[source.index('  release(): Promise<void>'):]
            else:
                excerpt = source[source.index('export async function recoverManagedLifecycle('):source.index('export interface ManagedPurgePlan')]
            prompt += '\nSOURCE EXCERPT ' + relative + ' FULL FILE SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + excerpt
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'tests/unit/modular-host-failures.test.ts',
            'tests/unit/modular-lifecycle-fault-injection.test.ts',
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'authority-writer-cleanup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/transactional-authority.ts',
                 'packages/mod-kernel/src/trust-authority.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'tests/unit/modular-transactional-authority.test.ts']
        prompt = ('Independent bounded review. No tools. TransactionalTrustGrantService.apply '
                  'acquired its writer before nextSequence/materialize outside try/finally. '
                  'Invalid approval, bad plan hash and sequence-read failure all reproduced a '
                  'retained lock. Move preflight inside the existing protected block without '
                  'changing validation. Apply and recover also suppressed release errors; reuse '
                  'the existing helper to retain operation/cleanup failures. Tests prove rejected '
                  'preflight writes no new trust, releases the lock and permits subsequent valid '
                  'apply. Eight remove/sync and success/failure combinations assert lock, record '
                  'and journal state. Focused tests/types passed. Check authority, ordering, '
                  'cleanup and test gaps. No new dependencies, personal trust or global state.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'rollback-writer-cleanup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/host-rollback.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'packages/mod-kernel/src/host-errors.ts',
                 'tests/unit/modular-rollback.test.ts']
        prompt = ('Independent bounded review. No tools. Generation rollback suppressed writer '
                  'release errors in preflight and finally, and setup outside try/finally leaked '
                  'the writer on failure. Reproduced on real temporary filesystem fixtures. '
                  'The fix puts all post-acquisition work under one cleanup boundary and uses '
                  'existing releaseLifecycleWriters. It preserves original and cleanup errors, '
                  'selected generations, recovery semantics, and existing public error codes '
                  'when cleanup succeeds. Standard non-enumerable causes preserve translated '
                  'post-commit errors. Fifteen fault combinations cover no failure, preflight, '
                  'setup, before/after pointer and no/remove/sync cleanup failure. Focused '
                  'tests and typecheck pass. Find concrete regressions and missing controls. '
                  'No dependencies, global state, retry or automatic lock reclamation added. '
                  'Do not certify the whole release.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'external-writer-cleanup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/external-activation-state.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'tests/unit/modular-s8-review-acceptance.test.ts']
        prompt = ('Independent bounded review. No tools. ExternalActivationStore apply, recover '
                  'and recordOutcome suppressed writer release failures. All four public paths '
                  '(including recordFailure and recordSuccess) reproduced false success under '
                  'remove failure. They now use the existing releaseLifecycleWriters helper, '
                  'preserving primary and cleanup errors without reverting completed effects. '
                  'Twenty-four real filesystem combinations cover success/failure and normal, '
                  'remove and directory-sync cleanup. Existing bootstrap catches deliberately '
                  'emit EXTERNAL_AUTHORITY_FAILED diagnostics; recovery failure keeps all external '
                  'mods blocked, outcome persistence failures report diagnostics. Those callers '
                  'are unchanged. No new grant, dependency, retry or global state. Check concrete '
                  'regressions and missing controls. Do not certify the full release.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            prompt += '\nSOURCE ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'transaction-recovery-context':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/durable-host.ts',
                 'packages/mod-kernel/src/managed-lifecycle.ts',
                 'packages/mod-kernel/src/writer-lock.ts',
                 'packages/mod-kernel/src/host-errors.ts']
        prompt = ('Independent bounded review. No tools. Prior cleanup aggregation retained '
                  'raw errors but discarded typed recovery context created later by host commit '
                  'and managed installation. Four updated regression cases reproduced the loss. '
                  'At each translation site, keep the translated error as the operation member '
                  'of the existing aggregate and retain raw error through standard cause. No '
                  'mutation ordering or cleanup policy change. SimulatedHostCrash still retains '
                  'its fence; existing DurableHostError passes through. Check control flow and '
                  'nested host/lifecycle errors, including unknown pointer outcomes. Find concrete '
                  'regressions and missing evidence, not style-only refactors. No dependencies, '
                  'new abstractions or personal state. Do not certify the release.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            if relative.endswith('/durable-host.ts'):
                excerpt = source[source.index('  async commitGeneration('):source.index('  async #hasBoundTerminalReceipt(')]
            elif relative.endswith('/managed-lifecycle.ts'):
                excerpt = source[source.index('  async apply('):source.index('  async readSelectedInstallation(')]
            elif relative.endswith('/writer-lock.ts'):
                excerpt = source[source.index('export async function releaseLifecycleWriters'):source.index('/** Run synchronous')]
            else:
                excerpt = source
            prompt += '\nSOURCE EXCERPT ' + relative + ' FULL FILE SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + excerpt
        for relative in ['tests/unit/modular-host-failures.test.ts', 'tests/unit/modular-lifecycle-fault-injection.test.ts']:
            source = (qualified / relative).read_text()
            prompt += '\nTEST ' + relative + ' SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'tests/unit/modular-host-failures.test.ts', 'tests/unit/modular-lifecycle-fault-injection.test.ts',
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id in ('retention-rollback-selection', 'retention-rollback-selection-complete'):
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-kernel/src/lifecycle-recovery.ts',
                 'packages/mod-kernel/src/host-rollback.ts',
                 'packages/mod-kernel/src/host-contracts.ts',
                 'packages/mod-kernel/src/folder-mod-bounds.ts']
        prompt = ('Independent bounded review. No tools. ManagedRetentionInspector wrongly '
                  'required generation creation transaction == selected pointer transaction. '
                  'Rollback creates a new selection transaction for an existing generation. '
                  'Both source regression and built safe-mode CLI reproduced rejection after '
                  'install/update/rollback. Fix retains graph/lock binding, allows a differing '
                  'transaction only through a parsed verified/committed rollback journal bound '
                  'to pointer transaction, target generation and lock hash; refuses symlink '
                  'components. Generation creation journals remain validated separately by '
                  'referencedInstallations. Does not mutate selection, recover snapshots, '
                  'expire leases or authorize purge. Tests cover re-entry, partial rollback '
                  'and ten corrupt/missing/linked/unrelated selection cases. Find concrete '
                  'regressions or security/contract gaps, not style preferences. No new '
                  'dependency or abstraction. Do not certify complete retention or release.\n')
        for relative in files:
            source = (qualified / relative).read_text()
            if relative.endswith('/lifecycle-recovery.ts'):
                excerpt = source[source.index('export async function referencedInstallations('):source.index('export async function previewManagedPurge(')]
            elif relative.endswith('/folder-mod-bounds.ts'):
                excerpt = source[source.index('export async function assertNoSymlinkComponents('):source.index('/** Iteratively enumerate')]
            else:
                excerpt = source
            if not excerpt.strip():
                raise ValueError('Empty review source excerpt: ' + relative)
            prompt += '\nSOURCE EXCERPT ' + relative + ' FULL FILE SHA256 ' + hashlib.sha256(source.encode()).hexdigest() + '\n' + excerpt
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'tests/unit/modular-purge-retention.test.ts', 'tests/unit/modular-first-party-cli-recovery.test.ts',
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-storage-accounting':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Extend existing read-only retention '
                  'accounting to owned generation metadata and staging namespaces. No deletion, '
                  'quota policy or external cache discovery. Existing installation byte counting '
                  'is reused. Check accurate totals, no double counting, fail-closed paths, lock '
                  'cleanup and preserved behavior. 80 source/built-CLI tests and types pass; '
                  'new tests fail against old source. Find concrete defects, not style. Do not '
                  'certify complete retention or release.\n')
        for relative in ['packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/folder-mod-bounds.ts',
                         'tests/unit/modular-purge-retention.test.ts']:
            source = (qualified / relative).read_text()
            if relative.endswith('/lifecycle-recovery.ts'):
                source = source[source.index('export async function referencedInstallations('):source.index('export async function previewManagedPurge(')]
            elif relative.endswith('/folder-mod-bounds.ts'):
                source = source[source.index('export async function assertNoSymlinkComponents('):source.index('/** Iteratively enumerate')]
            if not source.strip():
                raise ValueError('Empty storage review excerpt: ' + relative)
            prompt += '\nSOURCE ' + relative + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/mod-kernel/src/lifecycle-recovery.ts',
            'tests/unit/modular-purge-retention.test.ts',
            'tests/unit/modular-first-party-cli-recovery.test.ts',
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'worktree-overlay-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/support-worktree/src/dependency-overlay.ts',
                 'packages/mod-worktrees/src/runtime.ts', 'tests/unit/worktree-pnpm-link.test.ts']
        prompt = ('Independent bounded review. No tools. Consolidate physical worktrees overlay '
                  'onto existing support-worktree owner, keeping mod setup failures thrown and '
                  'legacy shared defaults warning. A broken optional scoped dependency previously '
                  'skipped healthy siblings in shared path; red regression reproduced this. '
                  'Per-sibling catch fixes it. Optional entry failures now warn rather than being '
                  'silent in mod path. Check actual behavioral parity, error boundaries, candidate '
                  'workspace links and retained artifact behavior. 28 tests and real git worktree '
                  'Node imports passed. Find concrete regressions, not style. No new dependency '
                  'or install. Do not certify full modular release.\n')
        for relative in files:
            prompt += '\nCURRENT ' + relative + '\n' + (qualified / relative).read_text()
            prompt += '\nBEFORE ' + relative + '\n' + subprocess.run(
                ['git', 'show', 'HEAD:' + relative], cwd=qualified, capture_output=True,
                text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'payload-fixture-lifecycle':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Challenge this test-only change, '
                  'including whether it weakens the oracle. A recurring full-suite 30s timeout '
                  'was measured: creation 16.5s, actual production rejection 0.181s, cleanup '
                  '14.3s. Synchronous fixture I/O was worse and was reverted. Proposed change '
                  'uses beforeAll/afterAll for this single 8193-file fixture and keeps the real '
                  'production walker, exact count and rejection assertion. Existing testTimeout '
                  'and hookTimeout are each 30s, unchanged. Aggregate fixture+test time may now '
                  'exceed 30s: explicitly assess this tradeoff, not just passing counts. This '
                  'test checks file-count refusal, not a declared 30s end-to-end install budget. '
                  'Check failure cleanup, meaningful negative controls and false-green risks. '
                  'Temporary phase logging will be removed before final acceptance. Do not '
                  'certify the product or waive flaky tests.\n')
        for relative in ['vitest.config.ts', 'packages/mod-kernel/src/folder-mod-bounds.ts',
                         'tests/unit/modular-candidate-process.test.ts']:
            source = (qualified / relative).read_text()
            if relative.endswith('modular-candidate-process.test.ts'):
                source = source[source.index("  describe('installed payload file limit'"):source.index("  it('bounds descendants")]
            if not source.strip():
                raise ValueError('Empty payload review excerpt')
            prompt += '\nSOURCE ' + relative + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'tests/unit/modular-candidate-process.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'artifact-hydration-publication':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/support-worktree/src/dependency-overlay.ts',
                 'packages/mod-worktrees/src/runtime.ts', 'tests/unit/worktree-pnpm-link.test.ts']
        prompt = ('Independent bounded review. No tools. Fix shared worktree artifact copy: '
                  'EACCES left partial dist, then retry skipped it. Regression failed in both '
                  'legacy and mod lanes. Node 26 native cp also aborted on a cyclic link; use '
                  'cp filter for JS validation and cycle refusal, stage then publish complete '
                  'dist. Preserve existing candidate dist including dangling symlinks. Check '
                  'cleanup, errors, retries, source preservation, valid symlinks, and missing '
                  'behavior tests. This is local developer artifact hydration, not a hostile '
                  'filesystem sandbox or crash-recovery protocol. Existing default warns, '
                  'strict callers throw. No new dependencies. Find concrete bugs, not taste. '
                  'Do not certify the whole modular release.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-synth-plan-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/synth-plan.ts', 'packages/mod-forge/src/index.ts',
                 'packages/mod-forge/package.json', 'packages/forge/src/synth-plan.ts',
                 'tests/unit/synth-plan.test.ts']
        prompt = ('Independent bounded review. No tools. Move pure Forge synthesis decision '
                  'function and its types from legacy Forge into its existing physical owner '
                  'mod-forge. Function source is byte-identical, SHA256 '
                  'b0b1045d6bb449ac949550abf714f229c3155b36a0e36a2c39512d1a80ecce48. '
                  'Legacy public path reexports; runtime runner imports mod-forge directly. '
                  'Already declared/approved dependency, no install or new edge. Existing '
                  'behavior tests plus function identity and frozen-input tie-order checks '
                  'pass, as do owner build and repository typecheck. Challenge regression '
                  'risk, boundary fit, and evidence. Full Forge runtime ownership remains '
                  'unfinished. No whole-release certification.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nLEGACY PACKAGE\n' + (qualified / 'packages/forge/package.json').read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'packages/forge/src/forge.ts', 'docs/specs/modular-agon-runtime-contract.md'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-public-type-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/types.ts', 'packages/mod-forge/src/index.ts',
                 'packages/mod-forge/package.json', 'packages/core/package.json',
                 'packages/core/tsconfig.json', 'packages/core/src/models/types.ts',
                 'tests/unit/modular-forge-type-boundary.test.ts']
        prompt = ('Independent bounded review. No tools. Move Forge result/event/options '
                  'types into physical mod-forge; Core keeps type-only compatibility exports. '
                  'New internal Core -> mod-forge edge explicitly approved. Graph traced: '
                  'mod-forge closure does not reach Core. All moved declarations checked '
                  'byte-identical against parent d6c7d0bc. Owner build and repository '
                  'typecheck passed; full gates running. Test compiles built public imports, '
                  'checks symbol identity and definition path, and rejects malformed values. '
                  'Frozen inventory misassigns EngineResult by name to engine-runtime; '
                  'docs explicitly record its actual Forge scoring semantics and pending '
                  'ledger reconciliation. Do not certify complete Forge runtime migration '
                  'or release. Find concrete contract, packaging or regression defects.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'package-lock.json', 'docs/specs/modular-agon-runtime-contract.md'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'fitness-process-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/support-engine-runtime/src/process.ts',
                 'packages/support-verification/src/fitness-command.ts',
                 'packages/support-verification/package.json',
                 'packages/support-verification/tsconfig.json',
                 'tests/unit/process.test.ts', 'tests/unit/modular-fitness-process.test.ts']
        prompt = ('Independent bounded review. No tools. Fix fitness pre-abort and shell-only '
                  'cancellation by reusing the existing engine-runtime process runner. '
                  'Both bugs reproduced before fix: pre-abort creates marker, one-second '
                  'timeout waits 4068ms on descendant pipes. Independent stdout/stderr '
                  '1MiB clipping must not fail successful commands. New opt-in bounded '
                  'capture preserves that; existing combined hard output limit unchanged. '
                  'Default result fields unchanged. New workspace edge explicitly approved, '
                  'graph and receipt expected count updated 152 to 153, roadmap verifier '
                  'passes. 28 focused real-process tests plus typecheck pass. Full gates '
                  'running. Review cancellation, output decoding/limits, error contract, '
                  'cleanup, correctness and discriminating tests. No release certification.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'package-lock.json'], cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-corpus-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/corpus.ts', 'packages/forge/src/corpus.ts',
                 'packages/mod-forge/src/index.ts', 'packages/mod-forge/src/types.ts',
                 'tests/unit/forge-corpus.test.ts']
        prompt = ('Independent bounded review. No tools. Move all seven Forge corpus '
                  'functions from legacy Forge to existing physical owner mod-forge. '
                  'Inject storage path through createForgeCorpus(path); legacy facade '
                  'binds existing CORPUS_PATH and retains synchronous public exports. '
                  'No new dependencies. Seven function bodies compared equal after only '
                  'indent/export removal and CORPUS_PATH -> corpusPath substitution; '
                  'normalized SHA256 18f65c3285344c336778c66bcb4863965e27fc64f74b6db2ec0f1a29c0390455. '
                  'Six characterization tests passed on old implementation, same tests '
                  'plus owner-instance isolation passed after move, build/types pass. '
                  'Existing concurrency/corruption limitations are preserved and documented; '
                  'do not claim transactional storage, gauntlet wiring or complete release. '
                  'Find concrete regressions, boundary risks and missing parity checks.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'package-generator-drift':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['scripts/spec/generate-modular-agon-ownership.mjs',
                 'tests/unit/modular-package-graph.test.ts',
                 'packages/mod-plan/package.json']
        prompt = ('Independent bounded review. No tools. The authoritative package map '
                  'already includes approved Plan -> support-worktree. The old generator '
                  'lost that edge on regeneration. This one-line fix preserves it. '
                  'The new test runs the real generator in a VM, captures writes in memory, '
                  'and compares the complete map to checked-in evidence. It failed before '
                  'the fix and all 20 graph tests pass after. No new dependency or runtime '
                  'change. Find concrete correctness or test-isolation defects, not taste.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'gauntlet-validation-errors':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/forge/src/gauntlet.ts', 'tests/unit/gauntlet-validation.test.ts',
                 'packages/support-engine-runtime/src/process.ts']
        prompt = ('Independent bounded review. No tools. Before migrating gauntlet to '
                  'mod-forge, fix demonstrated false-positive validation: timeouts and '
                  'thrown process errors were counted as deterministic patch failures. '
                  'Real Node subprocess regression failed before timeout checks; two '
                  'mocked boundary exception cases failed before catch changes. Preserve '
                  'completed failure/failure/pass acceptance. Review this five-line '
                  'correction and tests. No extraction yet. Distinguish pre-existing '
                  'cancellation/filename issues from introduced defects; provide exact '
                  'evidence and smallest remedies. No full-release claim.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'gauntlet-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/gauntlet.ts', 'packages/forge/src/gauntlet.ts',
                 'packages/mod-forge/src/index.ts', 'packages/mod-forge/package.json',
                 'tests/unit/gauntlet-workflow.test.ts', 'tests/unit/gauntlet-validation.test.ts']
        prompt = ('Independent bounded ownership review. No tools. Move the complete '
                  'gauntlet workflow and validation into mod-forge. Legacy facade binds '
                  'existing worktree/fitness/logging effects; owner controls orchestration. '
                  'No dependencies added. Five workflow characterization cases passed '
                  'before the move, then all 25 workflow/safety cases passed after. '
                  'Function bodies compared exactly after only signature/runtime binding '
                  'normalization. Prior committed safety fix rejects timeouts, abort and '
                  'spawn errors and uses UUID filenames. Find introduced boundary, runtime '
                  'or compatibility defects and missing parity evidence. Physical Forge '
                  'competition does NOT yet invoke gauntlet; full workflow cancellation '
                  'and legacy fitness extraction remain documented work, not claimed done.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-scoring-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/scoring.ts',
                 'packages/core/src/signals/scoring.ts',
                 'packages/mod-forge/src/index.ts',
                 'tests/integration/scoring.test.ts',
                 'tests/unit/team-forge-winner.test.ts']
        prompt = ('Independent bounded ownership review. No tools. Move existing '
                  'Forge fitness score contracts and pure scoring functions from '
                  'Core to mod-forge; Core retains public compatibility exports. '
                  'Core already depends on mod-forge. No new dependency. Exact '
                  'function-body byte comparison passed. Same 25 scoring/winner '
                  'tests pass before and after, owner build and full typecheck pass. '
                  'Removing the failing-fitness guard from the built owner makes '
                  'the legacy-import test fail (97 instead of 0). Find introduced '
                  'boundary, compatibility or behavior defects. Full fitness '
                  'orchestration and physical competition integration remain open, '
                  'not claimed complete. Do not recommend taste-only changes.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'packages/core/src/models/types.ts',
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-fitness-quality-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/fitness.ts', 'packages/mod-forge/src/quality.ts',
                 'packages/forge/src/fitness.ts', 'packages/forge/src/quality.ts',
                 'packages/mod-forge/src/index.ts', 'tests/unit/runSyntaxCheck.test.ts']
        prompt = ('Independent bounded ownership review. No tools. Move full legacy '
                  'fitness and quality policy into mod-forge. Existing legacy facades '
                  'bind Git and syntax capabilities at call time. No dependency added. '
                  'All function bodies match the old ones after normalizing only '
                  'runtime parameter/member calls and syntax input type. 36 existing '
                  'syntax/real-Git Forge/finalize tests passed before and after quality '
                  'move. All 41 tests including gauntlet pass after fitness move, owner '
                  'build and full typecheck pass. Removing diffGatePass from the built '
                  'owner made the existing no-op Forge test fail; guard restored. '
                  'Find introduced contract/boundary defects, not style. Existing '
                  'optional-tool fallbacks are preserved. Full cancellation, physical '
                  'competition integration and legacy caller retirement remain open.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-post-fitness-diff':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/implementation.ts',
                 'tests/unit/modular-forge-settings.test.ts']
        prompt = ('Independent focused regression review. No tools. Physical Forge '
                  'captured its candidate diff BEFORE fitness ran, omitting files '
                  'generated by compilers/formatters/snapshot checks. Legacy fitness '
                  'already captures AFTER fitness. Move only diff capture/counts '
                  'after measured fitness; do not change selection/scoring contracts. '
                  'Existing real-worktree test now includes a fitness command that '
                  'writes generated.txt. Before fix it failed: expected 2 changed '
                  'files, got 1. After fix whole settings suite and typecheck pass. '
                  'Review the diff for introduced defects. Full modular acceptance '
                  'is not claimed. Broader scoring/gauntlet parity remains open.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-fitness-cancellation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/fitness.ts', 'packages/mod-forge/src/quality.ts',
                 'packages/forge/src/fitness.ts', 'tests/unit/modular-fitness-process.test.ts',
                 'tests/unit/gauntlet-workflow.test.ts']
        callers = ['packages/forge/src/stages-impl.ts', 'packages/forge/src/forge.ts',
                   'packages/forge/src/synthesis.ts', 'packages/forge/src/team-forge.ts',
                   'packages/mod-forge/src/gauntlet.ts']
        prompt = ('Review this bounded cancellation fix for introduced defects. No tools. '
                  'Fitness ignored workflow cancellation; lint/style fallback also swallowed it. '
                  'Add optional signal, forward to the existing process owner, preserve abort '
                  'reason at async boundaries, and pass signals from all existing fitness callers. '
                  'Keep optional-tool fallback for non-abort failures. Baseline disposal remains '
                  'in finally. Four new tests failed before fix. Real child cancellation at '
                  'fitness/lint/style and real baseline worktree cleanup pass afterward, along '
                  'with existing Forge/finalization/gauntlet tests and types. Removing only '
                  'child-signal forwarding makes the live-process test fail, not just a mock. '
                  'Mutation restored. Broader orchestration phase cancellation and synchronous '
                  'syntax interruption remain open; this is not full release acceptance.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF INCLUDING CALLER CONTEXT\n' + subprocess.run(
            ['git', 'diff', '--unified=15', 'HEAD', '--', *files, *callers,
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-phase-cancellation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/implementation.ts', 'packages/mod-forge/src/gauntlet.ts',
                 'tests/unit/gauntlet-workflow.test.ts', 'tests/unit/modular-forge-settings.test.ts']
        prompt = ('Independent bounded review, no tools. Prior committed fitness cancellation '
                  'now kills real subprocesses. This diff stops subsequent orchestration phases: '
                  'physical Forge checks caller cancellation between awaits; internal quorum '
                  'cancellation remains candidate-only and must keep its winner. Gauntlet checks '
                  'entry and breaker/validation/fitness/repair boundaries while keeping clean '
                  'worktree disposal. Five gauntlet cases failed before, three physical Forge '
                  'cases failed before, and internal early-finalization passed before. All now '
                  'pass with existing regressions and typecheck. Source and real fixture evidence '
                  'are separate from full release acceptance. Inspect introduced safety/control '
                  'flow defects and missing discriminating cases. Legacy orchestration, synchronous '
                  'syntax interruption and full physical parity remain open.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files,
            'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-terminal-status':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/implementation.ts', 'packages/cli/src/run-record-host.ts',
                 'tests/unit/modular-run-record-exit.test.ts']
        prompt = ('Independent bounded lifecycle review, no tools. Forge owns its semantic run '
                  'outcome; the host owns persistence and retry. Previously cancellation or '
                  'invalid Git left a run pending until host exit. Five real isolated run-store '
                  'tests failed before and now pass; success and cancellation after finish '
                  'are preservation controls. The outer try/finally submits failure after arena '
                  'cleanup, unless an outcome was already submitted. Existing host retry behavior '
                  'must remain. Inspect correctness and missing discriminating cases, especially '
                  'persistence failure, cancellation, cleanup and already-completed outcomes. '
                  '47 focused tests and typecheck pass. This is not full release acceptance.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF (whitespace ignored for outer try indentation)\n' + subprocess.run(
            ['git', 'diff', '--ignore-all-space', 'HEAD', '--', *files,
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-candidate-drain':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/implementation.ts', 'tests/unit/modular-forge-settings.test.ts',
                 'packages/support-worktree/src/forge-arena.ts', 'packages/support-verification/src/fitness-command.ts']
        prompt = ('Independent bounded review, no tools. A real Git regression reproduced '
                  'physical Forge cleaning all worktrees after one candidate Git error while '
                  'a controlled sibling was still running. Existing dispatch errors are caught, '
                  'but fitness/diff errors were outside that catch. Fix retains Promise.all '
                  'success and first-error behavior, drains attempts with allSettled on error '
                  'before rethrowing. No new timeout, cancellation, winner or partial-success '
                  'policy is introduced. 56 focused tests and types pass; regression failed '
                  'before. Inspect safety, introduced behavior and discriminating evidence. '
                  'Remaining legacy-to-physical Forge parity is a separate open requirement.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF (whitespace ignored)\n' + subprocess.run(
            ['git', 'diff', '--ignore-all-space', 'HEAD', '--', *files,
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-stage-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/stages.ts', 'packages/forge/src/stages-impl.ts',
                 'packages/mod-forge/src/fitness.ts', 'packages/mod-forge/src/index.ts',
                 'packages/forge/src/types-impl.ts', 'tests/unit/forge-timeout.test.ts']
        prompt = ('Independent bounded ownership extraction review, no tools. Stage attempt, '
                  'baseline, stage1 and stage2 move from legacy forge into mod-forge. Canonical '
                  'factory injects only host effects plus existing ForgeFitnessRuntime; legacy '
                  'file becomes a narrow binding. StageResult/WorktreeEntry shapes move unchanged. '
                  'A local exact text comparison of all four async bodies, after only export/type '
                  'name/indent changes, is identical (normalized SHA256 '
                  '821730a4464e3e20caed085bfb9573511d70209f74be92064f28489d39f709c2). '
                  '52 tests passed including real Git Forge E2E, timeout harvesting and baseline '
                  'cancellation; independent owner build and repository typecheck pass. Owner '
                  'identity failed before; constructor no-effects test added. Inspect boundary, '
                  'typing, wiring and introduced semantic changes. Existing legacy timing issues '
                  'are not silently changed here. Top-level orchestration and physical feature '
                  'parity remain open; do not infer release acceptance from extraction.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nTYPE SHAPE DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-forge/src/types.ts',
             'packages/forge/src/types-impl.ts', 'docs/specs/modular-agon-runtime-contract.md'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nLEGACY SOURCE BEFORE\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/forge/src/stages-impl.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-prompt-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/prompts.ts', 'packages/mod-forge/src/stage-context.ts',
                 'packages/core/src/blocks/prompt-builder.ts',
                 'packages/core/src/models/context-parts.ts', 'packages/mod-forge/src/index.ts',
                 'tests/unit/context-parts.test.ts']
        prompt = ('Independent bounded ownership review, no tools. Four Forge prompt builders '
                  'and two stage-context helpers move from Core to mod-forge. Core keeps public '
                  'compatibility exports. Critique type moves unchanged. No new dependencies. '
                  'Exact source comparison confirms unchanged function bodies and prompt strings. '
                  '69 focused tests including real Git Forge E2E and repository typecheck pass; '
                  'owner-identity checks failed before extraction. Inspect introduced defects, '
                  'exports and ownership boundaries. Do not certify full runtime modularity.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/core/src', 'packages/mod-forge/src',
             'tests/unit/context-parts.test.ts', 'docs/specs/modular-agon-runtime-contract.md'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-refinement-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        files = ['packages/mod-forge/src/synthesis.ts', 'packages/mod-forge/src/errors.ts',
                 'packages/forge/src/synthesis.ts', 'packages/forge/src/fitness.ts',
                 'packages/mod-forge/src/fitness.ts', 'packages/core/src/models/errors.ts',
                 'packages/forge/src/types-impl.ts']
        prompt = ('Independent bounded ownership review. No tools. Existing Forge winner refinement '
                  'moves into mod-forge/createForgeSynthesis, binding Git and fitness effects. '
                  'Legacy file becomes a facade. Critique parsing and algorithm are unchanged; '
                  'exact normalized body SHA7361813214f77ffa40005aa23519526edc852224ef7637a20baab37bdf240a59. '
                  'SynthesisResult and FitnessError move to owner with compatibility reexports. '
                  '74 focused tests and owner build/typecheck passed. New four real-worktree '
                  'tests passed against legacy before move (agent/exec and pass/fail fitness); '
                  'owner identity test failed before. Inspect introduced defects, host boundary, '
                  'cleanup, API shape and test discrimination. Separate pre-existing behavior '
                  'from introduced defects. Top-level Forge cutover is not complete.\n')
        for relative in files:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/core/src/models/errors.ts',
             'packages/forge/src', 'packages/mod-forge/src', 'tests/integration/forge-e2e.test.ts',
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-manifest-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded extraction review. No tools. Forge manifest/history '
                  'read/write/update moves into mod-forge, with explicit runsDir and the same '
                  'withFileLock effect. Legacy module is a binding. Keep local atomic rename '
                  'and history replacement inside the ratings purge lock. No dependencies added. '
                  'Focused build/types, ratings protection and real Forge E2E passed. The old '
                  'VM-transpiled lock oracle now calls the real owner API and retains deferred '
                  'publication checks; deliberately bypassing the lock fails on changed history '
                  'bytes. Mutation restored. Inspect actual introduced defects, host effects, '
                  'historical-reader API, locks and missing discriminating tests. Do not claim '
                  'whole-project acceptance or attribute pre-existing behavior to this move.\n')
        for relative in ['packages/mod-forge/src/manifest.ts', 'packages/forge/src/manifest.ts',
                         'packages/support-persistence/src/file-lock.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/forge/src/manifest.ts',
             'packages/mod-forge/src/index.ts', 'tests/unit/modular-ratings-protection.test.ts',
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'result-envelope-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded ownership review. No tools. The existing versioned '
                  'result writer used by Forge/TeamForge/Goal moves from legacy forge to '
                  'support-persistence. Only implementation change is the sibling import of '
                  'createPersistenceEnvelope; legacy export preserves identity. No new dependency. '
                  'Inspect introduced behavior, public boundary, envelope fields, raw-result '
                  'preservation and test discrimination. Existing compatibility runtime identity '
                  'is unchanged and is not claimed as final generation-bound acceptance.\n')
        for relative in ['packages/support-persistence/src/result-envelope.ts',
                         'packages/support-persistence/src/persisted-envelope.ts',
                         'packages/forge/src/result-envelope.ts',
                         'tests/unit/forge-result-bundle.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/forge/src/result-envelope.ts',
             'packages/support-persistence/src/index.ts', 'tests/unit/forge-result-bundle.test.ts',
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'winner-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded ownership review. No tools. Shared deterministic '
                  'determineWinner moves from Core synthesis-utils to support-judge, not '
                  'mod-forge, because both Forge and AgentTeam use it. Core reexports the '
                  'same function; legacy Forge retains spread=8 wrapper. Minimal structural '
                  'ScoredCandidate replaces the Core EngineResult type; body unchanged. '
                  'No dependency edge added. 117 focused tests and typecheck passed. '
                  'Owner identity failed before; six comparison dimensions, nonmutation, '
                  'zero score and exact spread are covered. Removing positive-score filter '
                  'makes the zero-score test fail; mutation restored. Inspect introduced '
                  'defects, shared ownership, public type compatibility and test limits.\n')
        for relative in ['packages/support-judge/src/deterministic-ranking.ts',
                         'packages/core/src/cesar/synthesis-utils.ts', 'packages/forge/src/stages.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/core/src/cesar/synthesis-utils.ts',
             'packages/support-judge/src/index.ts', 'tests/integration/forge.test.ts',
             'docs/specs/modular-agon-runtime-contract.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-workflow-cutover':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent Forge ownership/cutover review. No tools. Source is a frozen '
                  'uncommitted increment on 684a548a. Legacy runForge moved into mod-forge '
                  'createForgeWorkflow with injected host effects; legacy export binds it. '
                  'Generated competition now invokes this workflow instead of its second loop. '
                  'Preserve legacy policy: isolated candidate failures, fitness harvesting of '
                  'failed dispatches with patches, cancellation rejection, tracked dirty snapshots. '
                  'Prior generated behavior drift is not authoritative. Verify introduced bugs, '
                  'authority/revocation, cancellation/draining, persisted results, option mapping '
                  'and public boundary mistakes. Distinguish inherited defects. 105 focused '
                  'tests passed; repository-wide gate is pending. Known unresolved: generated '
                  'dirtySourceExcluded field needs truthful replacement; source callback '
                  'composition needs scrutiny. Do not certify release or assume tests prove '
                  'ownership. Give exact source evidence and smallest corrections.\n')
        for relative in ['packages/mod-forge/src/workflow.ts',
                         'packages/mod-forge/src/competition.ts',
                         'packages/mod-forge/src/host.ts',
                         'packages/core/src/blocks/forge-host.ts',
                         'packages/support-engine-runtime/src/adapter-guard.ts',
                         'tests/helpers/forge-host.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-forge/src/stages.ts',
             'packages/mod-forge/src/fitness.ts', 'packages/cli/src/first-party-services.ts',
             'packages/mcp/src/first-party-services.ts', 'packages/mcp/src/surface-authority.ts',
             'packages/cli/src/surface-authority-runtime.ts',
             'tests/unit/forge-finalize.test.ts', 'tests/unit/modular-forge-settings.test.ts',
             'tests/unit/modular-run-record-exit.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-generation-inventory':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded retention inventory review. No tools. Review the '
                  'increment on 36d358c1: existing validated installation reference scan '
                  'now also returns generation inventory and the same active leases. '
                  'The exported referencedInstallations API still returns its original map. '
                  'ManagedRetentionInspector reports generation metadata bytes, selected '
                  'state, nullable installation ID, committed creation transaction and '
                  'process/artifact lease IDs. Existing lifecycle-then-generation fences '
                  'remain. This is reporting only: no expiry/default policy or deletion. '
                  'Check scope/identity, shared payload double counting, validation, '
                  'rollback behavior, missing tests and unintended purge behavior changes. '
                  'Distinguish inherited flaws. Do not certify complete retention or release.\n')
        source = (qualified / 'packages/mod-kernel/src/lifecycle-recovery.ts').read_text()
        prompt += '\nINVENTORY AND INSPECTOR\n' + source[source.index('async function retainedGenerationInventory'):source.index('export async function previewManagedPurge')]
        files = ['packages/mod-kernel/src/lifecycle-recovery.ts',
                 'tests/unit/modular-purge-retention.test.ts',
                 'tests/unit/modular-first-party-cli-recovery.test.ts',
                 'docs/specs/modular-agon-runtime-contract.md']
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--', *files],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'result-owner-kill-list':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded acceptance verifier review. No tools. KL-013 '
                  'is currently false-red because result persistence moved in b50ad2c6 '
                  'from Forge to support-persistence, leaving a compatibility export. '
                  'Review the fix: inspect the real producer, keep the facade binding '
                  'check, require envelope creation and disk publication, mutate each '
                  'in existing self-tests. No runtime code changes. Check whether this '
                  'weakens an oracle or creates false-green cases in the changed scope. '
                  'Regex drift guards are not claimed as full semantic proof. Existing '
                  'behavior tests write actual owner-tagged result envelopes. Distinguish '
                  'inherited verifier limitations. Do not certify release.\n')
        for relative in ['scripts/spec/verify-modular-kill-list.mjs',
                         'packages/support-persistence/src/result-envelope.ts',
                         'packages/support-persistence/src/index.ts',
                         'packages/forge/src/result-envelope.ts',
                         'tests/unit/forge-result-bundle.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'scripts/spec/verify-modular-kill-list.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-completion-design':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded design challenge. No tools. Review the proposal '
                  'against the supplied source. Choose the smallest existing lifecycle '
                  'extension that meets the ORIGINAL retention requirement. Challenge '
                  'rollback-window semantics, missing receipt repair after retirement, '
                  'cache ownership, crash commit point, and accidental new requirements. '
                  'Compare reuse of host garbage-collect journal with typed lifecycle '
                  'purge targets. Give concrete changes, not a new framework. No release '
                  'certification; distinguish verified source facts from design inference.\n')
        prompt += (output / 'retention-completion-design.md').read_text()
        for relative in ['packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/host-rollback.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-kernel/src/durable-host.ts').read_text()
        prompt += '\nHOST RECOVERY\n' + source[source.index('  async #hasBoundTerminalReceipt'):source.index('  async #validateSelectedJournal')]
    if review_id == 'retention-receipt-binding':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. A prerequisite for retention '
                  'is truthful terminal receipts. Four real-file regression tests fail '
                  'before the one-line change: a schema-valid receipt with different '
                  'operation, base generation, candidate lock or steps incorrectly '
                  'suppresses receipt reconstruction. Compare complete parsed journal '
                  'canonical JSON instead of three fields. Check redaction, recovery '
                  'timestamps, restart-required receipts and legitimate historical '
                  'evidence. No collection behavior added. Find actionable regressions '
                  'in this patch; do not certify retention or release.\n')
        for relative in ['packages/mod-kernel/src/durable-host.ts',
                         'packages/mod-kernel/src/host-observability.ts',
                         'tests/unit/modular-host-receipts.test.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/mod-kernel/src/durable-host.ts', 'tests/unit/modular-host-receipts.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id in ('retention-rollback-window', 'retention-selection-links'):
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded implementation review. No tools. This adds explicit '
                  'rollback-window inspection to existing fenced retention inspector and '
                  'CLI --rollback-window-ms. It is a precursor to collection, NOT collection '
                  'completion. No default duration, expiry writes or deletion. Selection '
                  'history protects the generation LEFT by a successful selection; original '
                  'bound receipts or current pointer provide actual selectedAt. Recovered '
                  'receipt timestamps are not trusted. Unknown/incomplete timing retains. '
                  'Check history binding, rollback, clock handling, lock cleanup, CLI parsing '
                  'and compatibility. The original requirement protects the prior generation '
                  'until the window closes, not forever. Find source-grounded flaws.\n')
        for relative in ['packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/host-rollback.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', 'HEAD', '--',
            'packages/mod-kernel/src/lifecycle-recovery.ts', 'packages/cli/src/commands/mod.ts',
            'packages/mod-kernel/src/durable-host.ts', 'packages/mod-kernel/src/host-rollback.ts',
            'tests/unit/modular-purge-retention.test.ts', 'tests/unit/modular-first-party-cli-recovery.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        if review_id == 'retention-selection-links':
            prompt += ('\nArchitecture extension after the earlier review: completed commit '
                       'and rollback receipts now contain optional previousSelection pointer. '
                       'No journal schema change and no extra journal or receipt type. '
                       'Inspection walks backwards from current pointer through exact links, '
                       'using only the first/latest departure of each generation. Legacy, '
                       'missing or reconstructed receipts without links stop the chain; older '
                       'departures remain unknown/protected. Full collection is still unfinished. '
                       'Challenge missing/reordered/repeated selections and backward compatibility.\n')
    if review_id == 'retention-collection-protocol':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded implementation review. No tools. Review the new '
                  'explicit generation collection and its historical recovery. This is WIP '
                  'toward the accepted retention requirement, not release acceptance. Quota '
                  'selection, cache accounting and CLI projection are still open. Those are '
                  'known gaps, not requests to remove requirements. Check destructive effects, '
                  'exact approval, lease races, crash/retry, journal binding, receipt loss, '
                  'rollback, installation recovery and compatibility with ordinary purge. '
                  'Only explicit collection deletes bytes; boot must never initiate deletion. '
                  'Current focused suite81tests and types pass. Find concrete flaws and '
                  'minimal fixes using existing owners, not a new lifecycle manager.\n')
        for relative in ['packages/mod-kernel/src/generation-retirement.ts',
                         'packages/mod-kernel/src/host-contracts.ts',
                         'packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/durable-host.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nTEST DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'tests/unit/modular-purge-retention.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-collection-cli':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the CLI extension and two '
                  'new protocol behaviors: explicit cancellation of untouched pending targets, '
                  'and shared execution refusal for retired IDs even if valid old bytes are '
                  'copied back. Collection requires exact saved-plan approval. Cancellation '
                  'may finish already staged removal, never delete pending originals. '
                  'Ordinary retained installation payloads stay intact. Previous protocol '
                  'review was locally reproduced and fixed; do not demand unrelated changes '
                  'to ordinary boot transaction rollback cleanup. No new retention collection '
                  'or quarantine deletion may start on boot. Quota/cache/payload collection '
                  'remain known unfinished requirements, not waived. Find concrete new '
                  'defects, privacy/path/approval problems and missing user behavior tests. '
                  'The existing host tree is operator-owned, not a sandbox against hostile '
                  'same-user filesystem mutation. Five review regressions plus cancellation '
                  'and copied-back tests pass in224focused tests. Built CLI run is pending.\n')
        for relative in ['packages/cli/src/commands/mod.ts',
                         'packages/mod-kernel/src/generation-retirement.ts']:
            prompt += '\nSOURCE ' + relative + '\n' + (qualified / relative).read_text()
        lifecycle = (qualified / 'packages/mod-kernel/src/lifecycle-recovery.ts').read_text()
        prompt += '\nCOLLECTION IMPLEMENTATION\n' + lifecycle[
            lifecycle.index('async function captureRetirementEvidence'):
            lifecycle.index('export async function previewManagedPurge')]
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-kernel/src/durable-host.ts',
             'tests/unit/modular-first-party-cli-recovery.test.ts',
             'tests/unit/modular-purge-retention.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-evidence-accounting':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review additive host-root logical-byte '
                  'accounting in the existing retention inspector. It counts existing storage '
                  'and installation groups once and adds all other retained root entries; '
                  'only locks are explicitly excluded. External caches remain outside this '
                  'named scope. No deletion, quota selection or cache collection is added. '
                  'Those remain required later. Check incorrect totals, missed files, links, '
                  'overflow, directory races and error/lock cleanup. Existing operator-owned '
                  'tree model is not a sandbox against hostile same-user mutation. Do not '
                  'certify release completion. Find concrete defects and discriminating tests; '
                  'prefer existing owners and no parallel inventory service.\n')
        lifecycle = (qualified / 'packages/mod-kernel/src/lifecycle-recovery.ts').read_text()
        prompt += '\nREPORT AND INSPECTOR\n' + lifecycle[
            lifecycle.index('export interface ManagedRetentionReport'):
            lifecycle.index('async function captureRetirementEvidence')]
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-kernel/src/lifecycle-recovery.ts',
             'tests/unit/modular-purge-retention.test.ts',
             'tests/unit/modular-first-party-cli-recovery.test.ts',
             'docs/specs/modular-agon-runtime-contract.md'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-quota-transition':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded architecture challenge. No tools. Help finish the '
                  'ORIGINAL quota retention requirement, not invent a broader storage product. '
                  'Compare both proposed compositions against source. Find minimal viable '
                  'approval/retry ownership, cache-first ordering, conditional payload safety, '
                  'shortfall reporting and test obligations. Do not silently drop cache or '
                  'payload collection. Prefer existing owners; no new GC manager/framework. '
                  'Mark source facts versus inferred design choices. Give a concrete next '
                  'implementation boundary, not a generic checklist.\n')
        design = (output / 'retention-completion-design.md').read_text()
        prompt += design[design.index('## Quota-to-cleanup transition proposal'):]
        prompt += '\nSOURCE lifecycle-recovery.ts\n' + (qualified / 'packages/mod-kernel/src/lifecycle-recovery.ts').read_text()
        prompt += '\nSOURCE generation-retirement.ts\n' + (qualified / 'packages/mod-kernel/src/generation-retirement.ts').read_text()
        catalog = (qualified / 'packages/support-engine-catalog/src/engine-registry.ts').read_text()
        prompt += '\nCACHE OWNER\n' + catalog[:catalog.index('export class EngineRegistry')]
        prompt += '\nCLI SAVED PLANS\n' + (qualified / 'packages/cli/src/commands/mod.ts').read_text()[:10000]
    if review_id == 'retention-immutable-payload':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the immutable installation purge fix. '
                  'Native macOS rename failed EACCES on an installed root at mode 0555 after its last '
                  'generation retired. The existing purge owner now temporarily changes only that '
                  'installation root to 0700 before quarantine, restoring 0555 on a failed rename. '
                  'Check recovery, reference protection, errors, replacement preservation and tests. '
                  'Quota composition is future work, not claimed complete. Find concrete defects, '
                  'not speculative machinery. No release certification.\n')
        for relative in ['packages/mod-kernel/src/host-io.ts',
                         'packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/managed-lifecycle.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-kernel/src/host-io.ts',
             'packages/mod-kernel/src/lifecycle-recovery.ts',
             'tests/unit/modular-purge-retention.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-binary-cache-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review binary-cache retention owner APIs '
                  'and serialized cache replacement. Only cache/binaries.json is disposable. '
                  'Explicit home binds retry; inspection captures inode/timestamps/size; eviction '
                  'rejects replacement identity, links, wrong homes and contention. Dead-writer '
                  'recovery reuses the existing kernel fence, now publicly exported through the '
                  'catalog existing kernel peer. No new dependency or second lock. Tests pass78 '
                  'plus types. Parent quota journal is NOT yet implemented: it must persist a '
                  'consumed cache attempt before eviction and report ambiguous outcome after '
                  'interruption, never chase replacements. Do not certify the release. Find '
                  'concrete defects in current APIs and integration constraints, not a generic '
                  'cache framework. Same-user arbitrary hostile mutation is not sandboxed.\n')
        for relative in ['packages/support-engine-catalog/src/engine-registry.ts',
                         'packages/support-engine-catalog/package.json',
                         'packages/mod-kernel/src/writer-lock.ts',
                         'tests/unit/engine-registry-binary-path.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-kernel/src/index.ts',
             'packages/support-engine-catalog/src/engine-registry.ts',
             'tests/unit/engine-registry-binary-path.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-quota-coordinator':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent adversarial implementation review. No tools. Review the quota '
                  'coordinator, conditional payload guards and purge cancellation. Existing '
                  'generation/purge owners retain child journals. Parent persists exact child '
                  'plans in protected retention-transactions, using its own writer fence so '
                  'children can take their existing lifecycle/host fences. Cache attempt is '
                  'consumed before eviction; ambiguity is never retried against replacement '
                  'bytes. Terminal stop/cancel/exhaustion never wakes later. Inspect safety, '
                  'progress, validation, recovery, estimates and claims. All201 focused tests '
                  'and types pass; CLI integration, broader fault matrix and full gates are '
                  'NOT complete. No release certification. Verify source facts; prefer fixes '
                  'within existing owners, not another GC framework. Model assumes cooperative '
                  'managed writers, not a sandbox against arbitrary same-user filesystem edits.\n')
        for relative in ['packages/mod-kernel/src/quota-retention.ts',
                         'packages/mod-kernel/src/lifecycle-recovery.ts',
                         'packages/mod-kernel/src/generation-retirement.ts',
                         'tests/unit/modular-quota-retention.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
    if review_id == 'payload-identity-fixture-lifecycle':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded test-lifecycle review. No tools. Review only the supplied '
                  'test diff, not the whole release. An unchanged4079-file test timed out at30s '
                  'in the full suite, passed alone in2.699s and with six filesystem suites in15.718s. '
                  'Diagnostic concurrent run measured setup7.862s, assertions2.293s, cleanup6.389s. '
                  'The fix moves setup/cleanup into existing30s hooks without changing assertions, '
                  'file count, production code or30s test timeout. It drains setup and verification '
                  'before cleanup. Check timeout/failure cleanup, weakening of oracles and regressions. '
                  'Do not certify the release or assume original timeout phase was directly measured.\n')
        for relative in ['tests/unit/modular-candidate-process.test.ts', 'vitest.config.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'tests/unit/modular-candidate-process.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'first-party-owner-generator-repair':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. The first-party generator --check failed '
                  'on Plan and Forge after their earlier physical extraction. Its stale template '
                  'would delete current public exports and Forge engine.dispatch permission. '
                  'Restore the current authored public surface in the existing generator, retain '
                  'Plan worktree declaration, and list Forge declarations already shipped by its '
                  'npm files=dist in its manifest pack allowlist. No new package or behavior. '
                  'Focused regression failed before and passes after. Find concrete loss of '
                  'exports, declaration omissions, capability drift or weak oracles. This is not '
                  'release certification; full qualification is pending.\n')
        for relative in ['scripts/spec/generate-modular-first-party-packages.mjs',
                         'packages/mod-forge/src/index.ts', 'packages/mod-plan/src/index.ts',
                         'packages/mod-forge/package.json']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'scripts/spec/generate-modular-first-party-packages.mjs',
            'packages/mod-forge/agon.mod.json', 'packages/mod-forge/src/index.ts',
            'packages/mod-plan/src/index.ts', 'tests/unit/modular-forge-settings.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'support-metadata-contract-repair':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. A committed boundary gate failed because '
                  'its expected support graph omitted verification -> engine-runtime, already approved '
                  'and used by fitness-command. The metadata generator also omitted this edge and '
                  'would revert engine-catalog kernel peer >=1.0.0 <2 to the prerelease range. '
                  'Repair generator and independent boundary expectations, normalize verification '
                  'tsconfig reference order, and add --check regression to the existing boundary test. '
                  'The test failed before at catalog package drift. Inspect for concrete regressions '
                  'and weak evidence. Existing self-test now removes each declared edge and adds '
                  'an unexpected edge per package. No new dependencies or runtime behavior. '
                  'Do not certify the whole release.\n')
        paths = ['scripts/spec/generate-modular-support-package-metadata.mjs',
                 'scripts/spec/verify-modular-support-boundaries.mjs',
                 'tests/unit/modular-source-boundaries.test.ts',
                 'packages/support-verification/package.json',
                 'packages/support-verification/tsconfig.json',
                 'packages/support-verification/src/fitness-command.ts',
                 'packages/support-engine-catalog/package.json']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'release-artifact-coverage':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. S9 qualifier expected50 artifacts, '
                  'but the existing release-set generator packs49 modular packages, one launcher '
                  'and one existing dedup compatibility package (51). It verifies exact identities '
                  'and packed content separately. Tests previously mirrored stale50. The regression '
                  'now uses the actual committed BOM count and adds missing/extra faults. Before '
                  'fix, valid51 was rejected and missing50 accepted; both tests failed. The fix '
                  'updates the independent qualification count to51, preserves every other gate '
                  'and adds self-test controls. Check for weakened acceptance or concrete defects. '
                  'Count alone is not identity/completeness proof; required release-set gate owns '
                  'that. No runtime or dependency changes. Do not certify the release.\n')
        for relative in ['scripts/spec/qualify-modular-agon-slice9.mjs',
                         'scripts/spec/verify-modular-release-set.mjs',
                         'tests/unit/modular-platform-matrix.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'scripts/spec/qualify-modular-agon-slice9.mjs', 'tests/unit/modular-platform-matrix.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'fitness-pid-publication':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded test review. No tools. Full suite failed because the '
                  'Prettier cancellation test saw its child PID alive after1500ms. Original PID '
                  'was not recorded, so its precise cause is unproven. Source contains a race: '
                  'it waits only for PID file existence, aborts the writer, then Number(empty) '
                  'becomes0 and process.kill(0,0) probes the test process group. Controlled fixture '
                  'creates empty file then publishes PID after250ms, deterministically reproducing '
                  'the same assertion failure before repair. Repair waits for complete newline '
                  'terminated positive PID before abort and preserves all shutdown deadlines and '
                  'runtime code. Same readiness guard protects resistant-child cases. Inspect '
                  'for weakened process cancellation evidence, leaks or new flakiness. Do not '
                  'claim this proves the original unlogged PID was zero or certify release.\n')
        for relative in ['tests/unit/modular-fitness-process.test.ts',
                         'packages/support-verification/src/fitness-command.ts',
                         'packages/support-engine-runtime/src/process.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'tests/unit/modular-fitness-process.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'surface-owner-identity-refresh':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Clean S9 qualification failed generated '
                  'artifact replay: first-party-surface-catalog.ts retains stale identity hashes '
                  'after earlier Plan/Forge manifests and Verification package metadata changes. '
                  'Existing generator is unchanged. Regeneration changes only48 contentHash values '
                  '(Plan30,Forge16,Verification2), with all450entries otherwise deep-equal to HEAD. '
                  'Added a real read-only generator --check invocation to existing surface suite. '
                  'It failed before refresh and passes after; full isolated generated replay and '
                  'its existing negative controls pass. Inspect concrete regression or weakened '
                  'evidence. This is a hash refresh, not proof of complete runtime ownership.\n')
        for relative in ['scripts/spec/generate-modular-surface-catalog.mjs',
                         'scripts/spec/verify-modular-generated-artifacts.mjs',
                         'tests/unit/modular-surface-generation.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-kernel/src/generated/first-party-surface-catalog.ts',
            'tests/unit/modular-surface-generation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'directory-fixture-lifecycle':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review only the empty-directory '
                  'entry-limit fixture change. Clean checkout failed its 30s test timeout; '
                  'unchanged isolated test passed389ms. Instrumented full-suite slow success '
                  'measured setup12844ms, traversal94ms, cleanup7047ms. The exact original '
                  'timeout phase is unknown, so this is fixture hardening, not a proven '
                  'production fix. New setup batches32 actual mkdir calls, uses existing '
                  'beforeAll/afterAll lifecycle pattern in this file, drains promises before '
                  'cleanup, and asserts4097 entries before the same real walker rejection. '
                  'Both hook and test budgets remain30s. Runtime unchanged. Check cleanup, '
                  'timeout/error propagation and whether evidence was weakened. Do not '
                  'certify release acceptance or assume missing validation passed.\n')
        for relative in ['tests/unit/modular-candidate-process.test.ts',
                         'packages/mod-kernel/src/folder-mod-bounds.ts',
                         'packages/mod-kernel/src/folder-mod-limits.ts', 'vitest.config.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'tests/unit/modular-candidate-process.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'acceptance-boundary-662b2edb':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent acceptance-boundary review. No tools. Current commit '
                  '662b2edb936a6c5821ed4331c4220d159eb744a3 completed all25 clean '
                  'checkout execution steps, including packed install, full tests, '
                  'performance/load, and clean contamination checks. Overall acceptance '
                  'correctly remains false: review subject mismatch and platform matrix '
                  'diagnostic1passed/11blocked rather than3native/9blocked. Quota CLI '
                  'composition is still incomplete and security upgrades remain pending. '
                  'This is NOT a request to approve the release. Inspect the supplied '
                  'acceptance machinery for concrete false-green or false-red defects, '
                  'especially committed subject binding, review records, generated '
                  'artifacts, clean-checkout coverage and external blockers. Identify '
                  'locally fixable defects with exact source evidence; distinguish '
                  'requirements from optional hardening. Do not invent executed tests.\n')
        for relative in ['scripts/spec/qualify-modular-agon-slice9.mjs',
                         'scripts/spec/slice1b-qualification-gates.mjs',
                         'scripts/spec/assess-modular-agon-slices.mjs',
                         'scripts/spec/verify-modular-platform-matrix.mjs',
                         'docs/specs/modular-agon-acceptance-roadmap.md']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        receipt = json.loads((output / '662b2edb-clean-release-qualification.log').read_text())
        summary = {key: receipt[key] for key in ['subject', 'contamination', 'graph',
                   'coverage', 'reviewEvidence', 'passed']}
        summary['steps'] = [{key: step[key] for key in ['id', 'status', 'passed']}
                            for step in receipt['cleanCheckoutSteps']]
        prompt += '\nACTUAL RECEIPT SUMMARY\n' + json.dumps(summary, indent=2)
    if review_id == 'slice-receipt-git-binding':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the slice assessor repair, '
                  'not the full release. Original checker accepted untracked receipt booleans '
                  'claiming clean HEAD and required a circular exact HEAD reference. Real Git '
                  'negative control reproduced the false pass. Repair reads committed metadata '
                  'at a pinned evidence commit, rejects dirty/ignored source, compares the '
                  'ancestor tested commit source hash with current evidence commit, excluding '
                  'only nine exact receipt files. Other evidence remains hash-bound. Schema2 '
                  'keeps subjectCommit as tested commit and adds subjectHash. Test controls '
                  'cover untracked/staged receipt, dirty/staged/committed source changes, '
                  'stale hash, invalid schema/verdict/commands, unrelated same-tree commit, '
                  'failed prerequisite, and non-receipt evidence drift. All focused controls '
                  'pass. Kimi review remains unavailable from earlier isolated launch failure. '
                  'Find concrete defects, false-green/false-red cases and minimal fixes. '
                  'Do not claim recorded booleans prove tests ran or certify the whole release.\n')
        paths = ['scripts/spec/assess-modular-agon-slices.mjs',
                 'scripts/spec/slice1b-qualification-gates.mjs',
                 'scripts/spec/verify-modular-slice1b-gates.mjs',
                 'docs/specs/modular-agon-acceptance-roadmap.md']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'pinned-checkout-subject':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review exact Git snapshot '
                  'qualification, not the full release. Reproduced old git archive '
                  'dropping export-ignore files and rewriting export-subst bytes. '
                  'All nine qualifiers now pin commit and index trees once and use '
                  'one raw cat-file batch materializer with path/mode/byte verification. '
                  'Hashes and reviews use the same pinned tree, retaining index/commit '
                  'labels. S4-S7 retain parent plus candidate Git history for rollback. '
                  'Real-Git tests execute all18 actual qualifier materializer paths '
                  '(commit/index), assert parent bytes, attributes ignored, binary and '
                  'executable files preserved, moving HEAD/index cannot change snapshot. '
                  'Negative controls reject missing/extra/changed bytes/modes/dirs, '
                  'Git indirection, symlinks and submodules. Types/lint pass. Current '
                  'HEAD contains2397blobs/20621770bytes, below64MiB batch guard. '
                  'Look for concrete correctness, identity, rollback and isolation '
                  'regressions; distinguish unverified hypotheses. Do not certify '
                  'full acceptance or invent executed tests. No personal state included.\n')
        paths = ['scripts/spec/slice1b-qualification-gates.mjs',
                 'scripts/spec/verify-modular-slice1b-gates.mjs',
                 'scripts/spec/qualify-modular-agon-clean-checkout.mjs',
                 'scripts/spec/qualify-modular-agon-slice4.mjs',
                 'scripts/spec/qualify-modular-agon-slice9.mjs',
                 'tests/unit/modular-platform-matrix.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nALL QUALIFIER DIFFS\n' + subprocess.run(['git', 'diff', '--',
            'scripts/spec/qualify-modular-agon-*.mjs', 'scripts/spec/slice1b-qualification-gates.mjs',
            'docs/specs/modular-agon-acceptance-roadmap.md'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'physical-bridge-retirement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review retirement of the unused '
                  'firstPartyCompatibility service and the generator fallback which recreated '
                  'legacy bridges when a physical implementation was absent. All36 physical '
                  'mods already exist; repo-wide search found no current mod consumer of this '
                  'property. Keep GeneratedSurfaceRuntime for kernel management and activation. '
                  'The change removes only private createServices/loadPackage threading, the '
                  'bridge closures, obsolete generator output, and fixture bridge providers. '
                  'Missing implementations now fail before the generator write loop. '
                  'Before-fix controls demonstrated bootstrap property presence, generator '
                  'success with missing implementation, and a kill-list guard missing the '
                  'restored bridge. Check concrete regressions, ownership, missing behavior '
                  'tests, and safe failure. Distinguish inherited issues. Do not certify the '
                  'full release. No personal state or credentials included.\n')
        paths = ['packages/mod-kernel/src/first-party-surface-bootstrap.ts',
                 'scripts/spec/generate-modular-first-party-packages.mjs',
                 'scripts/spec/measure-modular-slice6.mjs',
                 'scripts/spec/verify-modular-kill-list.mjs',
                 'tests/unit/modular-first-party-observability.test.ts',
                 'tests/unit/modular-forge-settings.test.ts',
                 'tests/unit/modular-physical-surface-activation.test.ts']
        for relative in paths:
            source = (qualified / relative).read_text()
            if relative.endswith('modular-forge-settings.test.ts'):
                source = '\n'.join(source.splitlines()[690:840])
            prompt += '\nFILE ' + relative + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'ask-failure-diagnostics':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Modular Ask discarded provider stderr '
                  'while the legacy Ask command printed trimmed stderr capped at500characters. '
                  'Restore that existing failure contract, preserving timeout summaries and '
                  'successful answer-only output. Synthetic exit2 and timeout tests failed '
                  'before this fix because diagnostics were missing. No provider authentication '
                  'changes, dependencies, or new framework. Check concrete regressions and '
                  'test discrimination. Distinguish inherited behavior from this diff. '
                  'Do not certify the whole release.\n')
        paths = ['packages/mod-ask/src/implementation.ts', 'tests/unit/ask-command.test.ts',
                 'packages/cli/src/commands/ask.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'retention-quota-cli':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review new quota CLI composition. '
                  'Existing kernel quota coordinator and engine-catalog cache owner are already '
                  'implemented; do not copy their policy into CLI. CLI must preview explicit '
                  'quota and rollback window, save exact plan, require exact approval, reject '
                  'replacement policy, support cancellation and terminal replay. Separate '
                  'AGON_HOME and modular host root, missing cache/home, changed cache identity '
                  'and logical rather than physical byte reporting matter. Internal CLI to '
                  'catalog dependency explicitly approved. No external versions added. Find '
                  'concrete defects and discriminating test gaps. Do not certify full release.\n')
        paths = ['packages/cli/src/commands/mod.ts', 'packages/mod-kernel/src/quota-retention.ts',
                 'packages/support-engine-catalog/src/engine-registry.ts',
                 'tests/unit/modular-first-party-cli-recovery.test.ts', 'packages/cli/package.json']
        for relative in paths:
            source = (qualified / relative).read_text()
            if relative.endswith('engine-registry.ts'):
                source = '\n'.join(source.splitlines()[:115])
            prompt += '\nFILE ' + relative + '\n' + source
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-invocation-host-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move Forge invocation-host policy '
                  'from Core to the existing Forge mod. Core preserves its public positional '
                  'factory as a compatibility effect binding. No new dependency. Preserve '
                  'lazy construction, abort-before-effects, captured authority on every adapter '
                  'entry point, invocation-local registry and seed binding. Existing shared '
                  'adapter guard is reused. Invalid authority callback results must fail before '
                  'transport, not fall back to unrestricted execution. Core effect composition '
                  'and Brainstorm facade retirement remain unfinished; do not certify those or '
                  'full release. Check concrete regressions, boundary coherence, tests.\n')
        paths = ['packages/mod-forge/src/host.ts', 'packages/mod-forge/src/index.ts',
                 'packages/core/src/blocks/forge-host.ts',
                 'packages/support-engine-runtime/src/adapter-guard.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-forge/src/workflow.ts').read_text()
        prompt += '\nWORKFLOW CONTRACT\n' + source[source.index('export interface ForgeWorkflowRegistry'):source.index('/** Construct a workflow')]
        test = (qualified / 'tests/unit/modular-forge-settings.test.ts').read_text()
        prompt += '\nTEST IMPORTS AND DIRECT HOST CASES\n' + test[:test.index("  it.each(['timeout'")]
        prompt += '\nEXISTING CORE GUARD CASES\n' + test[test.index("  it('does not open transport"):test.index("  it('settles every candidate")]
        old = subprocess.run(['git', 'show', 'f058e61e:packages/core/src/blocks/forge-host.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nOLD AUTHORITATIVE HOST\n' + old
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths,
            'scripts/spec/generate-modular-first-party-packages.mjs',
            'tests/unit/modular-forge-settings.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'brainstorm-invocation-authority':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Brainstorm host previously opened '
                  'effects and deferred adapter dispatch without checking cancellation or '
                  'captured generation authority. Reuse the existing guardEngineAdapter, '
                  'preserve the Core factory with an optional third argument, and wire CLI '
                  'and MCP callbacks using their existing authority mechanisms. Find concrete '
                  'regressions, missing call paths and discriminating test gaps. Five tests '
                  'failed before and pass after. No dependencies added. Do not certify full '
                  'modularity: the Core effect-composition facade remains unfinished.\n')
        paths = ['packages/mod-brainstorm/src/host.ts',
                 'packages/core/src/blocks/brainstorm-host.ts',
                 'packages/cli/src/first-party-services.ts',
                 'packages/mcp/src/first-party-services.ts',
                 'packages/support-engine-runtime/src/adapter-guard.ts',
                 'packages/mcp/src/surface-authority.ts',
                 'tests/unit/modular-brainstorm-host-owner.test.ts',
                 'tests/unit/modular-engine-dispatch-contract.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text()
        prompt += '\nCLI AUTHORITY\n' + source[source.index('export function captureProcessSurfaceAuthority'):source.index('export function processSurfacePublicIds')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-gauntlet-config-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move four existing settings '
                  'gauntletEnabled, gauntletMaxBreakers, gauntletRepairTimeout, corpusReplayLimit '
                  'from kernel defaults to Forge schema ownership. Preserve defaults false/3/300/5 '
                  'and flat legacy read/write compatibility. The first three have Forge workflow '
                  'consumers; corpusReplayLimit has no current runtime consumer and this change '
                  'does not add one. Registration now reads IDs from the existing manifest. '
                  '72 focused tests, typecheck and generated drift checks pass. Both surface '
                  'catalog diffs contain only content hash changes. Check concrete regressions '
                  'and discriminating test gaps, not style preferences. No new dependencies. '
                  'Do not certify full modular acceptance.\n')
        paths = ['packages/mod-forge/schemas/config.schema.json',
                 'packages/mod-forge/src/implementation.ts',
                 'packages/mod-kernel/src/legacy-config-assignments.generated.ts',
                 'packages/core/src/signals/config.ts',
                 'tests/unit/config-memo.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nNON-CATALOG DIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-forge', 'packages/core/src/models',
            'packages/mod-kernel/src/settings.ts',
            'scripts/spec/generate-modular-agon-ownership.mjs',
            'tests/unit/config-memo.test.ts', 'tests/unit/modular-forge-settings.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'role-ranking-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move role-specialization from Core '
                  'into the existing Ratings mod. Consumers include Forge, Review and Cesar, '
                  'not only Forge. Core retains exact public export signatures as reexports. '
                  'No dependency added: Ratings already depends on engine-runtime for TaskClass '
                  'and buildRolePrompt. Implementation body is byte-identical after stripping '
                  'the three changed imports. Preserve random ties, confidence floor, newcomer '
                  'threshold, role text and persisted rating bytes. Eight focused tests and '
                  'typecheck pass. A wrong Core export alias fails the identity regression. '
                  'Find concrete regressions, boundary problems and discriminating test gaps. '
                  'Do not certify full modular acceptance or invent executed tests.\n')
        paths = ['packages/mod-ratings/src/role-specialization.ts',
                 'packages/mod-ratings/src/index.ts', 'packages/mod-ratings/package.json',
                 'packages/core/src/blocks/role-specialization.ts',
                 'tests/unit/role-specialization.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nOLD IMPLEMENTATION\n' + subprocess.run(['git', 'show',
            'HEAD:packages/core/src/blocks/role-specialization.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-executor-assembly':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Plan must own its executor catalog, '
                  'not only the individual step algorithms. This moves construction of the five '
                  'existing factory families and the outer authority wrapper from CLI into mod-plan. '
                  'CLI retains provider/UI/filesystem effects and generation lease implementation. '
                  'Keep step keys/order, raw results, cancellation, nested owner admission, lease '
                  'cleanup and error behavior. No dependency or version changes. Do not claim full '
                  'Plan retirement: the coordinator integration remains separately open. Check '
                  'concrete regressions, unnecessary duplication and discriminating tests.\n')
        paths = ['packages/mod-plan/src/step-executors.ts',
                 'packages/cli/src/handlers/plan-mode.ts',
                 'tests/unit/modular-plan-step-admission.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nOLD CLI\n' + subprocess.run(['git', 'show',
            'HEAD:packages/cli/src/handlers/plan-mode.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        authority = (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text()
        prompt += '\nAUTHORITY\n' + authority[authority.index('export async function withProcessSurfaceAuthority'):authority.index('export function processSurfacePublicIds')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-plan/src/index.ts', 'tests/unit/modular-plan-agent-review-parity.test.ts',
            'tests/unit/modular-plan-forge-step-parity.test.ts', 'tests/unit/modular-plan-self-step-parity.test.ts',
            'tests/unit/modular-plan-panel-steps-parity.test.ts', 'tests/unit/modular-plan-pipeline-step-parity.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-proposal-coordinator':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move two remaining Plan policies '
                  'from CLI into the existing physical owners: no-pending/manual approval '
                  'dispatch into proposal-workflow; consuming a matching pending proposal '
                  'only after running-state persistence into execution-coordinator. CLI keeps '
                  'state access and effects. Optional clearProposal preserves existing public '
                  'coordinator hosts without proposal state. Preserve exact errors, false/true '
                  'meaning, save/clear/Markdown order, and different-proposal identity. Check '
                  'concrete regressions and missing tests, not style. No new dependencies. '
                  'Do not certify whole-product acceptance or invent executed evidence.\n')
        paths = ['packages/mod-plan/src/proposal-workflow.ts',
                 'packages/mod-plan/src/execution-coordinator.ts',
                 'packages/cli/src/signals/dispatch/plan-execution.ts',
                 'tests/unit/modular-plan-proposal-workflow.test.ts',
                 'tests/unit/plan-coordinator-persistence.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths,
            'tests/unit/modular-plan-coordinator.test.ts', 'packages/mod-plan/src/index.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'run-directory-retention':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Core pruneRuns claims directory '
                  'retention but used stat on all entries, deleting JSON history and metadata '
                  'under a conflicting 100-entry/24h policy. Fix uses lstat and isDirectory '
                  'before sorting/counting. Existing support-persistence retains JSON policy. '
                  'Three new isolated real-filesystem tests failed before and pass after. '
                  'Check concrete regressions and missing discriminating cases. Existing '
                  'age-only live-directory protection is NOT claimed complete; distinguish '
                  'inherited risks from this target-selection fix. No new dependencies.\n')
        paths = ['packages/core/src/signals/config.ts',
                 'packages/support-persistence/src/runs-store.ts',
                 'tests/unit/config-prune.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'api-catalog-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move the existing models.dev API '
                  'catalog from Core into existing support-engine-catalog. Preserve every '
                  'algorithm and Core export. Only cache-path import becomes an equivalent '
                  'local function; public API TTL gets alias API_MODELS_CACHE_TTL_MS to avoid '
                  'collision with CLI catalog TTL, Core retains CACHE_TTL_MS. No new deps. '
                  'Check cache memo/function identity, path semantics, bundling boundaries, '
                  'pricing/context/vision/URL/search behavior and meaningful test gaps. '
                  '46 focused tests and typecheck pass; identity test failed before. '
                  'Do not certify whole release or claim execution.\n')
        paths = ['packages/support-engine-catalog/src/api-models-registry.ts',
                 'packages/support-engine-catalog/src/index.ts',
                 'packages/core/src/signals/models-registry.ts',
                 'packages/core/src/utils/paths.ts',
                 'packages/support-engine-catalog/package.json',
                 'tests/unit/catalog-context-window.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nOLD CATALOG\n' + subprocess.run(['git', 'show',
            'd6fa2754:packages/core/src/signals/models-registry.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'host-ownership-closure':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent architecture review of the next ownership transition. No tools. '
                  'Original audit explicitly says legacy packages need not all disappear: '
                  'CLI owns terminal shell and Core includes shared host behavior; injection '
                  'itself is appropriate, unfinished policy/effects ownership is the issue. '
                  'Yet specific temporary Brainstorm host adapter removal requires final '
                  'physical effect owners and CLI/MCP decorators using those owners. Plan '
                  'A20 compatibility binding also says retire with shared legacy host. '
                  'Distinguish verified remaining mode policy from legitimate final host '
                  'composition and historical compatibility. What concrete minimal changes '
                  'are still required by these removal conditions? Do not invent a generic '
                  'host framework or demand deleting Core wholesale. Assess current source, '
                  'not comments alone. Identify exactly what further evidence is needed to '
                  'close each boundary. No release certification, no claimed test execution.\n')
        paths = ['packages/core/src/blocks/brainstorm-host.ts',
                 'packages/mod-brainstorm/src/host.ts',
                 'packages/core/src/cesar/plan-cost-estimator.ts',
                 'packages/mod-plan/src/runtime.ts',
                 'packages/mod-plan/src/cost-estimator.ts',
                 'packages/core/src/signals/config.ts',
                 'packages/core/src/signals/glicko.ts',
                 'packages/core/src/blocks/task-classifier.ts',
                 'packages/core/src/signals/engine-registry.ts',
                 'packages/cli/src/first-party-services.ts',
                 'packages/mcp/src/first-party-services.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nBOUNDARY NOTES: Ratings algorithms/persistence live in mod-ratings; '
        prompt += 'Core token-tracker still owns estimator tables and token metrics, and '
        prompt += 'imports API catalog pricing. Kernel owns scoped config store, namespace '
        prompt += 'merging, generated setting ownership, generation reads and writer fences. '
        prompt += 'Core config.ts composes kernel with browser/engine normalization. '
        prompt += 'All given tests are outside this packet; no test-based certification.\n'
    if review_id == 'brainstorm-config-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Only change is two tests of real '
                  'global/project/private config precedence in Brainstorm preflight, through '
                  'physical and compatibility hosts. Inspect isolation, oracle quality, cleanup '
                  'and whether these tests protect invocation-scoped configuration. A temporary '
                  'source mutation replacing context.cwd with process.cwd failed with observed '
                  '41/41/41 instead of 41/52/74; restored suite passed 78 tests. Providers '
                  'are blocked and adapter dispatch is fake. No production change or release '
                  'certification. Report concrete findings only.\n')
        for relative in ['tests/unit/modular-brainstorm-host-owner.test.ts',
                         'tests/helpers/agon-home.ts',
                         'packages/mod-brainstorm/src/host.ts',
                         'packages/core/src/blocks/brainstorm-host.ts',
                         'packages/support-panel/src/health-check.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'tests/unit/modular-brainstorm-host-owner.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'review-subject-coupling':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent acceptance-contract review. No tools. Verify this hypothesis, '
                  'do not assume it true: S1B and S9 review manifests contain subject hashes '
                  'that include the other manifest. Each excludes only its own review record. '
                  'Refreshing one invalidates the other. Aggregate schema2 receipts exclude '
                  'only nine exact receipt paths, and require identical tested source plus '
                  'immutable prerequisite receipt blobs. We need all final acceptance on one '
                  'clean committed source subject, without a waiver, new dependency or broad '
                  'evidence exclusion. Read-only probe matched production hashing and changing '
                  'only the other manifest object ID in memory changed both subjects. '
                  'Determine whether this prevents an achievable final qualification, or '
                  'whether existing semantics already offer a valid ordering. Distinguish '
                  'roadmap command success from simultaneous validity of historical reviews. '
                  'Propose the smallest contract repair if needed, with tamper controls, '
                  'precise migration implications, and a feasible commit/review/receipt '
                  'sequence. Do not propose fabricating passed receipts. No release claim.\n')
        for relative in ['scripts/spec/assess-modular-agon-slices.mjs',
                         'scripts/spec/qualify-modular-agon-clean-checkout.mjs',
                         'scripts/spec/qualify-modular-agon-slice9.mjs',
                         'scripts/spec/slice1b-qualification-gates.mjs']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nROADMAP\n' + (qualified / 'docs/specs/modular-agon-acceptance-roadmap.md').read_text()
    if review_id == 'brainstorm-final-owners':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. CLI/MCP Brainstorm and '
                  'pipeline-orchestration decorators now compose the physical Brainstorm '
                  'factory directly, replacing the Core wrapper as their execution path. '
                  'Core loadConfig remains final shared host config; Ratings, classifier, '
                  'registry and protocol come from physical owners. Preserve lazy opening, '
                  'authority capture, invocation cwd, Ratings lookup, terminal output and '
                  'legacy public callers. Existing internal dependency declarations were '
                  'approved; no versions changed. Find concrete regressions or missing '
                  'behavior tests. Do not certify the entire release.\n')
        for relative in ['packages/cli/src/first-party-services.ts',
                         'packages/mcp/src/first-party-services.ts',
                         'packages/core/src/blocks/brainstorm-host.ts',
                         'packages/core/src/signals/engine-registry.ts',
                         'packages/mod-brainstorm/src/host.ts',
                         'tests/unit/modular-engine-dispatch-contract.test.ts',
                         'packages/cli/package.json', 'packages/mcp/package.json',
                         'packages/mcp/tsconfig.json']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'review-hash-policy':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded acceptance-contract code review. No tools. '
                  'Operator approved breaking circular review hashing by excluding only '
                  'the nine named review manifests and nine aggregate acceptance receipts '
                  'from review-input hashes. Existing per-slice receipt/log exclusions stay. '
                  'Aggregate hashing must still bind all reviews/artifacts; all reviews and '
                  'receipts must be fresh. Check fixed exclusion policy, domain separation, '
                  'Git object binding, tamper controls and feasible receipt progression. '
                  'The aggregate assessor now independently validates all nine reviews. '
                  'Historical reviews are untouched and should fail the new policy. '
                  'Find concrete defects or missing discriminating tests; no release claim.\n')
        for relative in ['scripts/spec/slice1b-qualification-gates.mjs',
                         'scripts/spec/assess-modular-agon-slices.mjs',
                         'scripts/spec/verify-modular-slice1b-gates.mjs',
                         'scripts/spec/qualify-modular-agon-clean-checkout.mjs',
                         'scripts/spec/qualify-modular-agon-slice9.mjs']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-brainstorm-binding':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Plan panel and pipeline '
                  'Brainstorm calls now compose the physical Brainstorm runtime directly '
                  'instead of importing its legacy Forge facade. Existing guarded adapters, '
                  'options, registry, signal, outputs and shared config must remain identical. '
                  'Ratings, classifier and protocol effects use their existing owners. '
                  'No new dependency or API. Legacy public exports remain for other callers. '
                  'Review behavior parity, lazy effects, authority and test oracles. '
                  'Do not certify all modular ownership from this bounded change.\n')
        for relative in ['packages/cli/src/handlers/plan-mode.ts',
                         'packages/forge/src/brainstorm.ts',
                         'packages/mod-brainstorm/src/host.ts',
                         'packages/mod-brainstorm/src/runtime.ts',
                         'tests/unit/modular-plan-panel-steps-parity.test.ts',
                         'tests/unit/modular-plan-pipeline-step-parity.test.ts',
                         'tests/unit/modular-plan-step-admission.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-option-forwarding':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Repair Conquer option forwarding only: '
                  'TUI parsing emits numeric maxTurns/gateTimeout/maxHours and turnTimeout/engineIds aliases, '
                  'but the physical command schema and runner expect string scalars and timeout/engines. '
                  'The change normalizes these at parse and runtime entry. Preserve CLI strings and '
                  'public parser compatibility. Verify schema acceptance, exact options, side effects, '
                  'and tests. Completion-policy divergence is already confirmed and remains a separate '
                  'open repair, not fixed or certified by this change. No new dependencies.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-agent/src/implementation.ts',
                         'packages/cli/src/signals/dispatch/intent-session.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'session-worktree-retained-failures':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Reproduced rm/prune deleting locked '
                  'session worktrees after Git refusal. Remove recursive fallback from both '
                  'physical runtime and shared destroyWorktree; keep manifest if path survives '
                  'and return a clear failure. Shared prune has optional onError callback '
                  'to collect partial errors without losing successful removals; old callers '
                  'without callback still get a thrown failure. Physical command records '
                  'partial session/ephemeral results and errors in its receipt and exits1. '
                  'Core compatibility forwards optional callback, legacy CLI reports retained '
                  'branches and sets exitCode1. 51 real-Git focused tests pass. No new dependencies. '
                  'Review concrete regressions, error semantics and meaningful missing tests. '
                  'Cross-process leases and per-path scoped permissions remain known separate '
                  'unfinished work; do not claim full release acceptance.\n')
        for relative in ['packages/support-worktree/src/worktree-session.ts',
                         'packages/mod-worktrees/src/runtime.ts',
                         'packages/mod-worktrees/src/implementation.ts',
                         'packages/mod-worktrees/src/implementation.test.ts',
                         'packages/core/src/blocks/worktree-session.ts',
                         'packages/cli/src/commands/worktree.ts',
                         'tests/unit/worktree-session.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'worktree-prune-safety':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Reproduced unsafe pruning in both '
                  'physical and legacy paths: fresh dirty ephemeral directories were removed '
                  'after an empty dry-run preview. Shared support-worktree now owns registered '
                  'ephemeral selection, exact root/symlink checks, age, dirty and Git-lock '
                  'checks, preview and removal. Core automatic orphan cleanup only prunes '
                  'missing Git registrations; it never removes existing directories. Core '
                  'age janitor skips known active paths. No force on default removal, no '
                  'recursive fallback. Explicit force permits stale dirty removal but not '
                  'locked paths. No new dependencies. Tests use disposable real Git repos. '
                  'Check destructive-effect boundaries, regressions, user-visible output, '
                  'cross-process risks and meaningful missing tests. Distinguish inherited '
                  'limitations from introduced defects. Do not claim whole release acceptance.\n')
        for relative in ['packages/support-worktree/src/ephemeral-prune.ts',
                         'packages/mod-worktrees/src/runtime.ts',
                         'packages/mod-worktrees/src/implementation.ts',
                         'packages/mod-worktrees/src/implementation.test.ts',
                         'tests/unit/worktree-session.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nCORE WORKTREE LIFECYCLE\n' + '\n'.join((qualified / 'packages/core/src/blocks/git.ts').read_text().splitlines()[:265])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-oracle-preservation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Goal resume overwrote its frozen '
                  'oracle evidence before rejecting changed gate or file inputs. Two real '
                  'controller regression cases failed before this fix. Hash inputs before '
                  'writing; only create the snapshot when journal has no oracleHash. '
                  'Matching resumes preserve original evidence too. Inspect concrete '
                  'regressions and missing cases in this small repair, not the entire '
                  'legacy controller architecture. No dependencies or global state changes.\n')
        for relative in ['packages/forge/src/goal/controller.ts',
                         'packages/forge/src/goal/oracle.ts',
                         'tests/unit/goal-oracle-jit.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-pr-handoff':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Restore physical Goal PR handoff '
                  'after explicit successful task pushes. Share existing Conquer preparation '
                  'with support-worktree, preserving public Conquer wrapper. Existing Forge '
                  'prose owner remains injected from CLI with disabled/generation checks. '
                  'Goal --push returns draft/template/link; --push --pr can create through gh '
                  'with explicit repo/base/head only after verifying the published current tip, '
                  'permission, branch, commit, remote identity and execution authority. '
                  'Persist pending/created/unknown creation state to prevent duplicate effects '
                  'on resume. Optional prose failure must not invalidate completed local work '
                  'or successful push. GitHub link helper now selects the push URL (all traced '
                  'consumers are post-push). Tests use local bare remotes and mocked gh; no '
                  'live providers or remote writes. Check safety, lost responses, stale state, '
                  'behavior parity and meaningful missing cases. No new dependencies. '
                  'This does not certify full Goal oracle or release acceptance.\n')
        for relative in ['packages/support-worktree/src/pull-request.ts',
                         'packages/support-worktree/src/pr-links.ts',
                         'packages/mod-conquer/src/pull-request.ts',
                         'packages/mod-goal/src/host.ts',
                         'packages/mod-goal/src/implementation.ts',
                         'packages/mod-goal/src/implementation.test.ts',
                         'packages/cli/src/first-party-services.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nLEGACY HANDOFF\n' + '\n'.join((qualified / 'packages/cli/src/commands/goal.ts').read_text().splitlines()[760:825])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-per-task-push':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Restore Goal per-task push parity: '
                  'legacy controller pushes each completed task when explicitly requested and '
                  'keeps completed local work if push fails. Physical Goal previously only '
                  'returned promotion metadata. New path checks git.write, captured generation, '
                  'cancellation and writer fence; verifies branch/head then pushes the exact '
                  'completed SHA to the selected remote. No implicit push. A failed or lost '
                  'response is unknown remote outcome, never automatic same-task retry. '
                  'Local bare remote tests verify task-order publication and no publication '
                  'after permission/cancellation/branch changes. PR prose/create parity remains '
                  'a separate known unfinished next increment, not certified here. Review '
                  'concrete correctness/security/compatibility defects and discriminating tests. '
                  'No new dependencies or global installation.\n')
        for relative in ['packages/mod-goal/src/implementation.ts',
                         'packages/mod-goal/src/implementation.test.ts',
                         'packages/mod-goal/src/host.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nLEGACY PUSH\n' + '\n'.join((qualified / 'packages/forge/src/goal/controller.ts').read_text().splitlines()[530:565])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'cli-kebab-projection':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Generated CLI drops explicitly supplied '
                  'kebab-case options because it enumerates parsed camelCase schema keys, while '
                  'Citty defaults mask alternate spellings. Built CLI goal --dry-run actually '
                  'attempted builder execution (provider blockers stopped launches). Fix normalizes '
                  'known long-option names before reparsing using existing Citty, preserves -- '
                  'terminator, negation, short aliases, canonical spellings, schema metadata and '
                  'direct-run fallback. Five tests failed before and now pass. Real built CLI '
                  'dry-run/stale-lock/resume smoke now passes. Focus on concrete argument, safety '
                  'and compatibility regressions, not taste. Goal retention changes were separately '
                  'reviewed already and are outside this packet. No new dependency.\n')
        for relative in ['packages/cli/src/lazy-commands.ts', 'tests/unit/modular-cli-nested-dispatch.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nCITTY PARSER\n' + '\n'.join((qualified / 'node_modules/citty/dist/index.mjs').read_text().splitlines()[95:275])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/cli/src/lazy-commands.ts', 'tests/unit/modular-cli-nested-dispatch.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id in ('goal-retained-worktree', 'goal-retained-worktree-retry'):
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Goal currently deletes failed uncommitted '
                  'work in Forge arena cleanup and returns empty final diffs after commits. Replace '
                  'disposable arena with existing retained session worktree effects, injected by CLI. '
                  'Resume validates path/repo/branch/base ancestry before overlays; persist identity; '
                  'keep final diff based on original commit. Refuse branch/gate/repository changes. '
                  'Existing kernel WriterFence injected by host serializes the global goal id; '
                  'reread state after acquisition and release on every path. Failed tasks with '
                  'remaining requested attempt budget requeue on explicit resume. Tests use local '
                  'Git and isolated state, no live providers. Review concrete data-loss, race, '
                  'authorization or compatibility defects and meaningful test gaps. Goal push/PR '
                  'parity and frozen-oracle parity remain known separate unfinished work; do not '
                  'certify full Goal/release acceptance. No new dependencies.\n')
        for relative in ['packages/mod-goal/src/host.ts',
                         'packages/mod-goal/src/implementation.ts',
                         'packages/mod-goal/src/implementation.test.ts',
                         'packages/cli/src/first-party-services.ts',
                         'packages/support-worktree/src/worktree-session.ts',
                         'packages/mod-kernel/src/writer-lock.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-pr-handoff':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Restore Conquer post-push PR handoff '
                  'parity. One Conquer-owned preparation helper used by legacy CLI and physical '
                  'runtime; reuse Forge-owned prose parser via optional host callback, no new '
                  'dependencies. Disabled Forge must not dispatch; stale/cancelled authority '
                  'must not leak effects or accepted drafts. Optional prose failure falls back '
                  'to template and cannot negate a completed push. Preserve diff cap, human '
                  'merge gate, prefilled link and durable result. Never create PR/open browser '
                  'or push again here. Git fixture remotes local only. Inspect concrete defects '
                  'and meaningful test gaps, not taste. This is not full release acceptance.\n')
        for relative in ['packages/mod-conquer/src/pull-request.ts',
                         'packages/mod-conquer/src/host.ts',
                         'packages/mod-conquer/src/implementation.ts',
                         'packages/cli/src/first-party-services.ts',
                         'packages/cli/src/commands/conquer.ts',
                         'tests/unit/conquer-publication.test.ts',
                         'tests/unit/modular-brainstorm-cli-output-host.test.ts',
                         'packages/mod-forge/src/pr-text.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nPHYSICAL INTEGRATION TEST FIRST 220 LINES\n' + '\n'.join(
            (qualified / 'packages/mod-conquer/src/implementation.test.ts').read_text().splitlines()[:220])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-physical-publication':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Wire physical Conquer explicit --push '
                  'through the existing owned publication sequence. Preserve no-push behavior. '
                  'Host captures kernel protected branches and guarded attribution formatter. '
                  'Require git.write=allow before run and each publication command, recheck '
                  'authority/cancellation across awaits, preserve work on failure. Both legacy '
                  'and physical callers pass expectedBranch; verify before staging and before '
                  'push to reject builder/hook branch changes. Real Git tests use local bare '
                  'remotes only. No new dependencies. PR prose/link parity remains unfinished '
                  'and outside this increment; do not certify full release. Same-user malicious '
                  'hooks/ref/config races are not sandboxed. Find concrete regressions, missing '
                  'failure handling and discriminating test gaps, not taste changes.\n')
        for relative in ['packages/mod-conquer/src/host.ts',
                         'packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-conquer/src/publication.ts',
                         'tests/unit/conquer-publication.test.ts',
                         'packages/cli/src/first-party-services.ts',
                         'packages/cli/src/commands/conquer.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-conquer', 'packages/cli/src/first-party-services.ts',
            'packages/cli/src/commands/conquer.ts', 'tests/unit/conquer-publication.test.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-committed-publication':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. ESM TypeScript. Fix an inherited '
                  'Conquer publication bug: already-committed valid builder output fails the '
                  'unconditional second commit, so never reaches push. After staging, inspect '
                  'git diff --cached --quiet --exit-code. Exit0 skips commit, exit1 commits, '
                  'other exits/timeouts/cancellation fail closed. Keep explicit push approval '
                  'and verified completion in caller, existing protected branch guard and '
                  'all other errors. No new dependencies. Real local bare-remote regression '
                  'failed before fix and now passes; uncommitted/committed/mixed fixtures '
                  'verify remote payload, exact commit count and source branch untouched. '
                  'Branch/config races are inherited and separately pending; do not certify '
                  'physical runtime wiring or full release. Find concrete regressions and '
                  'test gaps, not taste changes.\n')
        for relative in ['packages/mod-conquer/src/publication.ts',
                         'tests/unit/conquer-publication.test.ts',
                         'packages/cli/src/commands/conquer.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-conquer/src/publication.ts', 'tests/unit/conquer-publication.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-publication-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. ESM TypeScript, preserve behavior. '
                  'Move the legacy Conquer CLI Git publication sequence into physical mod-conquer. '
                  'CLI remains the approval/completion gate, binds the same process effect, and '
                  'prints the same failure messages. PR prose generation remains in CLI for now. '
                  'No new dependency. Physical Conquer push wiring is still a separate unfinished '
                  'acceptance item. Do not certify whole release. Review exact sequence, timeout, '
                  'protected branch and failure parity, package exports and test discrimination. '
                  'Existing already-committed builder failure and branch races are inherited; '
                  'identify separately from extraction regressions. 12 focused tests/types/exports '
                  'pass; real Git test uses only a disposable local bare remote.\n')
        for relative in ['packages/mod-conquer/src/publication.ts',
                         'packages/cli/src/commands/conquer.ts',
                         'tests/unit/conquer-publication.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/cli/src/commands/conquer.ts', 'packages/mod-conquer',
            'scripts/spec/generate-modular-first-party-packages.mjs'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'git-pr-link-bounds':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. ESM TypeScript, preserve public API. '
                  'Fix valid Unicode surrogate splitting in PR title/body truncation and enforce '
                  'the existing 7500-character URL bound. Never truncate repo/base/branch identity; '
                  'return the existing empty-link fallback when fixed components or note cannot fit. '
                  'Callers print full PR text and only print the link when nonempty. '
                  'Malformed unpaired input surrogates are inherited behavior, not claimed fixed. '
                  'Check concrete regressions and discriminating tests, no taste-only changes. '
                  'Focused tests/types/export checks pass. No network or provider in tests.\n')
        for relative in ['packages/support-worktree/src/pr-links.ts', 'tests/unit/pr-link.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/pr-links.ts', 'tests/unit/pr-link.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'git-pr-links-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move normalizeGitHubRemote, '
                  'githubRepoUrl, defaultBaseBranch and prefilledPrUrl from Core to existing '
                  'support-worktree; Core keeps exact reexports. Function bodies unchanged. '
                  'Private Git metadata reader preserves execFileSync timeout/stdio/encoding; '
                  'the former GitError wrapping was only observed by catches returning the '
                  'same fallbacks. No new dependency, no network, no push. New identity test '
                  'failed before move; real local Git metadata tests passed before/after, '
                  'including explicit remote, missing repo/remote and default branch fallback. '
                  'Review behavioral parity, boundary/exports and meaningful test gaps. '
                  'Report concrete actionable regressions, distinguish inherited behavior.\\n')
        for relative in ['packages/support-worktree/src/pr-links.ts',
                         'packages/support-worktree/src/index.ts',
                         'tests/unit/pr-link.test.ts']:
            prompt += '\\nFILE ' + relative + '\\n' + (qualified / relative).read_text()
        prompt += '\\nDIFF\\n' + subprocess.run(['git', 'diff', '--',
            'packages/core/src/blocks/git.ts', 'packages/support-worktree/src/index.ts',
            'tests/unit/pr-link.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'pr-text-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Move PR-text prompt/parser/result '
                  'and fail-open orchestration into the frozen physical owner mod-forge. '
                  'Legacy runPrText signature stays unchanged and binds runDelegate through '
                  'a narrow dispatch effect. No new dependencies. Pure prompt/parser bytes '
                  'are preserved. New owner identity test failed before extraction; focused '
                  'tests preserve exact dispatch cwd/mode/timeout/output/signal, malformed '
                  'responses, parser wrappers and thrown engine errors. Check parity, public '
                  'type boundaries, pack exports and unwanted runtime coupling. Do not certify '
                  'Conquer push or whole release: those remain unfinished. Return only '
                  'source-grounded actionable findings, distinguish inherited issues.\\n')
        for relative in ['packages/mod-forge/src/pr-text.ts',
                         'packages/forge/src/pr-text.ts',
                         'packages/forge/src/delegate.ts',
                         'tests/unit/pr-text.test.ts']:
            prompt += '\\nFILE ' + relative + '\\n' + (qualified / relative).read_text()
        prompt += '\\nDIFF\\n' + subprocess.run(['git', 'diff', '--',
            'packages/forge/src/pr-text.ts', 'packages/mod-forge',
            'tests/unit/pr-text.test.ts', 'scripts/spec/generate-modular-first-party-packages.mjs'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-retained-worktree':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Conquer now preserves named '
                  'session worktrees for review/recovery instead of removing its Forge arena. '
                  'Legacy naming policy moves into mod-conquer with injected existing shared '
                  'session effects. Source revision is captured before the builder, and patches '
                  'compare against that revision even if the builder commits. worktree.json is '
                  'written before providers run. Metadata creation failure now rolls back the '
                  'allocated worktree. Check behavior, authority, recovery, contracts and tests. '
                  'Known remaining gaps: explicit push parity and historical envelopes are not '
                  'finished; worktreeAddOnBranch throwing after partial creation predates this '
                  'change and is not covered by the metadata rollback fix. No new dependency. '
                  'Tests include real Git and killed child process, with fake providers. '
                  'Report concrete actionable findings, distinguish inherited defects, and do '
                  'not certify the whole release.\\n')
        for relative in ['packages/mod-conquer/src/isolation.ts',
                         'packages/mod-conquer/src/host.ts',
                         'packages/mod-conquer/src/implementation.ts',
                         'packages/support-worktree/src/forge-arena.ts',
                         'packages/support-worktree/src/worktree-session.ts']:
            prompt += '\\nFILE ' + relative + '\\n' + (qualified / relative).read_text()
        prompt += '\\nDIFF\\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-conquer', 'packages/support-worktree',
            'packages/forge/src/conquer.ts', 'packages/cli/src/first-party-services.ts',
            'tests/unit/conquer-isolation.test.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-clean-reproduction':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Fix a reproduced inherited falsifier '
                  'defect: rerunning in the critic-modified copy could create or hide a failure. '
                  'Two real copy/shell fixtures invert the answer during critic dispatch; both '
                  'failed before the fix. Verification now clones the source candidate again '
                  'after a safe FLAWED counterexample, executes only in that distinct clean copy, '
                  'checks authority and cancellation across clone, and cleans both copies. '
                  'Three fixtures cover failed, throwing and aborted second clone. Same legacy '
                  'and physical owner; no new API/dependency/installer. Review exact lifecycle, '
                  'evidence preservation, false positives/negatives, cancellation and cleanup. '
                  'This is not OS isolation: same-user agents can escape copy boundaries, '
                  'and denylist restrictions are unchanged. Do not certify sandbox security '
                  'or the whole release. Report source-grounded actionable findings only.\n')
        for relative in ['packages/mod-conquer/src/falsifier.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-conquer/src/falsifier.ts', 'tests/unit/conquer.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-physical-falsifier':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Physical Conquer now invokes the '
                  'existing mod-owned done oracle instead of cheap checks alone, persists records '
                  'through the existing run host, and opens catalog/provider effects with captured '
                  'generation authority. Shared pure Nero cascade preserves legacy ranking. No new '
                  'dependencies. Missing host fails before work. Authority checks outside the oracle '
                  'prevent its advisory error handling from accepting a retired session. Real Git, '
                  'copy and shell fixtures exercise reproducing/nonreproducing counterexamples and '
                  'builder retry feedback; providers are fake. Check concrete regressions, authority '
                  'gaps, cleanup, evidence, run-finalization errors and package contracts. Known '
                  'inherited gaps: rerun uses critic-mutated copy; denylist is not OS isolation; '
                  'advisory semantics remain; oracleTampered is false and reported as unverified; '
                  'persistent named worktree/push and full historical envelopes remain unfinished. '
                  'Do not certify entire release. Distinguish introduced vs inherited findings.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/host.ts',
                         'packages/mod-conquer/src/falsifier.ts',
                         'packages/mod-conquer/src/workflow.ts',
                         'packages/mod-nero/src/critic-cascade.ts',
                         'packages/support-engine-runtime/src/adapter-guard.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-conquer', 'packages/mod-nero', 'packages/forge/src/nero.ts',
            'packages/cli/src/first-party-services.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-falsifier-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded ownership review. No tools. Move the existing Conquer '
                  'falsifier and done-oracle from legacy Forge to mod-conquer/falsifier.ts. '
                  'Preserve legacy public signatures through narrow wrappers. Inject engine lookup, '
                  'adapter and ranked critic IDs; legacy wrapper retains rating seeding and the '
                  'existing rankNeroCritics cascade. Pure policy exports preserve identity. '
                  'Use existing engine-runtime process/types and mod-nero verdict owner. No new '
                  'dependencies. New declaration pack allowlist and generated export updated. '
                  'Owner negative control failed before extraction; focused tests/types pass. '
                  'Check behavioral parity, type/package boundary, cleanup, lost evidence and '
                  'whether wrappers accidentally change early exits or ranking side effects. '
                  'Physical Conquer falsifier wiring is the NEXT increment, not claimed done here. '
                  'Known inherited limits: same critic-mutated copy for rerun, denylist is NOT OS '
                  'confinement, advisory fallback semantics. Flag concrete defects but distinguish '
                  'new extraction regressions from inherited issues. Do not certify full release.\n')
        for relative in ['packages/mod-conquer/src/falsifier.ts',
                         'packages/mod-conquer/src/completion-policy.ts',
                         'packages/forge/src/conquer.ts',
                         'packages/mod-conquer/src/index.ts',
                         'packages/mod-conquer/package.json']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nLEGACY BEFORE\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/forge/src/conquer.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'tests/unit/conquer.test.ts', 'scripts/spec/generate-modular-first-party-packages.mjs',
            'packages/mod-conquer/agon.mod.json'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-test-renames':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the test-rename bypass repair. '
                  'Conquer prohibits changing existing tests. Its completion check only saw the '
                  'destination path from parsePatch, so a Git rename from tests/guard.test.ts to '
                  'src/guard.ts passed even with no new coverage. Preserve optional renamedFrom '
                  'metadata in the existing shared parser, and reject test origins in the existing '
                  'Conquer evidence owner. Do not change destination-path behavior for other callers. '
                  'Copies leave the source unchanged and must not be treated as deletion. '
                  'Four real Git fixtures failed before the fix; 271 focused tests and typecheck '
                  'pass afterward. Check quote decoding, rename/edit handling, copies, compatibility, '
                  'false positives, and whether tests discriminate. Full repository gate follows. '
                  'Larger Conquer falsifier/persistent branch gaps remain outside this bounded fix.\n')
        for relative in ['packages/support-worktree/src/patch-parser.ts',
                         'packages/support-worktree/src/git-path.ts',
                         'packages/support-worktree/src/git-diff.ts',
                         'packages/mod-conquer/src/completion-policy.ts',
                         'tests/unit/modular-patch-paths.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/patch-parser.ts',
            'packages/mod-conquer/src/completion-policy.ts',
            'packages/mod-conquer/src/implementation.test.ts',
            'tests/unit/modular-patch-paths.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-controller-convergence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review Conquer controller convergence. '
                  'Move the legacy loop and pure routing/types to mod-conquer/workflow.ts; legacy '
                  'runConquer now binds the same owner with effects. Physical runConquerTask uses '
                  'that loop instead of a separate for-loop and turn-number advisor rotation. '
                  'DONE alone runs the gate, ASK selects Nero/Tribunal/Brainstorm/Council, ordinary '
                  'output continues, one Nero advisor is valid. Preserve objective/previous output '
                  'and context spine. Cancelled builder/oracle results cannot claim success. '
                  'Approved internal Conquer->Brainstorm edge updates graph from153to154, lock, '
                  'manifest and nine frozen qualification counts; negative graph controls retained. '
                  'Tests previously expecting unsolicited gates/advisors now emit explicit DONE or '
                  'ASK to preserve their budget/alias/timeout/cancellation assertions. Two negative '
                  'controls reproduced routing bugs before changes. Focused tests/types pass. '
                  'Check test weakening, actual behavior drift, cleanup, cancellation, dependency '
                  'boundaries, default-pool leakage, packaged declarations, and source duplication. '
                  'Known unfinished next slices: physical tool-enabled falsifier, persistent named '
                  'worktree, explicit guarded push, historical result/event/session integration, '
                  'rename-away test defense. They are not certified by this slice. OSV16findings '
                  'remain. Do not certify the entire release. Full repository gate follows.\n')
        for relative in ['packages/mod-conquer/src/workflow.ts',
                         'packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/completion-policy.ts',
                         'packages/mod-conquer/src/index.ts',
                         'packages/mod-conquer/package.json',
                         'packages/mod-agent/src/implementation.ts',
                         'packages/cli/src/first-party-services.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nLEGACY BEFORE\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/forge/src/conquer.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/forge/src/conquer.ts', 'packages/mod-conquer/src/implementation.test.ts',
            'tests/unit/conquer.test.ts', 'tests/unit/modular-package-graph.test.ts',
            'tests/unit/modular-brainstorm-cli-output-host.test.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs',
            'scripts/spec/generate-modular-agon-ownership.mjs',
            'scripts/spec/qualify-modular-agon-clean-checkout.mjs', 'package-lock.json'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'nero-verdict-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Mechanical Nero verdict-parser ownership '
                  'move: legacy function body is unchanged in mod-nero/verdict.ts; old Forge export '
                  'imports/reexports it, physical Nero replaces its equivalent private parser with '
                  'the same owner. Approved existing Forge->mod-nero dependency, lock, TS reference '
                  'and generated pack allowlist/public export updated. No external versions or '
                  'installation. Existing tests plus legacy/public identity check and physical '
                  'final-marker command test pass after rebuilding both packages. Inspect behavioral '
                  'parity, import cycles, missing packaged declarations, accidental private imports '
                  'and compatibility. Full gate follows. Do not certify whole Nero/Conquer parity.\n')
        paths = ['packages/mod-nero/src/verdict.ts', 'packages/mod-nero/src/index.ts',
                 'packages/mod-nero/src/implementation.ts', 'packages/mod-nero/agon.mod.json',
                 'packages/forge/package.json', 'packages/forge/tsconfig.json',
                 'packages/mod-nero/src/implementation.test.ts', 'tests/unit/nero.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nLEGACY AND GENERATOR DIFF\n' + subprocess.run(
            ['git', 'diff', '--', *paths, 'packages/forge/src/nero.ts',
             'package-lock.json', 'scripts/spec/generate-modular-first-party-packages.mjs'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-deleted-tests':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Conquer completion previously accepted '
                  'deleted or emptied existing tests because parseChangedLines deliberately returns '
                  'only added-line positions for mutation witnesses. Two real Git/worktree workflow '
                  'cases reproduce completed exit0 before fix. Replace only completion classification '
                  'with existing support-worktree parsePatch file inventory; leave mutation helpers '
                  'unchanged. New tests remain allowed through existing newFilesInDiff. Focused tests '
                  'and types pass. Inspect correctness/regressions, new-file identity, deletion, '
                  'quoted paths and rename behavior. Known unresolved issue: parsePatch exposes '
                  'only final path, so renaming a test away may remain unprotected; do not certify '
                  'all acceptance-drift defenses or the release. Prefer existing owners over new '
                  'parsers/abstractions. Identify exact blocking regressions versus inherited gaps.\n')
        paths = ['packages/mod-conquer/src/completion-policy.ts',
                 'packages/mod-conquer/src/implementation.test.ts',
                 'packages/support-worktree/src/git-diff.ts',
                 'packages/support-worktree/src/patch-parser.ts',
                 'packages/support-worktree/src/git-path.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'gauntlet-pid-readiness':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review ONLY Gauntlet cancellation-test '
                  'readiness fix. Full suite failed again at child-death poll; failure diagnostic '
                  'now proves pid=0, elapsed1018ms, ps -p0 rejected. Test waited for file existence, '
                  'aborted during create/truncate-before-write window, then Number(empty string)=0 '
                  'and process.kill(0,0) probes its own process group. Fixture now deliberately '
                  'publishes empty marker then PID after0/500ms. Old existence check fails500ms '
                  'case; new check waits for positive-digit contents and asserts positive safe '
                  'integer before abort. SAME startup3000ms, cancel2500ms, child-death1000ms bounds. '
                  'No production changes, no skipped assertion, no timeout increase. Does this '
                  'fix the observation race without masking real cancellation leaks? Find concrete '
                  'oracle/cleanup/timing defects. Unrelated Conquer edits are not this review.\n')
        for relative in ['tests/unit/gauntlet-validation.test.ts', 'packages/mod-forge/src/gauntlet.ts',
                         'packages/support-engine-runtime/src/process.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'tests/unit/gauntlet-validation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-tui-budget':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review Conquer TUI numeric input fixes. '
                  'Previous digit-only regexes left negative/invalid/missing budget flags in task '
                  'text and silently used defaults. Parse full option tokens, reject invalid '
                  'turn/hour budgets, retain legacy parseInt/parseFloat prefix behavior and '
                  '600/1800 timeout fallbacks. Existing typed TUI schema accepts finite numbers '
                  'only, no schema/API expansion. A second reproduced bug coerces numeric1e21 '
                  'through String then parseInt into1. Normalize finite integer-option numbers '
                  'via BigInt(Math.trunc(value)).toString; leave maxHours parseFloat and string '
                  'inputs unchanged. No new dependency. 13 parser cases and3 large-value execution '
                  'cases fail before their respective fixes. Check regressions, optional flags, '
                  'missing values, finite numeric contracts, correct user errors and test gaps. '
                  'The shared TUI host catches parser errors and never invokes the workflow. '
                  'Full gate follows review. Do not certify broader Conquer/release acceptance.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'tests/unit/modular-tui-input-validation.test.ts',
                         'packages/mod-kernel/src/json-schema-input.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-done-evidence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Check the Conquer completion-evidence fix. '
                  'Physical Conquer previously accepted green gate + diff without a completion claim '
                  'and after rewriting existing tests. Reuse the existing owner policy, extracting '
                  'legacy parseBuilderSignals and buildConquerSystemPrompt byte-identically. Both '
                  'legacy and physical paths now use one evaluateDoneEvidence helper for unchanged '
                  'test-diff classification. Physical Agent receives the protocol system prompt and '
                  'its result.final (not JSON stdout) supplies the completion claim. No new dependency. '
                  '7 negative/positive tests failed before the fix, now pass; one previous success '
                  'fixture now emits the required DONE claim. Independent real-Git parity probes '
                  'for missing claim and test rewriting now agree with legacy. Verify regressions, '
                  'API/export boundary, cancellation, meaningful tests and truthful diagnostics. '
                  'This is NOT full Conquer parity: falsifier, signal-driven consult routing, '
                  'persistent worktree, push and raw envelope migration remain open. The inherited '
                  'diff heuristic misses deletion-only changes; do not claim we fixed that. '
                  'Do not certify release acceptance. Full gate follows your review.\n')
        for relative in ['packages/mod-conquer/src/completion-policy.ts',
                         'packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-agent/src/implementation.ts',
                         'packages/support-worktree/src/git-diff.ts',
                         'packages/forge/src/conquer.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'shared-git-diff-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review behavior-preserving ownership '
                  'extraction of isTestFile,parseChangedLines,newFilesInDiff from legacy Forge '
                  'goal/diff.ts to existing support-worktree/git-diff.ts. Original helper bytes '
                  'equal the moved source. All5consumers move to the shared package; legacy path '
                  'remains one public re-export, same function identities. Operator approved '
                  'existing Forge->support-worktree1.0.0 dependency. Lock changes only packages/forge, '
                  'no external version or installation. Owner identity test failed before extraction; '
                  '213focused Goal/Mutate/Conquer tests and types pass. Support and Forge build. '
                  'Find concrete cycle, public-import, pack or behavior risks. Do not conflate '
                  'inherited diff parsing limitations with this unchanged move. Full qualification '
                  'and support compatibility gates follow. OSV16inherited findings remain open.\n')
        for relative in ['packages/support-worktree/src/git-diff.ts',
                         'packages/support-worktree/src/index.ts',
                         'packages/support-worktree/package.json',
                         'packages/support-verification/package.json',
                         'packages/forge/src/goal/diff.ts', 'packages/forge/package.json',
                         'packages/forge/tsconfig.json', 'tests/unit/goal-diff.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'gauntlet-cancel-diagnostics':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        relative = 'tests/unit/gauntlet-validation.test.ts'
        prompt = ('Independent bounded review. No tools. Review only failure diagnostics added '
                  'to the existing real subprocess cancellation test. One full suite failed '
                  'the process.kill(pid,0) disappearance assertion after1000ms; isolated rerun '
                  'and subsequent full-suite run pass. Root cause is NOT claimed fixed. '
                  'The patch leaves deadline/assertion unchanged and captures ps PID/PPID/PGID/'
                  'state/comm on failure, then rethrows the original error. No command arguments '
                  'or personal state are logged. Find concrete safety/portability/oracle regressions.\n')
        prompt += '\nFILE\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', relative], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-engine-resolution':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review explicit engine selection across '
                  'Conquer and its real nested Agent/Nero/Tribunal/Council workflows. Existing host '
                  'listActive intentionally returns the filtered DEFAULT orchestration roster. '
                  'Existing resolveRequested handles explicit aliases and rejects removed/unavailable engines. '
                  'Use that existing port instead of rejecting explicit selections against defaults. '
                  'No new API/dependency; keep defaults and singular engine/chairman precedence. '
                  'Ten new regression cases failed before changes; now77focused tests/types pass, '
                  'including real Git Conquer composition through all nested workflows, defaults, '
                  'singular override and resolver rejection before execution. Providers are simulated. '
                  'Find concrete regressions, boundary failures or missing discriminating tests. '
                  'Separate inherited Conquer sentinel/oracle/retention/consult-policy gaps remain open. '
                  'Do not certify the whole release.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-agent/src/implementation.ts',
                         'packages/mod-nero/src/implementation.ts',
                         'packages/mod-tribunal/src/implementation.ts',
                         'packages/mod-council/src/implementation.ts',
                         'packages/support-verification/src/review-engines.ts',
                         'packages/cli/src/commands/conquer.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-nero-pool':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review one caller contract fix: '
                  'Conquer passes critics to Nero, but Nero reads engines. Change the caller key to engines. '
                  'Real Conquer->Nero composition regression reproduced dispatch[builder,builder] despite '
                  'explicit advisors advisor-a/advisor-b. Fixed test dispatches[builder,advisor-a]. '
                  '50focused tests/types pass. Check concrete regressions or missing tests. '
                  'Known separate gaps: alias/default-exclusion validation, legacy controller/sentinel/oracle '
                  'and consult routing parity. No new dependencies or claim that these gaps are fixed.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-nero/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-completion-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review a pure ownership extraction: '
                  'DoneOracleInput and doneOracleDecision move unchanged from legacy Forge to physical '
                  'mod-conquer completion-policy.ts. Forge imports and re-exports the same function/type. '
                  'The operator approved existing internal Forge->mod-conquer1.0.0 dependency. '
                  'Package/reference/lock metadata and generated public exports/pack contents updated. '
                  '125focused tests and typecheck pass; identity regression failed before extraction. '
                  'This does not yet switch physical Conquer completion behavior, extract its controller, '
                  'or claim overall parity. Find actual cycles, public export/pack hazards or behavior drift. '
                  'OSV reports16inherited vulnerabilities; no external version changed and security is not certified.\n')
        for relative in ['packages/mod-conquer/src/completion-policy.ts',
                         'packages/mod-conquer/src/index.ts', 'packages/mod-conquer/package.json',
                         'packages/mod-conquer/agon.mod.json', 'packages/forge/package.json',
                         'packages/forge/tsconfig.json', 'packages/forge/src/conquer.ts',
                         'tests/unit/conquer.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-timeout-parity':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review Conquer timeout fallback parity. '
                  'Legacy CLI parseInt defaults nonpositive/nonfinite builder and gate timeouts to600/1800seconds. '
                  'Physical Conquer previously clamped negatives to1second. The diff restores the legacy '
                  'defaults only at the Conquer boundary. Agent independent behavior is unchanged. '
                  'Separate negative tests caught builder and gate cases;45focused tests/types pass now. '
                  'Find concrete regressions or missing discriminating tests. Known unrelated Conquer '
                  'sentinel/oracle,engine selection,TUI malformed parsing,push and retention gaps remain open.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-agent/src/implementation.ts',
                         'packages/cli/src/commands/conquer.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-budget-validation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review Conquer turn/hour budget validation parity. '
                  'Legacy CLI rejects invalid/negative turn and hour budgets before worktree creation. '
                  'Physical Conquer silently defaulted or clamped them, imposed an undocumented 200-turn cap, '
                  'and used Number rather than legacy parseFloat for hours. Restore legacy parsing and '
                  'rejection at the physical runtime boundary. Eight negative cases failed before the fix; '
                  '29 focused tests and typecheck now pass. Preserve permissive parseInt/parseFloat behavior. '
                  'Separate known gaps remain: timeout fallback, explicit engine resolution, sentinel/oracle, '
                  'consult routing, push and retained worktrees. Do not certify those as fixed. '
                  'Find concrete regressions and missing tests for this bounded diff.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/cli/src/commands/conquer.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-builder-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review Conquer builder execution boundaries. '
                  'Legacy runConquer always performs requested work even if existing tests pass, and stops '
                  'on a failed or timed-out builder. The physical controller wrongly returned already_satisfied '
                  'before dispatch, then retried failed builders and ran verification after cancellation. '
                  'Remove the baseline early success and stop before gate/advisor calls on failed builder or abort. '
                  'Preserve partial patches, receipt and cleanup; no new dependencies. '
                  'Five new real-Git fixtures failed before this change and now pass. Existing option tests '
                  'expect one post-builder gate call instead of a baseline call plus post-builder call. '
                  'Known separate gaps remain: sentinel/oracle protection, falsification, consult routing, '
                  'push policy and full legacy controller extraction. Do not certify those as fixed. '
                  'Find concrete regressions or missing behavior tests in this bounded repair.\n')
        for relative in ['packages/mod-conquer/src/implementation.ts',
                         'packages/mod-conquer/src/implementation.test.ts',
                         'packages/mod-agent/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        legacy = (qualified / 'packages/forge/src/conquer.ts').read_text()
        prompt += '\nLEGACY CONTROLLER\n' + legacy[legacy.index('export async function runConquer('):]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'ownership-source-precedence':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review an ownership classifier repair. '
                  'The broad /forge source rule shadowed specific legacy workflows under packages/forge/src. '
                  'Prefer the immediate workflow path before the existing broad source/name fallback. '
                  'Do not globally reorder rules: Forge owns its SynthesisResult and autoReviewAfterForge. '
                  'Twenty assigned occurrences change owner; total assignments and dependency graph stay unchanged. '
                  'The roadmap reconciler now removes sources assigned exclusively to other owners, preserving '
                  'unassigned manual paths and sources with multiple owners. It also resolves five pre-existing '
                  'roadmap conflicts for routing-docs/kernel settings. All generated consumers were regenerated. '
                  'This does NOT physically extract remaining implementations or certify release acceptance. '
                  'Find concrete mapping, consumer, compatibility and test defects. No taste-only suggestions.\n')
        for relative in ['scripts/spec/generate-modular-agon-ownership.mjs',
                         'scripts/spec/reconcile-modular-roadmap-sources.mjs',
                         'scripts/spec/generate-modular-first-party-migration-ledger.mjs',
                         'tests/unit/modular-package-graph.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'worktree-command-retirement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Retire the unreachable legacy CLI '
                  'worktree command. Generated CLI worktree/wt already dispatch through '
                  'the physical mod. Repository search found only the old declaration '
                  'and an existing test forbidding its dynamic import. CLI build has '
                  'three explicit entrypoints, not a commands-directory glob. Core '
                  'session APIs remain unchanged. New ownership guard failed before '
                  'deletion; focused routes, physical implementation, Core session tests '
                  'and typecheck pass. Check concrete deletion regressions or missing '
                  'evidence. Do not certify the whole release. No new dependencies.\n')
        for relative in ['packages/cli/src/lazy-commands.ts',
                         'packages/cli/src/lazy-commands.test.ts',
                         'packages/cli/tsup.config.ts',
                         'packages/mod-worktrees/ownership.json',
                         'packages/mod-worktrees/src/implementation.ts',
                         'tests/unit/modular-no-legacy-orchestration-owner.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-brainstorm-closure-assessment':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded architecture/acceptance review. No tools. We must finish '
                  'the ORIGINAL modularization, not rename effect binders to claim closure. '
                  'Distinguish required UI/process composition from still-owned workflow policy. '
                  'Original A05 coordinator removal condition: Plan session activation supplies '
                  'effects directly; remaining selection, approval and callback lifecycle moves '
                  'out of CLI. Original A05 session-host condition: migrate coordination and '
                  'approval/execution policy to physical owner, prove raw event/state parity, '
                  'delete old adapter and assert no imports of legacy Plan session handlers. '
                  'Old CLI plan-session-host.ts is absent, physical session-scope.ts now owns it. '
                  'Original A06 session effects condition: effects injected through public host '
                  'boundary. Old CLI brainstorm-session-record.ts is absent. Original A06 Core '
                  'host condition: effects have final physical owners and CLI/MCP decorators '
                  'use them; old Core brainstorm-host.ts is absent. Legacy Forge brainstorm.ts '
                  'remains public compatibility for runBrainstorm/runScout plus legacy Conquer '
                  'and team-brainstorm. Original removal condition also requires installed '
                  'raw-oracle parity. Core compatibility readers must remain where required. '
                  'Assess what genuinely remains, with exact source symbols and smallest '
                  'behavior-preserving remedy. Do not declare the whole project complete or '
                  'suggest deleting public compatibility blindly. Report concrete defects '
                  'separately from missing proof and optional simplification. Current full '
                  'suite has 10017 passing tests; counts alone do not prove these contracts.\n')
        for relative in ['packages/cli/src/signals/dispatch/plan-execution.ts',
                         'packages/cli/src/handlers/plan.ts',
                         'packages/mod-plan/src/session-scope.ts',
                         'packages/mod-plan/src/session.ts',
                         'packages/mod-plan/src/execution-coordinator.ts',
                         'packages/cli/src/blocks/brainstorm-session.ts',
                         'packages/mod-brainstorm/src/session-workflow.ts',
                         'packages/forge/src/brainstorm.ts',
                         'packages/mod-brainstorm/src/host.ts',
                         'tests/unit/modular-plan-entry-authority.test.ts',
                         'tests/unit/modular-brainstorm-host-owner.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nPLAN INTERACTIVE BINDING\n' + '\n'.join((qualified / 'packages/cli/src/signals/dispatch/intent-session.ts').read_text().splitlines()[:94])
        for relative in ['packages/cli/src/first-party-services.ts', 'packages/mcp/src/first-party-services.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
    if review_id == 'plan-session-composition':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Plan session composition moves '
                  'to physical mod-plan. Interactive worktree controls no longer import '
                  'the five legacy Plan handlers. Their public wrappers stay compatible. '
                  'The raw CLI worktree effect binder moved unchanged except its relative '
                  'Forge import. Host creation stays lazy per action to preserve authority '
                  'capture and live session reads. Task/resume workflows are composed by '
                  'the same physical factory. Pending Cesar proposal callbacks still use '
                  'existing wrappers: this increment does NOT close all A05 acceptance. '
                  'Review behavior, fallback order, errors, stale authority, export safety '
                  'and test discrimination. Find concrete regressions, not taste changes. '
                  'No dependencies changed. No full-release certification.\n')
        for relative in ['packages/mod-plan/src/session.ts',
                         'packages/mod-plan/src/session-workflow.ts',
                         'packages/mod-plan/src/worktree-workflow.ts',
                         'packages/mod-plan/src/session-scope.ts',
                         'packages/cli/src/blocks/worktree-plan-effects.ts',
                         'packages/cli/src/handlers/plan.ts',
                         'tests/unit/modular-plan-session-tui.test.ts',
                         'tests/unit/modular-worktree-plan-workflow.test.ts',
                         'tests/unit/plan-approval-refusal.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages', 'tests'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-execution-session':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Physical mod-plan now composes '
                  'existing selection, approval, proposal, resume, callbacks and coordinator. '
                  'CLI supplies raw effects. Interactive actions bypass legacy execution '
                  'wrappers, which remain public and compatible. Verify behavior parity, '
                  'authority capture, lazy state reads, error propagation and test quality. '
                  'No full acceptance claim. Identify concrete defects, not taste changes.\n')
        for relative in ['packages/mod-plan/src/execution-session.ts',
                         'packages/mod-plan/src/execution-coordinator.ts',
                         'packages/mod-plan/src/proposal-workflow.ts',
                         'packages/mod-plan/src/resume-workflow.ts',
                         'packages/mod-plan/src/approval-policy.ts',
                         'packages/mod-plan/src/session-selection.ts',
                         'packages/cli/src/blocks/plan-execution-effects.ts',
                         'packages/cli/src/signals/dispatch/intent-session.ts',
                         'tests/unit/modular-plan-entry-authority.test.ts',
                         'tests/unit/modular-plan-session-tui.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nOLD EXECUTION BINDING\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/cli/src/signals/dispatch/plan-execution.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages/cli/src',
            'packages/mod-plan/src', 'tests'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-natural-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Move natural Plan input ordering '
                  'and post-dispatch event policy into existing physical mod-plan session '
                  'owner. CLI binds live state, surface checks and execution session. '
                  'Preserve approval-before-resume, fallback when approval returns false, '
                  'propagated action errors, disabled status access and tail event counts. '
                  'No new dependency or full acceptance claim. Find concrete regression '
                  'or material missing behavioral evidence; do not propose taste rewrites.\n')
        for relative in ['packages/mod-plan/src/session.ts',
                         'packages/mod-plan/src/session-selection.ts',
                         'packages/mod-plan/src/execution-session.ts',
                         'packages/cli/src/blocks/plan-execution-effects.ts',
                         'packages/cli/src/signals/dispatch/intent-router.ts',
                         'tests/unit/modular-plan-session-route.test.ts',
                         'tests/unit/modular-plan-session-tui.test.ts',
                         'tests/unit/modular-plan-natural-input.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nOLD ROUTER\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/cli/src/signals/dispatch/intent-router.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages', 'tests',
            'scripts/spec/generate-modular-first-party-packages.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-final-bindings':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Retire last production imports '
                  'of Plan execution/selection compatibility wrappers from Cesar and '
                  'interactive session. Use existing physical execution session factory '
                  'and selectResumablePlan. No wrapper API removed or policy changed. '
                  'Verify call-time laziness, raw proposal identity, retry/control flow '
                  'and test coverage. No full acceptance claim. Report concrete issues.\n')
        for relative in ['packages/cli/src/signals/dispatch/plan-execution.ts',
                         'packages/cli/src/signals/dispatch/plan-queries.ts',
                         'packages/cli/src/blocks/plan-execution-effects.ts',
                         'packages/mod-plan/src/execution-session.ts',
                         'packages/mod-plan/src/session-selection.ts',
                         'tests/unit/cesar-recovery-cleanup.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        cesar = (qualified / 'packages/cli/src/signals/dispatch/cesar-router.ts').read_text().splitlines()
        for start, end in [(775, 850), (1090, 1170)]:
            prompt += f'\nCESAR CONTEXT {start}-{end}\n' + '\n'.join(cesar[start - 1:end])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages/cli/src', 'tests'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-review-cost':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Fix lost reported review costs: '
                  'physical Review retains finite nonnegative reported costUsd per seat, '
                  'including failed responses; Goal sums those seat costs once, and counts '
                  'adjudication cost before parsing its verdict. Missing costs remain zero, '
                  'not a claim of free execution. Preserve existing verdict, authority, '
                  'publication and budget policy. No new dependencies or whole-release claim. '
                  'Find concrete regressions and missing discriminating tests. Other Goal '
                  'parity gaps (Forge competition, witness, oracle, retry budgets) remain open.\n')
        for relative in ['packages/mod-review/src/implementation.ts',
                         'packages/mod-review/src/implementation.test.ts',
                         'packages/mod-goal/src/implementation.ts',
                         'packages/mod-goal/src/implementation.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages/mod-review/src',
            'packages/mod-goal/src'], cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-policy-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Move existing Goal journal types '
                  'and pure policies into physical mod-goal, with legacy Forge compatibility '
                  're-exports. Operator approved Forge -> existing mod-goal@1.0.0. No external '
                  'dependency/version/download. Preserve policy bodies; remove Core Mutant '
                  'type coupling through a structural generic requiring only class. Physical '
                  'Goal controller convergence and journal/oracle migration are later increments, '
                  'not claimed complete. Check behavior, public type compatibility, package '
                  'boundary, generator/pack declarations and discriminating regression coverage.\n')
        for relative in ['packages/mod-goal/src/policy.ts',
                         'packages/mod-goal/src/journal-types.ts',
                         'packages/mod-goal/src/index.ts',
                         'packages/mod-goal/agon.mod.json',
                         'packages/forge/package.json',
                         'packages/forge/tsconfig.json',
                         'tests/unit/goal-policy.test.ts',
                         'tests/unit/goal-mutation-gate.test.ts',
                         'tests/unit/goal-breaker-window.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages/forge',
            'packages/mod-goal', 'package-lock.json', 'tests/unit/goal-policy.test.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-journal-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review, no tools. Move existing Goal journal '
                  'transforms, filesystem persistence and pure path validation to mod-goal. '
                  'Legacy Forge injects its existing home/path effects and preserves exports. '
                  'No new dependency. Preserve JSON bytes, heartbeat mutation, unknown/corrupt '
                  'fallback, error propagation, path validation and task/event semantics. '
                  'Core resolveWithinRoot remains the single existing containment implementation. '
                  'Physical runGoal controller convergence is later, not claimed here. '
                  'Check actual regressions, boundaries, declaration/pack completeness and tests. '
                  'Do not mistake unchanged legacy behavior for newly introduced behavior.\n')
        for relative in ['packages/mod-goal/src/journal.ts', 'packages/mod-goal/src/paths.ts',
                         'packages/mod-goal/src/journal-types.ts', 'packages/mod-goal/src/index.ts',
                         'packages/mod-goal/agon.mod.json', 'packages/forge/src/goal/journal.ts',
                         'packages/forge/src/goal/paths.ts', 'tests/unit/goal-journal.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages/forge/src/goal',
            'packages/mod-goal', 'tests/unit/goal-journal.test.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-oracle-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review, no tools. Move existing Goal oracle '
                  'snapshots, fail-on-base/pass-on-head witnesses, per-task probe and red-team '
                  'policies to physical mod-goal. Legacy Forge injects its existing home, '
                  'process, temporary-worktree and containment effects; exports stay intact. '
                  'No dependency or behavior changes intended. AST-body comparison confirms '
                  'all six oracle/probe bodies unchanged after effect-name substitution; '
                  'red-team source is byte-identical. Check public API/type compatibility, '
                  'effect binding, cancellation/cleanup, pack/generator completeness and tests. '
                  'Physical runGoal controller convergence remains open, not claimed here. '
                  'Distinguish pre-existing limitations from introduced regressions.\n')
        for relative in ['packages/mod-goal/src/oracle.ts', 'packages/mod-goal/src/oracle-probe.ts',
                         'packages/mod-goal/src/oracle-redteam.ts', 'packages/mod-goal/src/journal.ts',
                         'packages/mod-goal/src/paths.ts', 'packages/mod-goal/src/index.ts',
                         'packages/mod-goal/agon.mod.json', 'tests/unit/goal-verify-oracle.test.ts',
                         'tests/unit/goal-oracle-jit.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', 'packages/forge/src/goal',
            'packages/mod-goal', 'tests/unit/goal-verify-oracle.test.ts',
            'scripts/spec/generate-modular-first-party-packages.mjs'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-mutation-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded source review, no tools. Move the existing Goal '
                  'single-file mutation assessment to physical mod-goal using injected '
                  'existing process, containment and mutant application effects. Generic '
                  'Mutant preserves the caller type without copying Core generator types. '
                  'No new dependency. Legacy Forge preserves its exports. Check restoration '
                  'on failure, timeout semantics, survivor identity, public declarations and '
                  'test discrimination. Full controller convergence remains open. Distinguish '
                  'pre-existing semantics from introduced defects.\n')
        for relative in ['packages/mod-goal/src/mutation.ts', 'packages/forge/src/goal/mutation.ts',
                         'packages/mod-goal/src/index.ts', 'packages/mod-goal/agon.mod.json',
                         'tests/unit/goal-mutation.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nOLD RUNNER\n' + subprocess.run(['git', 'show',
            'HEAD:packages/forge/src/goal/mutation.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/forge/src/goal/mutation.ts', 'packages/mod-goal',
            'tests/unit/goal-mutation.test.ts', 'scripts/spec/generate-modular-first-party-packages.mjs'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-mutation-admission':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Physical Goal previously ignored '
                  'mutation assessment failure, treating empty outcomes as zero survivors and '
                  'proceeding to review/commit. Seven negative cases reproduced successful '
                  'completion before the fix. Now reject failed baseline, absent report, abort, '
                  'budget exhaustion, notRun and invalid outcomes; retain edits and allow resume. '
                  'Use the existing changedLinesFromDiff parser to skip documentation-only '
                  'changes before assessment, not by matching error prose. No new dependencies '
                  'or policy service. Existing survivor grading and timeout-as-killed semantics '
                  'are unchanged and separate parity work remains. Check concrete regression, '
                  'false-green paths, restoration/resume and test discrimination.\n')
        for relative in ['packages/mod-goal/src/implementation.ts',
                         'packages/support-worktree/src/mutation-runner.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        test_path = 'packages/mod-goal/src/implementation.test.ts'
        prompt += '\nTEST HARNESS AND NEW CASES\n' + '\n'.join((qualified / test_path).read_text().splitlines()[:135])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', test_path], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'canonical-mutant-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Consolidate duplicated mechanical '
                  'mutation generators. Move Core canonical generator byte-for-byte into '
                  'existing support-worktree and preserve Core exports through that owner. '
                  'Replace support runner duplicate operator table with a wrapper over the '
                  'canonical generator, preserving required file/origin metadata, ID format '
                  'and source-line order. Confirmed defect: old support generator emits invalid '
                  'i-+; for i++; while canonical emits none. Restore canonical return/array '
                  'operators and block/template comment rules. Core already depends on '
                  'support-worktree. No new dependency. Check public type compatibility, '
                  'runtime cycles, intended versus accidental behavior changes and regression '
                  'coverage. Full Goal controller parity is not claimed.\n')
        for relative in ['packages/support-worktree/src/mutant-generator.ts',
                         'packages/support-worktree/src/mutation-runner.ts',
                         'packages/support-worktree/src/index.ts',
                         'packages/support-worktree/package.json', 'packages/core/package.json',
                         'packages/core/src/tools/mutant-generator.ts',
                         'tests/unit/mutant-generator.test.ts', 'tests/unit/goal-mutation.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/core/src/tools/mutant-generator.ts', 'packages/support-worktree/src',
            'tests/unit/mutant-generator.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'mutation-containment':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Verified defect: shared mutation '
                  'assessment follows tracked symlinks and writes outside its disposable '
                  'worktree. A fixture witness observed the external mutation before restoration. '
                  'Move the existing Core containment primitive unchanged into support-worktree; '
                  'retain Core exports. Replace lexical-only runner guard with the shared guard. '
                  'Core already depends on support-worktree. No new dependency. Check correctness, '
                  'cycles, compatibility and containment coverage. Do not certify all isolation: '
                  'executed test commands are trusted, not sandboxed. Report concrete defects.\n')
        for relative in ['packages/support-worktree/src/paths.ts',
                         'packages/core/src/blocks/paths.ts',
                         'packages/support-worktree/src/mutation-runner.ts',
                         'packages/support-worktree/src/index.ts',
                         'tests/unit/paths-containment.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/core/src/blocks/paths.ts', 'packages/support-worktree/src',
            'tests/unit/paths-containment.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-file-grading':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Close existing Goal parity gap: '
                  'replace aggregate mutation grading with existing per-file policy and fold. '
                  'Carry flagged survivor evidence into existing Review via an optional typed '
                  'composition argument; persist it and include it in result/adjudication. '
                  'Ordinary CLI prompts without evidence remain unchanged. No new dependencies. '
                  'Reject missing file identity/incomplete outcomes. Preserve existing retry, '
                  'cost, permission and authority checks. Verify concrete correctness and '
                  'regression risks, not taste. No claim of whole Goal convergence.\n')
        for relative in ['packages/mod-goal/src/policy.ts', 'packages/mod-review/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        goal_source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text().splitlines()
        prompt += '\nGOAL CONTEXT\n' + '\n'.join(goal_source[:30] + goal_source[640:855])
        goal_tests = (qualified / 'packages/mod-goal/src/implementation.test.ts').read_text().splitlines()
        prompt += '\nGOAL TESTS\n' + '\n'.join(goal_tests[:220])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts',
            'packages/mod-review/src/implementation.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'mutant-runner-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Move the canonical Core mutant runner '
                  'into existing support-worktree byte-for-byte except local paths and existing '
                  'support-engine-runtime process import. Core retains public reexports. '
                  'User approved internal support-worktree -> support-engine-runtime@1.0.0. '
                  'Generator, canonical graph and workspace lock record that edge. No install. '
                  'Check extraction regressions, runtime cycles, API shape and test discrimination. '
                  'Do not demand behavior changes in this mechanical move; distinguish inherited '
                  'issues. Shared mutation assessment has a separate loop to consolidate next. '
                  'No whole-project acceptance claim.\n')
        for relative in ['packages/support-worktree/src/mutant-runner.ts',
                         'packages/support-worktree/src/paths.ts',
                         'packages/support-worktree/src/index.ts',
                         'packages/support-worktree/package.json',
                         'packages/support-engine-runtime/package.json',
                         'packages/core/src/tools/mutant-runner.ts',
                         'packages/core/src/blocks/process.ts',
                         'tests/unit/mutant-runner.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/core/src/tools/mutant-runner.ts',
            'packages/support-worktree', 'tests/unit/mutant-runner.test.ts',
            'scripts/spec/generate-modular-support-package-metadata.mjs',
            'docs/specs/evidence/modular-agon-package-map.json', 'package-lock.json'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'mutation-execution':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Consolidate the duplicate assessment '
                  'execution loop onto the existing canonical runner in support-worktree. '
                  'Verified failures: per-mutant builds/typechecks missing, baseline exceeding '
                  'total budget, cancellation returned as success. Preserve baseline-first '
                  'generation using additive lazy mutants input; cap semantic dispatch to '
                  'remaining deadline. Restore bounded process capture and reject spawn errors '
                  'as operational failures, not kills or budget exhaustion. Preserve ordinary '
                  'array callers and MUTATE_BASELINE_RED error. Check actual correctness, '
                  'regressions, API compatibility and missing negative controls. No dependencies. '
                  'Inherited broad never-throws comment/write/progress exceptions and legacy '
                  'compiled artifact clearing remain separate known gaps; do not certify full '
                  'release acceptance. Build/typecheck/real fixture tests passed.\n')
        for relative in ['packages/support-worktree/src/mutant-runner.ts',
                         'packages/support-worktree/src/mutation-runner.ts',
                         'packages/mod-mutate/src/implementation.ts',
                         'packages/mod-mutate/src/implementation.test.ts',
                         'tests/unit/mutant-runner.test.ts',
                         'packages/support-engine-runtime/src/process.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/mutant-runner.ts',
            'packages/support-worktree/src/mutation-runner.ts',
            'packages/mod-mutate/src/implementation.test.ts', 'tests/unit/mutant-runner.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'mutation-result':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Legacy runMutate reports ok:true '
                  'after a green baseline followed by a process spawn failure. Confirmed by '
                  'two failing tests with zero or one earned verdict, plus two renderer '
                  'negative controls. Fix keeps partial evidence, returns the operational '
                  'error, and names it in existing flat/grouped/headline renderers. No new '
                  'API or dependencies. Preserve advisory survivor behavior and existing '
                  'budget semantics; canonical runner and physical assessment were reviewed '
                  'separately. Check concrete correctness, regressions and missing cases. '
                  'Focused tests and typecheck pass. Do not certify the full release.\n')
        for relative in ['packages/forge/src/mutate.ts', 'packages/forge/src/mutate-report.ts',
                         'tests/unit/mutate.test.ts', 'packages/support-worktree/src/mutant-runner.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/forge/src/mutate.ts', 'packages/forge/src/mutate-report.ts',
            'tests/unit/mutate.test.ts'], cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'mutation-sandbox-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Mechanical ownership move only: '
                  'legacy forge/mutate-sandbox.ts becomes a facade of support-worktree. '
                  'Body is byte-identical except isInsideRealpath comes from the same '
                  'existing shared paths owner instead of Core. No new dependencies. '
                  'Existing 123 focused tests and typecheck pass after rebuilding the '
                  'package; first run exposed stale build exports, not a policy change. '
                  'Verify public export compatibility, cycles, containment, package fit '
                  'and narrow migration risks. A separate confirmed gap is physical '
                  'assessment does not yet clear stale compiled artifacts; this move '
                  'prepares reuse but does not claim to fix it. Do not certify release.\n')
        for relative in ['packages/forge/src/mutate-sandbox.ts',
                         'packages/support-worktree/src/mutation-sandbox.ts',
                         'packages/support-worktree/src/index.ts',
                         'packages/support-worktree/src/paths.ts',
                         'packages/support-worktree/package.json',
                         'tests/unit/mutate-sandbox.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nBEFORE\n' + subprocess.run(['git', 'show', 'HEAD:packages/forge/src/mutate-sandbox.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/forge/src/mutate-sandbox.ts', 'packages/support-worktree/src/index.ts',
            'tests/unit/mutate-sandbox.test.ts'], cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'mutation-artifact':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Adopt the existing shared mutation '
                  'sandbox policy in runMutationAssessment: discover workspaces, repair links, '
                  'clear ignored target-package compiled outputs before baseline. Confirmed '
                  'built defect: compiled package import reported survivors without touching '
                  'the tested artifact; legacy path rejected it. Failed workspace link repair '
                  'now stops assessment, with a source-escaping scoped-overlay regression. '
                  'Optional throwOnError in existing clearShadowingDist preserves legacy '
                  'best effort but shared assessment fails on refused/failed deletion. '
                  'Real chmod0555 regression includes an ignore-selection precondition; '
                  'removing propagation makes it fail. Preserve committed artifacts and '
                  'source checkout. Baseline code mapping unchanged; physical stderr adds '
                  'existing detailed error and --build hint. 225 focused tests/types pass. '
                  'No dependencies. Check correctness, containment, compatibility and '
                  'missing discriminating tests; do not certify full release.\n')
        for relative in ['packages/support-worktree/src/mutation-runner.ts',
                         'packages/support-worktree/src/mutation-sandbox.ts',
                         'packages/support-worktree/src/forge-arena.ts',
                         'packages/mod-mutate/src/implementation.ts',
                         'packages/mod-mutate/src/implementation.test.ts',
                         'tests/unit/mutate-sandbox.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/mutation-runner.ts', 'packages/support-worktree/src/mutation-sandbox.ts',
            'packages/mod-mutate/src/implementation.ts', 'packages/mod-mutate/src/implementation.test.ts',
            'tests/unit/mutate-sandbox.test.ts'], cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'artifact-readonly':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Real native Mac non-root probe proved '
                  'readonly source dist directories survive cp with readonly modes, publication '
                  'fails and cleanup retains a staging directory even after Git unregisters '
                  'the arena worktree. Fix only existing copyBuildArtifacts owner: record copied '
                  'directories through its existing filter, add owner rwx to those isolated '
                  'copies before publish and before cleanup, check realpath containment and '
                  'directory identity. Never change source permissions. Existing strict/legacy '
                  'failure policies and aggregate errors stay intact. New real chmod tests '
                  'cover successful publication and injected error after actual copy, source '
                  'modes/bytes unchanged, no staging remnants, removable outputs. Assess '
                  'correctness, containment, partial failure and missing tests. No broad chmod '
                  'of caller worktrees is proposed. This is not full release certification.\n')
        paths = ['packages/support-worktree/src/dependency-overlay.ts',
                 'packages/support-worktree/src/paths.ts',
                 'packages/support-worktree/src/forge-arena.ts',
                 'tests/unit/worktree-pnpm-link.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-witness-command':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Physical Goal declared witnessCmd '
                  'but ignored it, using task.verify or gate for mutation assessment. Legacy '
                  'uses opts.witnessCmd or spec.gate. Restore that command choice only in '
                  'the physical controller: derive String(input.witnessCmd ?? gate), pass '
                  'to the existing shared assessment. Both new real-controller tests failed '
                  'before the change: explicit exit1 must stop before review/commit despite '
                  'green task and global gates; omitted witness must use global gate, not '
                  'task verify. No new dependency or surface. This does not implement the '
                  'separate missing base/head witness, frozen oracle or red-team parity. '
                  'Inspect correctness and regression risk within this exact change.\n')
        for relative, start, end in [
            ('packages/mod-goal/src/implementation.ts', 400, 520),
            ('packages/mod-goal/src/implementation.ts', 640, 800),
            ('packages/mod-goal/src/implementation.test.ts', 1, 125),
            ('packages/forge/src/goal/controller.ts', 119, 130),
            ('packages/forge/src/goal/controller.ts', 400, 490),
            ('packages/support-worktree/src/mutation-runner.ts', 196, 270),
        ]:
            prompt += f'\nFILE {relative}:{start}-{end}\n' + '\n'.join((qualified / relative).read_text().splitlines()[start-1:end])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-differential':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Close demonstrated physical Goal gaps: '
                  'tautological changed tests and already-green task verify were accepted. Reuse '
                  'existing createGoalOracle through optional host verification capability and '
                  'CLI composition with existing Core effects. Fail closed when needed effects '
                  'are absent. Guard each spawned command before/after with writer and generation '
                  'checks; combine invocation and per-witness abort signals, unconditional cleanup. '
                  'Add signal forwarding to legacy witnessTest too. Capture task HEAD before '
                  'builder, not original run base. Run global gate once then test/base-head witness '
                  'and differential verify before mutation/review; remove duplicate head verify. '
                  'Preserve the existing strict preflight check for now; actual red-team remains '
                  'a separate known gap, not claimed implemented. Shared diff parser, existing '
                  'physical test filename recognition, deleted tests no longer satisfy requireTests. '
                  'Persist witness results/base/command in existing event state. 139 focused tests '
                  'and types passed, including unicode paths, missing host, second-task base, retry, '
                  'timeout, authority/fence loss, cancellation and unchanged source. Before controls '
                  'failed on missing checks; replacing task base with run base fails the new test. '
                  'Check defects, compatibility, effect authority, API clarity and missing evidence. '
                  'No release certification; whole controller/competition/red-team parity remains open.\n')
        for relative in ['packages/mod-goal/src/host.ts', 'packages/mod-goal/src/oracle.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        for relative, start, end in [
            ('packages/mod-goal/src/implementation.ts', 400, 870),
            ('packages/mod-goal/src/implementation.test.ts', 1, 300),
            ('tests/unit/goal-verify-oracle.test.ts', 25, 165),
            ('packages/cli/src/first-party-services.ts', 125, 149),
            ('packages/forge/src/goal/controller.ts', 395, 463),
        ]:
            prompt += f'\nFILE {relative}:{start}-{end}\n' + '\n'.join((qualified / relative).read_text().splitlines()[start-1:end])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src', 'tests/unit/goal-verify-oracle.test.ts',
            'packages/cli/src/first-party-services.ts', 'packages/forge/src/goal/controller.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-task-isolation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review physical Goal task isolation, '
                  'attempt history, parking and acceptance recovery. Previously an exhausted task '
                  'stopped all work because failed dirty edits shared the accepted worktree. '
                  'New tasks use retained session-worktree candidates and a persisted acceptance '
                  'before adopting verified commits/patches. Parked work remains inspectable, '
                  'independent tasks continue, resume refreshes a stale candidate onto accepted '
                  'state using the existing private-index snapshot owner, preserving old candidates. '
                  'Existing old runs without a task candidate retain the legacy retry path. '
                  'The existing journal and park/breaker policies own history/decisions. '
                  'Acceptance supports commit=false and dirty accepted baselines, restores the '
                  'baseline on failed fast-forward, protects ignored files, and resumes publication '
                  'after acceptance interruption. Inspect actual safety, crash boundaries, stale '
                  'state, accounting, compatibility and maintainability. All claims are hypotheses. '
                  'Report concrete defects with exact source locations and a discriminating test. '
                  'Do not certify full release: competition, red-team, frozen oracle and complete '
                  'controller convergence remain separately open. No installs or personal state.\n')
        paths = ['packages/mod-goal/src/host.ts', 'packages/mod-goal/src/implementation.ts',
                 'packages/mod-goal/src/journal.ts', 'packages/mod-goal/src/journal-types.ts',
                 'packages/mod-goal/src/policy.ts', 'packages/support-worktree/src/forge-arena.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        for relative in ['packages/mod-goal/src/implementation.test.ts', 'tests/unit/goal-journal.test.ts',
                         'tests/unit/worktree-snapshot.test.ts', 'packages/support-worktree/src/patch-apply.ts']:
            prompt += '\nDIFF ' + relative + '\n' + subprocess.run(
                ['git', 'diff', '--', relative], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-oracle-snapshot':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review the existing Goal oracle snapshot owner. '
                  'Confirmed defects: repeat snapshot overwrote prior evidence; unavailable input files '
                  'were silently skipped. New behavior captures all input bytes before writing, rejects '
                  'non-files/missing inputs, verifies existing snapshots instead of replacing them, and '
                  'publishes a completed staging directory with rename. Hashing reads bytes instead of '
                  'lossy UTF-8; valid UTF-8 input retains its previous hash. The legacy standalone hash '
                  'still treats missing input as empty for compatibility, but snapshot and tamper checks '
                  'do not accept it. Check races, snapshot immutability, compatibility, false-green '
                  'claims, cleanup and maintainability. Identify concrete findings with source locations '
                  'and discriminating tests. Full physical Goal frozen-oracle integration is NEXT, not '
                  'claimed complete here. Do not certify release readiness. No credentials/personal state.\n')
        for relative in ['packages/mod-goal/src/oracle.ts', 'tests/unit/goal-verify-oracle.test.ts',
                         'packages/forge/src/goal/oracle.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/oracle.ts', 'tests/unit/goal-verify-oracle.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-frozen-state':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review physical Goal frozen-oracle integration. '
                  'The existing oracle owner now supports verification-only snapshots; the host gates '
                  'capture on lease, generation and cancellation. Physical Goal saves gate evidence '
                  'before task execution and rejects missing/changed evidence on resume. Historical '
                  'states without an oracle record capture their recorded gate once. CLI currently '
                  'passes no oracle files, so this change must not invent a new file-selection feature. '
                  'Find concrete defects in recovery, authority, compatibility and discriminating tests. '
                  'Inspect persisted-state failure boundaries and supervisor behavior. Pre-run Think '
                  'still precedes host acquisition in the supplied source; assess that boundary too. '
                  'Do not certify full Goal or release readiness. Give exact locations and tests.\n')
        for relative in ['packages/mod-goal/src/oracle.ts', 'packages/mod-goal/src/host.ts',
                         'packages/mod-goal/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src', 'tests/unit/goal-verify-oracle.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-exhaustive-mutation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Legacy Goal generates and tests every '
                  'mechanical mutant on changed source lines. Physical Goal accidentally used the '
                  'shared runner default sample of 25 (hard maximum 500), allowing omitted mutants '
                  'to disappear from its evidence. The change adds the literal all to the existing '
                  'maxMutants option and uses it only from Goal. Numeric and omitted sample limits '
                  'stay unchanged; total budgets, cancellation, baseline checks, grading and cleanup '
                  'must remain. Tests use 510 real generated mutations, real Git/worktree/file '
                  'mutation, with only process execution mocked, and check Goal forwards all. '
                  'Find concrete regressions, missing discriminating cases, contract or ownership '
                  'mistakes. Distinguish inherited issues from changes. Do not certify full release.\n')
        for relative in ['packages/support-worktree/src/mutation-runner.ts',
                         'packages/support-worktree/src/mutant-runner.ts',
                         'packages/mod-mutate/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        goal_source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        mutation_start = goal_source.index('          let mutationEvidence:')
        prompt += '\nGOAL MUTATION CONSUMER\n' + goal_source[mutation_start:mutation_start + 8000]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/mutation-runner.ts', 'packages/mod-goal/src/implementation.ts',
            'packages/mod-goal/src/implementation.test.ts', 'packages/mod-mutate/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'mutation-evidence-recovery':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Preserve existing mutation behavior and '
                  'completed evidence when callbacks, placement, artifact writing or receipt writing fail. '
                  'Five regression cases failed before this small fix. The runner now catches operational '
                  'exceptions into its existing baselineError channel, retaining outcomes and notRun. '
                  'The assessment retains a completed report if persistence fails, while returning ok:false. '
                  'No dependencies or new error fields. Review failure/cancellation/cleanup/consumer behavior '
                  'and discriminating test gaps. Distinguish inherited issues from this diff. '
                  'Do not certify full release.\n')
        for relative in ['packages/support-worktree/src/mutant-runner.ts',
                         'packages/support-worktree/src/mutation-runner.ts',
                         'packages/mod-mutate/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        goal_source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        mutation_start = goal_source.index('          let mutationEvidence:')
        prompt += '\nGOAL CONSUMER\n' + goal_source[mutation_start:mutation_start + 8000]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/mutant-runner.ts',
            'packages/support-worktree/src/mutation-runner.ts',
            'tests/unit/mutant-runner.test.ts', 'packages/mod-mutate/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-review-defaults':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Restore legacy Goal review defaults: '
                  'explicit panel overrides configured goalReviewEngines, else all nonlocal active '
                  'engines (fallback all active); no arbitrary cap or builder exclusion. A narrow '
                  'optional Goal host data projection uses existing config and registry owners. '
                  'Goal selects; existing resolveRequested handles aliases/availability. Resolve '
                  'before Think/new model work, not before replaying previously accepted commits '
                  'when providers are absent. No dependency changes. Implementation competition '
                  'is a known remaining gap awaiting internal dependency approval: valid plural '
                  'implementation rosters still use their first engine, NOT full parity. '
                  'Review this bounded change for new defects, authority/cancellation/config '
                  'boundaries, hidden behavior changes and discriminating missing tests. '
                  'Do not certify full release.\n')
        for relative in ['packages/mod-goal/src/host.ts', 'packages/cli/src/first-party-services.ts',
                         'packages/mod-review/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text().splitlines()
        prompt += '\nGOAL EXECUTION (lines 470-1180)\n' + '\n'.join(source[469:1180])
        legacy = (qualified / 'packages/cli/src/commands/goal.ts').read_text().splitlines()
        prompt += '\nLEGACY SELECTION\n' + '\n'.join(legacy[315:345])
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/host.ts', 'packages/mod-goal/src/implementation.ts',
            'packages/mod-goal/src/implementation.test.ts', 'packages/cli/src/first-party-services.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-artifact-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Move legacy Goal summary and result '
                  'formatting to its physical mod owner, preserving exact historical behavior. '
                  'Filesystem paths, result envelope writing, and controller execution remain '
                  'unchanged. No dependencies added. Inspect compatibility, runtime imports, '
                  'output shape and test discrimination. Distinguish inherited behavior from '
                  'new defects; this is not full Goal controller retirement or release certification.\n')
        for relative in ['packages/mod-goal/src/artifacts.ts', 'packages/mod-goal/src/journal-types.ts',
                         'packages/mod-goal/src/index.ts', 'tests/unit/goal-journal.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/forge/src/goal/controller.ts').read_text()
        prompt += '\nLEGACY WRITER\n' + source[:source.index('export async function runGoalController')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/forge/src/goal/controller.ts', 'packages/mod-goal/src/index.ts',
            'tests/unit/goal-journal.test.ts'], cwd=qualified, capture_output=True,
            text=True, check=True).stdout
    if review_id == 'goal-competition-recovery':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review Goal integration with the existing '
                  'Forge workflow: all explicit competitors, immutable dirty-baseline snapshot, '
                  'test-aware winner/synthesis application, failed-patch repair input, deferred '
                  'child cleanup, persisted interrupted-competition recovery and once-only estimated '
                  'cost accounting. Preserve authority, operator edits, acceptance isolation, '
                  'budgets and legacy Forge harvesting behavior. Inspect crash/replay boundaries, '
                  'stale generation/lease, input validation, cost omissions, dispatch/cleanup races '
                  'and meaningful missing tests. Distinguish confirmed defects from hypotheses. '
                  'Known unfinished work: actual oracle red-team, default heuristic implementation '
                  'routing, legacy controller retirement and final release qualification. Do not '
                  'certify the release. Report exact symbols and minimal reproductions.\n')
        for relative in ['packages/mod-goal/src/implementation.ts',
                         'packages/mod-goal/src/host.ts',
                         'packages/mod-forge/src/stages.ts',
                         'packages/mod-forge/src/workflow.ts',
                         'packages/support-worktree/src/forge-arena.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF (including regression assertions)\n' + subprocess.run(
            ['git', 'diff', '--', 'packages/mod-goal/src/implementation.ts',
             'packages/mod-goal/src/implementation.test.ts', 'packages/mod-forge/src/stages.ts',
             'packages/support-worktree/src/forge-arena.ts', 'tests/helpers/forge-host.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nAUDITED COMMIT\n' + subprocess.run(['git', 'rev-parse', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id in ('api-agent-usage', 'api-agent-usage-host-review'):
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Review new per-call usage aggregation '
                  'around the existing API agent tool loop, plus terminal adapter propagation. '
                  'Preserve tool behavior, authority checks, retry semantics and terminal states. '
                  'Inspect source/cached-count provenance, partial results, callback exceptions, '
                  'generator lifetime, overflow and test discrimination. Missing or invalid usage '
                  'must not masquerade as a complete total. This is NOT billing verification or '
                  'full Goal budget acceptance. Known separate gaps: adapter output-file writes '
                  'can throw away a completed result; Goal unknown-cost policy and crash recovery '
                  'remain open. Report concrete findings with source locations and reproductions; '
                  'do not certify the release.\n')
        paths = ['packages/support-agent-runtime/src/agent-loop.ts',
                 'packages/adapter-cli/src/execution-plan.ts',
                 'tests/unit/api-agent-loop.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nBASE COMMIT\n' + subprocess.run(['git', 'rev-parse', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-oracle-recovery':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the new real Forge oracle probe '
                  'and its interrupted-run recovery in Goal. Focus on attempt ordering, strict/warn/off '
                  'semantics, cancellation, cost-once accounting, receipt/state write failures, '
                  'identity validation, and never adopting cheating patches. The existing competition '
                  'checkpoint now has an oracle purpose and verify identity; normal competition recovery '
                  'still harvests repair input, oracle recovery must not. Legacy probes happen before '
                  'implementation attempts. Known open: actual SIGKILL/incomplete-ledger recovery, '
                  'unknown provider costs, default implementation routing and full release qualification. '
                  'A running/missing probe manifest currently stops recovery rather than assuming zero cost. '
                  'Find concrete defects or missing discriminating tests; label hypotheses. Do not certify '
                  'the release. Do not request new features outside those contracts.\n')
        for relative in ['packages/mod-goal/src/implementation.ts',
                         'packages/mod-goal/src/oracle-redteam.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.test.ts').read_text()
        prompt += '\nTEST HARNESS\n' + source[:source.index("describe('physical goal mod'")]
        prompt += '\nORACLE TESTS\n' + source[source.index("  it('stops a strict non-discriminating"):source.index("  it.each(['builder', 'reviewer'])")]
        source = (qualified / 'packages/mod-forge/src/workflow.ts').read_text().splitlines()
        prompt += '\nFORGE WORKFLOW LINES 570-780\n' + '\n'.join(source[569:780])
        prompt += '\nFORGE WORKFLOW LINES 1010-1070\n' + '\n'.join(source[1009:1070])
        source = (qualified / 'packages/forge/src/goal/controller.ts').read_text().splitlines()
        prompt += '\nLEGACY CONTROLLER LINES 245-335\n' + '\n'.join(source[244:335])
        prompt += '\nBASE COMMIT\n' + subprocess.run(['git', 'rev-parse', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'forge-synthesis-accounting':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Check Forge synthesis dispatch accounting: '
                  'critique and refinement previously bypassed the ledger. The new callback records '
                  'usage in the same metric ledger and checkpoints it. A shared usage calculator '
                  'preserves reported versus estimated provenance. Check failures, cancellation, '
                  'late responses, checkpoint ordering, double counting and public compatibility. '
                  'Verify concrete defects, not style. Distinguish inherited failures. Known open: '
                  'unknown cost when a provider throws without a result, mid-provider process death, '
                  'and full release qualification. Do not certify the release.\n')
        paths = ['packages/mod-forge/src/synthesis.ts', 'packages/mod-forge/src/stages.ts',
                 'packages/mod-forge/src/workflow.ts', 'packages/mod-forge/src/types.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.test.ts').read_text()
        start = source.index("  it.each(['improved', 'no-critiques', 'unchanged'])")
        end = source.index("  it.each(['maxAttempts'", start)
        prompt += '\nGOAL INTEGRATION CONTROLS\n' + source[start:end]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nBASE COMMIT\n' + subprocess.run(['git', 'rev-parse', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-default-routing':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Check restoration of legacy Goal task routing: '
                  'default roster may narrow via existing chooseImplementRoster; explicit engines never '
                  'narrow; repair attempts retain full roster; escalation may ask the judge for a subset. '
                  'The CLI injects existing deriveRoutingHints via authority-bound Goal host services. '
                  'Check authority/cancellation, task and run records, invalid answers, compatibility, '
                  'and tests. Known unfinished accounting: engine services normally return usage, not '
                  'costUsd; judge routing currently accounts only an explicit costUsd. Do not ignore '
                  'that gap or certify completion. Suggest the smallest existing-owner repair, not '
                  'a parallel billing subsystem. Distinguish inherited behavior and new defects.\n')
        for relative in ['packages/mod-goal/src/host.ts', 'packages/cli/src/cesar/routing.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        prompt += '\nENGINE PREPARATION\n' + source[source.index("      let engine = '';"):source.index("      if (input.think === true")]
        prompt += '\nIMPLEMENTATION AND ROUTING\n' + source[source.index('          let taskEngines = implementationEngines;'):source.index('          const gateResult = await runFitnessCommand(', source.index('          let taskEngines = implementationEngines;'))]
        source = (qualified / 'packages/mod-goal/src/implementation.test.ts').read_text()
        prompt += '\nTEST HARNESS AND ROUTING CONTROLS\n' + source[:source.index("  it.each(['implementation', 'oracle'])")]
        source = (qualified / 'packages/mod-goal/src/policy.ts').read_text()
        prompt += '\nEXISTING POLICY\n' + source[source.index('export function chooseImplementRoster'):source.index('export function mutationGateDecision')]
        source = (qualified / 'packages/cli/src/first-party-services.ts').read_text()
        prompt += '\nCLI HOST BINDING\n' + source[source.index("    ...(manifest.id === 'agon.goal'"):source.index("    ...(manifest.id === 'agon.conquer'")]
        source = (qualified / 'packages/cli/src/commands/goal.ts').read_text()
        prompt += '\nLEGACY IMPLEMENTATION ROUTING\n' + source[source.index('      const baseRoster ='):source.index('      try {\n        const manifest = await runForge')]
        prompt += '\nBASE COMMIT\n' + subprocess.run(['git', 'rev-parse', 'HEAD'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-supervisor-contract-delta':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded acceptance review. No tools. The modular Goal supervisor '
                  'previously dropped structured tasks and explicit false flags. The repair serializes '
                  'tasks into --tasks JSON and false flags into --no-*. The generated CLI declares '
                  'tasks:string and commit:boolean default true so child runs retain both. Legacy CLI '
                  'does not declare these two flags. Strict parity failed on these exact additions. '
                  'Review whether the attached exact expected-contract extension preserves the old '
                  'contract while testing the repaired one, or conceals a regression. Do not rubber '
                  'stamp a changed oracle. Trace serializer, parser and regression assertions. '
                  'Report concrete defects and smallest repairs; no release approval.\n')
        for relative in ['tests/unit/modular-cli-contract-parity.test.ts',
                         'tests/unit/modular-cli-nested-dispatch.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        prompt += '\nSUPERVISOR AND SCHEMAS\n' + source[source.index('function supervisorArguments'):source.index('function validateTasks')]
        source = (qualified / 'packages/mod-goal/src/implementation.test.ts').read_text()
        start = source.index("  it('owns bounded supervised")
        prompt += '\nSUPERVISOR REGRESSIONS\n' + source[start:start + 7000]
        source = (qualified / 'packages/cli/src/commands/goal.ts').read_text()
        prompt += '\nLEGACY CLI CONTRACT\n' + source[source.index('return defineCommand'):source.index('  async run')]
        prompt += '\nCONTRACT TEST DIFF\n' + subprocess.run(['git', 'diff', '--',
            'tests/unit/modular-cli-contract-parity.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'api-artifact-usage':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Both API agent dispatch paths previously '
                  'threw if writing the output file failed after receiving a model result, discarding '
                  'reported usage. Two real EISDIR fixtures reproduced the loss. The patch normalizes '
                  'the result before the shared write, returns failure plus usage/partial text, preserves '
                  'timeout/cancel codes and original error text, and does not blame the provider for '
                  'the local failure. Inspect both methods, health handling, stream cleanup and tests. '
                  'Find concrete defects. Scope is API agent output writes, not all transport paths; '
                  'diff capture errors and all other dispatch artifact paths are not yet qualified. '
                  'Do not certify release or suggest a parallel usage subsystem.\n')
        paths = ['packages/adapter-cli/src/adapter.ts', 'packages/adapter-cli/src/execution-plan.ts',
                 'tests/unit/adapter-api-fallback.test.ts']
        for relative in paths:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/adapter-cli/src/adapter-helpers.ts').read_text()
        prompt += '\nHEALTH AND DIFF CAPTURE\n' + source[source.index('export function recordDispatchHealth'):source.index('function stampDispatchDepth')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-dispatch-cost':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Six red cases proved actual CLI/MCP '
                  'engine services return usage but no costUsd, while Review and Goal expect costUsd '
                  'and substitute zero. The patch uses the existing token tracker for reported usage '
                  'and returns costUsd plus costSource (the usage provenance). No new price tables or '
                  'dependencies. Missing usage remains absent, not a measured zero; downstream unknown '
                  'usage treatment remains unfinished. Check shared memory tracking/double counting, '
                  'pricing provenance, invalid results, failed paid calls, subscription zero, cache '
                  'discounts and actual Review consumption. Separate confirmed defects from coverage '
                  'gaps. Do not certify release or invent a parallel accounting subsystem.\n')
        for relative, marker in [
            ('packages/cli/src/first-party-services.ts', 'export function createCliEngineServices'),
            ('packages/mcp/src/first-party-services.ts', 'export function createMcpEngineServices')]:
            source = (qualified / relative).read_text()
            prompt += '\nHOST ' + relative + '\n' + source[source.index(marker):]
        for relative in ['packages/core/src/signals/token-tracker.ts',
                         'tests/unit/modular-engine-dispatch-contract.test.ts',
                         'tests/unit/modular-review-engine-selection.test.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-review/src/implementation.ts').read_text()
        prompt += '\nREVIEW CONSUMER\n' + source[source.index('  const reviews ='):source.index('  const usable =')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/cli/src/first-party-services.ts', 'packages/mcp/src/first-party-services.ts',
            'tests/unit/modular-engine-dispatch-contract.test.ts', 'tests/unit/modular-review-engine-selection.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-consensus-policy':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Legacy Goal uses a two-signal consensus '
                  'policy: verified solo/pair findings and total panel failure block immediately; '
                  'only uncertain findings go to a judge. Physical Goal instead judged every failed '
                  'Review result, allowing a judge to clear a verified blocker. A real-worktree '
                  'regression reproduced that. The existing consensus module is moved byte-identically '
                  'from CLI to mod-review with a compatibility re-export. Goal now uses that owner. '
                  'No new dependency. Review command verdict/parse behavior itself is unchanged; '
                  'inspect any remaining contract differences without inventing another policy. '
                  'Check fail-closed behavior, pairing, uncertainty, accounting, retry and meaningful '
                  'tests. Prior judge-cost tests used confidence 0.9; now use 0.8 to test legitimate '
                  'adjudication, with separate no-override coverage retained. Do not certify release.\n')
        for relative in ['packages/mod-review/src/consensus.ts', 'packages/mod-review/src/implementation.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        prompt += '\nGOAL REVIEW GATE\n' + source[source.index('          const review = reviewEngines'):source.index('          if (input.commit !== false)')]
        source = (qualified / 'packages/cli/src/commands/goal.ts').read_text()
        prompt += '\nLEGACY GOAL POLICY\n' + source[source.index('      const consensus = buildConsensus'):source.index('    // ORACLE RED-TEAM')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts',
            'packages/cli/src/blocks/consensus.ts', 'packages/mod-review/src/index.ts',
            'packages/mod-review/agon.mod.json', 'scripts/spec/generate-modular-first-party-packages.mjs'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-supervisor-missing-queue':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. One missing permanent-error phrase '
                  'made modular Goal restart when its queue was absent. Legacy Goal already '
                  'stopped on that error. The regression calls actual runGoal to obtain the '
                  'diagnostic, feeds it through runGoalSupervisor, and failed with two restarts '
                  'instead of zero. Fix adds queue not found to the existing classifier. '
                  'Check this correction, false positives, and test discrimination. Do not '
                  'certify all supervisor behavior or propose unrelated rewrites.\n')
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        for start, end in [('export interface GoalSupervisorDecision', 'const schema ='),
                           ('function loadTasks(', 'function validateTasks('),
                           ('export async function runGoal(', '  const maxAttempts =')]:
            prompt += '\nSOURCE\n' + source[source.index(start):source.index(end, source.index(start))]
        prompt += '\nLEGACY CLASSIFIER\n' + (qualified / 'packages/forge/src/goal/supervisor.ts').read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-supervisor-invocation-cancel':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review invocation cancellation in '
                  'modular Goal supervision. Previously the invocation AbortSignal was not '
                  'passed to the process runtime. Real child fixtures failed before the fix '
                  'for already-aborted and active-child cases. The fix connects the signal, '
                  'checks interruption before spawning, and propagates the original abort '
                  'reason after cleanup. Three real-child cases now pass including backoff; '
                  'they assert process and abort listener cleanup and zero engine dispatch. '
                  'The initial backoff fixture incorrectly used zero retries, corrected to one. '
                  'Check races, cleanup, API compatibility and meaningful test coverage. '
                  'Distinguish introduced defects from pre-existing limitations such as '
                  'SIGTERM-resistant children. Do not certify whole-product readiness.\n')
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        for start, end in [('export interface GoalSupervisorDecision', 'const schema ='),
                           ('export async function runGoal(', '  const maxAttempts =')]:
            prompt += '\nSOURCE\n' + source[source.index(start):source.index(end, source.index(start))]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-historical-status':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Built CLI status failed to read '
                  'a valid legacy Goal journal, despite the existing journal reader reading '
                  'it. Fix adds a read-only historical fallback only when modular state is '
                  'absent. Existing Goal-owned journal storage and formatter are reused '
                  'through explicit host effects and captured authority. Modern state wins. '
                  'No migration, resume or controller retirement is claimed by this slice; '
                  'those remain required subsequent work. Check identity, corrupt inputs, '
                  'authority, nonmutation, precedence and integration. Seven boundary tests '
                  'pass; the initial valid-case assertion was corrected to compare persisted '
                  'JSON rather than undefined optional properties that JSON omits.\n')
        for relative in ['packages/mod-goal/src/host.ts', 'packages/mod-goal/src/journal.ts',
                         'packages/mod-goal/src/artifacts.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        prompt += '\nGOAL ENTRY\n' + source[source.index('const readGoal ='):source.index('  const maxAttempts =', source.index('const readGoal ='))]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/host.ts', 'packages/mod-goal/src/implementation.ts',
            'packages/mod-goal/src/implementation.test.ts', 'packages/cli/src/first-party-services.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-historical-resume-design':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Review a bounded migration design, not implementation approval. No tools. '
                  'Goal must preserve historical execution while retiring its legacy runtime. '
                  'The built CLI currently rejects resume of a valid legacy journal with '
                  'accepted task commit and frozen oracle. Status now has a read-only fallback. '
                  'Recommend the smallest safe integration into the existing physical runGoal, '
                  'not a second execution loop. Host effects and kernel staged migration already '
                  'exist. Preserve raw source bytes, unknown fields, accepted commits, costs, '
                  'attempts, limits, elapsed time, frozen oracle and rollback/re-entry. '
                  'Legacy journal lacks repoRoot/baseSha or a writer identity; old controller '
                  'does not use the modular WriterFence. A heartbeat is not proof of process '
                  'death. New hosts cannot change or stop the operator global installation. '
                  'Distinguish what can be proven from current repo/branch/commits versus what '
                  'needs explicit operator confirmation. Do not invent a historical base, '
                  're-run completed work, reset billed costs, or call rejection a completed '
                  'migration. Give concrete integration order and discriminating tests; flag '
                  'any genuine product decision rather than silently assuming it.\n')
        for relative in ['packages/mod-goal/src/journal-types.ts', 'packages/mod-goal/src/journal.ts',
                         'packages/mod-goal/src/host.ts', 'packages/mod-kernel/src/migration-engine.ts']:
            prompt += '\nFILE ' + relative + '\n' + (qualified / relative).read_text()
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        for start, end in [('type Task =', 'export interface GoalSupervisorDecision'),
                           ('const persistGoal =', '      let engine =')]:
            prompt += '\nPHYSICAL GOAL\n' + source[source.index(start):source.index(end, source.index(start))]
        source = (qualified / 'packages/forge/src/goal/controller.ts').read_text()
        prompt += '\nLEGACY CONTROLLER\n' + source
    if review_id == 'goal-resume-attempt-limit':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Check the saved Goal retry-limit fix. '
                  'A failing regression observed three attempts after a dry-run saved a limit of one. '
                  'Persist the effective limit, restore it on resume, preserve explicit overrides, '
                  'default historical records without the field to three, and reject corrupt stored '
                  'limits before effects. Existing input clamping to 1..20 remains unchanged. '
                  'Nine focused cases, typecheck and lint pass. Review concrete regressions and '
                  'missing controls. This is not legacy journal migration or whole-release approval.\n')
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        for start, end in [('type Task =', 'export interface GoalSupervisorDecision'),
                           ('const persistGoal =', '      let engine =')]:
            prompt += '\nGOAL SOURCE\n' + source[source.index(start):source.index(end, source.index(start))]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-supervisor-startup-recovery':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Explicit resume with supplied intent and '
                  'gate previously created fresh state when no saved state existed. Four additional '
                  'red controls demonstrate supervisor startup/recovery coupling: it unconditionally '
                  'passed --resume even for the first launch. Fix: first launch follows explicit '
                  'resume selection; automatic restarts always resume. Missing state stops rather '
                  'than reconstructing unknown history. Existing-goal collision stops rather than '
                  'implicitly resuming. Crash before the first checkpoint therefore stops at the '
                  'next resume, deliberately refusing ambiguous reconstruction. Crash after a '
                  'checkpoint resumes saved state. No new flags, dependencies or runtime callbacks. '
                  'Check cancellation, argument preservation, identity, races and compatibility. '
                  'Focused supervisor tests, typecheck and lint pass. Legacy journal migration '
                  'and entire-release acceptance remain unfinished. Find concrete defects.\n')
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        for start, end in [('export interface GoalSupervisorDecision', 'const schema ='),
                           ('const persistGoal =', '      let engine =')]:
            begin = source.index(start)
            stop = source.index(end, begin)
            prompt += '\nSOURCE\n' + source[begin:stop]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/implementation.ts', 'packages/mod-goal/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-tui-registry':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. TUI /goal previously used '
                  '/bin/sh -c with agon selected from PATH and no job AbortSignal. '
                  'This change parses quoted CLI text through the existing generated '
                  'schema and routes it through the same physical registry route as Cesar. '
                  'It captures generation authority at enqueue and passes cancellation. '
                  'Shell expansion/operators are intentionally rejected, not interpreted; '
                  'quoted gate commands remain literal. No dependencies added. Check '
                  'quoting, options, cancellation, disabled/generation checks, runtime '
                  'ownership, and remaining failure paths. Find concrete regressions.\n')
        for name in ['packages/cli/src/lazy-commands.ts',
                     'tests/unit/modular-goal-tui-routing.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        source = (qualified / 'packages/cli/src/signals/dispatch/cesar-router.ts').read_text()
        prompt += '\nREGISTRY ROUTE\n' + source[source.index('export async function runPhysicalCesarWorkflow'):source.index('export async function absorbReviewResultIntoCesar')]
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        prompt += '\nGOAL SCHEMA\n' + source[source.index('const schema ='):source.index('const slug =')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/cli/src/lazy-commands.ts', 'packages/cli/src/signals/dispatch/intent-orchestration.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'goal-historical-strict-read':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Historical Goal status used '
                  'legacy loadJournal, which intentionally collapses missing/corrupt '
                  'files to null. A regression proves corrupt JSON was reported as '
                  'no persisted goal. Keep legacy API behavior unchanged, but add '
                  'strict byte-preserving snapshot reading to the same journal owner '
                  'and consume it in the historical host. Only ENOENT means absence; '
                  'invalid UTF-8/JSON and I/O errors fail, without exposing content '
                  'in parse errors. Shape validation remains in the host/summary. '
                  'No migration publication, global state or dependency change. '
                  'Assess concrete defects, compatibility, errors and authority.\n')
        for name in ['packages/mod-goal/src/journal.ts', 'packages/mod-goal/src/artifacts.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        source = (qualified / 'packages/mod-goal/src/host.ts').read_text()
        prompt += '\nHOST\n' + source[:source.index('        ...(options.implementationHints')]
        source = (qualified / 'packages/mod-goal/src/implementation.ts').read_text()
        prompt += '\nSTATUS\n' + source[source.index('export async function runGoal('):source.index('  if (input.resume === true && !prior)')]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-goal/src/journal.ts', 'packages/mod-goal/src/host.ts',
            'packages/mod-goal/src/implementation.test.ts', 'tests/unit/goal-journal.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-safe-startup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Safe-mode CLI startup '
                  'currently imports optional feature host services before selecting the '
                  'kernel-only graph. This breaks recovery when feature code cannot load. '
                  'The change avoids that import in safe mode and makes pristine safe-mode '
                  'help use the kernel catalog instead of the all-feature metadata shortcut. '
                  'Version stays state-independent. Ordinary startup retains its engine '
                  'services and optional injected decorator. No dependency/API change. '
                  'Bundler externalization was diagnostic only and reverted; final packaging '
                  'is still unfinished, not part of this fix. Check regressions, error '
                  'propagation, authority, lifecycle and discriminating tests.\n')
        for name in ['packages/cli/src/surface-authority-runtime.ts',
                     'packages/cli/src/index.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        source = (qualified / 'packages/mod-kernel/src/first-party-surface-bootstrap.ts').read_text()
        start = source.index('export async function bootstrapFirstPartySurfaceGeneration')
        prompt += '\nKERNEL SAFE MODE\n' + source[start:source.index('  const selection = await selectedDesiredState', start)]
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/cli/src/surface-authority-runtime.ts', 'packages/cli/src/index.ts',
            'tests/unit/modular-production-surface-bootstrap.test.ts',
            'tests/unit/modular-first-party-cli-recovery.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-mcp-safe-startup':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. MCP surface authority statically '
                  'imported feature host services and Core before safe-mode selection. '
                  'The change imports host services only for ordinary startup, and loads '
                  'Core configuration only for an admitted tool invocation. That new await '
                  'is bracketed by captured host authority and cancellation checks. '
                  'Safe kernel bootstrap activates no feature packages and ignores decorators. '
                  'No public API/dependency changes. Scope is authority module plus tests; '
                  'the MCP entrypoint still imports its transport/orchestration module and '
                  'final packaging remains unfinished, not certified by this slice. '
                  'Check compatibility, stale-generation/cancellation races, import failures '
                  'and useful test controls.\n')
        for name in ['packages/mcp/src/surface-authority.ts',
                     'tests/unit/modular-mcp-production-authority.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mcp/src/surface-authority.ts', 'tests/unit/modular-mcp-production-authority.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-project-memory':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Repair original SaveMemory '
                  'contract: memory/section input, dated deduplicated project.md facts, '
                  'explicit per-call approval, cache refresh. The previous physical mod '
                  'incorrectly exposed engine observation input under the same tool name. '
                  'Shared pure formatter moves unchanged to existing persistence owner; '
                  'Core preserves its legacy exports. No new dependencies. Check approval '
                  'bypasses, cancellation, stale generation, cache and compatibility. '
                  'Do not certify broader packaging or final release.\n')
        paths = ['packages/mod-memory/src/implementation.ts',
                 'packages/mod-memory/src/implementation.test.ts',
                 'packages/support-persistence/src/project-memory.ts',
                 'packages/core/src/tools/tool-save-memory.ts',
                 'packages/mcp/src/surface-authority.ts',
                 'tests/unit/modular-mcp-production-authority.test.ts',
                 'tests/unit/modular-cesar-orchestration-parity.test.ts']
        for name in paths:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/mod-api/src/index.ts', 'packages/cli/src/cesar/tools.ts',
            'packages/cli/src/first-party-services.ts', 'packages/mcp/src/agon-orchestration.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nLEGACY REFERENCE\n' + subprocess.run(['git', 'show',
            '996ee253d:packages/core/src/tools/tool-save-memory.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-mcp-memory-retirement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Retire unreachable legacy '
                  'SaveMemory implementation from MCP kernel write helper. Actual MCP '
                  'runtime dispatches SaveMemory through the physical mod (already repaired '
                  'in 67f9dd743), and only AgonBash/Edit/Write reach kernel writes. '
                  'Removal also removes transport eager Core import. Unknown names now '
                  'return Unknown write tool before any permission signal. No new '
                  'dependency or public API change. Check caller parity and unsafe '
                  'bypass/regression risks; do not certify whole release.\n')
        paths = ['packages/mcp/src/agon-orchestration.ts',
                 'tests/unit/mcp-orchestration.test.ts']
        for name in paths:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nCALLERS\n' + subprocess.run(['rg', '-n',
            'executeApprovedKernelWrite', 'packages', 'tests', '--glob', '*.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-async-host':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Existing first-party host '
                  'decoration now accepts Awaitable<ModServices> and is awaited before '
                  'createMod. CLI decoration is async and loads Goal and Plan host '
                  'factories only in their owner branches. Existing sync decorators '
                  'remain supported; safe mode does not invoke decorators. This is a '
                  'step toward optional package isolation, NOT its completion: shared '
                  'Core/Ratings/Brainstorm/Conquer imports and bundler externalization '
                  'remain open. Check ordering, errors, callers, promises, and tests. '
                  'Do not certify whole release.\n')
        paths = ['packages/mod-kernel/src/first-party-surface-bootstrap.ts',
                 'packages/cli/src/first-party-services.ts',
                 'tests/unit/modular-production-surface-bootstrap.test.ts',
                 'tests/unit/modular-brainstorm-cli-output-host.test.ts']
        for name in paths:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--', *paths],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nCALLERS\n' + subprocess.run(['rg', '-n',
            'decorateCliFirstPartyServices|decorateFirstPartyServices', 'packages', 'tests', '--glob', '*.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-host-boundary-design':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent architecture review. No tools; inspect only supplied source. '
                  'The agreed final product must physically omit unselected mod packages, '
                  'not bundle their implementations into CLI. Preserve full-default behavior '
                  'and Core public compatibility; no private cross-package imports, parallel '
                  'registries, new dependencies, or speculative abstractions. We have an async '
                  'per-owner host decorator and real generated selection already. A temporary '
                  'tsup external regex removed bundled mod copies. Safe CLI help then worked '
                  'with optional imports blocked, but BOTH CLI and MCP host module imports '
                  'failed on mod-forge from the shared Core chunk before owner selection. '
                  'That chunk contains Core errors FitnessError, scoring, prompts, stage '
                  'context, and Forge/Brainstorm host factories. The diagnostic was reverted. '
                  'Compare two concrete routes: public narrow Core subpaths as temporary '
                  'compatibility seams versus moving remaining host composition to existing '
                  'kernel/support owners now. Explain which breaks actual eager imports, '
                  'including esbuild shared chunks, and which merely hides them. Give the '
                  'smallest coherent first implementation cut, exact symbols and tests. '
                  'Ratings is a separate hard issue: Brainstorm manifest has no Ratings '
                  'dependency while host injects glicko read/seed/update; do not silently '
                  'change default ranking or invent dependency policy. Distinguish source '
                  'facts, inference, and missing evidence. Do not certify the release or '
                  'recommend another series of cosmetic lazy imports that cannot isolate '
                  'an actual minimal installation.\n')
        paths = ['packages/cli/src/first-party-services.ts',
                 'packages/mcp/src/first-party-services.ts',
                 'packages/cli/tsup.config.ts', 'packages/core/tsup.config.ts',
                 'packages/core/package.json', 'tsconfig.base.json',
                 'packages/core/src/models/errors.ts',
                 'packages/core/src/signals/config.ts',
                 'packages/core/src/signals/engine-registry.ts',
                 'packages/core/src/blocks/forge-host.ts',
                 'packages/core/src/blocks/brainstorm-host.ts',
                 'packages/mod-kernel/src/first-party-surface-bootstrap.ts',
                 'packages/mod-brainstorm/agon.mod.json']
        for name in paths:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nCORE EXPORTS\n' + (qualified / 'packages/core/src/index.ts').read_text()
    if review_id == 'modular-host-error-owners':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. First dependency cleanup '
                  'for minimal host isolation: canonical AgonError and ConfigError move '
                  'unchanged to Kernel; GitError/WorktreeError/PlanStateError move unchanged '
                  'to support-worktree. Runtime reexports the same base; Core preserves '
                  'its public aliases and canonical Forge FitnessError. Core config/Git/Plan '
                  'consumers no longer import the mixed errors barrel. Existing declared '
                  'kernel peers permit these imports; no dependency additions. Tests show '
                  'common module imports with Forge blocked, exact constructor identity '
                  'and inheritance. This does NOT complete common host extraction, optional '
                  'package isolation or release acceptance. Check cycles, duplicate kernel '
                  'or class identity, packaging, old behavior, and discriminating tests.\n')
        paths = ['packages/mod-kernel/src/host-errors.ts',
                 'packages/support-engine-runtime/src/errors.ts',
                 'packages/support-worktree/src/errors.ts',
                 'packages/core/src/models/errors.ts',
                 'tests/unit/errors.test.ts',
                 'packages/support-engine-runtime/package.json',
                 'packages/support-worktree/package.json',
                 'packages/mod-kernel/package.json',
                 'packages/support-engine-runtime/tsup.config.ts',
                 'packages/support-worktree/tsup.config.ts']
        for name in paths:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/core/src/signals/config.ts', 'packages/core/src/blocks/git.ts',
            'packages/core/src/blocks/plan.ts', 'packages/mod-kernel/src/index.ts',
            'packages/support-worktree/src/index.ts', 'packages/support-engine-runtime/src/errors.ts',
            'packages/core/src/models/errors.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-git-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded extraction review. No tools. Existing Core Git '
                  'operations move to the existing support-worktree package. Core keeps '
                  'explicit compatibility reexports; CLI host imports moved operations '
                  'directly. No new dependency, Git flags, timeout, retry, cleanup or '
                  'attribution behavior is intended. The only implementation edits are '
                  'package-local imports and direct Set/String.split in place of identical '
                  'Core wrappers. Check exact API and function/state identity, exit hooks, '
                  'cycles, bundling and test discrimination. The physical worktrees mod '
                  'has deliberately different strict setup semantics; do not unify it '
                  'without evidence. Minimal-profile isolation remains unfinished. '
                  'Distinguish inherited defects from extraction regressions.\n')
        prompt += '\nPREVIOUS IMPLEMENTATION\n' + subprocess.run(
            ['git', 'show', 'c0f9f96d8:packages/core/src/blocks/git.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        for name in ['packages/support-worktree/src/git.ts',
                     'packages/core/src/blocks/git.ts',
                     'packages/support-worktree/src/index.ts',
                     'packages/support-worktree/src/errors.ts',
                     'packages/support-worktree/package.json',
                     'packages/support-worktree/tsup.config.ts',
                     'tests/unit/git-error-detail.test.ts',
                     'tests/unit/git-patch-applyability.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nCLI DIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages/cli/src/first-party-services.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-support-map':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. The support boundary verifier '
                  'had a stale duplicated dependency table, rejecting the already approved '
                  'Worktree -> Engine Runtime dependency. Physical package, metadata generator '
                  'and canonical package map agree. Replace only the verifier dependency table '
                  'with the canonical map; retain exact eleven owner inventory, fail-closed '
                  'duplicate/missing/unknown checks, source boundaries, peers, assets and '
                  'existing dependency-mutation self-tests. Full-gate regression now runs '
                  'the verifier, rather than only importing its source inspector. Review '
                  'false-green risks, unintended weakening, test discrimination. No runtime '
                  'code or dependencies change in this packet. Do not certify full release.\n')
        for name in ['scripts/spec/verify-modular-support-boundaries.mjs',
                     'tests/unit/modular-source-boundaries.test.ts',
                     'docs/specs/evidence/modular-agon-package-map.json',
                     'packages/support-worktree/package.json']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'scripts/spec/verify-modular-support-boundaries.mjs',
            'tests/unit/modular-source-boundaries.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-plan-default':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Retire duplicate default Plan '
                  'error adapters now that support-worktree owns PlanStateError. Physical '
                  'transitions previously defaulted to plain Error while Core and CLI '
                  'injected PlanStateError. Preserve the legacy public contract, custom '
                  'invocation-scoped createStateError override, transitions, and persistence '
                  'behavior. Only change the physical fallback and replace Core wrappers '
                  'with reexports; remove CLI default injection. No new dependencies. '
                  'New tests first failed for all four physical errors and wrapper identity; '
                  'focused tests/types pass after owner build. Check API/error identity, '
                  'behavior, custom capability isolation and missing test discrimination.\n')
        for name in ['packages/support-worktree/src/plan.ts',
                     'packages/support-worktree/src/errors.ts',
                     'packages/core/src/blocks/plan.ts',
                     'packages/cli/src/blocks/worktree-plan-effects.ts',
                     'packages/mod-plan/src/worktree-workflow.ts',
                     'tests/unit/modular-support-runtime-isolation.test.ts',
                     'tests/unit/modular-support-parity.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-worktree/src/plan.ts', 'packages/core/src/blocks/plan.ts',
            'packages/cli/src/blocks/worktree-plan-effects.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-config-placement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Bounded architecture review. No tools. Need a dependency-safe concrete '
                  'implementation route, not another cosmetic lazy-import patch. The accepted '
                  'architecture has 49 target packages, minimal Kernel, eleven hidden support '
                  'packages, and optional physical mods. Current minimal CLI/MCP hosts still '
                  'import Core, which statically exports six mods and installs them as ordinary '
                  'dependencies. Public compatibility Core may remain for full legacy consumers; '
                  'minimal hosts must not require it. Previous review proposed moving config '
                  'composition into Kernel, but Core config imports Engine/Browser normalization '
                  'and Persistence paths/types from Kernel dependants: copying those imports '
                  'creates cycles. Existing Kernel scoped store already injects merge/lock/path '
                  'policy. Need one coherent owner, no duplicate normalizers/cache, no mutable '
                  'global configure runtime, no new support package, no silent default/ranking '
                  'change, no private subpaths, no async change to legacy synchronous APIs. '
                  'Separate legitimate host composition from residual implementation ownership. '
                  'Compare concrete feasible placements symmetrically against supplied source. '
                  'Choose smallest final architecture with exact files/functions, necessary '
                  'dependency changes (flag those needing approval), migration order and live '
                  'proof with physically absent mods. If constraints genuinely conflict, say '
                  'which existing requirement needs a product decision; do not invent a waiver. '
                  'Ratings-disabled behavior is already an open product question: isolate it '
                  'rather than silently disabling ranking. Keep run pruning policy unchanged.\n')
        for name in ['packages/core/src/signals/config.ts',
                     'packages/core/src/models/types.ts',
                     'packages/core/src/models/first-party-settings.generated.js',
                     'packages/mod-kernel/src/scoped-config-store.ts',
                     'packages/support-engine-runtime/src/engine-settings.ts',
                     'packages/support-browser-bridge/src/settings.ts',
                     'packages/support-persistence/src/settings.ts',
                     'packages/core/package.json', 'packages/cli/package.json',
                     'packages/mcp/package.json',
                     'packages/cli/src/first-party-services.ts',
                     'packages/mcp/src/first-party-services.ts',
                     'docs/specs/evidence/modular-agon-package-map.json']:
            path = qualified / name
            if name.endswith('.generated.js'):
                path = path.with_suffix('.ts')
            prompt += '\nFILE ' + str(path.relative_to(qualified)) + '\n' + path.read_text()
    if review_id == 'modular-plan-envelope-status':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded correctness review. No tools. A built real-filesystem '
                  'probe found approved Worktree Plan payloads saved with draft envelope status. '
                  'The other six physical states match. Fix only the missing approved case in '
                  'planStatus; preserve awaiting_approval/done aliases and opaque payloads. '
                  'Existing tests now check raw saved envelopes and round trips for all states '
                  'and both aliases; approved failed before the fix. No historical rewrite '
                  'or new dependencies. Check regressions and whether proof discriminates.\n')
        for name in ['packages/support-persistence/src/plan-store.ts',
                     'packages/support-persistence/src/persisted-envelope.ts',
                     'tests/unit/modular-plan-store-owner.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/support-persistence/src/plan-store.ts',
            'tests/unit/modular-plan-store-owner.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-token-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded code review. No tools. Shared CLI/MCP host accounting still '
                  'depended on Core. Move the existing token tracker implementation unchanged to '
                  'Engine Catalog, which already owns the only lookup dependency. Core keeps '
                  'explicit compatibility exports. CLI/MCP use the physical tracker. No dependency '
                  'added, pricing rules and singleton lifetime unchanged. The ownership test failed '
                  'before extraction; focused accounting/catalog/host tests and typecheck pass. '
                  'Check identity, behavior parity, imports, initialization effects and test gaps. '
                  'Do not treat this as complete common-host isolation.\n')
        names = ['packages/support-engine-catalog/src/token-tracker.ts',
                 'packages/support-engine-catalog/src/index.ts',
                 'packages/core/src/signals/token-tracker.ts',
                 'tests/unit/modular-support-parity.test.ts',
                 'tests/unit/token-tracker.test.ts',
                 'tests/unit/catalog-context-window.test.ts']
        for name in names:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nBEFORE TOKEN IMPLEMENTATION\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/core/src/signals/token-tracker.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nHOST DIFF\n' + subprocess.run(['git', 'diff', '--',
            'packages/cli/src/first-party-services.ts', 'packages/mcp/src/first-party-services.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-apply-test-isolation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. The committed clean pressure run fails '
                  'Apply authority tests with shuffle seed 2719. The same test file fails alone '
                  'with that seed; the failing affirmative-prompt test passes alone. A sibling '
                  'test commits a new generation disabling Forge and leaves the shared selected '
                  'generation stale. Change only beforeAll/afterAll to beforeEach/afterEach. '
                  'Production guards and all assertions stay unchanged. Same failing seed now '
                  'passes with the workflow suite. Check fixture lifecycle and whether this '
                  'repairs isolation rather than concealing a production defect.\n')
        for name in ['tests/unit/modular-apply-authority.test.ts',
                     'packages/cli/src/patch-application-host.ts',
                     'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(['git', 'diff', '--',
            'tests/unit/modular-apply-authority.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'modular-pressure-stub-guard':
        prompt = ('Independent bounded review. No tools. This external diagnostic preload is '
                  'not shipped or a security sandbox. Its exact-byte recording-stub exception '
                  'only recognized /tmp/amr-runtime/tmp. A clean pressure checkout uses '
                  '/tmp/agon-pressure-<Python mkdtemp suffix>/runtime/tmp, so the guard blocked '
                  'harmless stubs and the unchanged CLI model-probe test failed. The only change '
                  'adds that owned pressure-directory shape to the provider-stub regex. Realpath '
                  'and exact script bytes remain mandatory. The npx exception is unchanged. '
                  'The failing test reproduces before; all 27 tests pass after. Thirty VM controls '
                  'cover all six child_process methods with valid stubs, edited content, symlink '
                  'escape, unapproved directories, and real provider paths. No real subprocesses '
                  'run in those VM controls. Check new unsafe allowances or missing evidence.\n')
        prompt += '\nBEFORE\n' + (output / 'pressure-c83036549-seed2719/no-login-before.cjs').read_text()
        prompt += '\nAFTER\n' + (output / 'no-login.cjs').read_text()
    if review_id == 'modular-config-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Review the composed configuration '
                  'owner extraction from Core to Persistence. Two approved existing workspace '
                  'dependencies are Persistence -> Engine Runtime and Browser Bridge. MCP '
                  'dependencies and Goal -> Think are unchanged. Core keeps synchronous '
                  'compatibility re-exports. Kernel still owns generic storage and fencing. '
                  'Check singleton identity, circular initialization, default aliasing, public '
                  'types, generation overlays, normalizer order, lock behavior and generator '
                  'consistency. Exact comparison confirms implementation bodies/default '
                  'initializer unchanged. Owner build/types and 123 focused config/Forge tests '
                  'passed; full gates still running. Find concrete regressions, not taste issues. '
                  'Distinguish inherited defects and remaining host migration from this slice. '
                  'Do not certify overall modular acceptance.\n')
        for name in ['packages/support-persistence/src/agon-config.ts',
                     'packages/support-persistence/src/agon-config-settings.ts',
                     'packages/support-persistence/src/first-party-settings.generated.ts',
                     'packages/support-persistence/src/index.ts',
                     'packages/support-persistence/src/paths.ts',
                     'packages/support-persistence/src/file-lock.ts',
                     'packages/support-persistence/package.json',
                     'packages/support-persistence/tsconfig.json',
                     'packages/core/src/signals/config.ts',
                     'packages/core/src/models/types.ts',
                     'packages/mod-kernel/src/scoped-config-store.ts',
                     'tests/unit/config-memo.test.ts',
                     'tests/unit/config-prune.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        for name in ['packages/core/src/signals/config.ts', 'packages/core/src/models/types.ts']:
            prompt += '\nBEFORE ' + name + '\n' + subprocess.run(
                ['git', 'show', 'HEAD:' + name], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        prompt += '\nGENERATOR/TEST DIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'scripts/spec/generate-modular-support-package-metadata.mjs',
             'scripts/spec/generate-modular-first-party-packages.mjs',
             'scripts/spec/generate-modular-agon-ownership.mjs',
             'tests/unit/modular-config-store.test.ts', 'tests/unit/modular-forge-settings.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'ratings-invocation-boundary':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. User decision: disabling '
                  'Ratings must keep workflows running without rating-derived selection or updates. '
                  'Review this first enforcement increment, NOT whole-feature acceptance. Existing '
                  'registry AsyncLocalStorage now exposes live owner availability, undefined outside '
                  'registry calls. Host Plan/job callbacks use that same scope. Brainstorm scoring, '
                  'Forge seed/roles/updates, engine fallback, host ranking and physical Conquer '
                  'skip Ratings when unavailable. Ratings seed/ranked-update effects skip before '
                  'lock acquisition; historical readers stay unchanged. Defaults outside modular '
                  'invocations stay unchanged. Engine-defined specialization and engine outcome '
                  'memory must remain. Known unfinished callers: legacy rating-derived selection '
                  'in Council/Nero/Research/Conquer, Core team composition and separate team Elo '
                  'store, Cesar rating hints, direct administrative save/pairwise APIs. Those '
                  'must be addressed later; do not mistake this for full isolation. Find concrete '
                  'regressions in the increment, async-context leaks, stale/disposed scopes, '
                  'incorrect return contracts, or discriminating test gaps. All test providers '
                  'are fake/blocked. No new dependency or global installation. Do not certify release.\n')
        for name in ['packages/mod-kernel/src/configuration-scope.ts',
                     'packages/mod-kernel/src/registry.ts',
                     'packages/support-engine-catalog/src/engine-registry.ts',
                     'packages/mod-ratings/src/glicko.ts',
                     'tests/unit/modular-registry.test.ts',
                     'tests/unit/modular-ratings-runtime.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nHOST LEASE WRAPPER\n' + '\n'.join(
            (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text().splitlines()[170:245])
        prompt += '\nCOMPLETE INCREMENT DIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages', 'tests'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'ratings-tui-scope':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review, no tools. Check this uncommitted '
                  'increment against HEAD a99e653d4. User requires workflows continue without '
                  'rating-based selection or writes when Ratings is disabled. Existing registry '
                  'invocation AsyncLocalStorage supplies live owner availability. The new host '
                  'scope bridge binds ordinary Cesar routing and direct/queued brain entry without '
                  'changing abort ownership or introducing leases. Already-scoped Plan/job calls '
                  'retain their scope. Routing suppresses rating summaries/spread and does not '
                  'label neutral confidence as measured win rate. Historical readers stay available. '
                  'Check context leaks, nested registry behavior, cancellation, stale host behavior, '
                  'and test discrimination. Known remaining work: other legacy selection consumers, '
                  'team Elo, generic slash-command scope. Do not certify whole release or confuse '
                  'these known gaps with a claim that this increment closes all isolation. '
                  'Distinguish concrete new defects from inherited gaps. Repository source only.\n')
        for name in ['packages/cli/src/surface-authority-runtime.ts',
                     'packages/mod-kernel/src/configuration-scope.ts',
                     'packages/mod-ratings/src/role-specialization.ts',
                     'packages/cli/src/cesar/routing.ts',
                     'tests/unit/modular-ratings-runtime.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        for name, start, end in [
            ('packages/cli/src/cesar/brain.ts', 135, 190),
            ('packages/cli/src/cesar/brain.ts', 3975, 4040),
            ('packages/cli/src/signals/dispatch/cesar-router.ts', 1100, 1245),
            ('tests/unit/modular-plan-step-admission.test.ts', 1, 175),
        ]:
            prompt += f'\nEXCERPT {name}:{start}\n' + '\n'.join(
                (qualified / name).read_text().splitlines()[start - 1:end])
        prompt += '\nFULL INCREMENT DIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages', 'tests'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-role-position':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Review this team composition '
                  'bug fix on HEAD886b6efba. Existing composer used the interleaved engine index '
                  'as role position: 2v2 Alpha had two architects and Beta two implementers. '
                  'Fix uses within-team position for roles, preserving engine ordering and '
                  'finite-size rounding/minimum behavior. It rejects nonfinite counts before '
                  'creating arrays; malformed Brainstorm/Tribunal counts previously produced '
                  'empty teams and undefined.engineId crashes. Forge retains its existing '
                  'numeric fallback/cap. Tests include size1/2/3/4 roles, exact engine ordering, '
                  'actual Forge Git/worktree/fitness effects with fake providers, and malformed '
                  'counts before dispatch. Check concrete regressions and test weaknesses. '
                  'Legacy team composition/Elo ownership remains separate unfinished work. '
                  'Do not certify full modular release. No new dependencies or production installs.\n')
        for name in ['packages/support-panel/src/teams.ts',
                     'packages/mod-team-forge/src/implementation.ts',
                     'packages/mod-team-forge/src/implementation.test.ts',
                     'packages/mod-team-brainstorm/src/implementation.ts',
                     'packages/mod-team-brainstorm/src/implementation.test.ts',
                     'packages/mod-team-tribunal/src/implementation.ts',
                     'packages/mod-team-tribunal/src/implementation.test.ts',
                     'tests/helpers/forge-host.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-intent-input':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Review the team intent '
                  'parse/run input mapping repair on e51b93945. Preserve public parser output '
                  'used by legacy TUI handlers and ordinary CLI input behavior. Physical intent '
                  'runners previously ignored membersPerSide, tribunalMode, and fitnessCmd, '
                  'silently choosing 2v2/adversarial/true fitness. The fix maps these fields at '
                  'the intent execution boundary into existing command inputs. No new dependency '
                  'or shared adapter. Three regressions failed before and all22 focused tests '
                  'plus typecheck now pass. Forge uses actual isolated Git/worktrees/fitness '
                  'with fake provider dispatch and checks Alpha pass, Beta fail, patch and '
                  'source-checkout isolation. Check concrete defects, schema/dispatch contracts '
                  'and test gaps. Distinguish inherited behavior and no-input defaults from '
                  'regressions. Do not certify the whole modular product.\n')
        for name in [
            'packages/mod-team-forge/src/implementation.ts',
            'packages/mod-team-forge/src/implementation.test.ts',
            'packages/mod-team-brainstorm/src/implementation.ts',
            'packages/mod-team-brainstorm/src/implementation.test.ts',
            'packages/mod-team-tribunal/src/implementation.ts',
            'packages/mod-team-tribunal/src/implementation.test.ts',
            'packages/support-panel/src/teams.ts',
        ]:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-shared-owners':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript ownership review. No tools. Compare the '
                  'supplied original Core team files at f09b391c8 with their extracted owners. '
                  'Kernel owns the exact team contract type closure as assigned by the frozen '
                  'ledger. Panel owns composition/roles with injected confidence-floor reader; '
                  'Ratings owns score snapshots, team Elo storage/math and contribution weights. '
                  'Core public signatures remain through narrow facades. Preserve three snapshot '
                  'reads per compose call, unrounded role scores, rounded composition scores, '
                  'random tie handling, UUIDs, weights, explicit/auto/adaptive behavior, file '
                  'locking and serialization. No dependency additions. Host Date/JSON/Object '
                  'wrappers were direct built-in calls. Baseline fixtures passed before move '
                  'and pass unchanged afterward. All selected existing tests/typecheck pass. '
                  'This is behavior-preserving extraction: optional-Ratings guards, static '
                  'team path behavior, and richer physical-team workflow parity remain separate '
                  'open work. Identify concrete regressions or boundary errors, distinguish '
                  'inherited defects, and do not certify complete modular acceptance.\n')
        for name in ['packages/core/src/teams/team.ts', 'packages/core/src/teams/team-elo.ts']:
            prompt += '\nBASELINE ' + name + '\n' + subprocess.run(
                ['git', 'show', 'f09b391c8:' + name], cwd=qualified,
                capture_output=True, text=True, check=True).stdout
        for name in ['packages/core/src/teams/team.ts', 'packages/core/src/teams/team-elo.ts',
                     'packages/mod-kernel/src/team-contracts.ts',
                     'packages/support-panel/src/team-composition.ts',
                     'packages/mod-ratings/src/team-elo.ts',
                     'tests/unit/modular-team-ratings-owner.test.ts',
                     'packages/support-panel/package.json', 'packages/mod-ratings/package.json']:
            prompt += '\nCURRENT ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages', 'tests'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-ratings-disabled':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. User requires workflows '
                  'to keep running when Ratings is disabled, without rating selection or '
                  'updates. New team owner guards return before reading ratings or taking '
                  'update locks. Missing confidence loader keeps role ordering stable; '
                  'aggregate floor retains existing neutral default100. Enabled behavior '
                  'and historical load/get/predict readers remain unchanged. Check concrete '
                  'regressions, invocation scope, enabled behavior, and discriminating tests. '
                  'Three regressions failed before the fix. Rich physical-team workflow '
                  'parity and inherited static TEAM_ELO_PATH remain separate open work. '
                  'Do not certify whole-project acceptance. Distinguish inherited issues.\n')
        for name in ['packages/mod-ratings/src/team-elo.ts',
                     'packages/support-panel/src/team-composition.ts',
                     'packages/core/src/teams/team.ts',
                     'packages/mod-kernel/src/registry.ts',
                     'tests/unit/modular-team-ratings-owner.test.ts',
                     'tests/unit/modular-ratings-runtime.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages', 'tests'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-raw-baselines':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript test review. No tools. Production unchanged. '
                  'Before moving rich legacy team workflows into physical mods, capture raw '
                  'behavior contracts. New tests cover cooperative Tribunal roles/context/events '
                  'and Brainstorm structured drafts, draft/synthesis failures and match envelope. '
                  'Tests invoke real workflow with recording fixture adapter, no live providers. '
                  'Existing composition/rating tests cover team construction separately. '
                  'A negative control replacing Tribunal totalTokens with zero failed only the '
                  'new raw contract; restoring source passed. Six focused tests and types pass. '
                  'Find concrete false-green risks, wrong expected behavior, state leaks and '
                  'important missing cases for THIS migration baseline. Not whole-project '
                  'acceptance. Distinguish existing production defects from test defects.\n')
        for name in ['tests/unit/team-prompt-routing.test.ts',
                     'packages/forge/src/team-brainstorm.ts',
                     'packages/forge/src/team-tribunal.ts',
                     'packages/mod-brainstorm/src/policy.ts',
                     'tests/helpers/agon-home.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'tests/unit/team-prompt-routing.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-brainstorm-physical-command':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Review the physical Team '
                  'Brainstorm runtime extraction, lazy invocation host, CLI binding and command '
                  'cutover. Compare legacy rich workflow with runtime; baseline tests run against '
                  'both. Preserve team composition, semantic prompts, scoring, raw envelopes, '
                  'events and configured judge. Ratings disabled must bypass rating reads/writes. '
                  'Host guards generation/cancellation before and after provider awaits and '
                  'command artifact/status/receipt boundaries. Completion persistence is outside '
                  'workflow catch so receipt failure cannot overwrite success; dual artifact '
                  'and failure-status errors are aggregated. Three regressions failed before fix. '
                  '58 focused tests and types now pass. Legacy facade retirement and MCP host '
                  'binding are explicitly NOT finished (pending internal dependency approval). '
                  'Do not certify release or count those known gaps as new findings. Find '
                  'concrete new regressions, missing behavior, unsafe effects and weak tests.\n')
        for name in ['packages/forge/src/team-brainstorm.ts',
                     'packages/mod-team-brainstorm/src/runtime.ts',
                     'packages/mod-team-brainstorm/src/host.ts',
                     'packages/mod-team-brainstorm/src/implementation.ts',
                     'packages/mod-team-brainstorm/src/implementation.test.ts',
                     'packages/mod-team-brainstorm/package.json',
                     'tests/unit/team-prompt-routing.test.ts',
                     'tests/unit/modular-team-ratings-owner.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nCLI BINDING DIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages/cli/src/first-party-services.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'team-brainstorm-session-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Team Brainstorm TUI '
                  'preparation, display and transcript settlement move from CLI to its mod. '
                  'CLI now binds effects and executeProcessCesarRoute, no legacy Forge import. '
                  'Existing workflow-event channel carries team:run-started with canonical path; '
                  'raw match envelope stays unchanged. No second TUI run directory. Job AbortSignal '
                  'is forwarded through its controller and listener is removed. The committed '
                  'legacy handler is preserved as a fixture; same six cases run on legacy and '
                  'physical session, with three real-binding cases. Missing result display '
                  'mutation failed both success cases. Runtime parity was reviewed/committed '
                  'previously; review this session migration and its boundary changes. '
                  'Find concrete regressions, cancellation/history/publication bugs and weak '
                  'tests. Existing duplicate spinner-stop on error was removed but terminal '
                  'cleanup retained. Broad final release and MCP/legacy facade retirement are '
                  'not claimed. No new dependencies.\n')
        for name in ['tests/fixtures/team-brainstorm-session-legacy.ts',
                     'packages/mod-team-brainstorm/src/session-workflow.ts',
                     'packages/mod-team-brainstorm/src/presentation.ts',
                     'packages/mod-team-brainstorm/src/implementation.ts',
                     'packages/mod-team-brainstorm/src/host.ts',
                     'packages/cli/src/handlers/team-brainstorm.ts',
                     'tests/unit/team-brainstorm-session-baseline.test.ts',
                     'packages/mod-team-brainstorm/src/implementation.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        authority = (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text()
        start = authority.index('export async function executeProcessCesarRoute(')
        prompt += '\nAUTHORITY EXECUTOR\n' + authority[start:start + 2600]
        prompt += '\nCALLSITE DIFF\n' + subprocess.run(
            ['git', 'diff', '--', 'packages/cli/src/signals/dispatch/intent-orchestration.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'team-tribunal-cooperative':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. This is an unfinished '
                  'Team Tribunal ownership migration, not release qualification. The cooperative '
                  'round executor was copied to its physical mod with public Kernel/Engine Runtime '
                  'imports, a narrow registry get port and string mode label. The orchestration '
                  'caller still validates mode and limits rounds. Exact body comparison confirms '
                  'no behavior change except removal of obsolete event casts. Production still '
                  'uses the legacy path. Parent Tribunal mode policy move and runtime/host cutover '
                  'remain pending; do not call this production modularity. Existing raw cooperative '
                  'trace/token/event and phase-failure tests now run against both implementations. '
                  'New 24-case legacy match baseline spans six modes, sizes 1/3 and draw/unscored '
                  'judges. Removing round caps fails all 24; omitting physical synthesis token '
                  'accounting fails its raw-output test. All 62 focused tests, modbuild, types '
                  'and lint pass. Review concrete regressions, misleading test evidence and missing '
                  'behavioral coverage required before the next extraction. Distinguish inherited '
                  'bugs from extraction regressions; do not propose a new abstraction merely for style.\n')
        for name in ['packages/forge/src/team-tribunal.ts',
                     'packages/forge/src/tribunal-modes.ts',
                     'packages/mod-team-tribunal/src/cooperative.ts',
                     'packages/mod-team-tribunal/src/index.ts',
                     'tests/unit/team-prompt-routing.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
    if review_id == 'tribunal-policy-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Review Tribunal policy ownership: '
                  'legacy modes.ts content moved byte-identically to the physical parent mod; legacy '
                  'tribunal-modes.ts now publicly reexports it. Forge has the explicitly approved '
                  'mod-tribunal dependency and build reference. The physical compact runtime now uses '
                  'canonical roles, round caps, participant and summary prompts rather than its duplicate '
                  'policy table. Seven regressions failed before and pass after. Round-context tests '
                  'cover parallel/chained/hybrid. This is NOT full runtime parity: legacy retry, logging, '
                  'envelopes and cancellation remain unfinished. Find concrete new regressions and '
                  'missing discriminating tests; separate inherited defects from introduced ones. '
                  'Do not certify release acceptance. No style-only abstraction requests.\n')
        for name in ['packages/mod-tribunal/src/modes.ts',
                     'packages/mod-tribunal/src/index.ts',
                     'packages/mod-tribunal/src/implementation.ts',
                     'packages/mod-tribunal/src/implementation.test.ts',
                     'packages/forge/src/tribunal-modes.ts',
                     'packages/forge/tsconfig.json',
                     'tests/unit/tribunal-modes.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nCHANGE DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-tribunal/src/implementation.ts',
             'packages/forge/package.json'], cwd=qualified, capture_output=True,
            text=True, check=True).stdout
    if review_id == 'tribunal-runtime-host':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Review an unfinished Tribunal '
                  'runtime migration. The legacy executor moved into mod-tribunal; Forge delegates '
                  'with existing config/rating effects. A bundled host factory guards provider and '
                  'rating entrypoints; CLI binding is prepared. IMPORTANT: implementation.ts still '
                  'has the old compact command executor and is NOT cut over yet; MCP host dependency '
                  'approval is pending. Do not certify full modularity or release. Original function '
                  'body matched after reversing effect injection and type changes; subsequent deliberate '
                  'fixes add optional invocation cwd and cancellation rejection before/after async work. '
                  'Three cancellation cases failed before; parallel cancellation waits for both started '
                  'seats. Rebuilt Promise.race mutation fails. Host guard removal also fails two tests. '
                  'Find concrete new bugs, missing tests and migration hazards; distinguish inherited '
                  'problems and required future cutover from defects in this increment. Focus on '
                  'cleanup, retries, late results, summary, configured engines, state and authority. '
                  'No style-only requests or speculative abstractions.\n')
        for name in ['packages/mod-tribunal/src/runtime.ts',
                     'packages/mod-tribunal/src/host.ts',
                     'packages/forge/src/tribunal.ts',
                     'tests/unit/tribunal-protocols.test.ts',
                     'packages/support-engine-runtime/src/adapter-guard.ts',
                     'packages/support-panel/src/seat-dispatch.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nORIGINAL RUNTIME\n' + subprocess.run(
            ['git', 'show', 'ad593e036:packages/forge/src/tribunal.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nCLI BINDING AND TEST DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/first-party-services.ts',
             'tests/unit/modular-engine-dispatch-contract.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'tribunal-presentation-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Check this mechanical '
                  'Tribunal CLI renderer extraction into the physical mod. Runtime is already '
                  'owned by the mod; compact command cutover remains future work. No dependency '
                  'changes. Terminal styling functions stay injected from the CLI. Quiet branch '
                  'and status writing remain in the caller unchanged. Compare source against the '
                  'baseline. A differential check executed the baseline render block from commit '
                  'a2bb08394 and the compiled new renderer across 72 argument/error length, failure '
                  'count and health-banner cases; all output calls matched exactly. Focused tests, '
                  'types and lint pass. Identify concrete regression or missing evidence, not style '
                  'preferences. Do not certify the complete release.\n')
        for name in ['packages/mod-tribunal/src/presentation.ts',
                     'packages/cli/src/commands/tribunal.ts',
                     'tests/unit/tribunal-presentation.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nBASELINE CLI\n' + subprocess.run(
            ['git', 'show', 'a2bb08394:packages/cli/src/commands/tribunal.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'tribunal-mcp-host':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Review the MCP binding '
                  'to the existing physical Tribunal host. CLI already binds this host. '
                  'MCP gains an existing internal mod-tribunal dependency only. No new external '
                  'package or install. Check lazy initialization, custom engines, disabled Ratings, '
                  'invocation cancellation and generation authority. The compact Tribunal command '
                  'executor remains unchanged and its future cutover is NOT claimed complete. '
                  'Four added MCP host cases failed before the binding; 94 focused tests and '
                  'typecheck pass afterward. Find concrete defects or missing evidence, not '
                  'style preferences. Do not certify the complete release.\n')
        for name in ['packages/mcp/src/first-party-services.ts',
                     'packages/mcp/src/surface-authority.ts',
                     'packages/mod-tribunal/src/host.ts',
                     'tests/unit/modular-engine-dispatch-contract.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mcp/src/first-party-services.ts',
             'packages/mcp/package.json', 'package-lock.json',
             'tests/unit/modular-engine-dispatch-contract.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'tribunal-command-cutover':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Check the Tribunal command '
                  'cutover from a duplicate compact executor to the canonical mod-owned runtime. '
                  'CLI gets human rendering with AGON_RUN/AGON_SUMMARY; MCP and nested calls retain '
                  'JSON. No new dependencies. Existing retries, preflight, judge and roles belong '
                  'to the runtime. Check cancellation, generation checks, failure finalization, '
                  'quiet output, nested Conquer/Pipeline use and behavior parity with old CLI. '
                  'TUI session ownership and retirement remain following work, not claimed done. '
                  'Focused tests pass; the configured judge test fails against the old compact '
                  'executor. Treat every finding as a hypothesis and cite exact source. No release '
                  'certification or style-only findings.\n')
        for name in ['packages/mod-tribunal/src/implementation.ts',
                     'packages/mod-tribunal/src/runtime.ts',
                     'packages/mod-tribunal/src/host.ts',
                     'packages/mod-tribunal/src/presentation.ts',
                     'packages/cli/src/commands/tribunal.ts',
                     'packages/cli/src/run-record-host.ts',
                     'packages/mod-tribunal/src/implementation.test.ts',
                     'tests/fixtures/modular-tribunal-host.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/mod-tribunal/src/implementation.ts',
             'packages/mod-tribunal/src/host.ts', 'packages/cli/src/first-party-services.ts',
             'packages/mod-conquer/src/implementation.test.ts',
             'packages/mod-pipeline-orchestration/src/implementation.test.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'tribunal-session-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review, no tools. Tribunal session ownership moves from CLI '
                  'to its physical mod. CLI binds storage/UI effects and selected registry execution. '
                  'Check cancellation, owner authority, behavioral parity, persistence ordering, '
                  'and cleanup. No new dependencies. Report concrete defects with exact source; '
                  'do not certify whole release. Focused 24 tests and types pass after package build.\n')
        names = ['packages/mod-tribunal/src/session-record.ts',
                 'packages/mod-tribunal/src/session-workflow.ts',
                 'packages/mod-tribunal/src/session-record.test.ts',
                 'packages/mod-tribunal/src/session-workflow.test.ts',
                 'packages/cli/src/blocks/tribunal-session.ts',
                 'tests/unit/modular-tribunal-session.test.ts']
        for name in names:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nTRACKED DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src', 'packages/mod-tribunal/src'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'tribunal-command-retirement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Bounded independent review, no tools. Remove unused legacy Tribunal CLI command '
                  'after physical command cutover. Whole-repository rg found only its declaration '
                  'and the negative import guard, no consumers. Existing public CLI name remains '
                  'in generated dispatch. No dependency changes. Missing-file regression failed '
                  'before removal; all14 lazy-command tests plus types pass afterward. '
                  'Review concrete regressions, not style or whole-release certification.\n')
        for name in ['packages/cli/src/lazy-commands.ts', 'packages/cli/src/lazy-commands.test.ts',
                     'packages/mod-tribunal/src/implementation.ts', 'packages/cli/package.json']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/commands/tribunal.ts',
             'packages/cli/src/lazy-commands.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-tribunal-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Bounded independent code review. No tools. Plan now binds the existing physical '
                  'Tribunal runtime instead of importing the Forge compatibility binding. No new '
                  'dependency. Keep caller-owned outputDir, signal, host effects and behavior. '
                  'Original252 focused tests passed. Ten real-runtime cases cover standalone and '
                  'nested pipeline success, Ratings availability scope, generation change after '
                  'round/summary, cancellation and artifacts. Periodic monitor is held pending: '
                  'four cases proved stale ratings callbacks before assertCurrent was bound; '
                  'all10 plus types passed after. Review source claims, concrete regressions and '
                  'missing failure cases. Do not certify whole release. Public Forge API remains.\n')
        for name in ['packages/cli/src/handlers/plan-mode.ts', 'packages/forge/src/tribunal.ts',
                     'packages/mod-tribunal/src/runtime.ts', 'packages/mod-plan/src/panel-step-execution.ts',
                     'packages/cli/src/surface-authority-runtime.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/handlers/plan-mode.ts',
             'tests/unit/modular-plan-step-admission.test.ts',
             'tests/unit/modular-plan-panel-steps-parity.test.ts',
             'tests/unit/modular-plan-pipeline-step-parity.test.ts',
             'tests/integration/workflow-plan-mode.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-session-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Conquer session ownership moves from the '
                  'legacy CLI handler to the physical mod. CLI binds history/telemetry and selected '
                  'registry execution, no new dependencies. Existing physical backend is authoritative. '
                  'Retain progress, worktree recovery, history, failed status, job cancellation and '
                  'disabled-mod enforcement. New event observer stays out of nested workflow contexts. '
                  'A failing-before test caught success display after cancellation; fixed locally. '
                  'Inspect concrete defects, lost legacy behavior, failure settlement and missing '
                  'tests. Do not certify the whole release. Full build/live gates are still pending.\n')
        for name in ['packages/mod-conquer/src/session-workflow.ts',
                     'packages/mod-conquer/src/session-workflow.test.ts',
                     'packages/cli/src/blocks/conquer-session.ts',
                     'packages/mod-conquer/src/implementation.ts',
                     'packages/mod-conquer/src/host.ts',
                     'tests/unit/modular-conquer-session.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nOLD HANDLER\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/cli/src/handlers/conquer.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/signals/dispatch/cesar-router.ts',
             'packages/cli/src/signals/dispatch/intent-session.ts',
             'packages/cli/src/signals/dispatch/intent-orchestration.ts',
             'packages/mod-conquer/src/implementation.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-cli-presentation':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Restore physical Conquer CLI human output '
                  'while preserving structured nested results, exit codes, cancellation, worktree '
                  'recovery and publication hints. Shared progress rendering also serves sessions. '
                  'The old standalone command is provided for behavior comparison, not used at runtime. '
                  'No new dependency or runtime algorithm. Check concrete regressions and missing '
                  'failure-path tests. Do not certify the complete modular release.\n')
        for name in ['packages/mod-conquer/src/cli-workflow.ts',
                     'packages/mod-conquer/src/presentation.ts',
                     'packages/mod-conquer/src/session-workflow.ts',
                     'packages/mod-conquer/src/session-workflow.test.ts',
                     'packages/mod-conquer/src/implementation.ts',
                     'packages/mod-conquer/src/host.ts',
                     'packages/cli/src/commands/conquer.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/first-party-services.ts',
             'packages/mod-conquer/src/implementation.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'conquer-command-retirement':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Remove obsolete standalone Conquer command. '
                  'Generated physical dispatch already owns execution. Preserve exact legacy CLI '
                  'meta/args in an AST-extracted immutable fixture bound to committed source. '
                  'Move the old mocked successful-push/disabled-Forge-prose test to existing physical '
                  'real-Git matrix, retaining assertions and adding readable CLI merge hint. '
                  'Inspect lost contracts, weakened tests, remaining consumers and retirement guard. '
                  'Do not certify the complete release. Focused tests and types pass.\n')
        for name in ['tests/fixtures/modular-conquer-command-contract.json',
                     'tests/unit/modular-cli-contract-parity.test.ts',
                     'packages/cli/src/lazy-commands.ts',
                     'packages/mod-conquer/src/cli-workflow.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/commands/conquer.ts',
             'packages/cli/src/lazy-commands.test.ts',
             'tests/unit/modular-brainstorm-cli-output-host.test.ts',
             'packages/mod-conquer/src/implementation.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'campfire-runtime-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Campfire runtime owner extraction. '
                  'Preserve frozen legacy prompt/dispatch/round behavior while correcting '
                  'pre-cancelled dispatch, authority revocation, wrong quarantined lead labels '
                  'and failure-record errors masking cancellation. Legacy Forge delegates to '
                  'one mod runtime. CLI/MCP supply guarded invocation capabilities. '
                  'Session host and CLI presentation retirement are subsequent slices, not '
                  'claimed complete here. Find concrete regressions, weakened oracles and '
                  'boundary/lifecycle defects. Do not certify full release acceptance.\n')
        for name in ['packages/mod-campfire/src/runtime.ts',
                     'packages/mod-campfire/src/host.ts',
                     'packages/mod-campfire/src/implementation.ts',
                     'packages/mod-campfire/src/implementation.test.ts',
                     'packages/mod-campfire/src/runtime.test.ts',
                     'tests/fixtures/modular-campfire-legacy.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/forge/src/campfire.ts',
             'packages/cli/src/first-party-services.ts', 'packages/mcp/src/first-party-services.ts',
             'packages/forge/package.json', 'packages/mcp/package.json', 'package-lock.json'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'campfire-session-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Campfire session ownership '
                  'moves into mod-campfire, with narrow CLI storage/display bindings. Selected '
                  'TUI and Cesar execution stays authoritative. Job signals must reach execution. '
                  'Preserve individual response history, tracker, session result and telemetry. '
                  'Stores are ordered nontransactional writes, not an atomic transaction. '
                  'Check cancellation, partial-write errors, timer cleanup, owner isolation, '
                  'legacy parity and test discrimination. CLI presentation is a later slice. '
                  'Find concrete defects; do not certify whole release acceptance.\n')
        for name in ['packages/mod-campfire/src/session-workflow.ts',
                     'packages/cli/src/blocks/campfire-session.ts',
                     'packages/mod-campfire/src/implementation.ts',
                     'tests/unit/modular-campfire-session.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nLEGACY HANDLER\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/cli/src/handlers/campfire.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nCALLSITE DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/signals/dispatch/cesar-router.ts',
             'packages/cli/src/signals/dispatch/intent-orchestration.ts',
             'packages/cli/src/signals/dispatch/intent-session.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'campfire-cli-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Restore human and quiet '
                  'output on physical Campfire CLI while leaving other surfaces structured. '
                  'Retire unused legacy command after freezing meta/args from Git HEAD. '
                  'Preserve flags, inherited quiet setting, per-run non-sticky quiet mode, '
                  'raw result structure, run status, authority checks and cancellation. '
                  'Verify concrete regressions and oracle weaknesses. No full release claim.\n')
        for name in ['packages/mod-campfire/src/implementation.ts',
                     'packages/mod-campfire/src/host.ts',
                     'packages/mod-campfire/src/implementation.test.ts',
                     'tests/fixtures/modular-campfire-command-contract.json',
                     'tests/unit/modular-cli-contract-parity.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nLEGACY COMMAND\n' + subprocess.run(
            ['git', 'show', 'HEAD:packages/cli/src/commands/campfire.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/first-party-services.ts',
             'packages/cli/src/lazy-commands.test.ts', 'packages/mod-campfire/src/implementation.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'plan-campfire-direct':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Plan now calls the physical '
                  'Campfire owner rather than the public Forge facade. Preserve topic/rounds, '
                  'use the Plan-captured cwd, enforce cancellation and generation authority. '
                  'Public Forge compatibility export stays. Check concrete regressions and '
                  'test weaknesses. No release certification.\n')
        for name in ['packages/cli/src/handlers/plan-mode.ts',
                     'packages/mod-campfire/src/runtime.ts',
                     'packages/mod-plan/src/panel-step-execution.ts',
                     'packages/forge/src/campfire.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/handlers/plan-mode.ts',
             'tests/unit/modular-plan-step-admission.test.ts'], cwd=qualified,
            capture_output=True, text=True, check=True).stdout
    if review_id == 'think-owner-metadata':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded review. No tools. Correct ThinkResult metadata ownership '
                  'from Forge to Think, preserving historical reader behavior and disposal. '
                  'Also repair stale first-party generator templates that erased existing public '
                  'exports and engine.dispatch permissions. Check the diff against existing '
                  'exports, exact assignment delta, generator test and result-reader coverage. '
                  'Runtime extraction is NOT completed by this change. Find concrete defects; '
                  'do not certify the release. No dependencies changed.\n')
        for name in ['scripts/spec/generate-modular-agon-ownership.mjs',
                     'scripts/spec/generate-modular-first-party-packages.mjs',
                     'packages/mod-think/src/implementation.ts',
                     'packages/mod-forge/src/implementation.ts',
                     'tests/unit/modular-package-graph.test.ts',
                     'tests/unit/modular-first-party-observability.test.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nDIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'scripts/spec/generate-modular-first-party-packages.mjs',
             'scripts/spec/generate-modular-agon-ownership.mjs', 'packages/mod-ratings/src/index.ts',
             'docs/specs/evidence/modular-agon-ownership.json', 'packages/mod-think',
             'packages/mod-forge/agon.mod.json', 'packages/mod-forge/src/implementation.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'think-runtime-cli-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Think execution now belongs '
                  'to mod-think; public Forge API delegates through a narrow facade. Physical '
                  'CLI/TUI contribution uses a captured host and run-status storage rather than '
                  'the old simplified generic engine dispatch. Preserve raw requests/results, '
                  'critic behavior, cancellation, generation authority, CLI full/quiet/JSON '
                  'output, help and failure status. Old CLI command is removed after freezing '
                  'its exact source and metadata. TUI session ownership is a subsequent slice, '
                  'not claimed complete here. Find concrete defects and discriminating test '
                  'gaps. No release certification. One new existing internal workspace edge '
                  'legacy Forge -> mod-think; no external version change.\n')
        for name in ['packages/mod-think/src/runtime.ts', 'packages/mod-think/src/host.ts',
                     'packages/mod-think/src/implementation.ts', 'packages/mod-think/src/presentation.ts',
                     'packages/mod-think/src/runtime.test.ts', 'packages/mod-think/src/implementation.test.ts',
                     'packages/mod-think/src/presentation.test.ts', 'packages/forge/src/thinking.ts',
                     'tests/fixtures/modular-think-command-legacy.txt']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nHOST/GENERATOR DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/first-party-services.ts',
             'scripts/spec/generate-modular-first-party-packages.mjs',
             'tests/unit/modular-cli-contract-parity.test.ts', 'packages/forge/package.json',
             'packages/forge/tsconfig.json', 'package-lock.json'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    if review_id == 'think-session-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Think TUI session policy '
                  'moves from the legacy handler into the physical Think package. CLI binds '
                  'storage, timers, display and captured generation authority. Generated slash '
                  'execution and legacy-shaped fallback now share the physical contribution; '
                  'fallback forwards the job signal. The old handler is retained byte-exactly '
                  'as a fixture and deleted from production. Check lost behavior, cancellation, '
                  'stale generation effects, cleanup, selection, failed result/receipt handling, '
                  'and user-visible parity. Tests compare displays and stores to the frozen '
                  'legacy handler. Full-suite and native TUI qualification are still pending. '
                  'Distinguish inherited defects from regressions; identify concrete fixes and '
                  'missing discriminating tests. Do not certify the entire release.\n')
        for name in ['packages/mod-think/src/session-workflow.ts',
                     'packages/mod-think/src/session-workflow.test.ts',
                     'packages/mod-think/src/implementation.ts',
                     'packages/cli/src/blocks/think-session.ts',
                     'tests/unit/modular-think-session.test.ts',
                     'tests/fixtures/modular-think-session-legacy.txt']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nROUTING DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/signals/dispatch/intent-orchestration.ts',
             'packages/cli/src/signals/dispatch/intent-session.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
        prompt += '\nFULL ROUTER\n' + (qualified / 'packages/cli/src/signals/dispatch/intent-router.ts').read_text()
        prompt += '\nGENERATION GUARD\n' + (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text()[
            (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text().index('export function assertProcessSurfaceAvailable'):
            (qualified / 'packages/cli/src/surface-authority-runtime.ts').read_text().index('/** Carry selected settings')]
    if review_id == 'council-runtime-owner':
        qualified = Path('/Users/ra/dev/agon-audit-qualification')
        prompt = ('Independent bounded TypeScript review. No tools. Council runtime ownership '
                  'moves to mod-council; legacy Forge delegates through its public API. Physical '
                  'Council previously had a shortened incompatible algorithm; now uses the '
                  'legacy runtime with injected effects. Check cancellation, stale generation, '
                  'nested Conquer aliases, optional Ratings, output/status/receipt ordering, '
                  'CLI/MCP host boundaries and missing behavior tests. MCP has no Council tool; '
                  'its nested host checks Council CLI contribution in the same generation. '
                  'TUI and Cesar now use an owned session workflow; original CLI command and '
                  'handler are retired. Check job failure propagation, captured session/signal, '
                  'disabled contributions, and retained verdicts after receipt failure. '
                  'Full release qualification remains unfinished. Report concrete bugs, not style. '
                  'Do not certify the release.\n')
        for name in ['packages/mod-council/src/runtime.ts', 'packages/mod-council/src/command.ts',
                     'packages/mod-council/src/host.ts', 'packages/mod-council/src/presentation.ts',
                     'packages/mod-council/src/session-workflow.ts',
                     'packages/mod-council/src/session-workflow.test.ts',
                     'packages/cli/src/blocks/council-session.ts',
                     'tests/unit/modular-council-session.test.ts',
                     'tests/unit/modular-council-session-routing.test.ts',
                     'packages/mod-council/src/implementation.test.ts', 'packages/mod-council/src/host.test.ts',
                     'packages/forge/src/council.ts', 'packages/mcp/src/surface-authority.ts']:
            prompt += '\nFILE ' + name + '\n' + (qualified / name).read_text()
        prompt += '\nHOST/CONSUMER DIFF\n' + subprocess.run(
            ['git', 'diff', 'HEAD', '--', 'packages/cli/src/first-party-services.ts',
             'packages/mcp/src/first-party-services.ts', 'packages/mod-conquer/src/implementation.test.ts',
             'packages/cli/src/signals/dispatch/intent-session.ts',
             'packages/cli/src/signals/dispatch/intent-orchestration.ts',
             'packages/cli/src/signals/dispatch/intent-router.ts',
             'packages/cli/src/signals/dispatch/cesar-router.ts',
             'packages/cli/src/cesar/brain-helpers.ts'],
            cwd=qualified, capture_output=True, text=True, check=True).stdout
    packet = output / f'{review_id}-review-input.txt'
    try:
        with packet.open('x') as stream:
            stream.write(prompt)
    except FileExistsError:
        if packet.read_text() != prompt:
            raise RuntimeError('Refusing to overwrite a different review packet')
    command = ['/usr/bin/sandbox-exec', '-f', str(output / 'review.sb'),
               '/opt/homebrew/bin/node', str(repo / 'packages/cli/dist/index.js'),
               'ask', engine, prompt, '--timeout', '600', '--quiet']
    log = output / f'{review_id}-{engine}-review.log'
    if log.exists():
        raise RuntimeError('Refusing to overwrite review evidence')
    with log.open('xb') as stream:
        result = subprocess.run(command, cwd=repo, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=660, check=False)
    receipt = {'engine': engine, 'exitCode': result.returncode,
               'packetSha256': hashlib.sha256(prompt.encode()).hexdigest(),
               'logSha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    with (output / f'{review_id}-{engine}-review.receipt.json').open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
finally:
    for destination in created:
        destination.unlink()
