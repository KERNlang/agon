# Roadmap status reconciliation

Status: building. Documentation correction under the existing remediation goal.
Observed subject: f11c6602fb873f7294760421e68037b785a82188.
Scope: acceptance-roadmap Markdown and the claims in its existing JSON source.
No production behavior, acceptance commands, slice criteria, ownership assignment,
package edge, or release budget changes are authorized by this correction.

## Confirmed defects

- Markdown still calls the durable host specified-only; JSON C04 already marks
  it implemented and names live source files.
- C03 repeats the original 148/144 edge discrepancy. Current committed graph
  diagnostic reports 49 packages, 151 declared and 151 unique edges, no duplicates.
- C05 says only API/kernel target packages exist. Physical mod and support
  implementations exist, but remaining Plan and Brainstorm host adapters prevent
  claiming extraction complete.
- C06-C08 call runtime surfaces, lifecycle, and trust specified-only despite
  executable implementations and tests. Existence is not release qualification.
- The old TS7016/ignored declaration/dirty-index diagnostic is historical. The
  current commit diagnostic has no contamination and equal index/commit hashes,
  but rejects stale review evidence and has not run clean-install steps.

## Evidence and limitations

`roadmap-current-clean-diagnostic.receipt.json`: exit 1, no provider launches.
Log SHA-256: 975d01e51422cc81983836a14b5bef68de00bb026bca83b4b694d27ad8e9cfe9.
Command: node scripts/spec/qualify-modular-agon-clean-checkout.mjs --subject=commit.
No --run-clean: that path invokes npm ci, forbidden by the current goal.

Source checks: managed-lifecycle.ts has install/update/downgrade plans and
rollback; first-party-surface-bootstrap.ts activates physical packages and has
kernel-only safe mode; trust-authority.ts and folder-mod-manager.ts implement
authority and discovery/activation. These paths support existence claims only.

Remaining adapters: core/src/blocks/brainstorm-host.ts binds configuration and
effects for CLI/MCP; cli/src/signals/dispatch/plan-execution.ts explicitly retains
its temporary coordinator effect adapter. Full ownership remains unqualified.

## Verification

Require unchanged package/slice/acceptance sections in JSON, valid repository
references, roadmap structural checks, and current-subject slice assessment.
Do not turn assessment red into success: missing clean receipts remain missing.
Independent review and repository gates precede a local commit.

## Review and current readiness

Agon review packet tree: 5481feb414202f895cf389837ecb4c43f4ad696d.
Packet SHA-256: d8d81fa4973819c4587577e070de92707d375f93c8191fc16d1e7d1fe93b2906.
Codex returned one finding: structural validation does not prove a governance
freeze. Confirmed against the verifier; C03 now names the declared-dependency
structural map, without changing any package/slice requirements. Also clarified
that Brainstorm's mod owns runtime dispatch while its Core facade binds effects,
and pinned diagnostic wording to the observed commit instead of calling it current.
Codex log SHA-256: bdead3ec48e0673d4397b336d63f7c095e1df5cb4a8eaee28117560bf03405ba.
Kimi returned no answer (exit 1); no authentication repair or login attempted.

Existing slice assessment at f11c6602: all acceptance commands are present;
zero ready slices because all nine exact clean-subject receipts are missing.
This does not mean implementations are absent. It means acceptance is unproven.
Receipt: roadmap-status-assessment.receipt.json; exit 1; provider launches zero.
Log SHA-256: 3a074a0515111fb51661c095ffdb3a442a415b44f8a5c89cc38c55982b9bd9c6.

## Completed documentation increment

Commit: 64ecbc42b0c6eb2d96a439c65c34d6efafbdd248.
Tree: d4bc3cf785939d21277e884d9535d006ed082a70.
Two documentation files only; 81 added lines, 40 removed. No runtime code change.
Final local checks confirmed all claim paths and relative Markdown links resolve;
all non-claim JSON fields (including every package and acceptance criterion) are
unchanged. The reviewer corrections were locally checked; no second panel ran.

roadmap-status-qualified passed once, 280.787 seconds: full build, typecheck,
lint, re-export guard, 8,458 passing tests, six skipped, and structural roadmap
verification. Provider launches: zero. Log SHA-256:
99225ca988dc9bbd6e6d1088ae69c503d6d71465647d8e1851ac91778b58f814.
This is a documentation-increment regression receipt, not release acceptance.

Candidate branch was advanced with compare-and-swap and index-only read-tree.
Preservation checks before and after passed with unchanged log hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Qualification worktree is clean. Nothing installed, promoted, or pushed.

Next implementation dependency checked: Core config.ts still owns concrete
configuration loading/merging, memoization, config writes, and run pruning.
The frozen ledger assigns config state paths to kernel. Its imports from
support-persistence (paths and file lock) cannot be copied into kernel unchanged:
support-persistence has a kernel peer boundary. Brainstorm facade retirement
must resolve that ownership boundary without a circular package dependency or
duplicating its effect wiring at CLI and MCP. Existing config-memo tests cover
clone isolation and invalidation; preserve these semantics in the next slice.

## Later checkpoint: 2026-10-16, commit 93f89463

This section updates the current checkpoint; the earlier sections remain historical.
The active goal now permits isolated frozen candidate installs, not global installs.

- Clean S9 execution: all25 steps pass at93f89463, including install, npx,
  migrations, complete test suite, performance and load. Overall release acceptance
  is still red: review subject mismatch and incomplete native platform evidence.
  Receipt: `93f89463-clean-release-qualification.receipt.json`; log SHA256
  `00e95db2934ba585d7398c4363d5debd51ad2d7d628665377f3553691d27bd1d`.
- Inventory reports49packages,36physical mods,872ownership assignments,
  51release artifacts. Those counts do not prove behavior or final acceptance.
- The physical first-party bootstrap bridge and generator fallback are removed
  in93f89463. Regression tests prove physical command execution and unchanged
  safe-mode kernel dispatch. KL-011 rejects bridge restoration.
- Historical Plan readers remain intentional. Core's Brainstorm host facade
  still exists at `packages/core/src/blocks/brainstorm-host.ts`, with live CLI/MCP
  consumers. It delegates runtime policy to mod-brainstorm but still binds effects.
  An empty surface-adapter list does not prove all compatibility facades retired.
- Quota kernel APIs exist; CLI quota composition remains absent. The existing
  CLI to support-engine-catalog dependency request is still unanswered.
- All nine required committed schema2 slice receipts remain absent. The assessor
  reports a clean worktree, valid roadmap and available commands, not readiness.
- Native Node22/24 and other architecture/OS evidence remain unavailable. Current
  diagnostic matrix has1passed/11external/0failed; it is not native qualification.
- Kimi review failed. Its isolated log contains authentication error types.
  No personal authentication changed. Bounded Codex reviews are not a substitute
  for final subject-bound independent acceptance.
- Latest recorded security scan remains red:16advisories,9package/version entries,
  2critical/7high/6medium/1low. Dependency upgrades require the pending approval.

After this checkpoint, the Ask diagnostic regression is under repair in the same
worktree. Keep its tests/review/receipt separate from93f89463 qualification.
No requirement, budget, acceptance command or ownership assignment changed here.
Durable archives remain at `/Users/ra/dev/modular-agon-evidence-archive/2026-10-10-2b59937b`.

## Later checkpoint: 2026-10-16, quota CLI committed

This supersedes the earlier statement that CLI quota integration lacks approval.
Raphael approved CLI -> existing support-engine-catalog. Implementation commit:
fc357caf3d3e5b4ea644f1224818d6a558a23cab. Development receipt refresh:
f058e61e (clean worktree after commit). No external version changed.

Explicit `mod retention quota` previews logical-byte quota and rollback-window
policy, then requires exact saved-plan approval or cancellation. Existing kernel
and cache owners implement collection; no second collector. Review found and
tests reproduced a missing-home replay defect; the cache owner now keeps a stable
canonical identity across home absence/creation. Selected and protected payloads
survive; cache-first success and terminal replay were exercised through the CLI.

Full gate receipt: `/Users/ra/dev/modular-agon-remediation/quota-cli-full-gate.receipt.json`.
9576 tests passed,6 skipped; build/types/lint/reexports/generated/release/SBOM
checks pass. Packed npm/npx84checks pass. Zero providers. This is increment
verification, not final clean-checkout S9 acceptance. OSV remains16findings.
Old and new packed receipts are retained with hashes/retrieval evidence in
`/Users/ra/dev/modular-agon-evidence-archive/2026-10-16-quota-cli`.

Remaining host ownership source trace: Core forge-host.ts still contains
invocation-scoped authority capture, adapter guard and registry-bound seed policy.
The Forge mod already depends on engine-runtime and has the host interface;
moving this policy into that owner needs no new dependency. Core effect wiring
still binds config/ratings/tracker/protocol owners and must not be called retired
merely by moving the host factory. Brainstorm's Core effect facade still has
both CLI/MCP consumers. Preserve compatibility signatures and invocation checks.
This invocation-policy increment is now committed as `02e3e290`. The remaining
Core effect wiring and Brainstorm facade are not retired.

Forge host checkpoint, 2026-10-16: full gate passed in 580.003 seconds,
9581 tests passed and 6 skipped; build, types, lint, generated projections,
release set, SBOM and packed npm/npx checks passed. Zero provider launches.
Receipt: `forge-host-owner-full-gate.receipt.json`; log SHA-256:
`c130cf1b4ad07e991dd8fa69b2e24be32044cd2b3196373ccf9657e347bada20`.
Independent Codex review found no concrete regression. Authority and registry
negative controls failed as required after correcting the registry identity
assertion. This verifies the increment, not full modular acceptance.

All prior native/reviewer/security/final-receipt limits remain. No push, promotion,
global install, personal-state change or acceptance waiver occurred.

## Clean committed checkpoint 02e3e290, 2026-10-16

Qualification completed in991.586s with zero providers. All25clean-checkout
steps passed, including frozen install, packed npm/npx, migrations, full tests,
performance, sustained load and final clean-worktree verification. Overall
acceptance remains RED: review subject mismatch; diagnostic platform matrix
has1passed/11external, not native release qualification. No waiver.

Subject:02e3e290fa052b4e46bfdcea6dc0af39aad5f142,
tree544003f6cfa5898e252f1b7686bf67914546a025,
hashsha256:00c1cef164eae193efb48b961f52a5e67ef2b3efdeeae4889227c7a441667d77.
Receipt:02e3e290-clean-release-qualification.receipt.json;
logSHA80e11820e572d9bef8d56ea29a6c9e7949eab6459ddd5704a8661832f0394c3c.

Brainstorm authority repair is uncommitted: shared adapter guard, Core forwarding,
CLI/MCP capture. Agon Codex review adjudicated;74focused tests/types/lint pass.
Core forwarding mutant fails and restored code passes. Full gate
brainstorm-authority-full-gate is now running. Remaining effect-composition
ownership and final release evidence are still unfinished.

Brainstorm authority checkpoint:a20bec52,2026-10-16. Shared guard,Core forwarding,
CLI/MCP authority capture and74focused checks verified. Full gate560.924s:
9595tests passed,6skipped,all repository and packed-install gates green,zero
providers. Receipt:brainstorm-authority-full-gate.receipt.json;logSHA
255f3f219212f6362ad7bf1118fcfae45f5c4efd2fdd23567ad7297354e97f73.
This does not retire Core effect composition or satisfy final release review.
## Current checkpoint: 7ccef6e3, 2026-10-16

This checkpoint supersedes earlier descriptions of unfinished quota integration,
Forge invocation policy, Brainstorm authority, and API catalog ownership. It does
not supersede the original acceptance criteria or qualify a release.

Verified local commits since 02e3e290:

- a20bec52: Brainstorm invocation authority and deferred-dispatch guards.
- 7fe95fdb: Forge owns its four gauntlet configuration keys.
- b29c8504: Ratings owns role-specialization behavior.
- a2d983e8: Plan owns executor assembly; CLI supplies narrow effects.
- 1ba706ca: Plan owns proposal approval and coordinator clearing order.
- d6fa2754: run-directory pruning excludes records, metadata and symlinks.
- 7ccef6e3: support-engine-catalog owns API catalog implementation; Core keeps
  compatibility exports with shared function/cache identity.

Latest completed full development gate is `api-catalog-owner-full-gate`:
9,629 tests passed, 6 skipped, 84 packed npm/npx checks, zero provider launches.
Build, types, lint, generated projections, release-set, SBOM and re-export guards
passed. These are component/integration receipts, not final subject acceptance.

Current working-tree change: two Brainstorm config-boundary tests. Global,
project and private timeout overrides pass through physical and compatibility
hosts. A deliberate process-cwd substitution fails. Restored focused run passes
78 tests, types and focused lint; independent Codex review found no actionable
finding. Full gate `brainstorm-config-boundary-full-gate` remains running.

Remaining ownership work is concrete, not "remove every Core import":

- Brainstorm CLI/MCP decorators still call the temporary Core effect factory.
  Final mode behavior already lives in mod-brainstorm. Direct owner composition
  requires the requested existing-workspace dependency batch. CLI catalog alone
  was approved; that approval does not cover the other edges.
- Plan's remaining Core binding supplies pricing and one shared cost estimator
  to proposal, execution, routing and auto-approval consumers. Replacement must
  preserve shared learning history and activated-owner enforcement. The old
  scheduler/sanitizer files are already gone.
- Forge still has Core effect composition. Apply backend is physically extracted;
  final adapter-retirement and original kill-list evidence must be reconciled.

Final acceptance still needs exact committed-subject slice receipts and review,
clean candidate qualification and the original ownership/kill-list reconciliation.
The last clean S9 run remains 02e3e290: all 25 checkout steps passed, overall red
for review subject mismatch and external platform evidence. No later component
gate changes that result. Native runner, provider-authentication, provenance and
security-upgrade limits remain as recorded above. No push or global installation.
## Apply ownership reconciliation at 39bfbbe9

The narrow Apply extraction requirement is implemented. Do not schedule another
backend rewrite based on the historical "backend extraction remains open" note.

Verified against current source and the original removal condition in
`modular-agon-completion-progress.md:82`:

- `mod-forge/src/apply.ts` owns selection, preflight, approval, rechecks and apply.
- `support-worktree/src/patch-apply.ts` and `patch-parser.ts` own Git effects,
  inversion and undo. No second backend algorithm remains in Core.
- Core parser and normalization facade files no longer exist. Production import
  guards and public-function identity tests cover their retirement.
- CLI Forge, Review and Undo consumers import worktree support directly and pass
  `persistencePath('undo')`. Core's remaining public two-argument undo wrappers
  preserve historical callers and inject the same directory. The removal
  condition explicitly requires preserving external compatibility; deleting
  those exports would violate it, not improve modular ownership.
- CLI `patch-application-host.ts` owns only terminal interaction lifetime and
  authority checks. The whole-workflow A13-APPLY-HOST callback is already retired.

Focused verification `39bfbbe9-apply-retirement` passed 127 tests across nine files
in3.801s, with zero provider launches. This includes real Git apply/undo and byte
restoration, malformed paths/inversion, real generation disable during approval,
borrowed UI refusal, expired contexts, and source-edge negative controls.
Log SHA-256:d161efff216aa6f1e89d51350d8c3db181becd301347d797fe39a24e6850ed05.

This closes the source/behavior ownership check for Apply, not global KL-011,
all five surface acceptance, platform qualification, or final release receipts.
No code change, commit, installation or push was needed for this reconciliation.

## Brainstorm direct-host cutover at eaa3a678

CLI/MCP decorators now import the physical Brainstorm factory and inject catalog,
Ratings, dedup and protocol owners directly. Core loadConfig remains the shared
configuration effect. Core's positional factory remains only for historical
public callers; the two execution decorators no longer consume it. This resolves
the specific direct-host ownership gap recorded above, not every KL-011 item.
Approved existing workspace edges are declared in package manifests, lock and
MCP project references. No external version or active installation changed.

Evidence: full pre-review production gate, final integrated factory tests,
independent Codex review, regression control restoring the old Core import, and
final permitted repository suite:9643passed,6existing skips,lint,zero providers.
Final-suite logSHA25681a53fa3e414fc5073940131bc31a73710d0ca201d7e4fe23796bac50e051a40.
An earlier sandbox run failed socket/fs.watch checks and is retained as failed,
not used as passing evidence. Commit is local only.

Next acceptance repair is authorized and implemented but uncommitted: fixed
versioned review inputs break cross-review/receipt circularity without changing
aggregate source hashing. Full gate review-hash-policy-full-gate is running.
Historical manifests intentionally remain invalid under the new policy until
fresh reviews/reaffirmations occur. All9aggregate receipts still require genuine
qualification. No overall release acceptance claim follows from fixture passes.

Read-only remaining-host trace during that gate: Plan's11-lineCore estimator
binding shares learning history across4CLI consumers; physical Plan owns runtime
assembly, executor, sanitizer, selection, approval and invocation session scope.
CLI session effects still bind context, presentation, pricing and leases. The
audit explicitly permits narrow shared-host effects, so do not manufacture a
requirement to delete every Core import or break public compatibility. The
original A05/A06 activation/removal conditions still need explicit reconciliation
against current paths and runtime tests, not just comment removal or file counts.

## Current acceptance and remaining-source reconciliation (567aa81d + Plan WIP)

The bounded review-hash repair is committed at567aa81d. All nine historical
review manifests fail the new policy; all nine schema2aggregate receipts are
missing. The committed assessor is correctly red, with a clean subject. Fresh
reviews and qualification are required, not a manifest relabel.

Plan nested Brainstorm still used the legacy Forge facade after the top-level
host cutover. The current four-file increment removes those two imports/calls
through direct physical runtime composition, without changing options or guards.
Independent review identified missing real-composition coverage; six existing-file
tests now cover both entry points, lazy effects, active probes, protocol parsing,
ratings and blocked dispatch after generation changes. A no-op seeding mutation
fails all six. Full repository gate is in progress; not committed or accepted yet.

A05 source facts: physical Plan owns session scope/expiry, dispatcher ordering,
task/resume policy, proposal approval/rejection, coordinator and callbacks.
CLI intent-session binds actions to host context; first-party-services supplies
physical planSessionHost. Old CLI plan-session-host.ts is absent. Generated and
legacy-shaped routes share dispatchPlanSession, with activation/route tests.
Remaining CLI plan-execution.ts still binds persistence, UI, pricing, callbacks
and authority. Do not claim its removal condition solely from the package import.

A06 source facts: the old brainstorm-session-record.ts is absent. Physical
Brainstorm owns session-workflow, record and presentation decisions. CLI
brainstorm-session.ts binds session/checkpoint/telemetry effects and is used by
both intent-session and cesar-router. Core's old public host facade has no CLI/MCP
decorator consumer after eaa3a678. Historical public compatibility and narrow
host effects must be distinguished from obsolete algorithm adapters.

Additional unclosed parity lead for the complete original ownership inventory:
legacy packages/forge/src/conquer.ts still has consumers in CLI commands/conquer.ts
and handlers/conquer.ts, while mod-conquer/src/implementation.ts has a separate
compact workflow and rejects input.push. The legacy command advertises/handles
push after success. This is verified source divergence, not yet a proved live
route regression: trace current generated dispatch, accepted compatibility
requirements, raw-oracle coverage and callers before deciding a repair. Do not
claim Conquer parity from package presence or delete its legacy facade consumer.

Further route trace confirms generated CLI selects Conquer's physical contribution:
cli/lazy-commands.ts:244 includes conquer; schemaGeneratedCommand passes parsed
properties to contribution.run at156; kernel first-party-surface-bootstrap.ts:146
loads the installed package createMod without a Conquer override in CLI services.
CLI contract-parity checks flags only. The physical Conquer implementation test
exercises a two-turn successful patch, not legacy done-oracle or push parity.
Legacy conquer.ts:doneOracleDecision checks oracle tampering, weakened tests,
claim and Nero falsification; the physical compact loop checks successful agent,
successful gate and nonempty diff. This is a substantial source-level semantic
divergence to reproduce and reconcile, not a style cleanup. Keep it separate from
the bounded Plan Brainstorm commit and do not silently relax original behavior.

Plan direct-runtime increment is now committed346c2baa. All relevant gates green:
9649tests,6existing skips,84packed npx checks,zero providers; full receipt
plan-brainstorm-final-gates.receipt.json (logSHA256fe3aa40aab6dfb10a3773d10690e4e72f1c86b698032b5979e420915345816b3).
This resolves the two nested Plan Brainstorm bindings, not Conquer parity, the
entire legacy wrapper or final committed-subject release qualification.

Conquer lead is now a confirmed behavioral regression, not only an inference:
conquer-oracle-parity-probe runs the installed physical contribution with a fake
builder that weakens a tracked test from exit1 to exit0. Physical result:completed;
legacy runDoneOracle on the exact same diff:rejected for L1 acceptance drift.
Raw probe/log retained outside Git; logSHA25636584953d23e1cfcabc4b47c955421d10ecf352bdb08e71cf12fe2a6cbc7b9f6.
Existing115tests pass and miss this comparison. Fix by restoring actual legacy
semantics under one physical owner, not by weakening the old oracle. Frozen-oracle
hashing is a legacy future-hardening note, not implemented baseline behavior.
Internal Forge→mod-conquer approval requested asynchronously before introducing
that owner dependency. No new external package or install is needed.

## Ownership-classifier defect found during Conquer follow-up

Verified on346c2baa while the option-only full gate runs. In
scripts/spec/generate-modular-agon-ownership.mjs:134, the Forge semantic rule
matches `/forge` in the package-directory prefix before narrower source rules
for Conquer, Council, Goal and other workflows. Thus ConquerResult and
FalsifierResult from packages/forge/src/conquer.ts are incorrectly assigned to
mod-forge despite the Conquer command/route assignments belonging to mod-conquer.
The wrong assignments propagate to mod-forge/ownership.json and the slice5 ledger.

A read-only ownership scan found18 rows with that same prefix-shadowing shape:
five Goal oracle events; AttemptRecord, CampfireResult, ConquerResult,
CouncilResult, FalsifierResult, GoalEvent, MutateResult, NaturalizeResult,
NeroResult, ResearchResult, WitnessResult; goals/tmp; and Goal journal.
This is an affected-candidate list, not authority to blindly reassign all18:
trace each actual physical owner and any shared-support destination first.
For reproduction, filter assignments with rule semantic-source-rule and owner
mod-forge whose source starts packages/forge/src/{campfire,council,nero,synthesis,
review,goal,conquer,research,rag,rooms,mutate,naturalize} followed by `.` or `/`.

Repair the generator precedence/path matching and add a discriminating existing
test before regenerating ownership, package assets and migration evidence. Do
not manually change generated rows or use package presence as migration proof.
Keep this separate from the frozen option-forwarding gate. No repository source
changes for this finding yet. This is an original ownership-accuracy requirement,
not a new feature or changed acceptance bar.

Conquer's old diff helpers are shared by Goal and Mutate as well as Conquer;
their imports are packages/forge/src/{conquer.ts,mutate.ts,mutate-semantic.ts,
goal/controller.ts,index.ts}. Do not move them into Conquer and make unrelated
workflows depend on a user-toggleable Conquer mod. Trace the existing support
owner and declare any required internal edges before extraction.

Read-only generator experiment: evaluated the existing generator in a Node VM
with captured writes (no filesystem outputs), moving the broad Forge rule after
the other semantic rules. This changes23rows, not18. Reject that blanket repair:
it also moves Forge's own SynthesisResult from types-impl.ts and
autoReviewAfterForge to other owners purely because their names contain Synthesis
or Review. Preserve those established owners. A bounded fix must prefer the
specific legacy workflow source path over the outer Forge package prefix, not
globally reprioritize name matching. Additional candidates exposed by this
experiment are SemanticMutantsResult in mutate-semantic.ts and SynthesisResult
in synthesis-modus.ts; PostSynthesisFitnessResult in Core requires its own trace.
No production generator edit made during the running Conquer gate.

Conquer option increment is committed16c3ff3b after the full green gate:
9654tests,6existing skips,84npm/npx checks,zero providers. Receipt is
conquer-options-corrected-full-gate.receipt.json in the remediation directory.
No push. Completion-policy parity is not included in that commit.

Next increment started after the green boundary: added assertions to the existing
modular-package-graph.test.ts generator test for specific legacy workflow paths
and preserved Forge controls (autoReviewAfterForge and its SynthesisResult).
ownership-prefix-negative intentionally fails on the current broad-prefix rule;
log SHA25619e6f9daa13600cd37beb835c4487aeda2eda44a729e224f0a9d46f567cb2dee.
Only that test file is uncommitted. Production generator is still unchanged.
Next: repair source-path precedence, regenerate affected artifacts from their
owners, trace the exact diff, review and verify. Do not move name-only matches
or claim that changing assignment metadata physically migrates implementations.

Ownership correction completed in `5c4c3709`: immediate workflow paths now win
over the outer legacy Forge directory. Exactly 20 owner assignments changed;
all 872 inventory occurrence keys retained. Thirteen result registrations moved
from Forge into their nine physical workflow owners with unchanged schemas,
version ranges and output. Roadmap removes exclusively reassigned paths and
preserves shared/manual paths. Full suite 9656 passed, six existing skips;
84 installed-candidate checks, all remaining gates green, zero providers.
Receipt `ownership-registration-final-gate.receipt.json`; detailed failures,
review adjudication and hashes are in durable-config-integration-scope.md.
Conquer completion-policy parity remains open; this ownership fix is not its
runtime fix. No push or final release-acceptance claim.

## Conquer parity follow-up, current source at 5c4c3709 plus boundary work

Builder-start/stop correction is in progress; receipts and independent review are
in durable-config-integration-scope.md. Keep the broader Conquer controller gap
open. Further verified source differences for the next implementation boundary:

- `packages/cli/src/commands/conquer.ts`, run: rejects maxTurns < 1/NaN and
  maxHours < 0/NaN before worktree creation; the physical runner silently replaces
  maxTurns 0 with 40, clamps negatives to 1 and caps all values at 200. It accepts
  negative/invalid maxHours as unlimited. Preserve actual legacy validation, not
  these silently changed budgets. TUI's old handler also rejects invalid turn caps.
- Legacy CLI resolves builder/advisor aliases and rejects inactive explicit
  advisors before creating the worktree. Physical Conquer checks a raw builder
  ID but does not validate explicit advisors. The current public engine service
  boundary must be checked before adding any new alias-resolution port.
- Legacy Conquer keeps its isolated branch/worktree for human inspection, even
  on errors; the physical arena always cleans up and returns patches. This is a
  behavior difference, not an authorized product choice. Do not claim equivalence
  from textual patch preservation alone (binary/untracked/state need tracing).
- Shared legacy `goal/diff.ts` serves Goal and Mutate as well as Conquer. Keep
  that support dependency separate from Conquer policy ownership. The previously
  requested Forge→mod-conquer edge is not yet approved; no edge has been added.

These are source-verified leads, not new completed fixes or expanded requirements.
Do not edit a frozen gate subject. Do not infer full workflow parity from the
focused Conquer execution-boundary tests.

Builder boundary repair is committed `88673d4e`: full gate 9666 passed/six
existing skips and 84 installed-candidate checks, zero provider launches.
Fresh parity probe on that commit confirms builder failure and green-baseline
behavior now agree with legacy. Numeric cap and TUI forwarding also remain
correct. Missing completion claim still falsely passes physical Conquer; the
comparison deliberately remains red. Receipt and hash details are in the durable
integration journal. No push. No final acceptance claim.
