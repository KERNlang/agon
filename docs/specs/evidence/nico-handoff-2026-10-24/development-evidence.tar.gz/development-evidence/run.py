"""Run existing repository gates with isolated state and provider blockers."""
import importlib.util
import json
import os
import re
from pathlib import Path
import sys

repo = Path('/Users/ra/dev/agon-audit-remediation')
root = Path('/Users/ra/dev/modular-agon-remediation')
run_id = sys.argv[1]
if not re.fullmatch(r'[a-z0-9][a-z0-9_-]*', run_id):
    raise SystemExit('Invalid verification run ID')
if (root / (run_id + '.receipt.json')).exists():
    raise SystemExit('Refusing to overwrite verification evidence: ' + run_id)
try:
    (root / (run_id + '.log')).touch(exist_ok=False)
except FileExistsError:
    raise SystemExit('Refusing to overwrite verification evidence: ' + run_id)
spec = importlib.util.spec_from_file_location('pressure', repo / 'scripts/spec/pressure_modular.py')
pressure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pressure)
env = pressure.isolated_environment(Path('/tmp/amr-runtime'), os.environ)
env['NODE_OPTIONS'] = '--max-old-space-size=4096 --require=/Users/ra/dev/modular-agon-remediation/no-login.cjs'
result = pressure.run_step(sys.argv[1], sys.argv[2:], repo, env, root, 1200)
result['providerLaunches'] = pressure.provider_launches(Path('/tmp/amr-runtime'))
result['passed'] = result['passed'] and not result['providerLaunches']
(root / (sys.argv[1] + '.receipt.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
raise SystemExit(0 if result['passed'] else 1)
