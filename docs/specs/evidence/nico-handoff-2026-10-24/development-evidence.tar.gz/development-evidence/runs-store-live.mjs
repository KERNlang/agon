import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, mkdirSync, writeFileSync, utimesSync, readdirSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { RunsStore as BuiltRunsStore } from '/Users/ra/dev/agon-audit-qualification/packages/support-persistence/dist/index.js';

let RunsStore = BuiltRunsStore;
if (process.argv.includes('--baseline')) {
  const require = createRequire('/Users/ra/dev/agon-audit-qualification/package.json');
  const ts = require('typescript');
  let source = execFileSync('git', ['show', '19c63d96:packages/support-persistence/src/runs-store.ts'], {
    cwd: '/Users/ra/dev/agon-audit-qualification', encoding: 'utf8',
  });
  const owner = 'file:///Users/ra/dev/agon-audit-qualification/packages/support-persistence/dist/index.js';
  for (const dependency of ['./file-lock.js', './paths.js']) {
    assert.equal(source.split(`'${dependency}'`).length, 2);
    source = source.replace(`'${dependency}'`, JSON.stringify(owner));
  }
  const output = ts.transpileModule(source, { compilerOptions: {
    module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022,
  } }).outputText;
  RunsStore = (await import('data:text/javascript;base64,' + Buffer.from(output).toString('base64'))).RunsStore;
}

const root = mkdtempSync(join(tmpdir(), 'agon-runs-live-'));
const original = join(root, 'original');
const replacement = join(root, 'replacement');
const previousHome = process.env.AGON_HOME;
function seed(home, count, content) {
  const dir = join(home, 'runs');
  mkdirSync(dir, { recursive: true });
  const old = new Date(Date.now() - 30 * 86400000);
  for (let index = 0; index < count; index++) {
    const path = join(dir, `run-${String(index).padStart(5, '0')}.json`);
    writeFileSync(path, content);
    utimesSync(path, old, old);
  }
  return dir;
}
try {
  const first = seed(original, 2005, 'original');
  const other = seed(replacement, 2005, 'replacement');
  process.env.AGON_HOME = original;
  const store = new RunsStore();
  const pruning = store.maybePrune({ force: true });
  process.env.AGON_HOME = replacement;
  const result = await pruning;
  assert.equal(result.deleted, 5);
  const names = dir => readdirSync(dir).filter(name => name.endsWith('.json'));
  assert.equal(names(first).length, 2000);
  assert.equal(names(other).length, 2005);
  for (const name of names(other)) assert.equal(readFileSync(join(other, name), 'utf8'), 'replacement');
  assert(existsSync(join(first, '.prune-stamp')));
  assert(!existsSync(join(other, '.prune-stamp')));
  assert.equal(store.snapshot().count, 2000);
  console.log('Real directory switch: original pruned, replacement bytes and stamp untouched');

  const large = join(root, 'large');
  const largeDir = seed(large, 10000, 'large');
  process.env.AGON_HOME = large;
  const largeStore = new RunsStore();
  let heartbeats = 0;
  const heartbeat = setInterval(() => { heartbeats++; }, 1);
  const started = performance.now();
  let largeResult;
  try { largeResult = await largeStore.maybePrune({ force: true }); }
  finally { clearInterval(heartbeat); }
  const elapsedMs = Math.round(performance.now() - started);
  assert.equal(largeResult.deleted, 8000);
  assert.equal(names(largeDir).length, 2000);
  assert.equal(largeStore.snapshot().count, 2000);
  assert(heartbeats > 0, 'Prune must yield to the event loop');
  assert(elapsedMs < 30000, 'Actual prune must fit the existing test timeout');
  console.log(JSON.stringify({ files: 10000, deleted: 8000, remaining: 2000, elapsedMs, heartbeats }));
} finally {
  if (previousHome === undefined) delete process.env.AGON_HOME;
  else process.env.AGON_HOME = previousHome;
  rmSync(root, { recursive: true, force: true });
}
