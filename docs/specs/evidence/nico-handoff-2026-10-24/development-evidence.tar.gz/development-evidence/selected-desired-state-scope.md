# Selected desired-state authority

Status: increment committed and locally verified; whole release not qualified.
Baseline: c2b4c115e47277b448705c74409061abff3f62ea.
Worktree: /Users/ra/dev/agon-audit-qualification.
Authority: original modular goal, one selected generation, rollback/re-entry and
disabled-mod enforcement. No global installation, personal-state writes or pushes.

## Verified defects

1. Setup/update preserved choices from `hostRoot/desired-state.json`. A stale
   mirror can re-enable disabled mods; a missing mirror falls back to full-compat.
   `setup-selected-state-red-v2` fails both actual `runManagedSetup` entrypoint
   tests. SHA-256 390cac52e395fe01ced82ff6e19de2a8c3c08c8c60ed62d6fa165582c54d637e.
2. Real bundled CLI startup rejects stale or missing mirrors before the setup
   command runs. `setup-selected-state-live` failed with "selected canonical lock
   does not bind desired state" at `first-party-surface-bootstrap.ts`.
   SHA-256 11afa66f74903a0896c2d41294cffa221f944a5a6da080895658c92539daf756.
3. Activation service reads the same mirror. It must use selected generation bytes
   rather than disagree with execution after interrupted mirror restoration.
4. The final consumer search found `cli/src/commands/mod.ts:listOutput` also reads
   the mirror. Its CLI/TUI management view can disagree with selected execution.
   This consumer still needs correction after the currently running gate finishes.

## Implemented so far

- Host `readGenerationDesiredState(pointer)` validates generation/pointer binding
  and hashes the exact artifact bytes before decoding them.
- Setup, activation and normal surface bootstrap use that host authority.
- Setup refuses corrupt existing installation state rather than treating it as
  absent. Selection checks bind the preview to the original full pointer hash.
- `--plan` does not use the launcher-writing already-qualified shortcut.
- Initial bootstrap still rejects orphan desired state with no pointer. Safe mode
  remains kernel-only and does not require a valid mutable mirror.

## Evidence and review

- `setup-selected-state-red` failed due two fixture errors (missing timestamp and
  source-vs-bundle release-channel path), not production evidence. Both corrected.
- `setup-selected-state-focused`: two regressions and types passed, no providers.
- `setup-selected-state-controls`: initial four tests, types/lint passed. The
  launcher assertion path was subsequently corrected to `dirname(hostRoot)/bin/agon`.
- `setup-selected-state-review-controls`: all eight expanded tests passed.
- Review packet tree 51c1b7dfb915d617b723184059e7582d759c8e6d covers the initial setup
  change, not the later shared-reader expansion. Codex found no concrete new defect
  and requested race, exact-byte, existing-launcher and fresh-install controls.
  Those controls were added and passed. Kimi exited 1, no review, not a pass.
  Packet SHA-256 70a367bf145c3e6b1ac523bfb1d64a62c18cdf7c0bd1bec85f6da7eaaa34551b.
  Codex log SHA-256 d58e6748454cf8e861c4d1a31637d83fb44714c3ceb1409a602d885b4ddae241.
- `selected-desired-owner-focused`: three artifact-copy injection assertions
  failed because added validation moved the read counts. The injection was moved
  to the actual artifact-builder boundary; unchanged exact-copy refusal assertions
  still apply. No oracle was broadened to accept an unrelated failure.
- `selected-desired-owner-controls`: targeted suites, CLI build and four real
  CLI processes pass, no providers. SHA-256
  4399821e10e2b5aadf06c70e0411cb4cddda2aec50561d1ad177d3f4c6c59268.
  Live fixture installer writes package metadata only, not executable installs.
- `selected-desired-owner-qualified` is running. Do not change repository source
  during this gate; its result is not final for the still-open management consumer.

## Remaining before commit

Fix management view consumer, extend real CLI evidence to cover it, rerun gates
on the final source, preserve candidate worktree bytes, then locally commit explicit
paths and advance candidate ref/index without checking out its dirty files.
Durable config schema migration is still unfinished. This is its state-selection
prerequisite, not a substitute for the original migration requirements.

## Subsequent findings and corrections

- `selected-desired-owner-qualified` passed 8,584 tests (6 skipped), types, lint,
  API compatibility, generator, release and supply-chain checks. It failed the
  cold-start budget: version p95 186.581917 ms and help p95 185.092791 ms against
  185 ms. Other performance dimensions passed. The final live probes did not run
  because the shell stopped at that failure. Receipt SHA-256
  c473c7c55dcc08db21e2051a408116e9c1ade01176e59339e1446b2c5b9f36b6.
  Do not drop the failure or claim this receipt is green.
- Added real `mod list` assertions. `selected-desired-management-red` returned
  enabled for Forge despite selected generation disabling it. SHA-256
  0a6269a0c0c8f9a99d7e96163d7642f6c868a975979e194536451dcd7d6b71d2.
- Management now uses the shared reader. `selected-desired-management-controls`
  passed types, targeted tests, CLI build and six CLI processes. SHA-256
  25a307536a2dde60c712d68390c00597828ef6641f5eb500ed3ace4a3d00074a.

The expanded host/startup/activation/UI boundary received its own bounded review,
not a re-review of corrections to the initial setup-only review. Frozen tree:
dd1eb5782f6c9b15056dd917198599f5c310480f. Packet SHA-256:
c498a6b4acad8f7be9daccecf8cfe8a1665ecc62f629585a0b10f4594e207176.
Codex log SHA-256 90fe1b57878eb65b570908065ada2e45a88a58ebc9ff9043e7e524214647d0ba.
Kimi again exited 1 with no review; no authentication changes were attempted.

All three findings were confirmed against source and reproduced:

1. Management assumed full-compat when pointer absent but orphan mirror remained.
2. Activation preview could read state from B but bind its plan to pointer A.
3. Activation wrapped MOD_SAFE_MODE and MOD_POINTER_CORRUPT as generation corruption.

`selected-desired-review-red` failed all five added cases (two orphan variants,
two pointer error variants, one real second-generation transition during preview).
SHA-256 be5abb23fecf6d32fc74bc3af042fbb9118dc0b2b572b7a44e42884657c0effc.
Corrections retain authoritative error types, parse state for the captured preview
pointer and refuse a changed selection, and reject orphan management state.
`selected-desired-review-fixed` is the pending focused verification. No further
review panel is required merely to recheck these corrections.

## Completed increment

Commit: `6f252733026c3f86431e30b5772069cd24b6b682`.
Committed tree: `748e6159b32a666c2797fe5ef605ce75c9e7a3b8`.
Twelve explicit paths; 301 additions / 68 deletions, including tests and generated
release metadata. Qualification checkout clean. Candidate branch/index advanced
without updating its preserved working files. No push or installation.

- `selected-desired-review-fixed` passed all focused controls, affected package
  builds and six real CLI processes. SHA-256
  2da7eec7cecd4255877e6a2084705877c6c34fa2826933962c3f77c3a7b32b3f.
- `selected-desired-owner-final` passed types/lint/reexports/API compatibility,
  generator drift, release-set/SBOM checks and self-tests, 8,589 tests (6 skipped),
  all eight release performance measurements, six real CLI processes and binary
  artifact retention/rollback/re-entry probe. Duration 204.547 s, no providers.
  SHA-256 ef6c16126aee3159fc61c7db898e574d0ce67856171e88bd1445d8a51d3981b9.
- Final cold-start p95: version 170.373834 ms, help 180.432291 ms, 15 runs each,
  unchanged 185 ms budget. Earlier over-budget run remains retained; the two runs
  show variation, not a guarantee that every machine or future sample stays green.
- Native evidence only: darwin-arm64, Node v26.3.0. No claim for missing platforms.
- Before/after preservation receipts pass for all 281 baseline paths with known
  authorized exceptions, same output hash
  bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.

Remaining: exact committed release qualification and durable settings migration.
The original acceptance criteria remain unchanged. This component result is not
proof that all slices or the final installable release candidate are complete.

Exact committed diagnostic `selected-desired-clean-subject` remains RED:
review subject mismatch and no clean-checkout install steps executed. Subject,
index and commit hashes match
`sha256:942809e85a09dc489bba68e34f1eb586b29cab2a810756f351de41de7a7ff0f8`;
ignored/untracked/unstaged source contamination is empty. Graph has 49 packages,
151 declared/unique edges and zero duplicates. Receipt log SHA-256
1fa1eabea98c85ac233c3a7f62113e66d01b6136910d4123319a088b9005e528.
This is an outstanding release gate, not an exception approved by this increment.
