# Legacy mod-setting compatibility bridge

Status: building; standing remediation goal authorizes implementation.
Date: 2026-10-11. Base 257fb2dfd774526764e98378401f8bb7c7d861e8.
No push, install, dependency, active installation or personal-state changes.

## Required behavior

Runtime contract gives each mod its canonical settings namespace. Existing users
must retain flat config APIs and global/project/private precedence. Currently
Core still reads flat fields; generated invocation reads namespaces. They can
disagree. Reading namespaces alone would also make configSet ineffective when
the same-layer namespace retains an old value.

Generate the nine legacy-key-to-owner mappings from the same schema/ledger
inputs already used for types/defaults. Project each individual config layer:
same-layer explicit namespace wins over its flat alias; higher-priority layers
win regardless of spelling. Unknown or inactive namespaces remain data, with
validation at the selected execution boundary. Do not activate or trust mods.

Use the existing Kernel config store's lock and atomic rename. Add an optional
write-policy callback to its options, leaving default store behavior unchanged.
Core uses it to update a known alias and its owner namespace together from the
freshly locked file. Invalid selected namespace shapes fail without writing.
Do not perform two independent writes or introduce another cache/store.

## Scope and acceptance

Generator + generated compatibility metadata; Core config composition; Kernel
store's additive policy callback; existing config-store tests; generated release
metadata. Expected eight files plus any demonstrated existing-test adjustments.
Green base: successful build, full types/lint/API/package checks, 8,540 tests,
historical 121-field parity and built configuration probes.

Prove scope/spelling precedence, explicit false/zero/arrays, inactive/unknown
retention, no activation authority from project settings, owner-only injection,
single locked write, concurrent unrelated-key preservation, refusal without
write on malformed selected namespace, and cache invalidation. Public defaults
and API compatibility remain unchanged. One isolated Agon review and full
verification with actual config CLI subprocesses before commit.

Durable versioned migration, snapshot readers and rollback integration remain
separate unfinished original requirements. An alias bridge is not their proof.

## Implementation and review evidence

Initial settings-alias-bridge-red failed (hash
02fb40cc835f334d05524e5bcacf35965280f3f2ab2401c75c0832c9f04ae6fe).
Source tests initially used the old built Kernel through Core's package import,
so the new write callback was not exercised. Rebuilding Kernel removed four
failures. One existing cache-binding test depended on being the first Core
import; vi.resetModules now isolates that import while retaining its exact
one-store/cache assertions. Process correction: rebuild a changed dependency
before testing mixed source/package boundaries.

settings-alias-bridge-controls passed tests/types/API compatibility/lint,
hash 434bdaa2ed2efcb4523adf7ed20801f54582f264a6d221529699094f03b450c5.
Agon review tree e3880793e88dd411816ff84d2d5287418f3c59fa; packet hash
460df34d52a1d2ae5329767426cead66e37214b477c583bae6001eab93ed7896.
Codex log 28da0ef6d8cc354ea56154a9504f3f0b840f4038e3d096d8240ac73527f5024f.
Kimi exit 1/no review, not counted as passing.

Review's namespace-replacement finding reproduced: a middle null/array/false
namespace followed by a valid private namespace discarded a canonical field
but retained its stale flat alias. settings-alias-replacement-red failed, hash
f5fcc63638533810aa7561f8a972210cf1c7ac658fd9bae6b7eecda85d8c4ab8.
Now each layer only promotes aliases into its namespace; legacy output resolves
from the final merged namespace, falling back to the unchanged owner default
when replacement discarded a value. No extra store or duplicate state.

Added all-nine-field/wrong-owner checks and unrelated writes preserving malformed
inactive data. settings-alias-review-fixed passed tests/types/API compatibility,
hash 7bac420c7514dbb72a0877523b7a36ecba1b93e8de42edb52c06e415cb32fec7.
The built CLI negative control reproduced the old flat 111 instead of namespace
222, hash 8e89e8ed29a98f131a5fd27d2400c57246b75840518e24aa614948d682528893.
The same five-process helper must pass after build, including canonical writes,
three-scope precedence, permission non-escalation and byte-preserving refusal.

Full settings-alias-bridge-qualified run is active. Do not alter its source
while it runs. No commit yet; final review corrections remain unstaged after the
frozen review subject. Shipping scope remains five authored/generated source
files plus three build-generated release artifacts.

## Qualified and committed

Commit `ddf4b761978a56f4a8f7ad8b3959e2759b88495c`, tree
`dc3d05fd45604d1b007463041721fc01db922e0e`.
Full `settings-alias-bridge-qualified` passed in 314.785 seconds. Repository
suite: 8,559 passed, six skipped. Build, types, lint, reexports, public API
compatibility, first-party generator drift, release-set and supply-chain checks
and their self-tests all passed. Log SHA-256:
`f4c1dabae1ff6f57eca2af7022aa3002b562ffffff75cf0a21740cee30c3debc`.
Provider launches: zero.

Historical 121-field types/defaults/key order remain unchanged. Four existing
config subprocesses, three registered-schema CLI subprocesses and the new five
alias CLI/Node subprocesses passed against the built code. Owner registration
probes passed but do not claim live provider execution. The old-binary CLI
negative control and review-reproduced replacement failure remain retained.
Final focused controls passed, log SHA-256
`d209e849117091d6df96b4bc9d265a27137212e6a05f59207b28e8d40c10068a`.

All eight explicit paths committed locally. Qualification checkout clean.
Candidate branch/index advanced with compare-and-swap and read-tree without -u;
candidate working files were not rewritten. Before/after 281-path preservation
checks passed, hash
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
No push, install, promotion, global Agon or personal-state change.

Not complete: durable config migration, remaining legacy ownership retirement,
and final clean-checkout release qualification. Native platform/provider gaps
remain external. This receipt qualifies the alias bridge only.
