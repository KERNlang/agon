import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const repo = '/Users/ra/dev/agon-audit-qualification';
const root = mkdtempSync(join(tmpdir(), 'settings-alias-cli-'));
const home = join(root, 'home'); const project = join(root, 'project');
mkdirSync(home); mkdirSync(project);
const configPath = join(home, 'config.json');
const projectPath = join(project, '.agon.json');
const privatePath = join(project, '.agon.local.json');
writeFileSync(configPath, JSON.stringify({ forgeFitnessTimeout: 111, permissions: { deny: ['Bash(*)'] },
  mods: { 'agon.forge': { forgeFitnessTimeout: 222, future: 'keep' }, 'absent.mod': 'retain' } }));
writeFileSync(projectPath, JSON.stringify({ forgeFitnessTimeout: 333 }));
writeFileSync(privatePath, JSON.stringify({ mods: { 'agon.forge': { forgeFitnessTimeout: 444, permissions: { allow: ['Bash(*)'] } } } }));
const projectBefore = readFileSync(projectPath, 'utf8'); const privateBefore = readFileSync(privatePath, 'utf8');
const env = { ...process.env, AGON_HOME: home };
let calls = 0;
const cli = `${repo}/packages/cli/dist/index.js`;
function run(args, status = 0) {
  const result = spawnSync(process.execPath, args, { cwd: project, env, encoding: 'utf8', timeout: 30000 });
  assert.equal(result.error, undefined); assert.equal(result.status, status, result.stderr + result.stdout);
  calls++;
  return result.stdout.trim();
}
assert.equal(run([cli, 'config', 'get', '--key', 'forgeFitnessTimeout']), '222');
run([cli, 'config', 'set', '--key', 'forgeFitnessTimeout', '--value', '0']);
assert.equal(run([cli, 'config', 'get', '--key', 'forgeFitnessTimeout']), '0');
const stored = JSON.parse(readFileSync(configPath, 'utf8'));
assert.equal(stored.forgeFitnessTimeout, 0);
assert.deepEqual(stored.mods, { 'agon.forge': { forgeFitnessTimeout: 0, future: 'keep' }, 'absent.mod': 'retain' });
const output = JSON.parse(run(['--input-type=module', '-e', `
  import { loadConfig } from '${repo}/packages/core/dist/index.js';
  import { selectModSettings } from '${repo}/packages/mod-kernel/dist/index.js';
  const config = loadConfig(process.cwd());
  console.log(JSON.stringify({ flat: config.forgeFitnessTimeout, settings: selectModSettings(config, 'agon.forge'), permissions: config.permissions }));
`]));
assert.equal(output.flat, 444);
assert.equal(output.settings.forgeFitnessTimeout, 444);
assert.deepEqual(output.permissions, { allow: [], deny: ['Bash(*)'] });
assert.equal(readFileSync(projectPath, 'utf8'), projectBefore); assert.equal(readFileSync(privatePath, 'utf8'), privateBefore);
const malformed = JSON.stringify({ mods: { 'agon.forge': null } }); writeFileSync(configPath, malformed);
run([cli, 'config', 'set', '--key', 'forgeFitnessTimeout', '--value', '5'], 1);
assert.equal(readFileSync(configPath, 'utf8'), malformed);
console.log(JSON.stringify({ passed: true, calls, namespaceRead: true, atomicAliasWrite: true, scopePrecedence: true, projectCannotChangePermissions: true, malformedPreserved: true, projectBytesPreserved: true }));
