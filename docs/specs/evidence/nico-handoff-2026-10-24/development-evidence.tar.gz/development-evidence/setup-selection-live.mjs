import assert from 'node:assert/strict';
import { cp, mkdtemp, mkdir, readFile, stat, unlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { DurableModHost, ManagedLifecycleService, createFirstPartyActivationService } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';

assert.ok(process.env.AGON_HOME?.startsWith('/tmp/amr-runtime/'));
const repo = '/Users/ra/dev/agon-audit-qualification';
const home = await mkdtemp(join(tmpdir(), 'setup-selection-cli-'));
const hostRoot = join(home, 'modular-host');
const env = { ...process.env, AGON_HOME: home, AGON_MODULAR_HOST_ROOT: hostRoot };
let calls = 0;
function cli(args) {
  const result = spawnSync(process.execPath, [join(repo, 'packages/cli/dist/index.js'), ...args], { cwd: home, env, encoding: 'utf8', timeout: 30000 });
  assert.equal(result.error, undefined);
  assert.equal(result.status, 0, result.stderr + result.stdout);
  calls++;
  return JSON.parse(result.stdout);
}
const initial = cli(['setup', '--plan']);
assert.equal(initial.lifecycle.basePointerHash, null);
const host = new DurableModHost(hostRoot, { kernelVersion: '1.0.0' });
// Copy local declared files as fixtures. Do not install or execute mod code.
const workspaces = JSON.parse(await readFile(join(repo, 'package.json'), 'utf8')).workspaces;
const packageRoots = new Map(await Promise.all(workspaces.map(async workspace => {
  const root = join(repo, workspace);
  return [JSON.parse(await readFile(join(root, 'package.json'), 'utf8')).name, root];
})));
await new ManagedLifecycleService(host).apply(initial.lifecycle, {
  async install(entry, prefix) {
    const source = packageRoots.get(entry.id);
    assert.ok(source, `missing local workspace: ${entry.id}`);
    const path = join(prefix, 'node_modules', entry.id);
    let manifest;
    try { manifest = JSON.parse(await readFile(join(source, 'agon.mod.json'), 'utf8')); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    for (const file of new Set(['package.json', ...(manifest?.pack.include ?? [])])) {
      await mkdir(dirname(join(path, file)), { recursive: true });
      await cp(join(source, file), join(path, file));
    }
  },
}, { async verify(prefix, plan) {
  const checks = await Promise.all(plan.packages.map(async entry => ({ id: entry.id,
    passed: JSON.parse(await readFile(join(prefix, 'node_modules', entry.id, 'package.json'), 'utf8')).version === entry.version })));
  return { passed: checks.every(check => check.passed), checks };
} });
assert.equal(cli(['setup', '--plan']).status, 'planned');
await assert.rejects(stat(join(home, 'bin', 'agon')), { code: 'ENOENT' });
const activation = createFirstPartyActivationService(host);
await activation.apply(await activation.preview({ kind: 'disable', id: 'agon.forge' }));
const selected = await host.readCurrentPointer();
const desired = JSON.parse(await readFile(join(host.generationPath(selected.generation), 'desired-state.json'), 'utf8'));
await writeFile(host.paths.desiredState, JSON.stringify(initial.selection.desiredState));
for (const fault of ['stale', 'missing']) {
  if (fault === 'missing') await unlink(host.paths.desiredState);
  const result = cli(['update', '--plan']);
  assert.deepEqual(result.selection.desiredState, desired);
  assert.ok(!result.selection.effectiveModIds.includes('agon.forge'));
  assert.deepEqual(await host.readCurrentPointer(), selected);
  const listed = cli(['mod', 'list']);
  const forge = listed.view.groups.flatMap(group => group.entries).find(entry => entry.id === 'forge');
  assert.equal(forge.status, 'disabled');
  assert.equal(forge.callable, false);
}
console.log(JSON.stringify({ passed: true, calls, staleMirror: true, missingMirror: true,
  previewLauncherAbsent: true, fixturePackagesOnly: true, liveProviders: false }));
