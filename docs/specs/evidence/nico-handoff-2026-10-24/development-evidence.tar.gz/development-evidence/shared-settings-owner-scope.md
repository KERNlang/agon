# Shared configuration owners

Status: verified and locally committed. Full release remains incomplete.
Base: 0f92bff32f8697cfdc9c70f566eb1318f1abd8f9, clean qualification tree.
Baseline engine-settings-owner-qualified passed full gates, 8,472 tests with
six skips, historical type/default/order parity and isolated real CLI checks.

## Scope

Move the frozen Kernel (92), persistence (6), and browser bridge (1) settings to
those existing packages. Core retains its public AgonConfig and default object,
composes the owners, and preserves the original object key order. Move existing
Kernel/browser normalization to the same owners without changing policy.
No new package edges, dependencies, schemas, installer changes or global state.

Nine authored files expected: three settings modules, three barrels, Core type
composition and config binding, and one focused test. Generated release/SBOM/
channel metadata follows compiled bytes. This is one shared-owner extraction;
do not move the nine remaining user-mod fields into Kernel as a shortcut.

## Verification

Refactor discipline: green base, exact declaration/default movement, preserved
Core exports, focused negative controls, full repository and package gates,
one default Agon review, and a live isolated CLI check last. Compare all 121
field types/optionalities and the exact defaults/key order to pre-extraction Git
objects. Keep the ledger and baseline unchanged. Show source delegation, not
just package directories or schemas. No completion claim for mod namespaces,
remaining host adapters or release acceptance follows from this increment.

## Review and preliminary controls

Absent-owner test failed before implementation, log SHA-256
ae6fae7f6a869dd1e9144c6af07329fc589b14267eb3cb747670fc626c6a2b66.
Focused package builds/types/tests passed, log
fa40d7aa03c8bdbc249de507607b46c32589cde0916961605cfaf344011e6c3e.
Expanded focused tests/types/lint/reexports passed, log
3a5984112fe48602b89587cfc150b69ba8ab7f26d46fa097c6201025a497f9c1.

Exact previous Core models restored temporarily: physical-default identity check
fails. Log 42a62ade6cc3ef08081ae5bf4745945c3d53c8b4ff65b658cbd1848362cd4adc.
Exact previous Core config binding restored temporarily: Kernel policy is called
zero times and the owner test fails. Log
c2fd081722ac38956c15d20289fd1e97f0607d9dcc06a301686b5c7daf35e9e3.
Both edited files restored immediately. These prove transfer, not just existence.

Agon review tree a066bd92fd867e8c3cb3b5fbd9563676d440bd9e.
Packet SHA-256: 4436e59d2cc82a86702e1c6c948365844b7f0bac9379f6b8c5ab793eca82fd20.
Codex found no actionable source defect; complete barrel safety and fresh-build
historical parity remain execution gates, not assumptions. New owner settings
modules have no imports. Core's three owner dependencies existed in the base.
The copied Kernel function aggregates deny rules; downstream permission checking
still performs enforcement. Do not claim aggregation alone proves authorization.
Codex log SHA-256: a0093971459689c53561b3fbcaa0880bb71db12be6b1b89f2f37008cf30f3acc.
Kimi produced no answer (exit 1); no authentication repair was attempted.

## Completed execution gates

`shared-settings-owner-qualified` passed in 306.497 seconds, exit 0, no
provider launches. Log SHA-256:
`d8ec34dc7d6d4ccebd877637335eac7d2e498deadb424e086c68b4c7c1730f12`.
Build, typecheck, lint, re-export guard, API compatibility, release-set and
supply-chain verification/self-tests passed. Repository suite: 8,480 passed,
six skipped. Skips are not passing coverage.

Historical comparison against fb77dc970e720403cb18a27577b5ebf9b2ad1a9b
proved all 121 public field types and exact default values/insertion order
unchanged. Physical setting ownership now covers 112 fields; nine mod-owned
fields still remain in Core. Default bytes SHA-256:
`2ce42634048b04c7ed0564438791070ae23f1e41bb9a8e1afa7f3555a0166414`.

One live isolated CLI/config run completed four subprocess checks: set, get,
reject unknown key without changing persisted bytes, and global/project/private
precedence with ordered permission aggregation. This completes the review's
pending runtime and parity checks. It is not clean-install or release approval.

## Committed subject

Commit: `77d6b300201ea5309f6188788d0b611169630b37`.
Tree: `5972321dd73b17ae46b3400ecd011b4f5bf52000`.
Twelve explicit paths: nine authored and three generated release metadata files.
Qualification checkout is clean. Candidate branch/index advanced with compare-
and-swap and read-tree without updating working files. Before/after preservation
checks passed for the 281-path original snapshot, both with log SHA-256
`bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82`.
No push, install, personal-state change or global Agon update occurred.
