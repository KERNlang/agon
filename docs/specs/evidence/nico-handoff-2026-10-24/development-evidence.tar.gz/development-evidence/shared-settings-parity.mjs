import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { runInNewContext } from 'node:vm';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';
import { DEFAULT_AGON_CONFIG } from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
const relative = 'packages/core/src/models/types.ts';
const base = execFileSync('git', ['show', `fb77dc97:${relative}`], { cwd: repo, encoding: 'utf8' });
function parse(name, text) { return ts.createSourceFile(name, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS); }
const before = parse(relative, base);
const core = parse(relative, readFileSync(`${repo}/${relative}`, 'utf8'));
const owners = [
  ['support-engine-runtime/src/engine-settings.ts', 'EngineSettings'],
  ['mod-kernel/src/settings.ts', 'KernelSettings'],
  ['support-persistence/src/settings.ts', 'PersistenceSettings'],
  ['support-browser-bridge/src/settings.ts', 'BrowserSettings'],
  ['core/src/models/first-party-settings.generated.ts', 'FirstPartyLegacySettings'],
].map(([path, name]) => ({ name, file: parse(path, readFileSync(`${repo}/packages/${path}`, 'utf8')) }));
function members(file, name) {
  const node = file.statements.find(n => ts.isInterfaceDeclaration(n) && n.name.text === name);
  assert.ok(node, name);
  return node.members.map(n => ({
    name: n.name.getText(file), optional: Boolean(n.questionToken), type: n.type.getText(file).replace(/\s/g, ''),
  }));
}
const originalMembers = members(before, 'AgonConfig');
const composedMembers = [...members(core, 'AgonConfig'), ...owners.flatMap(({ file, name }) => members(file, name))];
const byName = (a, b) => a.name.localeCompare(b.name);
assert.deepEqual(composedMembers.sort(byName), originalMembers.sort(byName));
const declaration = before.statements.filter(ts.isVariableStatement)
  .flatMap(n => [...n.declarationList.declarations]).find(n => n.name.getText(before) === 'DEFAULT_AGON_CONFIG');
assert.ok(declaration?.initializer);
// Evaluate only the original constant object expression, not the Core module.
const expression = ts.transpileModule(`globalThis.value = ${declaration.initializer.getText(before)};`, {
  compilerOptions: { target: ts.ScriptTarget.ES2022 },
}).outputText;
const context = {};
runInNewContext(expression, context, { timeout: 1000 });
const originalJson = JSON.stringify(context.value);
assert.equal(JSON.stringify(DEFAULT_AGON_CONFIG), originalJson, 'default values or key order changed');
console.log(JSON.stringify({
  passed: true, base: 'fb77dc970e720403cb18a27577b5ebf9b2ad1a9b',
  publicConfigFields: originalMembers.length, physicallyOwnedFields: owners.reduce((count, { file, name }) => count + members(file, name).length, 0),
  defaultsAndKeyOrderIdentical: true,
  defaultsSha256: createHash('sha256').update(originalJson).digest('hex'),
}));
