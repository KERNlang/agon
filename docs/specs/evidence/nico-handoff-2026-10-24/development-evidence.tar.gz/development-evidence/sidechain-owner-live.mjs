import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createSidechainLogger as kernel } from '/Users/ra/dev/agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { createSidechainLogger as compatibility } from '/Users/ra/dev/agon-audit-qualification/packages/core/dist/index.js';

assert.equal(kernel, compatibility, 'Core must expose the same public kernel function');
const root = mkdtempSync(join(tmpdir(), 'agon-sidechain-owner-'));
try {
  const parent = compatibility({ sessionId: 'parent', sessionType: 'forge', outputDir: join(root, 'nested') });
  parent.log('started', 'fixture', { multiline: 'first\nsecond', value: 0 });
  const child = parent.child('child', 'brainstorm');
  child.log('completed');
  const first = JSON.parse(readFileSync(parent.path, 'utf8'));
  const second = JSON.parse(readFileSync(child.path, 'utf8'));
  assert.equal(first.data.multiline, 'first\nsecond');
  assert.equal(first.data.value, 0);
  assert.equal(first.sessionId, 'parent');
  assert.equal(first.engineId, 'fixture');
  assert.equal(second.parentId, 'parent');
  assert.equal(second.sessionType, 'brainstorm');
  assert.equal(second.sessionId, 'child');
  assert.equal(second.engineId, undefined);
  assert.equal(child.path, join(root, 'nested', 'brainstorm_child_sidechain_parent.jsonl'));
  let warning = '';
  const original = console.warn;
  console.warn = message => { warning = message; };
  try {
    rmSync(join(root, 'nested'), { recursive: true });
    assert.doesNotThrow(() => child.log('after-directory-removal'));
    assert.match(warning, /sidechain write failed/);
  } finally { console.warn = original; }
  console.log('Public kernel/Core identity, real parent/child JSONL, nested directory creation, optional fields and nonfatal write failure passed.');
} finally { rmSync(root, { recursive: true, force: true }); }
