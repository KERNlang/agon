import { createSidechainLogger as kernel } from '../agon-audit-qualification/packages/mod-kernel/dist/index.js';
import type { SidechainLogger, SidechainEvent } from '../agon-audit-qualification/packages/mod-kernel/dist/index.js';
import { createSidechainLogger as core } from '../agon-audit-qualification/packages/core/dist/index.js';
import type { SidechainLogger as CoreLogger, SidechainEvent as CoreEvent } from '../agon-audit-qualification/packages/core/dist/index.js';

const kernelFactory: typeof kernel = core;
const coreFactory: typeof core = kernel;
declare const logger: SidechainLogger;
declare const compatibilityLogger: CoreLogger;
declare const event: SidechainEvent;
declare const compatibilityEvent: CoreEvent;
const a: CoreLogger = logger;
const b: SidechainLogger = compatibilityLogger;
const c: CoreEvent = event;
const d: SidechainEvent = compatibilityEvent;
void [kernelFactory, coreFactory, a, b, c, d];
