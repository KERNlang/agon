# Sustained host and workflow load

Status: building. Baseline evidence only; release gate not yet implemented.
Date: 2026-10-11.
Subject: 7394158eefc4df5cc1790d5737aa43d78b6c17cd, clean qualification checkout.
Authority: original S9 roadmap and active completion goal.
No new dependency, install, push, provider call, or personal state change.

## Required outcome

Implement `test:modular-load` and make clean S9 qualification consume its fresh
evidence. Keep existing budgets unchanged. Do not call ordinary unit tests a
sustained-load measurement. This file supplements release-performance-scope.md.

## Verified source and reuse

- `docs/specs/evidence/modular-agon-implementation-roadmap.json:2796,2806`
  requires sustained-host/concurrent-workflow budgets and names the missing gate.
- `scripts/spec/qualify-modular-agon-slice9.mjs` runs the fresh eight-part
  performance aggregate, but currently has no load step. It cannot prove this
  S9 requirement. Search `sustain|load budget|concurrent-workflow|test:modular-load`
  across `docs/specs` and `scripts/spec` found requirement prose, no numerical
  sustained-load budget definition. Numerical thresholds remain to be justified.
- Built CLI daemon exports `sendDaemonRequest`; reuse the actual client instead
  of another hand-coded socket protocol. Built chunk filename is discovered and
  must be unique. No source or package export change is needed for this probe.
- `cli/src/commands/daemon.ts` owns real socket admission, registry authority,
  JobService and shutdown. `cli/src/jobs/workflow-job.ts` has an existing echo
  seam after payload/engine validation. Echo does not prove workflow execution.
- `mod-jobs/src/job-service.ts`: defaults 4 execution slots, 100 terminal jobs,
  256 events per job. These are existing behavioral bounds, not new budgets.
- `mod-jobs/src/daemon-workflow.ts` and `workflow-process.ts` own actual child
  execution, output decoding, cancellation and exit handling. Local fixture
  processes can exercise them without a live provider.
- `support-engine-catalog/src/engine-registry.ts:212` discovers engine JSON in
  the isolated Agon home. A local Node fixture can therefore drive the real
  generated Think workflow and CLI adapter, without adding a production seam.

## Baseline 1: verified

`load-baseline-1.receipt.json`, one run, 60.779 seconds, no provider launches.
Log SHA-256 b61e622cc1216782987b9d56228d7b31df180eeb09eecca8d26e6e8f51caf9b7.

Thirty-second daemon phase: 7,272 echo jobs, 23,635 requests, p95 3.136 ms,
max 9.615 ms. Peak daemon RSS 183,009,280 bytes. Retention reached 100 and
remained bounded. Session identity stayed stable. Graceful shutdown exited 0.

Thirty-second scheduler phase: 720 actual local child processes completed,
four scheduler slots and four queued jobs per eight-job batch. Peak probe RSS
166,166,528 bytes. Every job preserved output and exit evidence. Retention
remained at most 100 and all tasks drained.

Limits: the two phases are separate; echo is not model/workflow execution;
scheduler running-state counts alone do not prove child overlap. Thirty seconds
does not prove memory stability over long operation. The first probe receipt
hashes its output but not its helper source. Later probe versions record their
source hash. None of this is accepted release qualification.

## Next evidence and acceptance boundaries

1. Extend the same baseline to two minutes per phase; preserve first results.
2. Run actual daemon jobs through the generated Think command and CLI adapter,
   with an explicit isolated local fixture engine. No default provider roster.
   Require expected Think output and fixture start/end records. Prove actual
   process overlap and no extra or unfinished fixture launches.
3. Use measurements to propose bounded performance/retention criteria. Keep
   behavioral zero-error, concurrency and cleanup checks independent of speed.
4. Add negative controls for false verdicts, short/missing phases, skipped jobs,
   leaks, wrong output, cancelled/failed work and stale stored-green receipts.
5. Implement the small tracked driver and S9 consumer, review once through
   isolated default Agon reviewers, then full gates and live load last.

Expected shipping blast radius: package command, one load driver and fixture,
S9 qualifier, focused gate tests. No production runtime change is justified by
the first baseline. Existing public owners must remain authoritative. A future
failure must be reproduced before any runtime fix.

External: this machine cannot supply native evidence for every release platform
or provider. Fixture qualification must never be labelled live-provider quality,
authentication or model-correctness evidence.

## Longer and actual-workflow baselines

`load-baseline-long.receipt.json`: one 240.761-second run, zero providers.
Log SHA-256 e481ee08b0c59c35bfb283006efab49b8ee53f2cf4ddbec2b710b3f09d21bc65.
Two-minute daemon phase completed 28,832 echo jobs / 93,705 requests.
p95 3.472 ms, maximum 13.612 ms; peak RSS 188,219,392 bytes.
Second-half RSS ranged 178,241,536–188,219,392 bytes. This bounds observed growth,
not proof that memory cannot leak. Two-minute subprocess phase completed 2,856
jobs; peak probe RSS 175,554,560 bytes; four slots, 100 retained terminal jobs.

`load-workflow-baseline.receipt.json`: one 61.723-second run, zero providers.
Log SHA-256 6367ac0e682319caefb49efd9a35835038713a3dc67e4d83fd926dfc610726dc.
Probe SHA-256 6f1acfafe76ae8b89989a7393f1da1fdb5a776ccc004863f800d6760d17d4a27.
Provider fixture SHA-256 1d3fced37c3412dc9dfd711f83cfe83b823029754de5cfab0bff46eb3c89b715.
Subprocess fixture SHA-256 14a5283a69714a76e66eedca64b3ee33963f9694310e5da8d2aed02b1ee36529.

The daemon phase ran 192 actual Think jobs in 31.151 seconds. Its 1,764
requests had p95 11.460 ms and max 20.219 ms. All jobs returned the expected
Think summary through actual command output events. 384 fixture start/end
records prove one selected fixture invocation per job, peak four simultaneous
fixture processes, and no unfinished fixture invocation. No echo seam was used.
The local fixture supplies a canned structured model answer, so this does not
test model quality. The observed path includes generated command dispatch,
physical Think, real adapter subprocesses, Jobs transport/events/retention and
graceful daemon shutdown. The separate scheduler phase also passed again.

Qualification design refinement: the tracked gate can use the actual workflow
route rather than retaining a redundant standalone scheduler phase. Keep a
transport-heavy phase because it places much more pressure on event retention.
Full workflow RSS sampling must run more often than every tenth batch (the
short baseline had only three daemon samples). Include owned child RSS and
failure/cancellation recovery before calling load qualification complete.

## Cancellation finding and repair increment

The longer real-workflow baseline passed once in 241.574 seconds:
`load-workflow-long.receipt.json`, log SHA-256
c42f7df5e003055a04a1f5c0e1bac3d562de82f087224f6cd27194fb1399f4f6.
744 Think jobs in 120.625 seconds; 6,835 requests, p95 11.148 ms, max 23.893 ms.
1,488 fixture records prove peak four concurrent model-fixture processes.
Observed daemon RSS peaked at 182,648,832 bytes. The subsequent scheduler phase
completed 2,856 jobs. This remains baseline evidence, not final acceptance.

A required cancellation control then failed on the same committed subject.
`load-cancellation-control.receipt.json` exited 1 in 4.271 seconds, no providers;
log SHA-256 0a8e1fa05c2956cbc6869690c72f77dac55e035d53b2d3216e6847f4649c9cdd.
The actual daemon marked a Think job cancelled, but its fixture engine was still
alive 3.513 seconds after cancellation. The probe explicitly killed that owned
fixture and daemon. No active/global process was targeted.

Source cause: `mod-jobs/src/workflow-process.ts` cancels the workflow CLI process
group. `support-engine-runtime/src/process.ts` launches the engine in a separate
group and already tracks it for synchronous JS exit cleanup. Node's default
SIGTERM termination does not run that exit hook. Thus the intermediary CLI died
before it stopped its owned detached engine. A job-state-only test misses this.

Chosen repair: CLI entry installs default SIGINT/SIGTERM handlers before command
handlers. Only when no command-specific signal handler exists, it exits through
`process.exit(130/143)` so existing process-owner cleanup runs. It does not change
the shared subprocess API or duplicate its process registry. Daemon, REPL, room,
goal, attach, extension and browser-host handlers retain their policy. Source
search found their `on/once` registrations and no later prepend registrations.
Numeric 128+signal exit status replaces default Node signal termination for the
previously unhandled CLI path; shell failure status remains the same.

Blast radius: CLI entry, one private 16-line CLI lifecycle helper, and existing
process-host-exit regression tests. No public API, dependencies, manifests or
persistent-state format changes. Boundaries to verify: ordinary and streaming
engines, SIGINT/SIGTERM, command once-handlers registered before/after the helper,
daemon cleanup, listener removal, entry wiring and original startup budgets.

Focused repair receipt `load-cancellation-focused` passed in 15.951 seconds.
Log SHA-256 f21b7421b2ac913d82c4e1d69ed03ff300f16a30a3e56ba346f6fe18e6f68990.
Native process tests, CLI build and the same real-daemon control passed; the
cancelled fixture was gone after 26.192 ms. All runs recorded zero providers.
Full repository gates and independent review are still required before commit.
Load-driver implementation waits for this confirmed runtime defect to be fixed.

## Review adjudication

Agon review packet bound to tree 3648e31f3c0f97e75661337e4eab78d1c57213b9,
SHA-256 0911120bf099bc5e44750c00300d1336d9b77349be7eccefa2ceac322fa85f3b.
Codex found no actionable source regression. Log SHA-256
8e5e294a4ca9bab21a70bb642330cb75e31e50838156edcaf7e4d0da828c7d94.
Kimi returned engine exit 2 and no answer; log SHA-256
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
Unavailable is not approval. No authentication or personal state was changed.

Two coverage findings were valid and added locally without a second panel:

- Async command signal handlers must finish their own cleanup before exit.
  Native fixtures now assert their completion marker before exit 23, for both
  signals and listener registration orders, streaming and non-streaming engines.
- Native helper fixtures alone do not prove CLI entry wiring. Two integration
  tests now run the actual built daemon, generated Think and local engine fixture,
  then cancel the job or shut down the daemon. They check that the engine PID
  disappears, not merely that the job record becomes terminal. Cancellation also
  checks that the daemon remains responsive afterward. No echo seam is used.

`cli-signal-review-controls` passed all focused tests, typecheck and lint in
68.850 seconds. SHA-256
07a2d5955647fb692736806d07d6cb9978fccb34923128c1a51f19621bb351a4.
The earlier full gate was intentionally stopped after 39.092 seconds to add
these tests without changing a running gate's subject. Its exit -15 receipt
(`cli-signal-cleanup-full`) is retained, not counted as a passing gate.

Final gate subject: c87018656e614d00ad8b41acd171be42fc6cd55b.
Four changed files, 85 additions and 3 removals: 19 production lines, the rest
regression coverage. This is CLI host lifecycle policy, not a new mod, process
registry or package dependency. Existing shared runtime remains the process
cleanup owner. SIGKILL is uncatchable and is not claimed to be repaired here.

## Committed repair and remaining load gate

Commit 67d7cca7c0810c9abdde9b01b73066c31eee23a3,
tree c87018656e614d00ad8b41acd171be42fc6cd55b, matches the final gate subject.
`cli-signal-cleanup-final` passed in 320.118 seconds:
full build, typecheck, lint, re-export guard, first-party generation, roadmap
verification, 8,321 tests (6 skipped), all eight performance measurements, and
the real daemon cancellation control last. Log SHA-256
9aa289100f87833346e7a378422b3bedf2cda062e6fd14587ba3a1e498a046fa.
The final live control observed the engine gone after 26.173 ms. Zero provider
launches in the verification harness; the separately authorized Agon review is
recorded above and is not included in that zero-provider claim.

The qualification checkout is clean. Candidate branch advanced with expected-old
Git ref checking and index-only read-tree; no candidate working bytes were
rewritten. Before/after preservation receipts checked 281 paths with the same
existing allowlist and identical log hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Nothing pushed, installed or promoted. Active/global Agon was not modified.

This closes the reproduced SIGINT/SIGTERM CLI cleanup defect. It does not close
the original sustained-load requirement. `test:modular-load` is still absent.
Next implementation must reuse the measured daemon transport and real Think
fixture routes, include this cancellation regression and failure recovery,
measure owned child memory, freeze justified limits, and make S9 require fresh
load evidence. Do not rerun the same baseline just to collect more green counts.
The existing evidence now establishes a safe real-workflow harness path and
shows why outcome labels alone are not a sufficient oracle.

## Load gate implementation contract

Implementation resumes on 67d7cca7. Six paths, approximately 400 lines: package
command, load driver, local engine fixture, S9 consumer and two test files.
No runtime package changes are planned. Reuse the built daemon client and the
shared bounded process runner. The fixture is explicit, local and non-networked.
Both phases run for at least 120 seconds. A short diagnostic run cannot qualify.

Engineering limits, based on the measurements above (new load limits, not claims
that these numbers were previously frozen): request p95 at most 50 ms (more than
twice the observed worst request, 23.893 ms); daemon sampled RSS at most 192 MiB
(existing S6/S7 full-runtime allowance; observed maximum 179.5 MiB); settled RSS
growth at most 32 MiB between second- and last-quarter medians (observed late
growth below 10 MiB in the transport baseline). Concurrent tree allowance is
9 × 192 MiB: one host, four workflow CLIs and four engine processes. Record raw
parent and tree samples so this derived allowance can be reviewed. At least
256 completed jobs per phase forces retention turnover and permits roughly
threefold slowdown relative to the 744-job real-workflow baseline.

Do not increase these limits to rescue a failed run. A failure requires a cause
check. These limits qualify this explicit workload, not arbitrary real models.
Other native platforms remain unqualified until they execute the same gate.

Required independent checks: exact expected output for each job; terminal events
and result state; at most 100 retained terminal jobs; observed peak four engine
fixtures; one fixture per workflow job; no pending fixture at steady-state end;
failed engine propagates failure; cancelled engine PID disappears; subsequent
work succeeds; daemon shutdown cancels active work and removes its files.
Errors, missing fields, nonfinite metrics, short phases, stale evidence, wrong
identity and contradictory booleans must make qualification red.

## First gate run and review corrections

The implementation uses seven paths, not six: a shared synthetic evidence fixture
avoids duplicating the positive control between the validator and S9 tests.
Current diff: 424 additions, 3 deletions. No production runtime package changes.

Initial tree 4c800a3c398414d564eb29e5528fe3e91c0e8be7 passed
`modular-load-live` in 244.016 seconds on native darwin-arm64, Node v26.3.0.
Log SHA-256 879ae35666c542dc7df40f76261b9e28542f4e1f438e3665647043f300562d4c.
Transport: 29,688 jobs, p95 1.987 ms, peak daemon RSS 178,159,616 bytes.
Workflow: 752 real Think fixture jobs, p95 10.274 ms, peak daemon RSS
179,683,328 bytes, peak owned-tree RSS 958,087,168 bytes, settled growth
3,637,248 bytes. All six recovery controls passed. Provider blockers recorded
zero launches. This result does not qualify subsequent review corrections.

Default Agon review used source packet SHA-256
22b1c8450b71effccfeaf27761108195587e3ad97a6d94d0744c7d26008c17ea.
Codex review log SHA-256
d8e386e98f3be91b7bf796f81e3c247eec90e744ced3d994a8e12deaed366c61.
Kimi returned no answer; log SHA-256
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No personal authentication repair was attempted. Unavailable is not approval.

All three Codex findings were confirmed against source and corrected locally:

1. The shutdown check started its deadline after awaiting the daemon. Natural
   eight-second fixture completion could therefore satisfy it. The measured
   deadline now starts before the shutdown request; the aggregate rejects
   shutdown above 3.5 seconds. The eight-second draining case is a negative
   evidence control, not an actual mutated-daemon run.
2. Inherited NODE_OPTIONS allowed arbitrary child preloads. Child environments
   now use fixed heap options and system-only PATH. A native Node sentinel test
   first proves that the inherited preload runs, then proves the isolated child
   does not run it. Actual workflow spawning uses absolute process.execPath;
   the fixture engine also uses an absolute Node path. Parent startup remains
   the caller's responsibility; this does not sandbox arbitrary caller code.
3. A failed job did not prove execution of the intended failing engine. The
   driver now requires exactly the new matching start/end fixture records for
   failure mode. Tests reject empty, partial and mismatched-PID records, and
   exercise the real fixture's status-7 path.

No second review panel is planned. Run focused controls, full repository gates,
fresh performance and the corrected actual load gate before committing.

## Qualified load gate

Commit 37f2dec6d1e458018becc7ec540795a0f542acab; tree
3ce51adb9e42cbb4fec3afec8aa4f0e7582ef221 matches the frozen full-gate subject.
`modular-load-review-controls` passed in 57.875 seconds, log SHA-256
244f53cfb4ca2b2b8a1837f9afd8cc1edfe826aa408d35b49cfe1b5c7d3553b5.
`modular-load-final` passed in 558.663 seconds: build, types, lint, re-export
guard, generated first-party and roadmap checks, 8,365 tests with six skips,
all eight performance measurements, then the corrected real load gate last.
Final log SHA-256 a63b05fdc0910f0bc86c5fa0c48fb733160e4c28fecfbc7491f14ee9bf77c9fb.

Final native darwin-arm64 / Node v26.3.0 results:

| Phase | Jobs | Request p95 | Peak daemon RSS | Peak tree RSS | Settled growth | Shutdown |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Transport | 29,592 | 2.021 ms | 177,291,264 B | 177,291,264 B | -278,528 B | 19.773 ms |
| Think fixture | 752 | 8.251 ms | 176,259,072 B | 964,935,680 B | 2,981,888 B | 20.168 ms |

Each phase exceeded 120 seconds. The actual fixture had four concurrent
engines, 752 paired starts/ends and no pending steady-state fixture. Failure,
cancellation, recovery, shutdown and host-file-removal checks passed. Limits
were not raised. These are local deterministic fixtures, not live model quality
or unmeasured native-platform evidence. Two gate runs total: the initial run and
one corrected final run. Verification recorded zero provider launches; the
separate authorized source review is not included in that claim.

Qualification checkout is clean. Candidate branch advanced with expected-old
ref checking and index-only read-tree. Working bytes were not replaced.
Before/after preservation checks cover 281 paths with the same allowlist and
matching log SHA-256 bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Nothing pushed or installed. Active/global Agon and personal state untouched.

The missing sustained-load command and fresh S9 consumption are now implemented.
This does not certify the whole release: remaining ownership, final clean release
receipts, security advisories and external platform cells remain open. The next
ownership trace is recorded in ratings-maintenance-scope.md, not silently treated
as completed by this gate.
