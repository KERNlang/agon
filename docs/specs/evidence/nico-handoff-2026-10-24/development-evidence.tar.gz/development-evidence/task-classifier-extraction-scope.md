# Task classifier ownership

Status: building under the agreed modular ownership goal; review fixes in verification.
Date: 2026-10-11
Verified at: qualification checkout 31ddb139, with two staged verification changes.
Authority: existing modular ownership goal; preserve behavior and public APIs.
Allowed: isolated extraction and tests after the current gate passes.
Not allowed: new dependencies, installs, global changes, pushes, provider launches.

## Verified source

- Core blocks/task-classifier.ts owned 89 lines before extraction.
- support-dedup owns the resolver and python/classifier.py asset already.
- Core imports support-dedup through its existing dedup-resolver facade.
- TaskClass is a seven-string union in support-engine-runtime/src/types.ts.
- support-dedup has no runtime dependencies. Adding an import of TaskClass from
  support-engine-runtime would change that graph and require dependency approval.
- `rg -n 'classifyTaskRegex|CLASSIFIER_CACHE|CLASSIFIER_TIMEOUT_MS|classifyTaskSemantic'
  tests --glob '*.ts'` found no direct tests. Brainstorm parity currently mocks
  the Core classifier. That does not test the sidecar contract.
- `rg -n 'createBrainstormHostServices|classifyTask' packages --glob '*.ts'
  --glob '!**/dist/**' --glob '!**/*.test.ts'` locates public Core consumers in
  Forge/team workflows, Cesar routing, finalization and Brainstorm host binding.
  CLI intent's separate code/question/ambiguous classifier is not this feature.

## Proposed narrow extraction

Move the implementation to support-dedup beside its resolver and Python asset.
Core keeps the same public functions, constants and shared cache identity as a
direct public-package facade. Callers do not change. No private imports.

Avoid a new dependency or configurable runtime factory solely for the type
annotation: infer the output union from the existing literal classification
values and prove equality with the public TaskClass type in a compile check.
Keep the same seven accepted outputs, regex priority and fallback behavior.
If inference cannot preserve the public type contract cleanly, stop this approach
rather than introduce a duplicate public domain type or silent graph edge.

Expected changed paths:
1. packages/core/src/blocks/task-classifier.ts
2. packages/support-dedup/src/task-classifier.ts (new physical owner)
3. packages/support-dedup/src/index.ts
4. tests/unit/modular-task-classifier-owner.test.ts (new behavior/ownership tests)
5. scripts/spec/generate-modular-support-migration-ledger.mjs
6. docs/specs/evidence/modular-agon-slice4-migration-ledger.json (generated only)

Inspect the migration generator's baseline before regeneration. Do not sweep
unrelated stale rows into this change. No package manifest or lockfile changes
are planned. Expected risk: medium, due to synchronous subprocess and cache
semantics, despite a small source move.

## Required invariants and evidence

- Regex order, word boundaries, case matching and 'other' fallback unchanged.
- Any nonempty AGON_DISABLE_CLASSIFIER_SIDECAR bypasses semantic work before cache.
- Cache remains shared through both public surfaces and stores valid success only.
- Missing asset, spawn exception, nonzero exit, empty/malformed output and invalid
  class still return null; no new warning, exception or installation side effect.
- Preserve 2,000ms timeout and JSON stdin/encoding contract.
- Preserve resolver precedence and exact Python asset bytes.
- Use a local fixture executable to inspect actual argv/stdin and failure modes;
  do not download embeddings or require live Python/model services for the gate.
- Compile caller return types against existing TaskClass; prove facade identities.
- Negative controls must detect changed regex priority, cache or sidecar bypass.
- Independently build/pack support-dedup, check declarations and package boundaries.
- Run Brainstorm raw workflow parity and full repository gates after extraction.
- One default isolated Agon review, source-verified findings, then local fixes.

## Not completion

This retires Core's classifier implementation, not all Brainstorm host wiring.
It does not close A06/A11, the unresolved daemon socket flake, or release gates.

## Baseline and corrections

Base is now 45749f249a8607dffe614de20456a88f4bf23637. Full qualification
`qualification-diagnostics-final` passed (8,380 tests, six skips, plus eleven
final real daemon tests; build/types/lint/re-exports/kill-list passed).

The S4 ledger baseline was red. A read-only evaluation intercepted the generator's
write and compared every row before regeneration: exactly three disposition
changes, no new/deleted ownership rows. Source checks confirmed their direct
support imports: telemetry/index.ts:10 (persistence lock), blocks/git.ts:9
(worktree normalization), blocks/workspace.ts:12 (worktree support). Regenerated
only this known artifact; check now passes. Counts change consumers 58→55 and
adapters 90→93. This is ledger reconciliation, not retirement of those adapters.
Include this explicit prerequisite in review; do not claim the classifier caused
those three changes.

Added the planned classifier test file before extraction. Run
`classifier-owner-negative`: 20 behavior tests pass against the unchanged Core
implementation; one ownership test fails because support-dedup does not export
the classifier yet. Log SHA-256:
f402ce8f860b96196030411f2743081539f5b7e96f204c529d40871555c03bbc.
The real fixture executable covered all seven valid outputs, cache reuse,
regex priority, bypass-before-cache, invalid/malformed/empty/nonzero output,
missing executable and actual two-second timeout. Zero provider launches.
No classifier implementation moved yet.

## Extraction and evidence

The implementation now lives in support-dedup/src/task-classifier.ts. Core's old
path reexports the same six bindings. No dependency or lockfile changes. Regex
tuples use `as const`; return/cache types derive from the existing result literals.
A real compiler-program test checks both assignment directions against TaskClass,
including rejected invalid cache values and non-string input.

TypeScript emitted identical JavaScript for the old source at 45749f24 and new
owner (same compiler settings, imports retained):
- legacy source SHA-256 c1782fbe1bac0cefbc11505f863b67d7e05af15ddf5105846dce34f08fa5ffc6
- owner source SHA-256 a9c525224081a20c87764a9fa3148e9a7616e0463424ba81b1078e3209444301
- shared emitted SHA-256 18781273bb646f55821ae9d372df28676c479c3107c71eff6083f6a3b064ef0f

Receipts (all zero provider launches):
- classifier-owner-positive: PASS, 12.985s. Build owner, typecheck, classifier and
  Brainstorm parity, ledger regeneration/check. Log hash
  c9afb8c2a6a829962eac6d15acc61378e02b62cc0ea266776db65ffc622e7ad0.
- classifier-owner-types-pack: PASS, 7.494s. 22 tests, real compiler, support
  boundaries/self-test and package dry-run (38,658 unpacked bytes, includes
  dist/task-classifier.d.ts). Log hash
  a38b278653f718cad5172f17025d4ae7790ca6854b2a7418be65d98c60f101dd.
- classifier-owner-controls: PASS, 63.968s. 39 classifier/Brainstorm tests,
  mutation controls and repository lint. Log hash
  0007c080fcb2903d34bb9504487cb7403c412042db40d34c8b3f34796d8053b5.

One default Agon review of staged tree 2cb38d64d92da43a5a4d0291fc31da574407c4d2.
Packet hash a28304f12438508d7ba70ce9913aaa07f9f8216e02be95d7ea5e58f754c42414.
Codex log c54401e77ecd6e694450c971b9bd91b541d6f812d4f82f45040fe23498ba50d4:
no production drift found, three confirmed coverage gaps. Added layered semantic
success/cache test with a real fixture, regex skip with sidecar enabled, measured
timeout with recorded invocation, and runtime identity via the public Core export.
Added an escalation-removal mutation to the existing in-memory probe. Mutation
evidence concerns this explicit probe, not a whole-suite mutation score.
Kimi returned no answer (Agon exit 1); unchanged unavailable-auth log hash
a4eebf5d7d44f5490f265ba973efba6a7b0a1712213a895f830b6440c27cdbff.
No authentication repair or second panel.

Current check: classifier-owner-review-controls rebuilds Core before the updated
tests, then typecheck/lint. Read its terminal receipt. Post-review test edits are
not yet staged. Full repository build/test and final live fixture checks still
required before committing. No whole-release completion claim.

Post-review receipt classifier-owner-review-controls passed in 68.442 seconds;
log hash f0c8d0d13ab666bf7a2f48b807c773022c54346ee140ae791e7e801a5dc0726e,
zero provider launches. Post-review test changes are now staged. Full frozen
gate classifier-owner-final is running: build, types, lint, re-exports, support
boundaries/ledger, full tests, performance and real classifier fixture tests last.
Read its terminal receipt before committing; do not restart a live handle.

## Verified local checkpoint

Final receipt `classifier-owner-final` passed in 321.559 seconds: build, types,
lint, re-export guard, support boundaries and ledger, 8,404 tests (6 skipped),
release performance gates, then 24 classifier tests with real fixture processes.
Zero provider launches. Log SHA-256
65fd14afb92efb340be1d1ca572589ab5be1872ab9a46acdbd835a549423d7d6.
Commit f9f59422cac3af1a9cffc4d33646651e7eb5b747 has the exact tested tree
3be6b5c308a4c4a5dc303ff3eab02eb4580b3c11. Candidate branch advanced with
index-only read-tree; working files were not replaced. Before/after preservation
receipts passed with log hash
bc873f2fdf37c3252fcbbdf126d799a2136c6351990930ed0446392b0d009e82.
Nothing pushed or installed. This closes classifier ownership only, not the
remaining Brainstorm host ownership or whole-release qualification. The prior
daemon failure remains unresolved; passing reruns do not establish its cause.
