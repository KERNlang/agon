import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const repo = '/Users/ra/dev/agon-audit-qualification';
const archive = '/Users/ra/dev/modular-agon-remediation';
const root = mkdtempSync(join(archive, 'team-cli-fixture-'));
const home = join(root, 'home');
mkdirSync(join(home, 'engines'), { recursive: true });
const gate = join(root, 'fixture-ready');
const log = join(root, 'engine-calls');
writeFileSync(gate, 'ready\n');
const engines = ['fixture-alpha', 'fixture-beta'];
for (const id of engines) writeFileSync(join(home, 'engines', id + '.json'), JSON.stringify({
  schemaVersion: 3, id, displayName: id, binary: process.execPath,
  searchPaths: [], versionCmd: ['--version'], isLocal: true, tier: 'user',
  installHint: 'Isolated fixture only', timeout: 5,
  exec: { args: [join(repo, 'scripts/spec/fixtures/brainstorm-engine.mjs'), gate, log, 'human', '{prompt}'] },
}));
writeFileSync(join(home, 'config.json'), JSON.stringify({ cesarEngine: engines[1],
  forgeEnabledEngines: engines, ratingsEnabled: false }));
const child = spawnSync(process.execPath, ['--import', join(repo, 'scripts/spec/fixtures/guard-brainstorm-effects.mjs'),
  join(repo, 'packages/cli/dist/index.js'), 'team-brainstorm', 'Installed fixture question',
  '--engines', engines.join(','), '--members', '1', '--timeout', '5'], {
  cwd: root, encoding: 'utf8', timeout: 45_000,
  env: { ...process.env, HOME: home, AGON_HOME: home, AGON_MODULAR_HOST_ROOT: join(home, 'modular-host'),
    XDG_CONFIG_HOME: join(home, 'config'), XDG_CACHE_HOME: join(home, 'cache'),
    XDG_DATA_HOME: join(home, 'data'), XDG_STATE_HOME: join(home, 'state') },
});
writeFileSync(join(root, 'stdout.log'), child.stdout ?? '');
writeFileSync(join(root, 'stderr.log'), child.stderr ?? '');
console.log(JSON.stringify({ root, status: child.status, error: child.error?.message }));
assert.equal(child.error, undefined);
assert.equal(child.status, 0, child.stderr);
const result = JSON.parse(child.stdout);
assert.equal(result.mode, 'brainstorm');
assert.equal(result.task, 'Installed fixture question');
assert.equal(result.teams.length, 2);
assert.equal(result.format.membersPerSide, 1);
assert.equal(Object.keys(result.submissions).length, 2);
assert.deepEqual(readFileSync(log, 'utf8').trim().split('\n').sort(), ['draft', 'draft', 'expansion', 'expansion', 'expansion']);
const entries = readdirSync(join(home, 'runs'), { withFileTypes: true });
const runs = entries.filter(entry => entry.isDirectory()).map(entry => entry.name);
assert.equal(runs.length, 1);
const run = join(home, 'runs', runs[0]);
assert.deepEqual(entries.filter(entry => !entry.isDirectory()).map(entry => entry.name), ['latest']);
assert.equal(realpathSync(join(home, 'runs/latest')), run);
assert.deepEqual(JSON.parse(readFileSync(join(run, 'team-result.json'), 'utf8')), result);
assert.equal(JSON.parse(readFileSync(join(run, 'status.json'), 'utf8')).ok, true);
console.log('PASS built CLI parser → registry → physical team host → fixture subprocesses → persisted raw result');
