import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = mkdtempSync(join(tmpdir(), 'agon-telemetry-pressure-'));
const ledger = join(root, 'telemetry.json');
const owner = pathToFileURL('/Users/ra/dev/agon-audit-qualification/packages/cli/dist-tsc/telemetry/index.js').href;
const started = performance.now();
try {
  const workers = Array.from({ length: 6 }, (_, worker) => new Promise((resolve, reject) => {
    const source = `
      import { TelemetryLedger } from ${JSON.stringify(owner)};
      const ledger = new TelemetryLedger(${JSON.stringify(ledger)});
      const record = id => ({ id, timestamp: 1000, mode: 'brainstorm', taskType: 'question',
        success: true, durationMs: 10, engineIds: ['fixture'], completionState: 'completed' });
      ledger.append(record('shared-retry'));
      for (let index = 0; index < 20; index++) ledger.append(record('worker-${worker}-' + index));
    `;
    const child = spawn(process.execPath, ['--input-type=module', '-e', source], {
      stdio: ['ignore', 'pipe', 'pipe'], timeout: 20000,
    });
    let output = '';
    child.stdout.on('data', chunk => { output += chunk; });
    child.stderr.on('data', chunk => { output += chunk; });
    child.on('error', reject);
    child.on('close', (code, signal) => {
      if (code === 0) resolve();
      else reject(new Error(`Writer ${worker}: exit=${code} signal=${signal}\n${output}`));
    });
  }));
  const results = await Promise.allSettled(workers);
  assert.deepEqual(results.filter(result => result.status === 'rejected'), []);
  const data = JSON.parse(readFileSync(ledger, 'utf8'));
  assert.equal(data.runs.length, 121);
  assert.equal(new Set(data.runs.map(record => record.id)).size, 121);
  assert.equal(data.runs.filter(record => record.id === 'shared-retry').length, 1);
  for (let worker = 0; worker < 6; worker++) {
    for (let index = 0; index < 20; index++) {
      assert(data.runs.some(record => record.id === `worker-${worker}-${index}`));
    }
  }
  console.log(JSON.stringify({ writers: 6, uniqueReceipts: 121, lostReceipts: 0,
    duplicateReceipts: 0, elapsedMs: Math.round(performance.now() - started),
    scope: 'Built telemetry owner, real child processes and filesystem; no providers' }));
} finally {
  rmSync(root, { recursive: true, force: true });
}
