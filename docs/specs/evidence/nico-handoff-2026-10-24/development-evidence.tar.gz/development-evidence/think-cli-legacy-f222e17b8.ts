import { defineCommand } from 'citty';

import { EngineRegistry, ensureAgonHome, loadConfig, createRunDir, writeRunStatus, printRunSummary } from '@kernlang/agon-core';

import type { RunStatus, RunStatusEngine } from '@kernlang/agon-core';

import { resolveBuiltinEnginesDir } from '../lib/engines-dir.js';

import { createCliAdapter } from '@kernlang/agon-adapter-cli';

import { runThinkChain, isThinkStrategy, joinProblemInput } from '@kernlang/agon-forge';

import { header, info, bold, dim } from '../blocks/output-format.js';

import { filterDefaultOrchestrationEngines } from '../handlers/engine-filter.js';

/**
 * Map a thought kind to a render glyph for the scrollback view.
 */
export function thoughtGlyph(kind: string): string {
  return kind === 'critique' ? '🔍' : kind === 'revision' ? '✏️' : kind === 'question' ? '❓' : kind === 'decision' ? '✅' : kind === 'hypothesis' ? '🔬' : kind === 'decompose' ? '🧩' : '💭';
}

export const thinkCommand: any = defineCommand({
  meta: {
    name: 'think',
    description: 'Sequential thinking — decompose a problem into structured thoughts before acting. `agon think "..." --strategy reflexion`. Opt-in; surfaces open questions and a goal handoff.',
  },
  args: {
    problem: {
      type: 'positional',
      description: 'The task / problem to think through.',
      required: false,
    },
    strategy: {
      type: 'string',
      description: 'Thinking method: linear | reflexion (forced critique+revision) | tot (self-scored branches, prune to winner) | graph (branch then merge) | hypothesis (competing hypotheses, eliminate losers).',
      default: 'linear',
    },
    critic: {
      type: 'string',
      description: 'A SECOND engine that adversarially attacks the chain after it is produced (cross-engine critique). e.g. --critic codex.',
    },
    engine: {
      type: 'string',
      description: 'Engine id to think with. Omit to use the default (first active) engine.',
    },
    steps: {
      type: 'string',
      description: 'Max thoughts (steps of thought) to produce. Clamped to 1..20.',
      default: '6',
    },
    branches: {
      type: 'string',
      description: 'Explore N alternative reasoning branches (emission only — v1 does not auto-score/prune). Clamped to 1..8. e.g. --steps 20 --branches 5.',
      default: '1',
    },
    timeout: {
      type: 'string',
      description: 'Timeout in seconds.',
      default: '120',
    },
    ground: {
      type: 'boolean',
      description: 'Verify file paths cited in thoughts against the repo and flag phantom ones. On by default; --no-ground to disable.',
      default: true,
    },
    goal: {
      type: 'boolean',
      description: 'Print a ready-to-run `agon goal` handoff built from the refined spec.',
    },
    json: {
      type: 'boolean',
      description: 'Emit the full ThinkResult as JSON on stdout (the handoff artifact; pipe-friendly).',
    },
    quiet: {
      type: 'boolean',
      description: 'Print only the summary.',
    },
    label: {
      type: 'string',
      description: 'Human-readable suffix baked into the run dir name.',
    },
  },
  async run({ args }) {
    ensureAgonHome();
    const config = loadConfig(process.cwd());

    const registry = new EngineRegistry();
    registry.load(resolveBuiltinEnginesDir());
    const adapter = createCliAdapter(registry);

    const positionals = Array.isArray((args as any)._) ? (args as any)._.map(String) : [];
    const problem = joinProblemInput(args.problem as string | undefined, positionals);
    if (!problem) {
      console.error('Provide a problem. Usage: agon think "your task" [--strategy reflexion] [--steps 8]');
      process.exitCode = 1;
      return;
    }

    const active = filterDefaultOrchestrationEngines(registry.activeIds(config as any));
    const engineId = (typeof args.engine === 'string' && args.engine.trim()) ? args.engine.trim() : active[0];
    if (!engineId) {
      console.error('No active engines. Run `agon engine list` or `agon engine add <id>`.');
      process.exitCode = 1;
      return;
    }

    const quiet = !!args.quiet;
    const json = !!args.json;
    const strategy = String(args.strategy || 'linear');
    if (!isThinkStrategy(strategy) && !quiet) {
      console.warn(`[agon] unknown strategy '${strategy}' — using linear (valid: linear|reflexion|tot|graph|hypothesis).`);
    }
    const steps = Math.max(1, Math.min(parseInt(String(args.steps ?? '6'), 10) || 6, 20));
    const branches = Math.max(1, Math.min(parseInt(String(args.branches ?? '1'), 10) || 1, 8));
    const timeoutSec = parseInt(String(args.timeout ?? '120'), 10) || 120;

    // Validate the optional --critic engine up front; a bad id otherwise only
    // surfaces as a buried console.warn after the main chain already ran.
    let critic: string | undefined;
    if (typeof args.critic === 'string' && args.critic.trim()) {
      const wanted = registry.resolveId(args.critic.trim());
      if (active.includes(wanted) || registry.activeIds(config as any).includes(wanted)) {
        critic = wanted;
      } else {
        console.warn(`[agon] --critic '${args.critic.trim()}' is not an active engine — skipping the adversarial critique.`);
      }
    }

    const engine = registry.get(engineId);
    const startedAt = new Date().toISOString();
    const { path: outputDir } = createRunDir({ mode: 'think', label: args.label, announce: false });

    if (!quiet && !json) {
      header(`Think · ${bold(strategy)} · ${engine.id}`);
      info(problem.length > 120 ? problem.slice(0, 120) + '...' : problem);
      console.log('');
    }

    const result = await runThinkChain({
      problem,
      strategy,
      engineId: engine.id,
      registry,
      adapter,
      maxThoughts: steps,
      branches,
      critic,
      timeout: timeoutSec,
      outputDir,
      cwd: process.cwd(),
      ground: args.ground !== false,
    });

    const engineStatus: RunStatusEngine = {
      id: engine.id,
      status: result.ok ? 'ok' : 'error',
      detail: result.ok ? `${result.thoughts.length} thoughts (${strategy})` : 'no usable thinking chain',
    };
    const status: RunStatus = {
      mode: 'think',
      label: args.label,
      startedAt,
      endedAt: new Date().toISOString(),
      engines: [engineStatus],
      summary: result.ok ? `${engine.id}: ${result.thoughts.length} thoughts (${strategy})` : `${engine.id} produced no usable chain`,
      ok: result.ok,
      requested: [engine.id],
      timeoutSec,
    };
    writeRunStatus(outputDir, status);

    if (json) {
      console.log(JSON.stringify(result, null, 2));
      if (!result.ok) process.exitCode = 1;
      return;
    }

    if (!result.ok) {
      console.error(`${engine.id} produced no usable thinking chain.`);
      process.exitCode = 1;
      return;
    }

    if (!quiet) {
      for (const t of result.thoughts) {
        const flag = t.grounded === false ? dim('  ⚠ ungrounded') : '';
        const score = typeof t.branchScore === 'number' ? `:${t.branchScore}` : '';
        const branchTag = t.branchId ? dim(` ⟜${t.branchId}${score}`) : '';
        const prunedTag = t.pruned ? dim(' ✂ pruned') : '';
        const line = `${thoughtGlyph(t.kind)} ${bold(`${t.thoughtNumber}/${t.totalThoughts}`)} ${dim(`[${t.kind}]`)}${branchTag} ${t.thought}${flag}${prunedTag}`;
        console.log(t.pruned ? dim(line) : line);
      }
      console.log('');
      if (result.chosenBranch) {
        console.log(`${bold('Chosen branch')}: ${result.chosenBranch}`);
        console.log('');
      }
    }

    if (result.summary) {
      console.log(bold('Summary'));
      console.log(result.summary);
      console.log('');
    }

    if (result.openQuestions.length > 0) {
      console.log(bold('Open questions'));
      for (const q of result.openQuestions) console.log(`  ❓ ${q}`);
      console.log('');
    }

    if (!quiet && result.groundingIssues.length > 0) {
      console.log(dim('Grounding warnings:'));
      for (const g of result.groundingIssues) console.log(dim(`  ⚠ ${g}`));
      console.log('');
    }

    if (!quiet && !result.protocolValid) {
      console.log(dim(`⚠ ${strategy} protocol not fully satisfied (machine validation failed).`));
      console.log('');
    }

    if (result.adversarialCritique) {
      console.log(bold(`Adversarial critique${result.criticEngineId ? ` (${result.criticEngineId})` : ''}`));
      console.log(result.adversarialCritique);
      console.log('');
    }

    if (args.goal) {
      console.log(bold('Handoff → goal'));
      console.log(`agon goal ${JSON.stringify(result.refinedSpec)}`);
      console.log('');
    }

    if (!quiet) {
      info(dim(`Saved: ${outputDir}`));
      printRunSummary(status);
    }
  },
});
