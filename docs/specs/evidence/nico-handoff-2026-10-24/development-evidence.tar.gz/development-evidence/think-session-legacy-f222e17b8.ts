import { join } from 'node:path';

import { mkdirSync } from 'node:fs';

import { ensureAgonHome, RUNS_DIR, tracker, appendMessage, resolveWorkingDir } from '@kernlang/agon-core';

import { runThinkChain, isThinkStrategy } from '@kernlang/agon-forge';

import { ENGINE_COLORS } from '../blocks/output-format.js';

import { sessionResultStore } from '../models/session-results.js';

import { recordRun, formatRunSummary } from '../telemetry/index.js';

import type { Dispatch, HandlerContext, EngineProgress } from './types.js';

import { filterDefaultOrchestrationEngines } from './engine-filter.js';

/**
 * Map a thought kind to a render glyph.
 */
export function thoughtGlyph(kind: string): string {
  return kind === 'critique' ? '🔍' : kind === 'revision' ? '✏️' : kind === 'question' ? '❓' : kind === 'decision' ? '✅' : kind === 'hypothesis' ? '🔬' : kind === 'decompose' ? '🧩' : '💭';
}

export async function handleThink(problem: string, dispatch: Dispatch, ctx: HandlerContext, opts?: {strategy?:string, steps?:number, critic?:string}): Promise<void> {
  const thAbort = new AbortController();
  try {
    ensureAgonHome();
    
    if (!problem || !problem.trim()) {
      dispatch({ type: 'warning', message: 'No problem provided. Usage: /think <problem> [--strategy reflexion] [--steps 8]' });
      return;
    }
    
    const allEngines = ctx.activeEngines();
    const engines = filterDefaultOrchestrationEngines(allEngines);
    if (engines.length === 0) {
      dispatch({ type: 'error', message: 'No engines available.' });
      return;
    }
    const engineId = engines[0];
    
    const strategy = opts?.strategy && isThinkStrategy(opts.strategy) ? opts.strategy : 'linear';
    if (opts?.strategy && !isThinkStrategy(opts.strategy)) {
      dispatch({ type: 'info', message: `Unknown strategy '${opts.strategy}' — using linear (valid: linear|reflexion|tot|graph|hypothesis).` });
    }
    const steps = Math.max(1, Math.min(opts?.steps ?? 6, 20));
    
    // An optional second engine that adversarially attacks the chain.
    let critic: string | undefined;
    if (opts?.critic && opts.critic.trim()) {
      const wanted = ctx.registry.resolveId(opts.critic.trim());
      if (engines.includes(wanted) || ctx.registry.activeIds(ctx.config as any).includes(wanted)) {
        critic = wanted;
      } else {
        dispatch({ type: 'info', message: `--critic '${opts.critic.trim()}' is not an active engine — skipping the adversarial critique.` });
      }
    }
    
    dispatch({ type: 'header', title: `Think · ${strategy} · ${engineId}` });
    dispatch({ type: 'info', message: problem.length > 120 ? problem.slice(0, 120) + '…' : problem });
    
    const outputDir = join(RUNS_DIR, `think-${Date.now()}`);
    mkdirSync(outputDir, { recursive: true });
    
    ctx.setActiveAbort(thAbort);
    
    const startTime = Date.now();
    const progressInterval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const progress: EngineProgress[] = [{ id: engineId, status: `thinking… ${elapsed}s`, elapsed, done: false, failed: false }];
      dispatch({ type: 'progress-update', engines: progress });
    }, 250);
    
    let progressCleared = false;
    function clearProgress(): void {
      if (progressCleared) return;
      progressCleared = true;
      clearInterval(progressInterval);
      dispatch({ type: 'progress-clear' });
    }
    
    let result: any;
    try {
      result = await runThinkChain({
        problem,
        strategy,
        engineId,
        registry: ctx.registry,
        adapter: ctx.adapter,
        maxThoughts: steps,
        branches: 1,
        critic,
        timeout: 120,
        outputDir,
        cwd: resolveWorkingDir(),
        ground: true,
        signal: thAbort.signal,
      });
    } catch (err) {
      clearProgress();
      throw err;
    }
    clearProgress();
    
    if (!result.ok) {
      dispatch({ type: 'error', message: `${engineId} produced no usable thinking chain.` });
      return;
    }
    
    const chainLines: string[] = [];
    for (const t of result.thoughts) {
      const flag = t.grounded === false ? '  ⚠ ungrounded' : '';
      const prunedTag = t.pruned ? ' ✂ pruned' : '';
      chainLines.push(`${thoughtGlyph(t.kind)} ${t.thoughtNumber}/${t.totalThoughts} [${t.kind}] ${t.thought}${flag}${prunedTag}`);
    }
    dispatch({ type: 'text', content: chainLines.join('\n') });
    
    if (result.chosenBranch) dispatch({ type: 'info', message: `Chosen branch: ${result.chosenBranch}` });
    
    if (result.summary) {
      dispatch({ type: 'engine-block', engineId, color: (ENGINE_COLORS as Record<string, number>)[engineId] ?? 124, content: result.summary });
    }
    
    if (result.openQuestions && result.openQuestions.length > 0) {
      dispatch({ type: 'text', content: ['Open questions:', ...result.openQuestions.map((q: string) => `  ❓ ${q}`)].join('\n') });
    }
    
    if (result.adversarialCritique) {
      dispatch({ type: 'engine-block', engineId: result.criticEngineId ?? 'critic', color: 196, content: result.adversarialCritique });
    }
    
    // Persist the refined thinking so Cesar can continue from it.
    const persisted = result.summary || chainLines.join('\n');
    appendMessage(ctx.chatSession, { role: 'user', content: `[think] ${problem}`, timestamp: new Date().toISOString() });
    appendMessage(ctx.chatSession, { role: 'engine', engineId, content: persisted, timestamp: new Date().toISOString() });
    tracker.record(engineId, { prompt: problem, response: persisted });
    
    sessionResultStore.add({
      type: 'think',
      timestamp: new Date().toISOString(),
      question: problem,
      engines: [engineId],
      winner: engineId,
      data: {
        strategy,
        thoughtCount: result.thoughts.length,
        summary: result.summary ?? '',
        openQuestions: result.openQuestions ?? [],
      },
    });
    
    const runRecord = recordRun({
      mode: 'think',
      intent: problem,
      winner: engineId,
      success: true,
      durationMs: Date.now() - startTime,
      engineIds: [engineId],
      completionState: 'completed',
    });
    if (!process.env.AGON_NO_SUMMARY) dispatch({ type: 'info', message: formatRunSummary(runRecord) });
  } finally {
    ctx.setActiveAbort(null);
  }
}
