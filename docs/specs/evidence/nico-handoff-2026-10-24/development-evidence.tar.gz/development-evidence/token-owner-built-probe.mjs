import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = '/Users/ra/dev/agon-audit-qualification';
const home = mkdtempSync(join(tmpdir(), 'token-owner-built-'));
process.env.AGON_HOME = home;
const catalog = await import(pathToFileURL(join(root, 'packages/support-engine-catalog/dist/index.js')));
const core = await import(pathToFileURL(join(root, 'packages/core/dist/index.js')));
for (const name of ['tracker', 'estimateTokens', 'estimateCost', 'estimateCostCacheAware', 'isFlatRateEngine']) {
  assert.equal(core[name], catalog[name], name);
}
catalog.tracker.reset();
const usage = core.tracker.record('fixture-metered', {
  usage: { promptTokens: 100, completionTokens: 20, totalTokens: 120, source: 'sdk' },
});
assert.equal(catalog.tracker.recent()[0], usage);
assert.equal(catalog.tracker.getStats().dispatches, 1);
catalog.tracker.record('fixture-coding-plan', {
  usage: { promptTokens: 100, completionTokens: 20, totalTokens: 120, source: 'sdk' },
});
assert.equal(core.tracker.getStats().flatRateApiDispatches, 1);
assert.equal(core.tracker.getStats().meteredDispatches, 1);
assert.equal(core.tracker.getStats().dispatches, 2);
core.tracker.reset();
assert.equal(catalog.tracker.getStats().dispatches, 0);

function javascriptFiles(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? javascriptFiles(path) : entry.name.endsWith('.js') ? [path] : [];
  });
}
const files = javascriptFiles(join(root, 'packages/cli/dist'));
const consumers = [];
for (const path of files) {
  const source = readFileSync(path, 'utf8');
  assert.doesNotMatch(source, /new TokenTracker\s*\(/, `duplicate bundled tracker: ${path}`);
  assert.doesNotMatch(source, /class TokenTracker\b|TokenTracker\s*=\s*class\b/, `duplicate bundled implementation: ${path}`);
  if (/import\s*\{[^}]*\btracker\b[^}]*\}\s*from\s*["']@kernlang\/agon-support-engine-catalog["']/s.test(source)) consumers.push(path);
}
assert.ok(consumers.length > 0, 'built host must import external shared accounting');
console.log(JSON.stringify({ home, coreCatalogIdentity: true, sharedRecordReset: true,
  builtFilesChecked: files.length, externalTrackerConsumers: consumers,
  scope: 'same-process public accounting and bundle ownership; no live provider dispatch', passed: true }));
