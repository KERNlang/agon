"""Exercise built Tribunal CLI with local fixtures and an isolated Agon home."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

repo = Path('/Users/ra/dev/agon-audit-qualification')
archive = Path('/Users/ra/dev/modular-agon-remediation')
receipt_path = archive / 'tribunal-cli-smoke-v6.receipt.json'
if receipt_path.exists():
    raise SystemExit('Refusing to overwrite smoke evidence')
spec = importlib.util.spec_from_file_location('pressure', repo / 'scripts/spec/pressure_modular.py')
pressure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pressure)
root = pressure.new_run_directory()
env = pressure.isolated_environment(root, os.environ)
env['NODE_OPTIONS'] += ' --require=/Users/ra/dev/modular-agon-remediation/no-login.cjs'
home = Path(env['AGON_HOME'])
engine_dir = home / 'engines'
engine_dir.mkdir()
trace = root / 'dispatch.jsonl'
fixture = root / 'fixture.cjs'
fixture.write_text('const fs = require("node:fs");\n'
                   'const [id, prompt] = process.argv.slice(2);\n'
                   f'fs.appendFileSync({json.dumps(str(trace))}, JSON.stringify({{id,prompt}})+"\\n");\n'
                   'console.log(id === "fixture-judge" ? "FIXTURE_VERDICT: compare observed evidence." : "A substantive fixture argument with supporting evidence.");\n')
for engine_id in ['fixture-alpha', 'fixture-beta', 'fixture-judge']:
    definition = {'schemaVersion': 3, 'id': engine_id, 'displayName': engine_id,
                  'binary': 'node', 'isLocal': True, 'tier': 'user', 'timeout': 5,
                  'exec': {'args': [str(fixture), engine_id, '{prompt}']}}
    (engine_dir / f'{engine_id}.json').write_text(json.dumps(definition))
(home / 'config.json').write_text(json.dumps({
    'engineActivationMode': 'explicit', 'forgeEnabledEngines': ['fixture-alpha', 'fixture-beta'],
    'cesarEngine': 'fixture-judge', 'forgeHealthCheckEnabled': False,
}))
results = []
try:
    for quiet in [False, True]:
        command = ['/opt/homebrew/bin/node', str(repo / 'packages/cli/dist/index.js'),
                   'tribunal', 'Compare fixture evidence', '--engines', 'fixture-alpha,fixture-beta',
                   '--rounds', '1', '--timeout', '5', '--label', 'smoke']
        if quiet:
            command.append('--quiet')
        completed = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=60)
        name = 'quiet' if quiet else 'normal'
        log = archive / f'tribunal-cli-smoke-v6-{name}.log'
        with log.open('x') as stream:
            stream.write(completed.stdout + '\nSTDERR\n' + completed.stderr)
        clean = re.sub(r'\x1b\[[0-9;]*m', '', completed.stdout)
        assert completed.returncode == 0, f'{name}: exit {completed.returncode}; inspect {log}'
        lines = clean.strip().splitlines()
        run_path = Path(lines[0] if quiet else next(line.removeprefix('AGON_RUN: ') for line in lines if line.startswith('AGON_RUN: ')))
        assert run_path.is_relative_to(home), f'Run escaped isolated home: {run_path}'
        status = json.loads((run_path / 'status.json').read_text())
        assert status['ok'] is True and status['mode'] == 'tribunal' and status['label'] == 'smoke'
        assert [seat['id'] for seat in status['engines']] == ['fixture-alpha', 'fixture-beta']
        assert lines[-1] == 'AGON_SUMMARY: 2/2 succeeded'
        if quiet:
            assert len(lines) == 2, lines
        else:
            assert 'FIXTURE_VERDICT' in clean and 'Round 1' in clean and 'Full debate saved:' in clean
        results.append({'quiet': quiet, 'exitCode': completed.returncode, 'runPath': str(run_path),
                        'log': log.name, 'logSha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    calls = [json.loads(line)['id'] for line in trace.read_text().splitlines()]
    assert len(calls) == 6, calls
    for offset in [0, 3]:
        assert set(calls[offset:offset + 2]) == {'fixture-alpha', 'fixture-beta'}, calls
        assert calls[offset + 2] == 'fixture-judge', calls
    assert not pressure.provider_launches(root), 'A live provider was attempted'
    passed = True
finally:
    receipt = {'passed': locals().get('passed', False), 'root': str(root), 'results': results,
               'providerLaunches': pressure.provider_launches(root)}
    with receipt_path.open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
