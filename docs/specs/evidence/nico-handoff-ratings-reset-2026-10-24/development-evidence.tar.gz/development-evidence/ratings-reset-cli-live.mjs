import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, readFileSync, readdirSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';

const repo = '/Users/ra/dev/agon-audit-qualification';
const root = mkdtempSync(join(tmpdir(), 'agon-reset-cli-'));
const home = join(root, 'agon');
mkdirSync(home);
const path = join(home, 'ratings.json');
const rating = { mu: 1900, phi: 40, sigma: 0.06, wins: 114, losses: 1, lastActive: '2026-10-24T00:00:00.000Z' };
const original = {
  global: { fixture: rating },
  byMode: { forge: { fixture: rating }, brainstorm: {}, tribunal: { fixture: rating }, critique: {} },
  byTaskClass: { bugfix: { fixture: rating } },
  engineMeta: { fixture: { firstSeen: rating.lastActive, lastActive: rating.lastActive, matchCount: 115, derivedFrom: null, versions: [] } },
  lastUpdated: rating.lastActive,
};
const bytes = JSON.stringify(original, null, 2) + '\n';
writeFileSync(path, bytes);
const backups = () => readdirSync(home).filter(name => name.startsWith('ratings.json.bak-'));
function run(args, expectedStatus) {
  const result = spawnSync(process.execPath, [join(repo, 'packages/cli/dist/index.js'), 'ratings', 'reset', ...args], {
    cwd: root, env: { ...process.env, AGON_HOME: home }, encoding: 'utf8', timeout: 30000,
  });
  assert.equal(result.error, undefined);
  assert.equal(result.signal, null);
  assert.equal(result.status, expectedStatus, result.stdout + result.stderr);
  console.log(JSON.stringify({ args, exitCode: result.status, stdout: result.stdout, stderr: result.stderr }));
  return result.stdout + result.stderr;
}
try {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  assert.match(run(['--modes', 'tribunal'], 0), /DRY RUN/);
  assert.equal(readFileSync(path, 'utf8'), bytes);
  assert.deepEqual(backups(), []);
  assert.match(run(['--modes', 'unknown', '--apply'], 1), /Unknown mode/);
  assert.equal(readFileSync(path, 'utf8'), bytes);
  assert.deepEqual(backups(), []);
  assert.match(run(['--modes', 'tribunal', '--engines', 'missing', '--apply'], 1), /Unknown engine/);
  assert.equal(readFileSync(path, 'utf8'), bytes);
  assert.deepEqual(backups(), []);
  assert.match(run(['--modes', 'tribunal', '--engines', 'fixture', '--apply'], 0), /APPLIED/);
  assert.equal(backups().length, 1);
  assert.equal(readFileSync(join(home, backups()[0]), 'utf8'), bytes);
  const after = JSON.parse(readFileSync(path, 'utf8'));
  assert.equal(after.byMode.tribunal.fixture.mu, 1500);
  assert.equal(after.byMode.tribunal.fixture.phi, 350);
  assert.equal(after.byMode.tribunal.fixture.wins, 0);
  assert.equal(after.byMode.tribunal.fixture.losses, 0);
  for (const key of ['global', 'byTaskClass', 'engineMeta']) assert.deepEqual(after[key], original[key]);
  for (const key of ['forge', 'brainstorm', 'critique']) assert.deepEqual(after.byMode[key], original.byMode[key]);
  writeFileSync(path, readFileSync(join(home, backups()[0])));
  assert.equal(readFileSync(path, 'utf8'), bytes);
  assert.match(run(['--modes', 'tribunal'], 0), /1900/);
  assert.equal(readFileSync(path, 'utf8'), bytes);
  console.log(JSON.stringify({ passed: true, nativeCliProcesses: 5, backupRestoredByteExactly: true }));
} finally {
  rmSync(root, { recursive: true, force: true });
}
