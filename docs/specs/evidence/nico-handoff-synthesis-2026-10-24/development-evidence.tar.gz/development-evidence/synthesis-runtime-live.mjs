import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, existsSync, chmodSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import ts from '/Users/ra/dev/agon-audit-qualification/node_modules/typescript/lib/typescript.js';

const repo = '/Users/ra/dev/agon-audit-qualification';
if (!process.argv[2]) {
  console.log('helperSha256', createHash('sha256').update(readFileSync(process.argv[1])).digest('hex'));
  for (const scenario of ['entry', 'markdown', 'disabled', 'all-failed', 'mcp-entry', 'mcp-cancel', 'session-entry', 'session-disabled', 'fallback-disabled']) {
    process.stdout.write(execFileSync(process.execPath, [process.argv[1], scenario], { encoding: 'utf8', timeout: 30000 }));
  }
  console.log(JSON.stringify({ passed: true, nativeProcesses: 9 }));
  process.exit(0);
}
const scenario = process.argv[2];
const root = mkdtempSync(join(tmpdir(), 'agon-synthesis-live-'));
process.env.AGON_HOME = join(root, 'data');
process.chdir(root);
const kernel = await import(join(repo, 'packages/mod-kernel/dist/index.js'));
const modules = new Map();
for (const [id, definition] of kernel.createFirstPartyModCatalog().packagesById) {
  if (definition.class !== 'user-toggleable-mod-package') continue;
  const packageRoot = join(repo, 'node_modules', id);
  const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
  modules.set(id, await import(pathToFileURL(join(packageRoot, metadata.exports['.'].import)).href));
}
const fixture = {};
new Function('exports', 'require', ts.transpileModule(readFileSync(join(repo,
  'tests/helpers/modular-surface-lock.ts'), 'utf8'), { compilerOptions: {
  target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS,
} }).outputText)(fixture, id => {
  if (id.includes('mod-kernel')) return kernel;
  assert.ok(modules.has(id), id);
  return modules.get(id);
});
const directory = join(repo, 'packages/cli/dist');
const chunks = readdirSync(directory).filter(name => name.endsWith('.js'));
async function owner(symbol) {
  const files = chunks.filter(name => readFileSync(join(directory, name), 'utf8').includes('function ' + symbol + '('));
  assert.equal(files.length, 1, symbol);
  const module = await import(pathToFileURL(join(directory, files[0])).href);
  assert.equal(typeof module[symbol], 'function', symbol);
  return module;
}
const authority = await owner('initializeProcessSurfaceAuthority');
const host = new kernel.DurableModHost(join(root, 'host'), { kernelVersion: '1.0.0', processIdentity: 'native-synthesis' });
function unlock(path) {
  if (!existsSync(path)) return;
  chmodSync(path, 0o700);
  for (const entry of readdirSync(path, { withFileTypes: true })) if (entry.isDirectory()) unlock(join(path, entry.name));
}

try {
  const catalog = kernel.createFirstPartyModCatalog();
  const full = kernel.createFullCompatDesiredState(catalog, '2026-10-24T00:00:00.000Z');
  const disabled = scenario.endsWith('disabled');
  const desired = disabled ? kernel.planDesiredStateChange(catalog, full,
    { kind: 'disable', id: 'agon.synthesis' }, '2026-10-24T00:00:00.000Z').nextState : full;
  await host.commitGeneration({ operation: disabled ? 'disable' : 'install',
    lock: await fixture.surfaceLockFor(desired), desiredState: desired, installedIndex: {} });
  await authority.initializeProcessSurfaceAuthority(join(root, 'host'));
  const definitions = join(process.env.AGON_HOME, 'engines');
  mkdirSync(definitions, { recursive: true });
  const marker = join(root, 'dispatches.txt');
  const ids = ['fixture-alpha', 'fixture-beta'];
  writeFileSync(join(process.env.AGON_HOME, 'config.json'), JSON.stringify({
    engineActivationMode: 'explicit', forgeEnabledEngines: ids,
  }));
  const response = scenario === 'markdown'
    ? '**SCORE_1:** 10\n**SCORE_2:** 90\n**WINNER:** **Entry 2**.\n**REASONING:** second wins'
    : 'SCORE_1: 10\nSCORE_2: 90\nWINNER: Entry 2\nREASONING: second wins';
  for (const id of ids) {
    const script = 'require("node:fs").appendFileSync(' + JSON.stringify(marker) + ',' + JSON.stringify(id + '\n') + ');'
      + (scenario === 'mcp-cancel' ? 'setTimeout(()=>console.log(' + JSON.stringify(response) + '),20000);'
        : 'console.log(' + JSON.stringify(response) + ');process.exitCode=' + (scenario === 'all-failed' ? 2 : 0));
    writeFileSync(join(definitions, id + '.json'), JSON.stringify({ schemaVersion: 3, id,
      displayName: id, binary: process.execPath, isLocal: true, tier: 'user', timeout: 5,
      exec: { args: ['-e', script] } }));
  }
  const input = { prompt: 'Native Synthesis', engines: ids.join(','), swaps: '0', timeout: '5' };
  if (scenario.startsWith('session-') || scenario.startsWith('fallback-')) {
    console.error('SESSION_PROBE', scenario, 'build-start');
    const { build } = await import(createRequire(join(repo, 'package.json')).resolve('esbuild'));
    const probePath = join(root, 'session-probe.mjs');
    await build({ stdin: { contents: [
      "export { initializeProcessSurfaceAuthority, disposeProcessSurfaceAuthority } from './packages/cli/src/surface-authority-runtime.ts';",
      "export { dispatchIntent } from './packages/cli/src/signals/dispatch/intent-router.ts';",
      "export { dispatchOrchestrationIntent } from './packages/cli/src/signals/dispatch/intent-orchestration.ts';",
      "export { detectIntent } from './packages/cli/src/signals/intent.ts';",
      "export { JobManager } from './packages/cli/src/signals/job-manager.ts';",
    ].join('\n'), resolveDir: repo, loader: 'ts' }, outfile: probePath,
    bundle: true, platform: 'node', format: 'esm', packages: 'external', logLevel: 'silent',
    plugins: [{ name: 'workspace-resolution', setup(builder) {
      const require = createRequire(join(repo, 'package.json'));
      builder.onResolve({ filter: /^[^./]/ }, args => {
        if (args.path.startsWith('node:')) return { path: args.path, external: true };
        if (args.path.startsWith('@kernlang/')) {
          const packageRoot = join(repo, 'node_modules', args.path);
          const metadata = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'));
          return { path: join(packageRoot, metadata.exports?.['.']?.import ?? metadata.main), external: true };
        }
        try { return { path: require.resolve(args.path), external: true }; } catch { return undefined; }
      });
    } }] });
    console.error('SESSION_PROBE', scenario, 'build-complete');
    const probe = await import(pathToFileURL(probePath).href);
    console.error('SESSION_PROBE', scenario, 'import-complete');
    await probe.initializeProcessSurfaceAuthority(join(root, 'host'));
    console.error('SESSION_PROBE', scenario, 'authority-ready');
    const { EngineRegistry } = await import(join(repo, 'packages/support-engine-catalog/dist/index.js'));
    const registry = new EngineRegistry();
    registry.load(definitions);
    const events = [];
    const manager = new probe.JobManager();
    let jobId;
    const cb = { dispatch: event => events.push(event), dynamicSkills: [], allSlashCommands: [],
      ctx: { registry, config: { sessionContinuity: false }, chatSession: { id: 'probe', messages: [] },
        inputEpoch: 1, activeEngines: () => ids, setActiveAbort: () => {},
        adapter: { dispatch: async () => { throw new Error('disabled fallback dispatched'); } } },
      runAsJob: (type, label, run) => { jobId = manager.run(type, label, run).id; } };
    try {
      const raw = '/synthesis Native Synthesis --swaps 0';
      let failure;
      try {
        if (scenario.startsWith('fallback-')) {
          await probe.dispatchOrchestrationIntent({ type: 'synthesis', input: 'Native Synthesis', swaps: 0 }, raw, cb);
        } else {
          const intent = probe.detectIntent(raw);
          if (!disabled) assert.ok(intent._modSurface, 'generated session contribution selected');
          await probe.dispatchIntent(intent, raw, cb);
        }
      } catch (error) { failure = error; }
      console.error('SESSION_PROBE', scenario, 'dispatch-returned', jobId, events);
      const finished = jobId ? await manager.wait(jobId) : undefined;
      console.error('SESSION_PROBE', scenario, 'job-finished', finished);
      if (disabled) {
        assert.equal(jobId, undefined, 'disabled Synthesis must not start a session job');
        assert.equal(existsSync(marker), false);
        assert.ok(failure || events.some(event => event.type === 'error' || event.type === 'warning'));
      } else {
        assert.equal(failure, undefined);
        assert.equal(finished.state, 'done');
        const result = events.find(event => event.type === 'engine-block');
        assert.ok(result);
        assert.equal(JSON.parse(result.content).winner, 'fixture-beta');
      }
    } finally { await probe.disposeProcessSurfaceAuthority(); }
  } else if (scenario.startsWith('mcp-')) {
    process.env.AGON_MODULAR_HOST_ROOT = join(root, 'host');
    const mcp = await import(pathToFileURL(join(repo, 'packages/mcp/dist/surface-authority.js')).href);
    try {
      await mcp.initializeMcpSurfaceAuthority();
      const entry = mcp.activeMcpSurfaceTools().find(tool => tool.ownerId === 'agon.synthesis');
      assert.ok(entry, 'Synthesis tool is discoverable');
      const controller = new AbortController();
      const pending = mcp.invokeActiveMcpSurfaceTool(entry.name, input, controller.signal);
      if (scenario === 'mcp-cancel') {
        const rejected = assert.rejects(pending, /native cancellation/);
        const deadline = Date.now() + 5000;
        while (!existsSync(marker) && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 20));
        assert.ok(existsSync(marker), 'fixture started before cancellation');
        controller.abort(new Error('native cancellation'));
        await rejected;
      } else {
        const result = await pending;
        assert.notEqual(result.isError, true);
        const parsed = result;
        assert.equal(parsed.winner, 'fixture-beta');
        assert.equal(parsed.scores[1].score, 90);
      }
    } finally { await mcp.disposeMcpSurfaceAuthority(); }
  } else {
    const { createGeneratedLazySubCommands } = await owner('createGeneratedLazySubCommands');
    const output = [];
    const original = process.stdout.write;
    let failure;
    try {
      process.stdout.write = chunk => { output.push(String(chunk)); return true; };
      await createGeneratedLazySubCommands().synthesis.run({ args: input });
    } catch (error) { failure = error; }
    finally { process.stdout.write = original; }
    if (disabled) {
      assert.ok(failure || (process.exitCode ?? 0) !== 0);
      assert.equal(existsSync(marker), false, 'disabled Synthesis cannot dispatch');
    } else if (scenario === 'all-failed') {
      assert.ok(failure || (process.exitCode ?? 0) !== 0);
    } else {
      assert.equal(failure, undefined);
      assert.equal(process.exitCode ?? 0, 0);
      const parsed = JSON.parse(output.join(''));
      assert.equal(parsed.winner, 'fixture-beta');
      assert.equal(parsed.scores[0].score, 10);
      assert.equal(parsed.scores[1].score, 90);
      assert.equal(readFileSync(marker, 'utf8').trim().split('\n').length, 3);
    }
  }
  process.exitCode = 0;
  console.log(JSON.stringify({ passed: true, scenario, compiledHost: true, realDurableHost: true }));
} finally {
  await authority.disposeProcessSurfaceAuthority?.();
  process.chdir(repo);
  unlock(root);
  rmSync(root, { recursive: true, force: true });
}
