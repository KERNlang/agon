# Upstream Tribunal judging review

## Council boundary requalification — 2026-10-24

Reused the existing council-runtime-live.mjs, council-mcp-live.mjs and
council-session-live.mjs helpers against the current built integration. Separate
isolated root /tmp/agon-council-proof-nb7sctrn; no shared full-suite fixture state.
All 21 child process scenarios passed: 7 CLI, 6 MCP-host and 8 session checks.
Coverage includes output formats, advisor failure, chair failover, all-failed,
disabled owner, fallback failure, cancellation/host exit, Cesar and external chair.
These are real durable-host/compiled-surface checks using local fixture engines,
not live model quality tests or complete wire-level MCP client qualification.
Zero provider launches. Receipt upstream-council-native-boundaries.receipt.json;
22.056 seconds; log SHA-256
f44472e272f627d6ec08944c2252c97e11b9bff9ba790adcfd99bb157deb4d6d.
The full gate 5995 remains live with 688 completed files and no reported failure.
Do not treat these component results as final development merge qualification.

## Native ratings reset qualification — 2026-10-24

Prepared ratings-reset-cli-live.mjs outside the shipping tree. Syntax check
passed. Executed the built CLI index in five fresh Node subprocesses, with a
separate pressure-runner isolated environment and provider blockers (not the
shared full-suite runtime). No production source changed during the full run.

All five processes passed their state/output/exit-code assertions: dry-run
preserves exact ratings bytes and creates no backup; unknown mode and unknown
engine refuse with exit 1 and no changes; explicit apply resets only the selected
discipline/engine and creates an exact pre-change backup; restoring that backup
recovers the original bytes and a fresh CLI preview observes the original score.
Global ratings, other disciplines, task-class ratings and engine metadata remain
unchanged. The owned disposable fixture directory was removed after the run;
the receipt, raw output and helper remain in this durable evidence directory.

Receipt: upstream-ratings-reset-native.receipt.json; 1.444 seconds, zero provider
launches; log SHA-256 8f0bc214d9da628677ec97884755c9199f81bf20391ad4e5081a8d8c674ae844.
Helper SHA-256 ee430896bbfb669d5b306c0ade4a5c72bdcbe295b431902512627e29c144db9a.
This is built working-tree CLI evidence, not clean-checkout release acceptance.
Full gate 5995 remains live; build/types/guard/release/SBOM passed, lint started.

## Current verification checkpoint — 2026-10-24

Prior goal turn: progress. Full run 62298 terminated with 11,602 passed,
23 failed and 6 skipped. Its receipt is upstream-dev-base-full.receipt.json.
The three failing Plan files were reconciled without changing frozen fixtures.
The focused rerun passed all 90 tests; zero provider launches. Receipt:
upstream-dev-base-parity-reconcile.receipt.json. Source-ledger comparison against
the index confirms exactly 29 changed SHA-256 fields and zero non-hash changes.
No ownership assignment, dependency, rollback statement or acceptance rule changed.

Full verification now runs as terminal 5995, receipt ID
upstream-dev-base-full-reconciled. It starts with the full npm build (not just
adapter/CLI), then types, re-export guard, release-set, supply-chain, lint and
all tests. Handle polled live during this continuation; build still progressing.
Do not edit source or start another shared run.py until it terminates.

Git reports zero unresolved merge entries; merge commit remains pending.
MODULAR-AGON-HANDOFF.md still has the older 13-conflict snapshot. Replace that
snapshot with terminal evidence before publishing the integration handoff.
Next evidence after this gate: native reset CLI preview/apply/backup/refusal,
existing Council CLI/MCP/session probes, then clean committed pressure checkout.
Keep the two earlier clean-checkout timing failures visible until requalified.
Development-base readiness is the immediate human merge checkpoint. Full release
acceptance is unchanged and resumes on a new branch after Nico's merge.

## Latest verification and fixes

Repository lint passes: 1,731 files, 55 partitions, zero warnings, 70.597s.
Receipt upstream-integration-lint; log SHA
267f20f093ca27f930bfc5d4103786898d55e4755fb75eeb029d3342fb0e9d08.
All run.py processes from this turn finished. No commit/push yet.

Finding 1 now reproduced and fixed. New regression first returned successfully
after retirement and overwrote initial ballot evidence. Negative receipt
upstream-ballot-fence-negative, SHA
50c3ebe19383561fbbed41cf7864e8709c7b598fcd19a067d4d9cc390adaf754.
Added optional assertAuthority to the judging effect contract; the real Tribunal
host supplies its captured generation check, separate from signal cancellation.
Ratings checks it before each dispatch and before every ballot-file write.
Started ballot tasks use allSettled before propagating an authority error.
Partial cancellation evidence remains supported. Direct helper test passes in
upstream-ballot-fence-fixed (28 tests), SHA
3b85667cc1772a5416ae634f90539ade359f61e45c929c3f31606d62bfcd7be5.
Extended the regression to execute through createTribunalHostServices without
supplying a caller authority hook: this proves host injection and byte-identical
evidence preservation, not just helper behavior. Fresh Ratings/Tribunal builds
and 29 helper + 141 protocol/command tests pass, 13.932s, zero provider launches:
upstream-ballot-host-fence, SHA
06687f6c6421d8ada22f4fa3391d4ffc3c8ac2fabf2ae2c5daf02db3306bf11f.

Raw dispatch lifetime remains under investigation, distinct from the fixed
concurrent effect return. Existing AC-6 test intentionally uses an adapter that
never settles, even after abort, and requires bounded timeout. Unconditionally
awaiting that raw dispatch would regress this contract. Need verify real API
adapter cancellation and resource cleanup before deciding on further changes.
The old helper's abort race can still return before its bounded ballot tasks
settle; preserve late-write guards and explicit timeout while addressing it.

Full baseline finished: 732.044s, 11,464 passed, 117 failed, 29 skipped,
18 failing files and 16 unhandled errors. Receipt upstream-integrated-tests;
log SHA92ed6abe33f7dd313d93ae33bd10fe4d362dba9b6fdbeb40fbcd93683501e304.
No provider launches. The chained lint/graph/generator gates did not run.

Socket/environment failures independently rerun outside the outer sandbox with
the same isolated home/provider guards: all 86 tests across eight files pass,
16.348s. Receipt upstream-socket-gates; log SHA
5deb70f76e0b9c353f4d9bc30ef528b261e6f74c31c2a6cd8cb13a0c26c9efc3.
Includes daemon survival/Jobs authority, serve authority/conformance/lifecycle,
capability wire contract, rooms tail/work. Zero provider launches. Full-suite
qualification must use the socket-capable environment too.

Finding 3 reproduced: disallowed gamma still judged a three-position ballot.
Negative upstream-peer-pool-negative (25 pass/1 fail), log SHA
809b3bb5468d2b07cfff1479b5c5944b330cc8e36c3f05b847d741200d0c27fe.
Peer ballot planning now intersects responding judges with the supplied pool,
while retaining excluded peers as ranked positions. Existing pure-call default
without a supplied pool remains all responding participants. A signal-hygiene
fixture had zero active peers but expected three ballots; split active/inactive
cases with explicit dispatch counts. All 30 checks pass in
upstream-peer-pool-fixed-v2, 1.51s, log SHA
f909c57ed16036d9990ba80a0d63963ea06a05feb115ef678147e5002a90b6de.

Finding 2 runtime portion reproduced: summary authority failure returned before
an injected pending judging effect settled. Negative receipt
upstream-tribunal-drain-negative, log SHA
adb36dc30c8d8ad986a5e014ed1fbbe3dfdd670a6070621957e2b8fb25a1be65.
Moved judge start after synchronous summary preparation and added finally-await
around summary execution. It waits for the captured judging outcome even when
summary authority checks throw. All 141 tests across three files pass in
upstream-tribunal-drain-fixed, 9.259s, log SHA
3037af9bfb2b54447ba506b38fb9bd9da0e4bbd24b485614f6aadafe4bf200ec.
This fixes effect lifetime, NOT raw adapter timeout/abort drainage yet.

Next: reproduce/fix finding 1 ballot-write fencing. Keep partial evidence on
ordinary cancellation; authority retirement must prevent later writes. Inspect
helper timeout/abort policy without making a non-cooperative adapter hang past
the existing explicit timeout test. Then rebuild Ratings/Tribunal before testing
legacy facades, refresh release metadata/docs, and reconcile remaining full-suite
failures against changed upstream contracts rather than weakening oracles.

Remaining baseline files include Council runtime/host expectations, Forge
settings generation, Plan step admission, Tribunal host dispatch contracts,
surface count/docs projection and setup selection. Raw baseline log holds exact
failures. No test process from this turn remains live. No commit or push yet.

Subject: in-progress main integration on 59cd5b564, not a committed acceptance
subject. Packet hash 1353614129d403842f77a31a6927a0751cd3a273c36db0fa4299020be04284d5.
Codex through isolated Agon, no personal-state writes. First launch failed to
apply nested sandbox (exit 71); retry used the same packet and its own sandbox.
Successful review log hash:
0c4bbff743f164e8e12a503e7d34b9f198b10ddfa8c8b15a16474e599c563235.

## Findings and current adjudication

1. Ballot write fencing: source-confirmed gap, behavioral reproduction pending.
   mod-ratings/rating-judge.ts catches dispatch errors and subsequently writes
   ballots through record(). The Tribunal host checks authority around the
   whole effect but supplies no authority check at those intermediate writes.
   Need retirement-during-ballot negative control. Preserve partial evidence on
   ordinary user cancellation without permitting retired-generation writes.

2. Concurrent task lifetime: source-confirmed gap, reproduction pending.
   mod-tribunal/runtime.ts creates judged before summary dispatch. A throwing
   assertCurrent in the summary catch exits without awaiting judged. The Ratings
   helper also races dispatch against timeout and all ballots against abort.
   Need distinguish bounded cancellation from actual provider drain; exercise
   late-settling providers before disposing caller-owned resources.

3. Active/allowed peer pool: source-confirmed mismatch, reproduction pending.
   judgeTribunal computes an active non-quarantined pool. planTribunalBallots
   applies the pool only to two-position independent judges; three-position
   peers use canJudge alone. Reproduce excluded/quarantined peer dispatch and
   preserve its eligibility as a ranked participant while forbidding judging.

4. Array/schema mismatch: reachable-failure claim refuted for current session routes.
   Public schema declares engines as string. Internal session execution supplies
   arrays. executeProcessCesarRoute forwards input directly to payload.run;
   TUI runPhysicalTuiContribution likewise forwards prepared input/context.
   registry.ts #register guards ownership and resolves config, then calls the
   original run with input unchanged. No input-schema validator lies on those
   internal paths. Keep the public CLI string contract; internal normalized
   arrays are supported. Add route-level regression coverage when reconciling
   the host tests, not a public schema widening for a hypothetical failure.

Additional suggestions: verify real CLI/MCP bindings with Ratings disabled,
off/shadow behavior, identity updates once per run, and trusted context judge
pool versus explicit engine selection. Existing protocol fixtures cover several
of these, but host composition needs its own evidence.

## Other gates

upstream-integrated-build passed build, typecheck and re-export guard (200.813s,
zero provider launches), log SHA:
67f38f9513c901715c602fbf7092a4444427e3adec744e51711a801aceab6b27.

upstream-integrated-tests is running (session 4124). It has reported a package
resolution failure; wait for the terminal receipt before diagnosing the full
failure set. Do not restart the live run or edit its source subject meanwhile.
Development-base verdict remains NOT ready. Full release goal remains active.

Read-only setup failure diagnosis while the suite runs: the current Ratings
manifest pack.include references five newly extracted declarations absent from
the existing release-set files list: dist/reset.d.ts, dist/identity.d.ts,
dist/ballot-prompt.d.ts, dist/judge-pool.d.ts, dist/rating-judge.d.ts.
modular-setup-selection copies only release-set files, then static discovery
requires manifest.pack.include paths to exist. This explains the reported
package-path resolution failures. Refresh release-set/channel/SBOM with their
existing generators after source fixes and rebuild; do not relax discovery.

Live-run check: session 4124 remains live. Process inspection identified parent
Vitest PID 54139 and outstanding worker PID 54145. A one-second native sample
is saved as upstream-tests-worker.sample.txt. The worker is performing file I/O
and subprocess work, not proven stalled. A precise completed-file scan finds
691 completed files; packages/mod-goal/src/implementation.test.ts is the sole
unfinished file. Earlier wording that all files had reported meant names had
appeared in logs, not completion. Do not restart the run. Runner timeout is
1200 seconds. After it terminates, retain its failure receipt and enumerate all
failures before fixes. Lint/graph/generator checks are chained after npm test
and therefore will not run if tests fail.

## Development-base checkpoint and continued verification, 2026-10-24

Raphael explicitly separated development-base merge readiness from full release
acceptance. The immediate deliverable is a verified development branch Nico can
merge. Do not merge automatically. After his merge, continue full acceptance on
a new branch. Release-only external evidence must remain visible, but must not
silently become a new development-base requirement. Existing runtime regressions,
failed repository gates, dirty-subject evidence and unresolved integration defects
still prevent declaring the development base ready.

The earlier full-suite run terminated: 11,464 passed, 117 failed, 29 skipped;
18 failed files, 673 passed files, one skipped file. Receipt:
upstream-integrated-tests.receipt.json. It is not still running. The isolated
socket-permitted rerun upstream-socket-gates passed 86 tests in eight files;
the original socket EPERM errors were sandbox failures. Other integration failures
remain tracked; no full-suite success is claimed.

Review fixes now include active/allowed peer-pool enforcement, runtime waiting
for concurrent judging on summary authority failure, and generation-authority
checks before ballot dispatch/evidence writes. Each has a failing negative control
and focused passing evidence. Host-level injection is covered, not only a direct
helper call. Existing lint gate upstream-integration-lint passed.

The helper-level cancellation race was independently reproduced by
upstream-ballot-drain-negative: it returned before started ballot cleanup finished.
Negative log SHA-256:
0ad5728d2b739c37f2720085e25aae93ab879a1d0dc05c9d09a18c4679d3dd61.
Removed the outer abort race; per-ballot abort propagation and deadlines remain.
The helper now awaits all bounded ballot tasks before returning. This does not
claim a non-cooperative adapter can be forcibly drained after its deadline.
upstream-ballot-drain-fixed passed 30 helper tests, owner builds and 141 Tribunal
tests, including timeout, partial cancellation and retired authority cases.
21.169 seconds; zero provider launches; log SHA-256:
bc2f370cb721c72210d7b57d8d193d92d77c596dc330cda3374395ba904b51ec.

Next: refresh existing generated release metadata/docs, reconcile stale fixtures
against verified upstream changes without weakening frozen oracles, then run
complete gates and clean-checkout qualification. No merge readiness claim yet.

Generated-metadata reconciliation: upstream-refresh-generated completed in
90.428 seconds with 419 passing and 24 failing tests (five failing files).
Setup-selection, docs projection, mode docs and engine dispatch contracts passed.
Release-set/channel/SBOM and modes docs were refreshed through existing generators.
The remaining failures were Council runtime/host, Plan step admission, Forge
settings, and surface generation. Log SHA-256:
cae9a47f1503739915bf1905f4644cf76586a432575cb55e82e0751ce9e8943b.

Surface catalog refresh then passed all ten tests (upstream-surface-refresh,
1.47 seconds). Upstream Ratings reset adds one CLI contribution: total 451,
CLI 78. The test now checks its Ratings owner and disabled-owner unreachability,
not only the increased count. The generator also refreshes owner content hashes.
Log SHA-256: 6b855f7afb1d5d27e2e96ff4d465cddeb95c8c2e70e8374e0170eb217422c764.
Both runs recorded zero provider launches. git diff --check passed.
No test process remains running from this block. Merge remains uncommitted;
no push, installation, promotion or global-state change was performed.
Remaining observed focused failures: 20 across four files. Reconcile those,
then rebuild/regenerate release metadata again because catalog source changed,
and perform full gates plus clean committed development-base qualification.

## Plan judging integration and remaining fixture reconciliation

Previous goal turn made concrete progress: cancellation repair, generated
metadata repair and surface checks. This continuation reconciled the remaining
four focused failure groups against source rather than changing production
behavior to match stale fixtures.

Council: frozen legacy source remains unchanged. Requests, results, events,
warnings and logs still compare against it. The effect comparison now explicitly
excludes retired length-based classification/rating writes when no judging
capability is supplied. Upstream MERGE_HEAD Council confirms this removal;
the existing council-judged tests exercise real replacement scoring through the
legacy facade into the physical owner. Host test now verifies ranking options
and that a foreign caller registry cannot replace the captured registry.

Settings: exact expected defaults now include upstream Council's exploration
setting and six Ratings settings, verified against MERGE_HEAD Core defaults.
Owner schemas and aliases must match. All invalid alias negative controls remain;
their expected errors distinguish duplicates from missing required aliases.
The first reconciliation run failed because the foreignSetting fixture already
has a property schema (so its error is missing assigned aliases, not missing
schema). Corrected that test expectation; no generator check was weakened.
upstream-council-settings-reconcile passed 93 tests in four files, 30.535 seconds,
zero provider launches. Log SHA-256:
e69a0e07f91c446ea2cdaff3ba95628514ac73f8360aac50c7c3b30c5a2fdead.

Plan: discovered a real omitted binding, not merely stale expectations.
buildStepExecutors constructed createTribunalRuntime without judgeForRating.
Thus Plan/pipeline Tribunal could never produce judged ratings. Added a test
through Plan execution with real Ratings helper and three fake API transports.
On and shadow both failed with zero ballots before the fix; off and disabled
passed (upstream-plan-judging-negative, SHA-256
261a9d7b2286d03605a0e4d122c311e833011e0e9fed4a05d07ea6b3c1c9ee61).
The binding now reuses judgeTribunalForRating, skips disabled Ratings, loads
invocation config and checks captured Tribunal authority before evidence writes.
No new package or runtime owner was introduced. Existing fault cases explicitly
use off mode; Brainstorm expectations include the new identity argument.
upstream-plan-judging-fixed passed all 180 tests in 61.956 seconds, zero provider
launches. Log SHA-256:
61ae2ea78dd79ad2c4c5c70804faf3de37b14ba837bd4c885b0ca9b6f9fb8e3f.

Live work started after these passes:
- Isolated Agon Codex review upstream-plan-judging: terminal 37216.
- Build/typecheck/reexport and release metadata refresh upstream-reconciled-build:
  terminal 65216. Uses run.py isolated runtime; do not start another run.py until
  this terminates. Review uses separate isolated state.
Poll these exact handles; neither has a terminal receipt yet. Then adjudicate
review findings and run full suite with local socket permissions, lint and
remaining qualification gates. No commit/push/readiness claim in this block.

The Plan Codex review subsequently finished successfully (terminal 37216 closed).
Packet SHA-256: 3d4e960e4b8dc55ba2554748b7bec65170724d0b49e52465aa7778ce91d1e22d.
Log SHA-256: adadca662e6ccc1e4df6a73821c55c019d562d3c4fe5eee494797663fdb9aade.
Findings are hypotheses until reproduced:
1. Timeout releases castOne's wrapper before a transport settles after abort.
   Source confirms the race; this was already a known boundary of bounded drain.
   Do not blindly await forever: existing AC-6 explicitly uses a never-settling
   transport. Reproduce delayed cleanup at timeout and inspect real adapter abort
   semantics before choosing a fix that preserves the timeout contract.
2. Plan workspace omission is source-confirmed: both panel.tribunal and
   pipeline.tribunal omit captured cwd; runtime falls back to process.cwd().
   Add a regression with setSessionRoot different from process directory and
   test both direct and pipeline paths, then pass captured cwd in both bindings.
3. Extend judged-mode coverage to pipeline; existing fault tests run with judging
   off and do not establish cancellation/retired-authority safety while ballots
   are active. Add discriminating controls rather than infer broad coverage.

Build terminal 65216 is still live, observed progressing through package builds.
Do not edit source while that gate runs. Poll the same handle; preserve its result
before applying reviewed fixes. Independent review must not be repeated after
local fixes unless a new scope justifies it. Development-base remains unready.

## Reviewed fixes continued

upstream-reconciled-build completed successfully: 221.318 seconds, build,
typecheck, re-export guard, release-set and SBOM generation. Zero provider
launches. Log SHA-256:
dd3497cc9637ecd1b28fd23e652853e276932e06c906ceb0518648d1316a0436.
This receipt predates the fixes below; do not treat it as their qualification.

Workspace finding reproduced in both direct Plan and pipeline paths, across all
four judging modes, with a captured session root changed before execution.
upstream-plan-workspace-negative failed (SHA-256
aeb9bc0c4b4dbb74d2a5a08b54d4c5f8375723b3486957e9f2854552bf1919ee).
Both bindings now pass the captured cwd. Tests assert each dispatch and config
lookup uses that root, not process.cwd() or the later session selection.

Timeout cleanup finding reproduced: one cancellation control passed, deadline
control failed because wrapper returned before delayed cleanup. Receipt
upstream-timeout-drain-negative, log SHA-256:
214967c21897fa3421d1f598a7c0fad6a40786556d183f075db0b865f0376bfd.
The ballot deadline now aborts, then waits up to one second for dispatch to
settle. Existing never-settling adapter test still remains unchanged and bounded;
the deadline test now uses a fake clock to avoid scheduling-dependent sleeps.
This proves cooperative delayed cleanup, NOT unconditional settlement of a
broken adapter. Do not claim that a transport ignoring abort cannot remain live.
Source inspection found the real API adapter writes its output file after API
dispatch returns, without checking the signal first (adapter-cli/src/adapter.ts).
That late-write boundary still needs a targeted reproduction/guard before fully
closing the timeout review finding. Do not hide it behind the one-second grace.

upstream-reviewed-drain-workspace passed helper tests, Ratings build, Tribunal
protocols and full Plan admission suite in 69.136 seconds, zero provider launches.
Log SHA-256:
8ecf365d4c82f078f150407051ec25979b5459efc18b000f3e45bdd3f4121bed.

Extended Plan tests to active-ballot cancellation and generation retirement,
for both direct and pipeline routes. On retired generation, ballot evidence
must stay byte-identical after authority changes. No ratings or context export
may escape either fault. All 12 judged-mode/route/fault cases pass:
upstream-plan-active-ballot-faults (6.554 seconds), log SHA-256
2aa55f0d835c934b67662bf708a644965d5cbb4e73828b0db87b1ec5dbf6b115.

Current live terminal: 79069, upstream-dev-base-preflight. It runs deterministic
helper tests, Ratings/CLI builds, typecheck, re-export guard, release-set/SBOM
refresh and lint. Do not start another run.py or edit source until it finishes.
Next: close real API adapter late-write boundary with a negative control, retain
finite timeout behavior, then full socket-permitted repository tests and exact
clean-checkout qualification. No commit/push/global changes; not merge-ready.

## API late publication guarded; full verification started

upstream-dev-base-preflight passed in 107.846 seconds: helper tests, Ratings/CLI
builds, typecheck, re-export guard, release-set/SBOM refresh and lint. Zero
provider launches. SHA-256:
fe08d3b3a2dffd12912e1be06b6008a619b7a1c5cd3da1d0be796bb9791d96db.
Terminal 79069 is complete; do not restart it.

Added plain-text and history API regressions using the real CliAdapter with
deferred API mocks. Both reproduced late success after abort before the guard.
They preserve a pre-existing output artifact and capture prior engine health.
upstream-api-late-output-negative failed both, log SHA-256:
e8f53df18dbf800298ebd8225527e1eb9d6dcba081f70102dd58cbeb99627dbb.
The API dispatch branch now calls signal.throwIfAborted immediately after the
awaited API response and before any output-directory creation, output write or
engine-health publication. Both tests require the original abort reason and
unchanged artifact/health; they also assert which API branch was exercised.

upstream-api-late-output-fixed passed 85 tests across adapter fallback, CLI-path
parity, engine identity and rating judging, 4.198 seconds; zero provider launches.
Log SHA-256: 0a64b4a8faa921bab21de8d4afb91c08723cdac4bcbdcf8b0e14f72314d3baa5.
This closes the concrete late output/health publication path after timeout.
The bounded cleanup contract remains honest: abort-ignoring third-party code
cannot be forcibly stopped in-process. No unconditional transport-drain claim.

Live verification: upstream-dev-base-full, terminal 62298. Elevated outer
sandbox solely for local socket tests; existing isolated homes/provider blockers
remain active. Command sequence: adapter/CLI rebuild, typecheck, re-export guard,
release-set/SBOM generation, lint, full npm test. Timeout 1200 seconds. Do not
edit source or start a second run.py while this gate is running. Poll the same
handle and preserve its terminal receipt. No component result implies readiness.

After full gate: inspect failures if any; otherwise verify remaining generated
drift/graph/package gates, stage only integration paths, commit verified merge,
qualify that exact clean committed checkout with the existing candidate harness,
update Nico handoff and push verified work. Development-base readiness is a
separate user checkpoint, not completion of the full modular release goal.

## Running full-suite observations (not a terminal receipt)

62298 remains live. Build/types/re-export/release/SBOM/lint completed; tests
progressed to 459 completed files. Three files have reported failures so far:
Plan migration ledger (1), pipeline parity (16), panel parity (6).
Ledger failure explicitly reports stale S5 generated migration evidence; Plan
handler bytes changed, so regenerate with the existing generator after this run.
Parity fixtures compare old arguments without the new captured cwd. Verify exact
diffs at run completion; preserve frozen fixtures and assert the intentional cwd
delta rather than dropping arguments from assertions without checks.

Earlier clean-checkout failures were re-read: the five MCP cases involved module
reset/singleton mismatch already repaired in the working integration; candidate
descendant case timed out correctly but lacked its readiness text within the
500ms wall-clock window; setup-selection idempotence case exceeded 30s under load.
Standalone passes do not resolve those timing cases. Keep them visible for the
next clean shuffled run; do not silently increase timeouts or waive failures.
The offline cache prepared at locked-cache remains applicable: package-lock hash
is still d29f887a385a0b1ac9c12a47e4a74b01a02ba238b1c35e5fad7bbc5681c4be82.
Existing pressure harness reads committed HEAD, excludes working changes and
copies only content-addressed cache into isolated state. Use after verified commit.
No source changed during the live full suite.
